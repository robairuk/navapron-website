"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __name = (target, value2) => __defProp(target, "name", { value: value2, configurable: true });
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // global-externals:@microsoft/msfs-sdk
  var require_msfs_sdk = __commonJS({
    "global-externals:@microsoft/msfs-sdk"(exports, module) {
      module.exports = msfssdk;
    }
  });

  // ../efb_api/dist/index.js
  var import_msfs_sdk = __toESM(require_msfs_sdk(), 1);
  var __defProp2 = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp2 = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = /* @__PURE__ */ __name((obj, key, value2) => key in obj ? __defProp2(obj, key, { enumerable: true, configurable: true, writable: true, value: value2 }) : obj[key] = value2, "__defNormalProp");
  var __spreadValues = /* @__PURE__ */ __name((a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp2.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  }, "__spreadValues");
  var __spreadProps = /* @__PURE__ */ __name((a, b) => __defProps(a, __getOwnPropDescs(b)), "__spreadProps");
  var AppBootMode = /* @__PURE__ */ ((AppBootMode2) => {
    AppBootMode2[AppBootMode2["COLD"] = 0] = "COLD";
    AppBootMode2[AppBootMode2["WARM"] = 1] = "WARM";
    AppBootMode2[AppBootMode2["HOT"] = 2] = "HOT";
    return AppBootMode2;
  })(AppBootMode || {});
  var AppSuspendMode = /* @__PURE__ */ ((AppSuspendMode2) => {
    AppSuspendMode2[AppSuspendMode2["SLEEP"] = 0] = "SLEEP";
    AppSuspendMode2[AppSuspendMode2["TERMINATE"] = 1] = "TERMINATE";
    return AppSuspendMode2;
  })(AppSuspendMode || {});
  var uid = 0;
  var _Container = class _Container {
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    constructor() {
      this._uid = uid++;
      this._registeredAppsPromises = [];
      this._installedApps = import_msfs_sdk.ArraySubject.create();
    }
    /**
     * Static singleton instance of Efb container
     * @internal
     */
    static get instance() {
      return window.EFB_API = _Container._instance = window.EFB_API || _Container._instance || new _Container();
    }
    /** @internal */
    apps() {
      return this._installedApps;
    }
    /** @internal */
    allAppsLoaded() {
      return this._registeredAppsPromises.length === this._installedApps.length;
    }
    /**
     * Method used by the OS to share the bus to apps
     * @internal
     */
    setBus(bus) {
      this.bus = bus;
      return this;
    }
    /**
     * Method used by the OS to share the units settings manager to the apps
     * @internal
     */
    setUnitsSettingManager(unitsSettingManager) {
      this.unitsSettingManager = unitsSettingManager;
      return this;
    }
    /**
     * Method used by the OS to share the settings manager to the apps
     * @internal
     */
    setEfbSettingManager(efbSettingsManager) {
      this.efbSettingsManager = efbSettingsManager;
      return this;
    }
    setOnboardingManager(onboardingManager) {
      this.onboardingManager = onboardingManager;
      return this;
    }
    /**
     * Method used by the OS to share the notification manager to the apps
     * @internal
     */
    setNotificationManager(notificationManager) {
      this.notificationManager = notificationManager;
      return this;
    }
    /**
     * Load stylesheet
     * @param uri
     * @returns Promise which is resolved when stylesheet is loaded or rejected if an error occur.
     */
    async loadCss(uri) {
      if (document.querySelector(`link[href*="${uri}"]`)) {
        return Promise.reject(`${uri} already loaded.`);
      }
      const linkTag = document.createElement("link");
      linkTag.rel = "stylesheet";
      linkTag.href = uri;
      document.head.append(linkTag);
      return new Promise((resolve, reject) => {
        linkTag.onload = () => resolve();
        linkTag.onerror = reject;
      });
    }
    /**
     * Load script file
     * @param uri
     * @returns Promise which is resolved when script is loaded or rejected if an error occur.
     */
    async loadJs(uri) {
      if (document.querySelector(`script[src*="${uri}"]`)) {
        return Promise.reject(`${uri} already loaded.`);
      }
      const scriptTag = document.createElement("script");
      scriptTag.type = "text/javascript";
      scriptTag.src = uri;
      document.head.append(scriptTag);
      return new Promise((resolve, reject) => {
        scriptTag.onload = () => resolve();
        scriptTag.onerror = reject;
      });
    }
    /**
     * Register an app in EFB
     * @template T - App registration options
     * @param app The app you wan't to register
     * @param options Options you'r app might need when installing
     * @returns EFB instance
     * @throws Throw an error if App install went wrong.
     */
    use(app, ...options) {
      var _a13;
      try {
        if (!this.bus) {
          throw new Error(`Bus has not been initialized yet.`);
        }
        const appInstance = app instanceof App ? app : new app();
        const installProps = {
          bus: this.bus,
          unitsSettingManager: this.unitsSettingManager,
          efbSettingsManager: this.efbSettingsManager,
          notificationManager: this.notificationManager,
          onboardingManager: this.onboardingManager,
          options: Object.keys(options).filter((key) => key !== "isCoreApp").reduce((acc, key) => {
            return Object.assign(acc, options[key]);
          }, {})
        };
        const appInstaller = appInstance._install.apply(appInstance, [installProps]);
        const name = appInstance.internalName;
        if (/\s/.test(name)) {
          throw new Error(`The App name can't have any whitespace character. "${name}"`);
        }
        this._registeredAppsPromises.push(
          appInstaller.then(() => {
            this._installedApps.insert(appInstance);
          })
        );
      } catch (e) {
        (_a13 = document.currentScript) == null ? void 0 : _a13.remove();
        console.error(`App can't be installed`, e);
        throw e;
      }
      return this;
    }
  };
  __name(_Container, "Container");
  var Container = _Container;
  var Efb = Container.instance;
  var EfbApiVersion = "1.0.3";
  var _App = class _App {
    constructor() {
      this._isInstalled = false;
      this._isReady = false;
      this._favoriteIndex = -1;
      this.available = import_msfs_sdk.Subject.create(true);
      this.BootMode = AppBootMode.COLD;
      this.SuspendMode = AppSuspendMode.SLEEP;
    }
    /**
     * @param props
     * @internal
     */
    async _install(props) {
      var _a13;
      if (this._isInstalled) {
        return Promise.reject("App already installed.");
      }
      this._isInstalled = true;
      this.bus = props.bus;
      this._unitsSettingsManager = props.unitsSettingManager;
      this._efbSettingsManager = props.efbSettingsManager;
      this._notificationManager = props.notificationManager;
      this._onboardingManager = props.onboardingManager;
      this._favoriteIndex = (_a13 = props.favoriteIndex) != null ? _a13 : -1;
      this.options = props.options;
      await this.install(props);
      this._isReady = true;
      Coherent.trigger("EFB_APP_INSTALLED", this.name, this.internalName, EfbApiVersion, this.getVersion());
      return Promise.resolve();
    }
    /**
     * Install hook
     * @param props
     */
    async install(props) {
      return Promise.resolve();
    }
    /** Boolean to check if app is loaded and installed. */
    get isReady() {
      return this._isReady;
    }
    /**
     * Internal app name
     * @defaultValue > Class's name (`this.constructor.name`)
     */
    get internalName() {
      return this.constructor.name;
    }
    /**
     * EFB units settings manager
     * @returns a unique unitsSettingsManager instance
     */
    get unitsSettingsManager() {
      const unitsSettingsManager = this._unitsSettingsManager;
      if (!unitsSettingsManager) {
        throw new Error("Units settings manager is not defined");
      }
      return unitsSettingsManager;
    }
    /**
     * EFB settings manager
     * @returns a unique efbSettingsManager instance
     */
    get efbSettingsManager() {
      const efbSettingsManager = this._efbSettingsManager;
      if (!efbSettingsManager) {
        throw new Error("EFB settings manager is not defined");
      }
      return efbSettingsManager;
    }
    /**
     * EFB notification manager
     * @returns a unique efbNotificationManager instance
     */
    get notificationManager() {
      const notificationManager = this._notificationManager;
      if (!notificationManager) {
        throw new Error("Notification manager is not defined");
      }
      return notificationManager;
    }
    /** Onboarding manager */
    get onboardingManager() {
      const onboardingManager = this._onboardingManager;
      if (!onboardingManager) {
        throw new Error("Onboarding manager is not defined");
      }
      return onboardingManager;
    }
    /**
     * Aircraft models list compatible with the App. If not defined, the App is compatible with all aircraft models.
     * example: ['Cabri G2', 'H125']
     * @returns a list of aircraft models compatible with the App or undefined
     */
    get compatibleAircraftModels() {
      return void 0;
    }
    /** @internal */
    get favoriteIndex() {
      return this._favoriteIndex;
    }
    /** @internal */
    set favoriteIndex(index2) {
      this._favoriteIndex = index2;
    }
    /**
     * @since 1.0.3
     * @returns True if the app is searchable (ie: app list)
     */
    getIsSearchable() {
      var _a13;
      return (_a13 = this.options.isSearchable) != null ? _a13 : true;
    }
    /**
     * @since 1.0.3
     * @returns True if the app can be added to favorites
     */
    getIsFavoritable() {
      var _a13;
      return (_a13 = this.options.isFavoritable) != null ? _a13 : true;
    }
    /**
     * @since 1.0.3
     * @returns Return app version
     */
    getVersion() {
      return "";
    }
  };
  __name(_App, "App");
  var App = _App;
  function isVNode(object) {
    return "instance" in object && "props" in object && "children" in object;
  }
  __name(isVNode, "isVNode");
  function toClassProp(classProp) {
    if (classProp === void 0) {
      return classProp;
    }
    if (Array.isArray(classProp)) {
      return toClassProp(classProp.join(" "));
    }
    if (typeof classProp !== "string") {
      return classProp;
    }
    return classProp.split(" ").reduce(function(stack, el) {
      return __spreadProps(__spreadValues({}, stack), { [el]: true });
    }, {});
  }
  __name(toClassProp, "toClassProp");
  function mergeClassProp(baseProp, ...args) {
    const mergedClassProp = Object.assign({}, toClassProp(baseProp));
    for (const arg of args) {
      Object.assign(mergedClassProp, toClassProp(arg));
    }
    return mergedClassProp;
  }
  __name(mergeClassProp, "mergeClassProp");
  function where(value2) {
    return (input) => value2 === input;
  }
  __name(where, "where");
  function toString() {
    return (input) => input.toString();
  }
  __name(toString, "toString");
  var __FlightPhaseManager = class __FlightPhaseManager {
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    constructor() {
      this._flightPhase = import_msfs_sdk.Subject.create(
        100
        /* UNKNOWN */
      );
      this.flightPhase = this._flightPhase;
      this.isFlightOver = this._flightPhase.map(where(
        11
        /* FLIGHT_OVER */
      ));
      this.onFlightPhaseStateChangedSubscription = null;
    }
    /**
     * Static singleton instance of the Flight Phase Manager
     * @internal
     */
    static get instance() {
      return window.FLIGHT_PHASE_MANAGER = __FlightPhaseManager._instance = window.FLIGHT_PHASE_MANAGER || __FlightPhaseManager._instance || new __FlightPhaseManager();
    }
    /**
     * The bus is set once at EFB initialization from efb_ui.tsx
     * @internal
     */
    setBus(bus) {
      var _a13;
      (_a13 = this.onFlightPhaseStateChangedSubscription) == null ? void 0 : _a13.destroy();
      this.onFlightPhaseStateChangedSubscription = bus.on("FlightPhaseChanged", (flightPhase) => {
        switch (flightPhase) {
          case "PREFLIGHT_RTC":
          case "PREFLIGHT":
          case "SKIP_TRANSITION_PREFLIGHT":
            this._flightPhase.set(
              0
              /* PREFLIGHT */
            );
            break;
          case "STARTUP":
            this._flightPhase.set(
              1
              /* STARTUP */
            );
            break;
          case "BEFORE_TAXI":
          case "TAXI":
          case "SKIP_TRANSITION_TAXI":
            this._flightPhase.set(
              3
              /* TAXI */
            );
            break;
          case "TAKEOFF":
            this._flightPhase.set(
              4
              /* TAKEOFF */
            );
            break;
          case "CLIMB":
            this._flightPhase.set(
              5
              /* CLIMB */
            );
            break;
          case "CRUISE":
          case "SKIP_TRANSITION_CRUISE":
            this._flightPhase.set(
              6
              /* CRUISE */
            );
            break;
          case "DESCENT":
            this._flightPhase.set(
              7
              /* DESCENT */
            );
            break;
          case "LANDING":
            this._flightPhase.set(
              8
              /* LANDING */
            );
            break;
          case "TAXITOGATE":
          case "SKIP_TRANSITION_TAXITOGATE":
            this._flightPhase.set(
              9
              /* TAXITOGATE */
            );
            break;
          case "SHUTDOWN":
            this._flightPhase.set(
              10
              /* SHUTDOWN */
            );
            break;
          case "RTC":
            break;
          case "MISSIONSUCCESS":
          case "MISSIONABORTED":
            this._flightPhase.set(
              11
              /* FLIGHT_OVER */
            );
            break;
          case "REACH BANNER APPROACH":
          case "HOOKBANNER":
          case "REACH PASS":
          case "PASS":
          case "CRUISEBACK":
          case "REACH DROP":
          case "DROP BANNER":
            break;
          case "WATERDROP":
            break;
          default:
            console.warn(`Received unknown flight phase '${flightPhase}'`);
            this._flightPhase.set(
              100
              /* UNKNOWN */
            );
        }
      });
    }
    /**
     * @description This function is used in order to verify if a given flight phase has been reached.
     * Always return true when the flight phase is unknown.
     * @param flightPhase The flight phase that has been reached or not
     * @returns A subscribable that returns whether the given flight phase has been reached
     */
    hasReachedFlightPhaseState(flightPhase) {
      return this.flightPhase.map(
        (currentFlightPhaseState) => currentFlightPhaseState >= flightPhase
      );
    }
  };
  __name(__FlightPhaseManager, "_FlightPhaseManager");
  var _FlightPhaseManager = __FlightPhaseManager;
  var FlightPhaseManager = _FlightPhaseManager.instance;
  var __GameModeManager = class __GameModeManager {
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    constructor() {
      this._gameMode = import_msfs_sdk.Subject.create(
        0
        /* UNKNOWN */
      );
      this.gameMode = this._gameMode;
      this.isCareer = this._gameMode.map(where(
        1
        /* CAREER */
      ));
      this.isChallenge = this._gameMode.map(where(
        2
        /* CHALLENGE */
      ));
      this.isDiscovery = this._gameMode.map(where(
        3
        /* DISCOVERY */
      ));
      this.isFreeflight = this._gameMode.map(where(
        4
        /* FREEFLIGHT */
      ));
      this.isInMenu = import_msfs_sdk.Subject.create(true);
      this.onGameModeChangedSubscription = null;
      this.onIsInMenuSubscription = null;
    }
    /**
     * Static singleton instance of the Game mode manager
     * @internal
     */
    static get instance() {
      return window.GAME_MODE_MANAGER = __GameModeManager._instance = window.GAME_MODE_MANAGER || __GameModeManager._instance || new __GameModeManager();
    }
    /**
     * The bus is set once at EFB initialization from efb_ui.tsx
     * @internal
     */
    setBus(bus) {
      var _a13, _b;
      (_a13 = this.onGameModeChangedSubscription) == null ? void 0 : _a13.destroy();
      (_b = this.onIsInMenuSubscription) == null ? void 0 : _b.destroy();
      this.onGameModeChangedSubscription = bus.on("GameModeChanged", (gameMode) => {
        switch (gameMode) {
          case "":
            this._gameMode.set(
              0
              /* UNKNOWN */
            );
            break;
          case "CAREER GAMEMODE":
            this._gameMode.set(
              1
              /* CAREER */
            );
            break;
          case "CHALLENGE GAMEMODE":
            this._gameMode.set(
              2
              /* CHALLENGE */
            );
            break;
          case "DISCOVERY GAMEMODE":
            this._gameMode.set(
              3
              /* DISCOVERY */
            );
            break;
          case "FREEFLIGHT GAMEMODE":
            this._gameMode.set(
              4
              /* FREEFLIGHT */
            );
            break;
          default:
            console.error(`Unknown game mode '${gameMode}'`);
            this._gameMode.set(
              0
              /* UNKNOWN */
            );
        }
      });
      this.onIsInMenuSubscription = bus.on("IsInMenuUpdate", (isInMenu) => this.isInMenu.set(isInMenu));
    }
  };
  __name(__GameModeManager, "_GameModeManager");
  var _GameModeManager = __GameModeManager;
  var GameModeManager = _GameModeManager.instance;
  Blob.prototype.arrayBuffer = function() {
    return new Promise((resolve, reject) => {
      const fileReader = new FileReader();
      fileReader.onload = function(event) {
        var _a13;
        const arrayBuffer = (_a13 = event.target) == null ? void 0 : _a13.result;
        if (typeof arrayBuffer === "string" || arrayBuffer === null || arrayBuffer === void 0) {
          reject("ArrayBuffer is null");
          return;
        }
        resolve(arrayBuffer);
      };
      fileReader.readAsArrayBuffer(this);
      fileReader.result;
    });
  };
  var uint8 = new Uint8Array(4);
  var uint32 = new Uint32Array(uint8.buffer);
  function isPromise(value2) {
    return value2 instanceof Promise;
  }
  __name(isPromise, "isPromise");
  function toPromise(value2) {
    return isPromise(value2) ? value2 : Promise.resolve(value2);
  }
  __name(toPromise, "toPromise");
  function checkUserSetting(setting, type) {
    if (!Object.values(type).includes(setting.get())) {
      setting.resetToDefault();
    }
  }
  __name(checkUserSetting, "checkUserSetting");
  var basicFormatter = import_msfs_sdk.NumberFormatter.create({
    maxDigits: 0,
    forceDecimalZeroes: false,
    nanString: "-"
  });
  var _a;
  var _UnitFormatter = (_a = class {
    /**
     * Creates a function which formats measurement units to strings representing their abbreviated names.
     * @param defaultString The string to output when the input unit cannot be formatted. Defaults to the empty string.
     * @param charCase The case to enforce on the output string. Defaults to `'normal'`.
     * @returns A function which formats measurement units to strings representing their abbreviated names.
     */
    static create(defaultString = "", charCase = "normal") {
      var _a13, _b;
      switch (charCase) {
        case "upper":
          (_a13 = _a.UNIT_TEXT_UPPER) != null ? _a13 : _a.UNIT_TEXT_UPPER = _a.createUpperCase();
          return (unit) => {
            var _a22, _b2;
            return (
              // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
              (_b2 = (_a22 = _a.UNIT_TEXT_UPPER[unit.family]) == null ? void 0 : _a22[unit.name]) != null ? _b2 : defaultString
            );
          };
        case "lower":
          (_b = _a.UNIT_TEXT_LOWER) != null ? _b : _a.UNIT_TEXT_LOWER = _a.createLowerCase();
          return (unit) => {
            var _a22, _b2;
            return (
              // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
              (_b2 = (_a22 = _a.UNIT_TEXT_LOWER[unit.family]) == null ? void 0 : _a22[unit.name]) != null ? _b2 : defaultString
            );
          };
        default:
          return (unit) => {
            var _a22, _b2;
            return (_b2 = (_a22 = _a.UNIT_TEXT[unit.family]) == null ? void 0 : _a22[unit.name]) != null ? _b2 : defaultString;
          };
      }
    }
    /**
     * Creates a record of lowercase unit abbreviated names.
     * @returns A record of lowercase unit abbreviated names.
     */
    static createLowerCase() {
      const lower = {};
      for (const family in _a.UNIT_TEXT) {
        const familyText = _a.UNIT_TEXT[family];
        lower[family] = {};
        for (const unit in familyText) {
          lower[family][unit] = familyText[unit].toLowerCase();
        }
      }
      return lower;
    }
    /**
     * Creates a record of uppercase unit abbreviated names.
     * @returns A record of uppercase unit abbreviated names.
     */
    static createUpperCase() {
      const upper = {};
      for (const family in _a.UNIT_TEXT) {
        const familyText = _a.UNIT_TEXT[family];
        upper[family] = {};
        for (const unit in familyText) {
          upper[family][unit] = familyText[unit].toUpperCase();
        }
      }
      return upper;
    }
    /**
     * Gets a mapping of unit family and name to text used by UnitFormatter to format units. The returned object maps
     * unit families to objects that map unit names within each family to formatted text.
     * @returns A mapping of unit family and name to text used by UnitFormatter to format units.
     */
    static getUnitTextMap() {
      return _a.UNIT_TEXT;
    }
  }, __name(_a, "_UnitFormatter"), _a);
  _UnitFormatter.UNIT_TEXT = {
    [import_msfs_sdk.UnitFamily.Distance]: {
      [import_msfs_sdk.UnitType.METER.name]: "M",
      [import_msfs_sdk.UnitType.FOOT.name]: "FT",
      [import_msfs_sdk.UnitType.KILOMETER.name]: "KM",
      [import_msfs_sdk.UnitType.NMILE.name]: "NM",
      [import_msfs_sdk.UnitType.MILE.name]: "SM"
    },
    [import_msfs_sdk.UnitFamily.Angle]: {
      [import_msfs_sdk.UnitType.DEGREE.name]: "\xB0",
      [import_msfs_sdk.UnitType.RADIAN.name]: "rad"
    },
    [import_msfs_sdk.UnitFamily.Duration]: {
      [import_msfs_sdk.UnitType.SECOND.name]: "SEC",
      [import_msfs_sdk.UnitType.MINUTE.name]: "MIN",
      [import_msfs_sdk.UnitType.HOUR.name]: "HR"
    },
    [import_msfs_sdk.UnitFamily.Weight]: {
      [import_msfs_sdk.UnitType.KILOGRAM.name]: "KG",
      [import_msfs_sdk.UnitType.POUND.name]: "LBS",
      [import_msfs_sdk.UnitType.LITER_FUEL.name]: "LT",
      [import_msfs_sdk.UnitType.GALLON_FUEL.name]: "GAL",
      [import_msfs_sdk.UnitType.IMP_GALLON_FUEL.name]: "IG"
    },
    [import_msfs_sdk.UnitFamily.Volume]: {
      [import_msfs_sdk.UnitType.LITER.name]: "L",
      [import_msfs_sdk.UnitType.GALLON.name]: "GAL"
    },
    [import_msfs_sdk.UnitFamily.Pressure]: {
      [import_msfs_sdk.UnitType.HPA.name]: "HPA",
      [import_msfs_sdk.UnitType.IN_HG.name]: "IN"
    },
    [import_msfs_sdk.UnitFamily.Temperature]: {
      [import_msfs_sdk.UnitType.CELSIUS.name]: "\xB0C",
      [import_msfs_sdk.UnitType.FAHRENHEIT.name]: "\xB0F"
    },
    [import_msfs_sdk.UnitFamily.TemperatureDelta]: {
      [import_msfs_sdk.UnitType.DELTA_CELSIUS.name]: "\xB0C",
      [import_msfs_sdk.UnitType.DELTA_FAHRENHEIT.name]: "\xB0F"
    },
    [import_msfs_sdk.UnitFamily.Speed]: {
      [import_msfs_sdk.UnitType.KNOT.name]: "KT",
      [import_msfs_sdk.UnitType.KPH.name]: "KM/H",
      [import_msfs_sdk.UnitType.MPM.name]: "MPM",
      [import_msfs_sdk.UnitType.FPM.name]: "FPM"
    },
    [import_msfs_sdk.UnitFamily.WeightFlux]: {
      [import_msfs_sdk.UnitType.KGH.name]: "KG/HR",
      [import_msfs_sdk.UnitType.PPH.name]: "LB/HR",
      [import_msfs_sdk.UnitType.LPH_FUEL.name]: "LT/HR",
      [import_msfs_sdk.UnitType.GPH_FUEL.name]: "GAL/HR",
      [import_msfs_sdk.UnitType.IGPH_FUEL.name]: "IG/HR"
    }
  };
  var UnitFormatter = _UnitFormatter;
  function value(arg) {
    return typeof arg === "function" ? arg() : arg;
  }
  __name(value, "value");
  var _AppContainer = class _AppContainer extends import_msfs_sdk.DisplayComponent {
    constructor() {
      super(...arguments);
      this.appMainRef = import_msfs_sdk.FSComponent.createRef();
      this.appStackRef = import_msfs_sdk.FSComponent.createRef();
    }
    onAfterRender(node) {
      super.onAfterRender(node);
      this.props.appViewService.onAppContainerRendered(this.appStackRef.instance);
    }
    render() {
      return /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent("div", { ref: this.appMainRef, class: `app-container` }, /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent(DefaultAppViewStackContainer, { ref: this.appStackRef }));
    }
  };
  __name(_AppContainer, "AppContainer");
  var AppContainer = _AppContainer;
  var _DefaultAppViewStackContainer = class _DefaultAppViewStackContainer extends import_msfs_sdk.DisplayComponent {
    constructor() {
      super(...arguments);
      this.rootRef = import_msfs_sdk.FSComponent.createRef();
    }
    renderView(view) {
      import_msfs_sdk.FSComponent.render(view, this.rootRef.instance);
    }
    render() {
      return /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent("div", { ref: this.rootRef, class: mergeClassProp("app-view-stack", this.props.class) });
    }
  };
  __name(_DefaultAppViewStackContainer, "DefaultAppViewStackContainer");
  var DefaultAppViewStackContainer = _DefaultAppViewStackContainer;
  function Memoize(args) {
    let hashFunction;
    let duration;
    let tags;
    {
      hashFunction = args;
    }
    return (target, propertyKey, descriptor) => {
      if (descriptor.value != null) {
        descriptor.value = getNewFunction(descriptor.value, hashFunction, duration, tags);
      } else if (descriptor.get != null) {
        descriptor.get = getNewFunction(descriptor.get, hashFunction, duration, tags);
      } else {
        throw "Only put a Memoize() decorator on a method or get accessor.";
      }
    };
  }
  __name(Memoize, "Memoize");
  var clearCacheTagsMap = /* @__PURE__ */ new Map();
  function getNewFunction(originalMethod, hashFunction, duration = 0, tags) {
    const propMapName = Symbol(`__memoized_map__`);
    return function(...args) {
      let returnedValue;
      if (!this.hasOwnProperty(propMapName)) {
        Object.defineProperty(this, propMapName, {
          configurable: false,
          enumerable: false,
          writable: false,
          value: /* @__PURE__ */ new Map()
        });
      }
      let myMap = this[propMapName];
      if (Array.isArray(tags)) {
        for (const tag of tags) {
          if (clearCacheTagsMap.has(tag)) {
            clearCacheTagsMap.get(tag).push(myMap);
          } else {
            clearCacheTagsMap.set(tag, [myMap]);
          }
        }
      }
      if (hashFunction || args.length > 0 || duration > 0) {
        let hashKey;
        if (hashFunction === true) {
          hashKey = args.map((a) => a.toString()).join("!");
        } else if (hashFunction) {
          hashKey = hashFunction.apply(this, args);
        } else {
          hashKey = args[0];
        }
        const timestampKey = `${hashKey}__timestamp`;
        let isExpired = false;
        if (duration > 0) {
          if (!myMap.has(timestampKey)) {
            isExpired = true;
          } else {
            let timestamp = myMap.get(timestampKey);
            isExpired = Date.now() - timestamp > duration;
          }
        }
        if (myMap.has(hashKey) && !isExpired) {
          returnedValue = myMap.get(hashKey);
        } else {
          returnedValue = originalMethod.apply(this, args);
          myMap.set(hashKey, returnedValue);
          if (duration > 0) {
            myMap.set(timestampKey, Date.now());
          }
        }
      } else {
        const hashKey = this;
        if (myMap.has(hashKey)) {
          returnedValue = myMap.get(hashKey);
        } else {
          returnedValue = originalMethod.apply(this, args);
          myMap.set(hashKey, returnedValue);
        }
      }
      return returnedValue;
    };
  }
  __name(getNewFunction, "getNewFunction");
  var GamepadEvents = /* @__PURE__ */ ((GamepadEvents2) => {
    GamepadEvents2["JOYSTICK_LEFT_X_AXIS"] = "JOYSTICK_LEFT_X_AXIS";
    GamepadEvents2["JOYSTICK_LEFT_Y_AXIS"] = "JOYSTICK_LEFT_Y_AXIS";
    GamepadEvents2["JOYSTICK_RIGHT_X_AXIS"] = "JOYSTICK_RIGHT_X_AXIS";
    GamepadEvents2["JOYSTICK_RIGHT_Y_AXIS"] = "JOYSTICK_RIGH_Y_AXIS";
    GamepadEvents2["BUTTON_A"] = "BUTTON_A";
    GamepadEvents2["BUTTON_B"] = "BUTTON_B";
    GamepadEvents2["BUTTON_Y"] = "BUTTON_Y";
    GamepadEvents2["BUTTON_X"] = "BUTTON_X";
    GamepadEvents2["JOYDIR_LEFT"] = "JOYDIR_LEFT";
    GamepadEvents2["JOYDIR_RIGHT"] = "JOYDIR_RIGHT";
    GamepadEvents2["JOYDIR_UP"] = "JOYDIR_UP";
    GamepadEvents2["JOYDIR_DOWN"] = "JOYDIR_DOWN";
    return GamepadEvents2;
  })(GamepadEvents || {});
  var InputAction = /* @__PURE__ */ ((InputAction2) => {
    InputAction2[InputAction2["SECONDARY"] = 0] = "SECONDARY";
    InputAction2[InputAction2["TERTIARY"] = 1] = "TERTIARY";
    InputAction2[InputAction2["PREV"] = 2] = "PREV";
    InputAction2[InputAction2["NEXT"] = 3] = "NEXT";
    InputAction2[InputAction2["PREV_SUB"] = 4] = "PREV_SUB";
    InputAction2[InputAction2["NEXT_SUB"] = 5] = "NEXT_SUB";
    InputAction2[InputAction2["ZOOM_OUT"] = 6] = "ZOOM_OUT";
    InputAction2[InputAction2["ZOOM_IN"] = 7] = "ZOOM_IN";
    InputAction2[InputAction2["SCROLL_UP"] = 8] = "SCROLL_UP";
    InputAction2[InputAction2["SCROLL_RIGHT"] = 9] = "SCROLL_RIGHT";
    InputAction2[InputAction2["SCROLL_DOWN"] = 10] = "SCROLL_DOWN";
    InputAction2[InputAction2["SCROLL_LEFT"] = 11] = "SCROLL_LEFT";
    return InputAction2;
  })(InputAction || {});
  var InputActions = {
    [
      0
      /* SECONDARY */
    ]: "KEY_EFB_SECONDARY",
    [
      1
      /* TERTIARY */
    ]: "KEY_EFB_TERTIARY",
    [
      2
      /* PREV */
    ]: "KEY_EFB_NAV_TABS_PREV",
    [
      3
      /* NEXT */
    ]: "KEY_EFB_NAV_TABS_NEXT",
    [
      4
      /* PREV_SUB */
    ]: "KEY_EFB_ZOOM_OUT",
    [
      5
      /* NEXT_SUB */
    ]: "KEY_EFB_ZOOM_IN",
    [
      6
      /* ZOOM_OUT */
    ]: "KEY_EFB_ZOOM_OUT",
    [
      7
      /* ZOOM_IN */
    ]: "KEY_EFB_ZOOM_IN",
    [
      8
      /* SCROLL_UP */
    ]: "KEY_EFB_SCROLL_UP",
    [
      9
      /* SCROLL_RIGHT */
    ]: "KEY_EFB_SCROLL_RIGHT",
    [
      10
      /* SCROLL_DOWN */
    ]: "KEY_EFB_SCROLL_DOWN",
    [
      11
      /* SCROLL_LEFT */
    ]: "KEY_EFB_SCROLL_LEFT"
  };
  var InternalInputAction = /* @__PURE__ */ ((InternalInputAction2) => {
    InternalInputAction2[InternalInputAction2["VALID"] = 0] = "VALID";
    InternalInputAction2[InternalInputAction2["BACK"] = 1] = "BACK";
    InternalInputAction2[InternalInputAction2["SECONDARY"] = 2] = "SECONDARY";
    InternalInputAction2[InternalInputAction2["TERTIARY"] = 3] = "TERTIARY";
    InternalInputAction2[InternalInputAction2["PREV_TAB"] = 4] = "PREV_TAB";
    InternalInputAction2[InternalInputAction2["NEXT_TAB"] = 5] = "NEXT_TAB";
    InternalInputAction2[InternalInputAction2["ZOOM_OUT"] = 6] = "ZOOM_OUT";
    InternalInputAction2[InternalInputAction2["ZOOM_IN"] = 7] = "ZOOM_IN";
    InternalInputAction2[InternalInputAction2["UP"] = 8] = "UP";
    InternalInputAction2[InternalInputAction2["RIGHT"] = 9] = "RIGHT";
    InternalInputAction2[InternalInputAction2["DOWN"] = 10] = "DOWN";
    InternalInputAction2[InternalInputAction2["LEFT"] = 11] = "LEFT";
    InternalInputAction2[InternalInputAction2["PREV_APP"] = 12] = "PREV_APP";
    InternalInputAction2[InternalInputAction2["NEXT_APP"] = 13] = "NEXT_APP";
    InternalInputAction2[InternalInputAction2["OPEN_NOTIFICATION_MENU"] = 14] = "OPEN_NOTIFICATION_MENU";
    InternalInputAction2[InternalInputAction2["SCROLL_UP"] = 15] = "SCROLL_UP";
    InternalInputAction2[InternalInputAction2["SCROLL_RIGHT"] = 16] = "SCROLL_RIGHT";
    InternalInputAction2[InternalInputAction2["SCROLL_DOWN"] = 17] = "SCROLL_DOWN";
    InternalInputAction2[InternalInputAction2["SCROLL_LEFT"] = 18] = "SCROLL_LEFT";
    InternalInputAction2[InternalInputAction2["TEXTBOX_VALID"] = 19] = "TEXTBOX_VALID";
    InternalInputAction2[InternalInputAction2["TEXTBOX_UP"] = 20] = "TEXTBOX_UP";
    InternalInputAction2[InternalInputAction2["TEXTBOX_RIGHT"] = 21] = "TEXTBOX_RIGHT";
    InternalInputAction2[InternalInputAction2["TEXTBOX_DOWN"] = 22] = "TEXTBOX_DOWN";
    InternalInputAction2[InternalInputAction2["TEXTBOX_LEFT"] = 23] = "TEXTBOX_LEFT";
    return InternalInputAction2;
  })(InternalInputAction || {});
  var InternalInputActions = {
    [
      0
      /* VALID */
    ]: "KEY_EFB_VALID",
    [
      1
      /* BACK */
    ]: "KEY_EFB_BACK",
    [
      2
      /* SECONDARY */
    ]: "KEY_EFB_SECONDARY",
    [
      3
      /* TERTIARY */
    ]: "KEY_EFB_TERTIARY",
    [
      4
      /* PREV_TAB */
    ]: "KEY_EFB_NAV_TABS_PREV",
    [
      5
      /* NEXT_TAB */
    ]: "KEY_EFB_NAV_TABS_NEXT",
    [
      6
      /* ZOOM_OUT */
    ]: "KEY_EFB_ZOOM_OUT",
    [
      7
      /* ZOOM_IN */
    ]: "KEY_EFB_ZOOM_IN",
    [
      8
      /* UP */
    ]: "KEY_EFB_UP",
    [
      9
      /* RIGHT */
    ]: "KEY_EFB_NAV_APP_NEXT",
    [
      10
      /* DOWN */
    ]: "KEY_EFB_DOWN",
    [
      11
      /* LEFT */
    ]: "KEY_EFB_NAV_APP_PREV",
    [
      12
      /* PREV_APP */
    ]: "KEY_EFB_NAV_APP_PREV",
    [
      13
      /* NEXT_APP */
    ]: "KEY_EFB_NAV_APP_NEXT",
    [
      14
      /* OPEN_NOTIFICATION_MENU */
    ]: "KEY_EFB_NOTIFICATIONS_MENU",
    [
      15
      /* SCROLL_UP */
    ]: "KEY_EFB_SCROLL_UP",
    [
      16
      /* SCROLL_RIGHT */
    ]: "KEY_EFB_SCROLL_RIGHT",
    [
      17
      /* SCROLL_DOWN */
    ]: "KEY_EFB_SCROLL_DOWN",
    [
      18
      /* SCROLL_LEFT */
    ]: "KEY_EFB_SCROLL_LEFT",
    [
      19
      /* TEXTBOX_VALID */
    ]: "KEY_EFB_VALID_TEXT",
    [
      20
      /* TEXTBOX_UP */
    ]: "KEY_EFB_TEXTBOX_UP",
    [
      21
      /* TEXTBOX_RIGHT */
    ]: "KEY_EFB_TEXTBOX_RIGHT",
    [
      22
      /* TEXTBOX_DOWN */
    ]: "KEY_EFB_TEXTBOX_DOWN",
    [
      23
      /* TEXTBOX_LEFT */
    ]: "KEY_EFB_TEXTBOX_LEFT"
  };
  var _a2;
  var _InputsListener = (_a2 = class extends ViewListener.ViewListener {
    /**
     * @deprecated
     * @param context The input context.
     * @param action The input action.
     * @param callback The callback that will be called when the input is triggered.
     * @returns The input watcher ID.
     */
    static addInputChangeCallback(context, action, callback) {
      const idWatcher = "InputWatcher_" + context + "_" + action + "_" + import_msfs_sdk.UUID.GenerateUuid();
      _a2.inputsListener.trigger("ADD_INPUT_WATCHER", idWatcher, context, action);
      _a2.inputsListener.on("InputListener.InputChange", (id, down) => {
        if (id === idWatcher) {
          callback(down);
        }
      });
      return idWatcher;
    }
    /**
     * @deprecated
     * @param id The event ID.
     */
    static removeInputChangeCallback(id) {
      _a2.inputsListener.trigger("REMOVE_INPUT_WATCHER", id);
    }
  }, __name(_a2, "_InputsListener"), _a2);
  _InputsListener.isLoaded = import_msfs_sdk.Subject.create(false);
  _InputsListener.inputsListener = RegisterViewListener(
    "JS_LISTENER_INPUTS",
    () => _InputsListener.isLoaded.set(true)
  );
  var _InputStackListener = class _InputStackListener {
    constructor() {
      this._isReady = import_msfs_sdk.Subject.create(false);
      this.isReady = this._isReady;
      this.inputActionMap = /* @__PURE__ */ new Map();
      this.inputStackListener = RegisterViewListener(
        "JS_LISTENER_INPUT_STACK",
        () => this._isReady.set(true)
      );
      this.onInputTriggeredCallback = this._onInputTriggeredCallback.bind(this);
      this.inputStackListener.on("ON_INPUT_TRIGGERED", this.onInputTriggeredCallback);
    }
    _onInputTriggeredCallback(task, value2, _activeId, uuid) {
      var _a13;
      (_a13 = this.inputActionMap.get(uuid)) == null ? void 0 : _a13(task, value2);
    }
    /**
     * Add an action that will be executed when the given input is triggered.
     * @param input The input that, when triggered, will execute the action.
     * @param callback The action callback that will be called when the input is triggered.
     * @param inputType The trigger type of the input between 'pressed', 'released' and 'axis'. Default to 'released'.
     * @param context The context which the input will be applied to. Default to 'DEFAULT'.
     * @returns A callback that has to be called when the input action is not needed anymore.
     */
    addInputAction(input, callback, inputType = "released", context = "DEFAULT") {
      const uuid = import_msfs_sdk.UUID.GenerateUuid().toUpperCase();
      const formattedUuid = `{${uuid}}`;
      this.inputActionMap.set(uuid, (task, value2) => {
        const isConsumed = callback(value2);
        this.inputStackListener.call(`RESOLVE_${task}`, isConsumed);
      });
      this.inputStackListener.trigger("ADD_INPUT_ACTION", input, formattedUuid, "", inputType, context);
      return () => {
        this.inputStackListener.trigger("REMOVE_INPUT_ACTION", input, formattedUuid);
        this.inputActionMap.delete(uuid);
      };
    }
  };
  __name(_InputStackListener, "InputStackListener");
  var InputStackListener = _InputStackListener;
  var _InternalInputManager = class _InternalInputManager {
    constructor(inputActionRecord) {
      this.inputActionRecord = inputActionRecord;
      this.defaultInputType = "released";
      this.defaultScrollAxis = "all";
      this.defaultScrollSpeedFactor = 10;
      this.inputStackListener = new InputStackListener();
    }
    //#region Add input action
    /**
     * Add an action that will be executed when the given input is triggered.
     * @param inputAction The input that, when triggered, will execute the action.
     * @param callback The action callback that will be called when the input is triggered.
     * @param options The optional input action options.
     * @returns A callback that has to be called when the input action is not needed anymore.
     */
    addInputAction(inputAction, callback, options) {
      var _a13;
      return this.inputStackListener.addInputAction(
        this.inputActionRecord[inputAction],
        callback,
        (_a13 = options == null ? void 0 : options.inputType) != null ? _a13 : this.defaultInputType
      );
    }
    //#endregion
    //#region On hover
    /**
     * Add an action that will be executed when the given input is triggered on hover of the given HTML element.
     * @param element The HTML element that will allow the action to be executed when hovered on.
     * @param inputAction The input that, when triggered, will execute the action.
     * @param callback The action callback that will be called when the input is triggered.
     * @param options The optional input action options.
     * @returns A callback that has to be called when the input action is not needed anymore.
     */
    addInputActionOnHover(element, inputAction, callback, options) {
      let inputActionDestructor = null;
      const mouseEnterCallback = /* @__PURE__ */ __name(() => {
        var _a13;
        if (inputActionDestructor) {
          inputActionDestructor();
        }
        inputActionDestructor = this.inputStackListener.addInputAction(
          this.inputActionRecord[inputAction],
          callback,
          (_a13 = options == null ? void 0 : options.inputType) != null ? _a13 : this.defaultInputType
        );
      }, "mouseEnterCallback");
      const mouseLeaveCallback = /* @__PURE__ */ __name(() => {
        inputActionDestructor == null ? void 0 : inputActionDestructor();
      }, "mouseLeaveCallback");
      element.addEventListener("mouseenter", mouseEnterCallback);
      element.addEventListener("mouseleave", mouseLeaveCallback);
      return () => {
        element.removeEventListener("mouseenter", mouseEnterCallback);
        element.removeEventListener("mouseleave", mouseLeaveCallback);
        inputActionDestructor == null ? void 0 : inputActionDestructor();
      };
    }
    //#endregion
  };
  __name(_InternalInputManager, "InternalInputManager");
  var InternalInputManager = _InternalInputManager;
  var _InputManager = class _InputManager extends InternalInputManager {
    constructor() {
      super(InputActions);
    }
    //#region Scroll
    /**
     * Add scroll input actions using the gamepad joystick for a given HTML element.
     * @param element The scrollable HTML element.
     * @param options The optional scroll input action options.
     * @returns A callback that has to be called when the scroll input action is not needed anymore.
     */
    addScrollInputAction(element, options) {
      var _a13;
      const scrollSpeed = options == null ? void 0 : options.scrollSpeed;
      let predicate;
      if (scrollSpeed === void 0) {
        predicate = /* @__PURE__ */ __name((axis) => this.computeScrollSpeedFactor(axis, this.defaultScrollSpeedFactor), "predicate");
      } else if (typeof scrollSpeed === "number") {
        predicate = /* @__PURE__ */ __name((axis) => this.computeScrollSpeedFactor(axis, scrollSpeed), "predicate");
      } else {
        predicate = scrollSpeed;
      }
      switch ((_a13 = options == null ? void 0 : options.scrollAxis) != null ? _a13 : this.defaultScrollAxis) {
        case "vertical":
        case "y":
          return this.setupVerticalScroll(element, predicate);
        case "horizontal":
        case "x":
          return this.setupHorizontalScroll(element, predicate);
        default: {
          const verticalScrollDestructor = this.setupVerticalScroll(element, predicate);
          const horizontalScrollDestructor = this.setupHorizontalScroll(element, predicate);
          return () => {
            verticalScrollDestructor();
            horizontalScrollDestructor();
          };
        }
      }
    }
    setupVerticalScroll(element, predicate) {
      const scrollUpInputActionDestructor = this.addInputActionOnHover(
        element,
        InputAction.SCROLL_UP,
        (axisValue) => {
          if (axisValue < 0) {
            return false;
          }
          element.scroll({
            top: element.scrollTop - predicate(axisValue)
          });
          return true;
        },
        { inputType: "axis" }
      );
      const scrollDownInputActionDestructor = this.addInputActionOnHover(
        element,
        InputAction.SCROLL_DOWN,
        (axisValue) => {
          if (axisValue < 0) {
            return false;
          }
          element.scroll({
            top: element.scrollTop + predicate(axisValue)
          });
          return true;
        },
        { inputType: "axis" }
      );
      return () => {
        scrollUpInputActionDestructor();
        scrollDownInputActionDestructor();
      };
    }
    setupHorizontalScroll(element, predicate) {
      const scrollLeftInputActionDestructor = this.addInputActionOnHover(
        element,
        InputAction.SCROLL_LEFT,
        (axisValue) => {
          if (axisValue < 0) {
            return false;
          }
          element.scroll({
            left: element.scrollLeft - predicate(axisValue)
          });
          return true;
        },
        { inputType: "axis" }
      );
      const scrollRightInputActionDestructor = this.addInputActionOnHover(
        element,
        InputAction.SCROLL_RIGHT,
        (axisValue) => {
          if (axisValue < 0) {
            return false;
          }
          element.scroll({
            left: element.scrollLeft + predicate(axisValue)
          });
          return true;
        },
        { inputType: "axis" }
      );
      return () => {
        scrollLeftInputActionDestructor();
        scrollRightInputActionDestructor();
      };
    }
    computeScrollSpeedFactor(axisValue, factor) {
      return axisValue * axisValue * factor;
    }
    //#endregion
  };
  __name(_InputManager, "InputManager");
  var InputManager = _InputManager;
  var _a3;
  var _GamepadUiComponent = (_a3 = class extends import_msfs_sdk.DisplayComponent {
    constructor() {
      var _a13, _b;
      super(...arguments);
      this.classSubscriptions = [];
      this.gamepadUiComponentRef = import_msfs_sdk.FSComponent.createRef();
      this.inputManager = new InputManager();
      this.areGamepadInputsEnabled = import_msfs_sdk.Subject.create(false);
      this._nextHandler = import_msfs_sdk.Subject.create(void 0);
      this.nextHandler = this._nextHandler;
      this.disabled = import_msfs_sdk.SubscribableUtils.toSubscribable((_a13 = this.props.disabled) != null ? _a13 : false, true);
      this.visible = import_msfs_sdk.SubscribableUtils.toSubscribable((_b = this.props.visible) != null ? _b : true, true);
      this.componentClickListener = this.handleComponentClick.bind(this);
    }
    setNextGamepadEventHandler(ref) {
      this._nextHandler.set(ref);
    }
    deletePreviousGamepadEventHandler() {
      throw new Error("Method not implemented.");
    }
    handleGamepadEvent(gamepadEvent) {
      console.log(`Received ${gamepadEvent} in handleMoveEvent`);
    }
    onAfterRender(node) {
      super.onAfterRender(node);
      const gamepadUiComponentInstance = this.gamepadUiComponentRef.getOrDefault();
      if (gamepadUiComponentInstance === null) {
        return;
      }
      const classes = mergeClassProp(this.props.class);
      Object.keys(classes).forEach((className) => {
        const subscribable = import_msfs_sdk.SubscribableUtils.toSubscribable(classes[className], true);
        this.classSubscriptions.push(
          subscribable.sub((value2) => {
            gamepadUiComponentInstance.classList.toggle(className, value2);
          }, true)
        );
      });
      this.isVisibleSubscription = this.visible.sub((isVisible) => {
        gamepadUiComponentInstance.hidden = !isVisible;
      }, true);
      if (import_msfs_sdk.SubscribableUtils.isSubscribable(this.props.disabled)) {
        this.isDisabledSubscription = this.props.disabled.sub((disabled) => {
          disabled ? this.disable() : this.enable();
        }, true);
      } else {
        this.props.disabled ? this.disable() : this.enable();
      }
      window.addEventListener("click", this.componentClickListener);
      if (this.props.onboardingStepId !== void 0) {
        gamepadUiComponentInstance.setAttribute("id", this.props.onboardingStepId);
      }
    }
    handleComponentClick(e) {
      if (!this.gamepadUiComponentRef.instance.contains(e.target)) {
        this.onClickOutOfComponent(e);
      }
    }
    onButtonAPressed() {
      if (this.props.onButtonAPressed !== void 0) {
        this.props.onButtonAPressed();
      }
    }
    onButtonBPressed() {
      if (this.props.onButtonBPressed !== void 0) {
        this.props.onButtonBPressed();
      }
    }
    onClickOutOfComponent(_e) {
      return;
    }
    enableGamepadInputs() {
      if (this.areGamepadInputsEnabled.get()) {
        console.warn("Trying to enable gamepad inputs that are already enabled. Operation cancelled.");
        return;
      }
      this.areGamepadInputsEnabled.set(true);
    }
    disableGamepadInputs() {
      this.areGamepadInputsEnabled.set(false);
    }
    enable() {
      this.gamepadUiComponentRef.instance.removeAttribute("disabled");
    }
    disable() {
      this.gamepadUiComponentRef.instance.setAttribute("disabled", "");
    }
    show() {
      this.gamepadUiComponentRef.instance.style.visibility = "visible";
    }
    hide() {
      this.gamepadUiComponentRef.instance.style.visibility = "hidden";
    }
    toggleFocus(value2) {
      if (value2 !== void 0) {
        if (value2 === true) {
          this.gamepadUiComponentRef.instance.classList.add(_a3.FOCUS_CLASS);
        } else {
          this.gamepadUiComponentRef.instance.classList.remove(_a3.FOCUS_CLASS);
        }
        return;
      }
      this.gamepadUiComponentRef.instance.classList.toggle(_a3.FOCUS_CLASS);
    }
    getComponentRect() {
      return this.gamepadUiComponentRef.instance.getBoundingClientRect();
    }
    destroy() {
      var _a13, _b;
      this.classSubscriptions.forEach((subscription) => subscription.destroy());
      (_a13 = this.isVisibleSubscription) == null ? void 0 : _a13.destroy();
      (_b = this.isDisabledSubscription) == null ? void 0 : _b.destroy();
      window.removeEventListener("click", this.componentClickListener);
      super.destroy();
    }
  }, __name(_a3, "_GamepadUiComponent"), _a3);
  _GamepadUiComponent.FOCUS_CLASS = "focus";
  var GamepadUiComponent = _GamepadUiComponent;
  var _GamepadUiParser = class _GamepadUiParser {
    constructor() {
      this.gamepadUiViewVNode = null;
    }
    /** On veut focus le premier élément */
    bindVNodeReference(gamepadUiViewVNode) {
      this.gamepadUiViewVNode = gamepadUiViewVNode;
      this.focusFirstElement();
    }
    focusFirstElement() {
      if (this.currentElement = this.findFirstElement()) {
        this.currentElement.instance.toggleFocus(true);
      }
    }
    goUp() {
      this.goDir("UP");
    }
    goRight() {
      this.goDir("RIGHT");
    }
    goDown() {
      this.goDir("DOWN");
    }
    goLeft() {
      this.goDir("LEFT");
    }
    pushButtonA() {
      var _a13;
      (_a13 = this.currentElement) == null ? void 0 : _a13.instance.onButtonAPressed();
    }
    pushButtonB() {
      var _a13;
      (_a13 = this.currentElement) == null ? void 0 : _a13.instance.onButtonBPressed();
    }
    goDir(dir) {
      const HTMLElementList = this.parseDOM();
      if (!this.currentElement || HTMLElementList === null) {
        return;
      }
      const nextElement = this.findClosestNode(this.currentElement, HTMLElementList, dir);
      if (nextElement !== null) {
        this.currentElement.instance.toggleFocus(false);
        this.currentElement = nextElement;
        this.currentElement.instance.toggleFocus(true);
      }
    }
    parseDOM() {
      if (this.gamepadUiViewVNode === null) {
        throw new Error(`Can't parse DOM, VNode is null`);
      }
      const VNodeList = [];
      import_msfs_sdk.FSComponent.visitNodes(this.gamepadUiViewVNode, (node) => {
        if (node.instance instanceof GamepadUiComponent) {
          const ref = import_msfs_sdk.FSComponent.createRef();
          ref.instance = node.instance;
          VNodeList.push(ref);
        }
        return false;
      });
      return VNodeList.length ? VNodeList : null;
    }
    findFirstElement() {
      const HTMLElementList = this.parseDOM();
      if (HTMLElementList === null) {
        return null;
      }
      return HTMLElementList[0];
    }
    /** On réduit la liste dont le top est en dessous du bottom du current node. */
    findClosestNode(currentGamepadUiComponent, gamepadUiComponentList, direction) {
      let candidateIndex = -1;
      switch (direction) {
        case "UP":
          candidateIndex = this.findBestCandidate(
            currentGamepadUiComponent,
            gamepadUiComponentList,
            "bottom",
            "top"
          );
          break;
        case "RIGHT":
          candidateIndex = this.findBestCandidate(
            currentGamepadUiComponent,
            gamepadUiComponentList,
            "left",
            "right"
          );
          break;
        case "DOWN":
          candidateIndex = this.findBestCandidate(
            currentGamepadUiComponent,
            gamepadUiComponentList,
            "top",
            "bottom"
          );
          break;
        case "LEFT":
          candidateIndex = this.findBestCandidate(
            currentGamepadUiComponent,
            gamepadUiComponentList,
            "right",
            "left"
          );
          break;
      }
      if (candidateIndex !== -1 && candidateIndex < gamepadUiComponentList.length) {
        return gamepadUiComponentList[candidateIndex];
      }
      return null;
    }
    findBestCandidate(currentGamepadUiComponent, gamepadUiComponentList, side1, side2) {
      const htmlElementCandidates = [];
      let closestDistance = Infinity;
      let candidateIndex = -1;
      const currentHTMLElementRect = currentGamepadUiComponent.instance.getComponentRect();
      gamepadUiComponentList.forEach((htmlElement, index2) => {
        const htmlElementRect = htmlElement.instance.getComponentRect();
        if (this.isRectPosValid(htmlElementRect, currentHTMLElementRect, side1, side2, false)) {
          if (!htmlElementCandidates.some(
            (htmlElementCandidate) => this.isRectPosValid(
              htmlElementRect,
              htmlElementCandidate.instance.getComponentRect(),
              side1,
              side1,
              true
            )
          )) {
            htmlElementCandidates.push(htmlElement);
            const corner = side1 === "bottom" || side1 === "top" ? "left" : "top";
            const distance = this.distances1D(htmlElementRect, currentHTMLElementRect, corner);
            if (distance <= closestDistance) {
              closestDistance = distance;
              candidateIndex = index2;
            }
          }
        }
      });
      return candidateIndex;
    }
    isRectPosValid(rect1, rect2, side1, side2, strict) {
      if (side1 === "bottom" || side1 === "right") {
        if (strict) {
          return rect1[side1] < rect2[side2];
        } else {
          return rect1[side1] <= rect2[side2];
        }
      } else {
        if (strict) {
          return rect1[side1] > rect2[side2];
        } else {
          return rect1[side1] >= rect2[side2];
        }
      }
    }
    distances1D(rect1, rect2, side) {
      return Math.abs(rect2[side] - rect1[side]);
    }
  };
  __name(_GamepadUiParser, "GamepadUiParser");
  var GamepadUiParser = _GamepadUiParser;
  var _UiView = class _UiView extends import_msfs_sdk.DisplayComponent {
    constructor() {
      super(...arguments);
      this.services = [];
    }
    onOpen() {
      var _a13;
      for (const service of this.services) {
        (_a13 = service.onOpen) == null ? void 0 : _a13.call(service);
      }
    }
    onClose() {
      var _a13;
      for (const service of this.services) {
        (_a13 = service.onClose) == null ? void 0 : _a13.call(service);
      }
    }
    onResume() {
      var _a13;
      for (const service of this.services) {
        (_a13 = service.onResume) == null ? void 0 : _a13.call(service);
      }
    }
    onPause() {
      var _a13;
      for (const service of this.services) {
        (_a13 = service.onPause) == null ? void 0 : _a13.call(service);
      }
    }
    onUpdate(time) {
      var _a13;
      for (const service of this.services) {
        (_a13 = service.onUpdate) == null ? void 0 : _a13.call(service, time);
      }
    }
    destroy() {
      var _a13;
      for (const service of this.services) {
        (_a13 = service.destroy) == null ? void 0 : _a13.call(service);
      }
      super.destroy();
    }
  };
  __name(_UiView, "UiView");
  var UiView = _UiView;
  var _GamepadUiView = class _GamepadUiView extends UiView {
    constructor() {
      super(...arguments);
      this.gamepadUiViewRef = import_msfs_sdk.FSComponent.createRef();
      this.gamepadUiParser = new GamepadUiParser();
      this._nextHandler = import_msfs_sdk.Subject.create(void 0);
      this.nextHandler = this._nextHandler;
      this.inputManager = new InputManager();
      this.gamepadComponentChildren = [];
      this.areGamepadInputsEnabled = import_msfs_sdk.Subject.create(false);
      this.viewCoreInputManager = new InternalInputManager(InternalInputActions);
    }
    /**
     * Enable the gamepad inputs for this UI view.
     * Gamepad inputs of any UI view shall be added in its own enableGamepadInputs function via inputManager.
     */
    enableGamepadInputs() {
      if (this.areGamepadInputsEnabled.get()) {
        console.warn("Trying to enable gamepad inputs that are already enabled. Operation cancelled.");
        return;
      }
      this.goBackActionDestructor = this.viewCoreInputManager.addInputAction(
        InternalInputAction.BACK,
        () => {
          if (this.props.appViewService === void 0) {
            return false;
          }
          try {
            this.props.appViewService.goBack();
          } catch (e) {
            return false;
          }
          return true;
        }
      );
      this.gamepadComponentChildren.forEach((child) => child.enableGamepadInputs());
      this.areGamepadInputsEnabled.set(true);
    }
    /**
     * Disable the gamepad inputs for this UI view.
     * Gamepad input destructors of any UI view shall be called in its own disableGamepadInputs function.
     */
    disableGamepadInputs() {
      var _a13;
      (_a13 = this.goBackActionDestructor) == null ? void 0 : _a13.call(this);
      this.gamepadComponentChildren.forEach((child) => child.disableGamepadInputs());
      this.areGamepadInputsEnabled.set(false);
    }
    onClose() {
      super.onClose();
      this.disableGamepadInputs();
    }
    onResume() {
      super.onResume();
      this.enableGamepadInputs();
    }
    onPause() {
      super.onPause();
      this.disableGamepadInputs();
    }
    onAfterRender(node) {
      super.onAfterRender(node);
      this.gamepadUiParser.bindVNodeReference(node);
      import_msfs_sdk.FSComponent.visitNodes(node, (childNode) => {
        if (childNode.instance instanceof GamepadUiComponent) {
          this.gamepadComponentChildren.push(childNode.instance);
        }
        return false;
      });
    }
    destroy() {
      super.destroy();
      this.disableGamepadInputs();
    }
    setNextGamepadEventHandler(ref) {
      this._nextHandler.set(ref);
    }
    deletePreviousGamepadEventHandler() {
      this._nextHandler.set(void 0);
    }
    handleGamepadEvent(_gamepadEvent) {
      if (_gamepadEvent === GamepadEvents.BUTTON_B) {
        this.gamepadUiParser.pushButtonB();
      }
      const nextHandler = this._nextHandler.get();
      if (nextHandler !== void 0) {
        return nextHandler.handleGamepadEvent(_gamepadEvent);
      }
      switch (_gamepadEvent) {
        case GamepadEvents.JOYDIR_UP:
          this.gamepadUiParser.goUp();
          break;
        case GamepadEvents.JOYDIR_RIGHT:
          this.gamepadUiParser.goRight();
          break;
        case GamepadEvents.JOYDIR_DOWN:
          this.gamepadUiParser.goDown();
          break;
        case GamepadEvents.JOYDIR_LEFT:
          this.gamepadUiParser.goLeft();
          break;
        case GamepadEvents.BUTTON_A:
          this.gamepadUiParser.pushButtonA();
          break;
      }
    }
  };
  __name(_GamepadUiView, "GamepadUiView");
  var GamepadUiView = _GamepadUiView;
  var ViewBootMode = /* @__PURE__ */ ((ViewBootMode2) => {
    ViewBootMode2[ViewBootMode2["COLD"] = 0] = "COLD";
    ViewBootMode2[ViewBootMode2["HOT"] = 1] = "HOT";
    return ViewBootMode2;
  })(ViewBootMode || {});
  var ViewSuspendMode = /* @__PURE__ */ ((ViewSuspendMode2) => {
    ViewSuspendMode2[ViewSuspendMode2["SLEEP"] = 0] = "SLEEP";
    ViewSuspendMode2[ViewSuspendMode2["TERMINATE"] = 1] = "TERMINATE";
    return ViewSuspendMode2;
  })(ViewSuspendMode || {});
  var defaultViewOptions = {
    BootMode: ViewBootMode.COLD,
    SuspendMode: ViewSuspendMode.SLEEP
  };
  var _AppViewService = class _AppViewService {
    constructor(bus) {
      this.registeredUiViewEntries = /* @__PURE__ */ new Map();
      this.appViewStack = [];
      this.registeredUiViewPromises = [];
      this.hasInitialized = false;
      this._currentUiView = import_msfs_sdk.Subject.create(null);
      this.currentUiView = this._currentUiView;
      this.bus = bus;
      this.goHomeSub = this.bus.on(
        "_efb_appviewservice_go_home",
        () => {
          const steps = this.appViewStack.length - 1;
          if (steps >= 1) {
            this.goBack(steps);
          }
        },
        true
      );
    }
    onOpen() {
      var _a13, _b;
      this.goHomeSub.resume();
      (_b = (_a13 = this.getActiveUiViewEntry()) == null ? void 0 : _a13.ref) == null ? void 0 : _b.onOpen();
    }
    onClose() {
      var _a13, _b;
      this.goHomeSub.pause();
      (_b = (_a13 = this.getActiveUiViewEntry()) == null ? void 0 : _a13.ref) == null ? void 0 : _b.onClose();
    }
    onResume() {
      var _a13, _b;
      this.goHomeSub.resume();
      (_b = (_a13 = this.getActiveUiViewEntry()) == null ? void 0 : _a13.ref) == null ? void 0 : _b.onResume();
    }
    onPause() {
      var _a13, _b;
      this.goHomeSub.pause();
      (_b = (_a13 = this.getActiveUiViewEntry()) == null ? void 0 : _a13.ref) == null ? void 0 : _b.onPause();
    }
    /**
     * Registers and renders a view (page or popup) to be opened by the service.
     * @param key The UiView string key.
     * @param type The view type
     * @param vNodeFactory A function that returns a {@link UiView} VNode for the key
     * @param options The {@link UiView} {@link ViewOptions}
     * @returns UiViewEntry
     */
    registerView(key, type, vNodeFactory, options) {
      if (this.registeredUiViewEntries.has(key)) {
        throw new Error(`View "${key}" is already used`);
      } else if (typeof vNodeFactory !== "function") {
        throw new Error("vNodeFactory has to be a function returning a VNode");
      }
      const viewOptions = Object.assign({}, defaultViewOptions, options);
      const appViewEntry = {
        key,
        render: vNodeFactory,
        vNode: vNodeFactory,
        ref: null,
        containerRef: import_msfs_sdk.FSComponent.createRef(),
        isVisible: import_msfs_sdk.Subject.create(false),
        layer: import_msfs_sdk.Subject.create(-1),
        type: import_msfs_sdk.Subject.create(type),
        isInit: false,
        viewOptions
      };
      if (viewOptions.BootMode === ViewBootMode.HOT) {
        this.initViewEntry(appViewEntry);
      }
      this.registeredUiViewEntries.set(key, appViewEntry);
      return appViewEntry;
    }
    registerPage(key, vNodeFactory, options) {
      return this.registerView(key, "page", vNodeFactory, options);
    }
    registerPopup(key, vNodeFactory, options) {
      return this.registerView(key, "popup", vNodeFactory, options);
    }
    async killView(viewEntry) {
      var _a13;
      if (viewEntry.isInit === false) {
        return;
      }
      if (this.appViewStack.find((view) => view.key === viewEntry.key)) {
        throw new Error("You must close your view before killing it");
      }
      viewEntry.isInit = false;
      (_a13 = viewEntry.ref) == null ? void 0 : _a13.destroy();
      viewEntry.containerRef.instance.destroy();
      viewEntry.ref = null;
      viewEntry.containerRef = import_msfs_sdk.FSComponent.createRef();
      viewEntry.vNode = viewEntry.render.bind(viewEntry);
      return new Promise((resolve) => {
        if (viewEntry.viewOptions.BootMode === ViewBootMode.HOT) {
          this.initViewEntry(viewEntry);
        }
        resolve();
      });
    }
    /**
     * @param entry a {@link UiViewEntry}
     * @param shouldOpen opens the view on initialization, defaults to false
     */
    initViewEntry(entry, shouldOpen = false) {
      var _a13;
      if (entry.isInit) {
        return;
      }
      entry.isInit = true;
      entry.vNode = value(entry.vNode);
      entry.ref = entry.vNode.instance;
      (_a13 = this.appViewRef) == null ? void 0 : _a13.renderView(
        /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent(
          AppViewWrapper,
          {
            viewName: entry.key,
            isVisible: entry.isVisible,
            type: entry.type,
            layer: entry.layer,
            ref: entry.containerRef
          },
          entry.vNode
        )
      );
      shouldOpen && entry.ref.onOpen();
    }
    /**
     * Destroys every view in registered view entries and resets the view stack.
     */
    unload() {
      var _a13;
      this.registeredUiViewPromises = [];
      for (const viewEntry of this.registeredUiViewEntries.values()) {
        (_a13 = viewEntry.ref) == null ? void 0 : _a13.destroy();
      }
      this.registeredUiViewEntries.clear();
      this.appViewStack.splice(0, this.appViewStack.length);
      this.hasInitialized = false;
    }
    /**
     *
     * @param homePageUiViewKey the string key of the {@link UiView}
     * @returns a Promise resolving when all pages are initialized
     */
    async initialize(homePageUiViewKey) {
      if (this.hasInitialized) {
        return Promise.resolve();
      }
      return Promise.all(this.registeredUiViewPromises).then(() => {
        this.initializeAppViewStack(homePageUiViewKey);
        this.hasInitialized = true;
      });
    }
    /**
     * @returns the current active view entry.
     */
    getActiveUiViewEntry() {
      const activeViewEntry = import_msfs_sdk.ArrayUtils.peekLast(this.appViewStack);
      return activeViewEntry;
    }
    /** @deprecated */
    on(_event, _viewKey, _callback) {
      return this;
    }
    /**
     * Handles logic associated with changing the open page.
     * @param page Page to close
     */
    handleCloseView(page) {
      var _a13;
      if (!page || page.isVisible.get() === false) return;
      (_a13 = page.ref) == null ? void 0 : _a13.onPause();
      page.isVisible.set(false);
      this._currentUiView.set(null);
      if (page.viewOptions.SuspendMode === ViewSuspendMode.TERMINATE) {
        setTimeout(() => this.killView(page));
      }
    }
    /**
     * Handles logic associated with changing the open page.
     * @param page Page to open
     */
    handleOpenView(page) {
      var _a13;
      if (!page || page.isVisible.get() === true) return;
      (_a13 = page.ref) == null ? void 0 : _a13.onResume();
      page.isVisible.set(true);
      this._currentUiView.set(page);
    }
    /**
     * Populate the view stack with its respective home page.
     * @param mainPageUiViewKey the key of the home page
     */
    initializeAppViewStack(mainPageUiViewKey) {
      this.open(mainPageUiViewKey);
    }
    /**
     * @param key the {@link UiView} string key
     * @returns the {@link UiViewEntry} corresponding to the key
     * @throws if the {@link UiViewEntry} doesn't exists
     */
    getUiViewEntry(key) {
      const appViewEntry = this.registeredUiViewEntries.get(key);
      if (!appViewEntry) {
        throw new Error(`${key} wasn't registered as a view`);
      }
      return appViewEntry;
    }
    /**
     * Called by AppContainer to pass in the refs to the view.
     * Should only be called once.
     * @param appViewRef The app view ref.
     */
    onAppContainerRendered(appViewRef) {
      this.appViewRef = appViewRef;
    }
    isInViewStack(view) {
      const key = typeof view === "string" ? view : view.key;
      return this.appViewStack.findIndex((stackViewEntry) => key === stackViewEntry.key) !== -1;
    }
    isActive(view) {
      const key = typeof view === "string" ? view : view.key;
      const activeViewEntry = this.getActiveUiViewEntry();
      if (activeViewEntry === void 0) {
        return false;
      }
      return key === activeViewEntry.key;
    }
    open(key) {
      const viewEntry = this.advanceViewStack(key);
      return viewEntry;
    }
    goBack(steps) {
      steps != null ? steps : steps = 1;
      if (steps <= 0) {
        throw new RangeError(`Steps must be superior to 0.`);
      } else if (steps >= this.appViewStack.length) {
        throw new RangeError(`Steps can't be superior to ${this.appViewStack.length} when called.`);
      }
      const activeViewEntry = this.getActiveUiViewEntry();
      if (this.appViewStack.length > steps && activeViewEntry) {
        const viewsToOpen = [];
        const viewsToClose = [];
        while (steps--) {
          const view = this.appViewStack.pop();
          if (view) {
            viewsToClose.push(view);
          }
        }
        let i = this.appViewStack.length;
        do {
          viewsToOpen.push(this.appViewStack[--i]);
        } while (i > 0 && this.appViewStack[i].type.get() !== "page");
        for (const page of viewsToClose) {
          this.handleCloseView(page);
        }
        for (const page of viewsToOpen.reverse()) {
          this.handleOpenView(page);
        }
      }
      return this.getActiveUiViewEntry();
    }
    /**
     * Handles view stack logic
     * @param key the {@link UiView} string key
     * @returns the current {@link UiViewEntry}
     */
    advanceViewStack(key) {
      const viewEntry = this.getUiViewEntry(key);
      if (this.appViewStack.includes(viewEntry)) {
        if (this.getActiveUiViewEntry() !== viewEntry) {
          throw new Error("Page or popup is already in the viewstack and can't be opened twice");
        }
        return viewEntry;
      }
      switch (viewEntry.type.get()) {
        case "page":
          for (const page of [...this.appViewStack].reverse()) {
            this.handleCloseView(page);
          }
          break;
      }
      this.appViewStack.push(viewEntry);
      this.openView(viewEntry);
      this.handleOpenView(viewEntry);
      return viewEntry;
    }
    /**
     * Handle logic associated with opening a view
     * @param view the view to open.
     */
    openView(view) {
      if (!view.isInit) {
        this.initViewEntry(view, true);
      }
      const index2 = this.appViewStack.indexOf(view);
      if (index2 < 0) {
        throw new Error(`AppViewService: view not found in view stack: ${view.key}`);
      }
      view.layer.set(index2);
    }
    /**
     * Updates all the pages/popups that are initialized and visible
     * @param time timestamp
     */
    update(time) {
      this.registeredUiViewEntries.forEach((UiView2) => {
        var _a13;
        if (UiView2.isInit && UiView2.isVisible.get()) {
          (_a13 = UiView2.ref) == null ? void 0 : _a13.onUpdate(time);
        }
      });
    }
    /**
     * Routes the event to the current {@link UiView}
     * @param gamepadEvent the {@link GamepadEvents}
     */
    routeGamepadInteractionEvent(gamepadEvent) {
      const _currentUiView = this.getActiveUiViewEntry();
      if ((_currentUiView == null ? void 0 : _currentUiView.ref) instanceof GamepadUiView) {
        _currentUiView.ref.handleGamepadEvent(gamepadEvent);
      }
    }
  };
  __name(_AppViewService, "AppViewService");
  var AppViewService = _AppViewService;
  var _AppViewWrapper = class _AppViewWrapper extends import_msfs_sdk.DisplayComponent {
    constructor() {
      super(...arguments);
      this.rootRef = import_msfs_sdk.FSComponent.createRef();
    }
    render() {
      return /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent(
        "div",
        {
          ref: this.rootRef,
          class: {
            "ui-view": true,
            [this.props.viewName]: true,
            hidden: this.props.isVisible.map(import_msfs_sdk.SubscribableMapFunctions.not()),
            page: this.props.type.map(where("page")),
            popup: this.props.type.map(where("popup"))
          },
          style: {
            "z-index": this.props.layer.map(toString())
          }
        },
        this.props.children
      );
    }
    destroy() {
      var _a13;
      const root = this.rootRef.getOrDefault();
      if (root !== null) {
        (_a13 = root.parentNode) == null ? void 0 : _a13.removeChild(root);
      }
      super.destroy();
    }
  };
  __name(_AppViewWrapper, "AppViewWrapper");
  var AppViewWrapper = _AppViewWrapper;
  var __defProp22 = Object.defineProperty;
  var __getOwnPropDesc2 = Object.getOwnPropertyDescriptor;
  var __decorateClass = /* @__PURE__ */ __name((decorators, target, key, kind) => {
    var result = __getOwnPropDesc2(target, key);
    for (var i = decorators.length - 1, decorator; i >= 0; i--)
      if (decorator = decorators[i])
        result = decorator(target, key, result) || result;
    if (result) __defProp22(target, key, result);
    return result;
  }, "__decorateClass");
  var _AppView = class _AppView extends import_msfs_sdk.DisplayComponent {
    constructor(props) {
      var _a13;
      super(props);
      this.rootRef = import_msfs_sdk.FSComponent.createRef();
      this.pageKeyActions = /* @__PURE__ */ new Map();
      this._appViewService = props.appViewService || (props.bus ? new AppViewService(props.bus) : void 0);
      this._bus = (_a13 = this._appViewService) == null ? void 0 : _a13.bus;
      this._unitsSettingManager = props.unitsSettingManager;
      this._efbSettingsManager = props.efbSettingsManager;
      this._notificationManager = props.notificationManager;
      this._onboardingManager = props.onboardingManager;
    }
    get appViewService() {
      const _appViewService = this._appViewService;
      if (!_appViewService) {
        throw new Error(
          `Cannot resolve 'appViewService' because none of 'appViewService' and 'bus' props were given.`
        );
      }
      return _appViewService;
    }
    get bus() {
      const _bus = this._bus;
      if (!_bus) {
        throw new Error(`Cannot resolve 'bus' because none of 'appViewService' and 'bus' props were given.`);
      }
      return _bus;
    }
    get unitsSettingManager() {
      const _unitsSettingManager = this._unitsSettingManager;
      if (_unitsSettingManager === void 0) {
        throw new Error(`Cannot resolve 'unitsSettingManager'`);
      }
      return _unitsSettingManager;
    }
    get efbSettingsManager() {
      const _efbSettingsManager = this._efbSettingsManager;
      if (_efbSettingsManager === void 0) {
        throw new Error(`Cannot resolve 'efbSettingsManager'`);
      }
      return _efbSettingsManager;
    }
    /**
     * EFB notification manager
     * @returns a unique efbNotificationManager instance
     */
    get notificationManager() {
      const notificationManager = this._notificationManager;
      if (!notificationManager) {
        throw new Error("Notification manager is not defined");
      }
      return notificationManager;
    }
    get onboardingManager() {
      const _onboardingManager = this._onboardingManager;
      if (!_onboardingManager) {
        throw new Error(`Cannot resolve 'onboardingManager'`);
      }
      return _onboardingManager;
    }
    /**
     * Called once when the view is opened for the first time.
     */
    onOpen() {
      var _a13;
      (_a13 = this._appViewService) == null ? void 0 : _a13.onOpen();
    }
    /**
     * Called once when the view is destroyed.
     */
    onClose() {
      var _a13;
      (_a13 = this._appViewService) == null ? void 0 : _a13.onClose();
    }
    /**
     * Called each time the view is resumed.
     */
    onResume() {
      var _a13;
      (_a13 = this._appViewService) == null ? void 0 : _a13.onResume();
    }
    /**
     * Called each time the view is closed.
     */
    onPause() {
      var _a13;
      (_a13 = this._appViewService) == null ? void 0 : _a13.onPause();
    }
    /**
     * On Update loop - It update the `AppViewService` if it is used.
     * @param time in milliseconds
     */
    onUpdate(time) {
      var _a13;
      (_a13 = this._appViewService) == null ? void 0 : _a13.update(time);
    }
    /**
     * Callback to register all views the app might use.
     */
    registerViews() {
    }
    /**
     * @internal
     * TODO : Need to be documented after Gamepad integration
     */
    routeGamepadInteractionEvent(gamepadEvent) {
      var _a13;
      (_a13 = this._appViewService) == null ? void 0 : _a13.routeGamepadInteractionEvent(gamepadEvent);
    }
    /**
     * @internal
     * @param key custom page key defined in `pageKeyActions`
     * @param args array of arguments given to the defined callback
     */
    handlePageKeyAction(key, args) {
      if (key === null) {
        return;
      }
      const action = this.pageKeyActions.get(key);
      if (action === void 0) {
        console.error(`Key "${key}" doesn't exists.`);
        return;
      }
      toPromise(action(args)).catch((reason) => {
        console.error(`handlePageKeyAction Error for key "${key}"`, reason);
      });
    }
    /**
     * If using EFB's AppViewService, this method returns an AppContainer binded to AppViewService.
     * Otherwise it can be customized with plain JSX/TSX or custom view service, etc...
     *
     * @example
     * Surrounding AppContainer with a custom class:
     * ```ts
     * public render(): TVNode<HTMLDivElement> {
     * 	return <div class="my-custom-class">{super.render()}</div>;
     * }
     * ```
     * @example
     * Here's an plain JSX/TSX example:
     * ```ts
     * public render(): TVNode<HTMLSpanElement> {
     * 	return <span>Hello World!</span>;
     * }
     * ```
     */
    render() {
      return /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent(AppContainer, { appViewService: this.appViewService });
    }
    /** @inheritdoc */
    onAfterRender(node) {
      var _a13;
      super.onAfterRender(node);
      this.registerViews();
      if (this.defaultView) {
        (_a13 = this._appViewService) == null ? void 0 : _a13.initialize(this.defaultView);
      }
    }
    /** @internal */
    destroy() {
      var _a13;
      (_a13 = this._appViewService) == null ? void 0 : _a13.unload();
      super.destroy();
    }
  };
  __name(_AppView, "AppView");
  var AppView = _AppView;
  __decorateClass([
    Memoize()
  ], AppView.prototype, "appViewService");
  __decorateClass([
    Memoize()
  ], AppView.prototype, "bus");
  __decorateClass([
    Memoize()
  ], AppView.prototype, "unitsSettingManager");
  __decorateClass([
    Memoize()
  ], AppView.prototype, "efbSettingsManager");
  __decorateClass([
    Memoize()
  ], AppView.prototype, "onboardingManager");
  var _Button = class _Button extends GamepadUiComponent {
    constructor() {
      var _a13, _b, _c, _d;
      super(...arguments);
      this.isButtonDisabled = import_msfs_sdk.SubscribableUtils.toSubscribable((_a13 = this.props.disabled) != null ? _a13 : false, true);
      this.isButtonHoverable = import_msfs_sdk.MappedSubject.create(
        ([isHoverable, isDisabled]) => {
          return isHoverable && !isDisabled;
        },
        import_msfs_sdk.SubscribableUtils.toSubscribable((_b = this.props.hoverable) != null ? _b : true, true),
        this.isButtonDisabled
      );
      this.isButtonSelected = import_msfs_sdk.MappedSubject.create(
        ([isSelected, state]) => isSelected || state,
        import_msfs_sdk.SubscribableUtils.toSubscribable((_c = this.props.selected) != null ? _c : false, true),
        import_msfs_sdk.SubscribableUtils.toSubscribable((_d = this.props.state) != null ? _d : false, true)
      );
    }
    /**
     * @deprecated Old way to render the button. Instead of extending the `Button` class, render your content as a children of `<Button>...</Button>`.
     */
    buttonRender() {
      return null;
    }
    render() {
      return /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent(
        "button",
        {
          ref: this.gamepadUiComponentRef,
          class: mergeClassProp(
            "button",
            "abstract-button",
            // deprecated
            {
              hoverable: this.isButtonHoverable,
              selected: this.isButtonSelected
            },
            this.props.class
          ),
          style: this.props.style
        },
        /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent("div", { class: "disabled-layer" }),
        this.props.children,
        this.buttonRender()
      );
    }
    onAfterRender(node) {
      super.onAfterRender(node);
      if (this.props.callback) {
        this.gamepadUiComponentRef.instance.onclick = (event) => {
          var _a13;
          if (this.isButtonDisabled.get() === true) {
            return;
          }
          (_a13 = this.props.callback) == null ? void 0 : _a13.call(this, event);
        };
      }
    }
    destroy() {
      this.isButtonHoverable.destroy();
      super.destroy();
    }
  };
  __name(_Button, "Button");
  var Button = _Button;
  var _a4;
  var _GamepadListNavigationManager = (_a4 = class {
    constructor(data, toolbox) {
      var _a13, _b;
      this.data = data;
      this.toolbox = toolbox;
      this.allowedUpcomingNavigationMs = 0;
      this.currentItemIndex = import_msfs_sdk.Subject.create(-1);
      this.isListFocusedSubscriptions = [];
      this.currentItemIndexSubscription = this.currentItemIndex.sub((index2) => {
        var _a22, _b2;
        const item = index2 < 0 || index2 >= this.data.length ? null : this.data.get(index2);
        (_b2 = (_a22 = this.toolbox).onItemHovered) == null ? void 0 : _b2.call(_a22, item, index2);
      });
      this.internalInputManager = new InternalInputManager(InternalInputActions);
      this.navigationBetweenItemsDelayMs = (_a13 = toolbox.navigationBetweenItemsDelayMs) != null ? _a13 : _a4.defaultNavigationBetweenItemsDelayMs;
      if (toolbox.wrap) {
        this.computeUpcomingItemIndex = (previousItemIndex, step) => (this.data.length + previousItemIndex + step) % this.data.length;
      } else {
        this.computeUpcomingItemIndex = (previousItemIndex, step) => {
          const upcomingItemIndex = previousItemIndex + step;
          if (upcomingItemIndex >= 0 && upcomingItemIndex < this.data.length) {
            return upcomingItemIndex;
          } else {
            return previousItemIndex;
          }
        };
      }
      if (import_msfs_sdk.SubscribableUtils.isMutableSubscribable(toolbox.isListFocused)) {
        this.isListFocused = toolbox.isListFocused;
      } else if (import_msfs_sdk.SubscribableUtils.isSubscribable(toolbox.isListFocused)) {
        this.isListFocused = import_msfs_sdk.Subject.create(toolbox.isListFocused.get());
        this.isListFocusedSubscriptions.push(
          toolbox.isListFocused.sub((value2) => this.isListFocused.set(value2))
        );
      } else {
        this.isListFocused = import_msfs_sdk.Subject.create((_b = toolbox.isListFocused) != null ? _b : false);
      }
      this.isListFocusedSubscriptions.push(
        import_msfs_sdk.MappedSubject.create(
          ([is2D, isFocused]) => {
            if (is2D && isFocused) {
              this.enableGamepadNavigation();
            } else {
              this.disableGamepadNavigation();
            }
          },
          window.PanelInfo.is2D,
          this.isListFocused
        )
      );
    }
    navigateThroughList(step) {
      const currentNavigationTryMs = Date.now();
      if (currentNavigationTryMs < this.allowedUpcomingNavigationMs) {
        return false;
      }
      this.allowedUpcomingNavigationMs = currentNavigationTryMs + this.navigationBetweenItemsDelayMs;
      const currentItemIndex = this.currentItemIndex.get();
      if (currentItemIndex === -1) {
        return false;
      }
      const upcomingItemIndex = this.computeUpcomingItemIndex(currentItemIndex, step);
      this.currentItemIndex.set(upcomingItemIndex);
      return true;
    }
    enableGamepadNavigation() {
      Coherent.trigger("SET_EFB_GAMEPAD_NAVIGATION", true);
      this.currentItemIndex.set(0);
      this.unfocusListActionDestructor = this.internalInputManager.addInputAction(
        InternalInputAction.BACK,
        () => {
          this.isListFocused.set(false);
          return true;
        }
      );
      this.selectItemActionDestructor = this.internalInputManager.addInputAction(
        InternalInputAction.VALID,
        () => {
          var _a13, _b;
          const currentItemIndex = this.currentItemIndex.get();
          try {
            (_b = (_a13 = this.toolbox).onItemSelected) == null ? void 0 : _b.call(_a13, this.data.get(currentItemIndex), currentItemIndex);
          } catch (e) {
            return false;
          }
          return true;
        }
      );
      this.allowedUpcomingNavigationMs = Date.now();
      this.prevItemActionDestructor = this.internalInputManager.addInputAction(
        InternalInputAction.UP,
        () => this.navigateThroughList(
          -1
          /* UP */
        ),
        { inputType: "axis" }
      );
      this.nextItemActionDestructor = this.internalInputManager.addInputAction(
        InternalInputAction.DOWN,
        () => this.navigateThroughList(
          1
          /* DOWN */
        ),
        { inputType: "axis" }
      );
    }
    disableGamepadNavigation() {
      var _a13, _b, _c, _d;
      (_a13 = this.unfocusListActionDestructor) == null ? void 0 : _a13.call(this);
      this.unfocusListActionDestructor = void 0;
      (_b = this.selectItemActionDestructor) == null ? void 0 : _b.call(this);
      this.selectItemActionDestructor = void 0;
      (_c = this.prevItemActionDestructor) == null ? void 0 : _c.call(this);
      this.prevItemActionDestructor = void 0;
      (_d = this.nextItemActionDestructor) == null ? void 0 : _d.call(this);
      this.nextItemActionDestructor = void 0;
      this.currentItemIndex.set(-1);
      Coherent.trigger("SET_EFB_GAMEPAD_NAVIGATION", false);
    }
    pause() {
      this.disableGamepadNavigation();
      this.currentItemIndexSubscription.pause();
      this.isListFocusedSubscriptions.forEach((subscription) => {
        subscription.pause();
      });
    }
    resume() {
      this.currentItemIndexSubscription.resume(this.isListFocused.get());
      this.isListFocusedSubscriptions.forEach((subscription) => {
        subscription.resume(true);
      });
    }
    destroy() {
      this.currentItemIndexSubscription.destroy();
      this.isListFocusedSubscriptions.forEach((subscription) => {
        subscription.destroy();
      });
      this.disableGamepadNavigation();
    }
  }, __name(_a4, "_GamepadListNavigationManager"), _a4);
  _GamepadListNavigationManager.defaultNavigationBetweenItemsDelayMs = 100;
  var _IconElement = class _IconElement extends import_msfs_sdk.DisplayComponent {
    constructor() {
      super(...arguments);
      this.url = import_msfs_sdk.SubscribableUtils.toSubscribable(this.props.url, true);
      this.el = import_msfs_sdk.FSComponent.createRef();
      this.onSVGIconLoaded = (found, svgAsString) => {
        this.el.instance.innerText = "";
        if (!found) {
          console.error(`Image ${this.url.get()} was not found`);
          return;
        }
        const template = document.createElement("template");
        template.innerHTML = svgAsString;
        const svgAsHtml = template.content.querySelector("svg");
        if (svgAsHtml) {
          this.el.instance.appendChild(svgAsHtml);
        }
      };
    }
    render() {
      return /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent("div", { ref: this.el, class: mergeClassProp("icon-element", this.props.class) });
    }
    onAfterRender(node) {
      super.onAfterRender(node);
      this.urlSub = this.url.sub((url) => {
        if (url.endsWith(".svg")) {
          getIconCacheMgr().loadURL(url, this.onSVGIconLoaded);
        } else {
          this.el.instance.innerHTML = `<img src="${url}" onerror="console.error('Image ${url} was not found')" />`;
        }
      }, true);
    }
    destroy() {
      var _a13;
      (_a13 = this.urlSub) == null ? void 0 : _a13.destroy();
      super.destroy();
    }
  };
  __name(_IconElement, "IconElement");
  var IconElement = _IconElement;
  var _IconButton = class _IconButton extends import_msfs_sdk.DisplayComponent {
    render() {
      return /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent(
        Button,
        {
          class: mergeClassProp("icon-button", this.props.class),
          style: this.props.style,
          callback: this.props.callback,
          hoverable: this.props.hoverable,
          selected: this.props.selected,
          state: this.props.state,
          disabled: this.props.disabled,
          onboardingStepId: this.props.onboardingStepId
        },
        /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent(IconElement, { url: this.props.iconPath })
      );
    }
  };
  __name(_IconButton, "IconButton");
  var IconButton = _IconButton;
  var _a5;
  var _BearingDisplay = (_a5 = class extends import_msfs_sdk.AbstractNumberUnitDisplay {
    constructor() {
      var _a13;
      super(...arguments);
      this.unitFormatter = (_a13 = this.props.unitFormatter) != null ? _a13 : _a5.DEFAULT_UNIT_FORMATTER;
      this.unitTextBigDisplay = import_msfs_sdk.Subject.create("");
      this.unitTextSmallDisplay = import_msfs_sdk.Subject.create("");
      this.numberText = import_msfs_sdk.Subject.create("");
      this.unitTextBig = import_msfs_sdk.Subject.create("");
      this.unitTextSmall = import_msfs_sdk.Subject.create("");
    }
    /** @inheritdoc */
    onValueChanged(value2) {
      let displayUnit = this.displayUnit.get();
      if (!displayUnit || !value2.unit.canConvert(displayUnit)) {
        displayUnit = value2.unit;
      }
      const numberValue = value2.asUnit(displayUnit);
      this.updateNumberText(numberValue);
      this.updateUnitText(numberValue, displayUnit);
      if (this.props.hideDegreeSymbolWhenNan === true) {
        this.updateUnitTextVisibility(numberValue);
      }
    }
    /** @inheritdoc */
    onDisplayUnitChanged(displayUnit) {
      const value2 = this.value.get();
      if (!displayUnit || !value2.unit.canConvert(displayUnit)) {
        displayUnit = value2.unit;
      }
      const numberValue = value2.asUnit(displayUnit);
      this.updateNumberText(numberValue);
      this.updateUnitText(numberValue, displayUnit);
      this.updateUnitTextVisibility(numberValue);
    }
    /**
     * Updates this component's displayed number text.
     * @param numberValue The numeric value to display.
     */
    updateNumberText(numberValue) {
      let numberText = this.props.formatter(numberValue);
      if (this.props.use360 !== false && parseFloat(numberText) === 0) {
        numberText = this.props.formatter(360);
      }
      this.numberText.set(numberText);
    }
    /**
     * Updates this component's displayed unit text.
     * @param numberValue The numeric value to display.
     * @param displayUnit The unit type in which to display the value.
     */
    updateUnitText(numberValue, displayUnit) {
      _a5.unitTextCache[0] = "";
      _a5.unitTextCache[1] = "";
      this.unitFormatter(_a5.unitTextCache, displayUnit, numberValue);
      this.unitTextBig.set(_a5.unitTextCache[0]);
      this.unitTextSmall.set(_a5.unitTextCache[1]);
    }
    /**
     * Updates whether this component's unit text spans are visible.
     * @param numberValue The numeric value displayed by this component.
     */
    updateUnitTextVisibility(numberValue) {
      if (this.props.hideDegreeSymbolWhenNan === true) {
        if (isNaN(numberValue)) {
          this.unitTextBigDisplay.set("none");
          this.unitTextSmallDisplay.set("none");
          return;
        }
      }
      this.unitTextBigDisplay.set(this.unitTextBig.get() === "" ? "none" : "");
      this.unitTextSmallDisplay.set(this.unitTextSmall.get() === "" ? "none" : "");
    }
    /** @inheritdoc */
    render() {
      var _a13;
      return /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent("div", { class: (_a13 = this.props.class) != null ? _a13 : "", style: "white-space: nowrap;" }, /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent("span", { class: "bearing-num" }, this.numberText), /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent("span", { class: "bearing-unit", style: { display: this.unitTextBigDisplay } }, this.unitTextBig), /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent("span", { class: "bearing-unit-small", style: { display: this.unitTextSmallDisplay } }, this.unitTextSmall));
    }
  }, __name(_a5, "_BearingDisplay"), _a5);
  _BearingDisplay.DEFAULT_UNIT_FORMATTER = (out, unit) => {
    out[0] = "\xB0";
    out[1] = unit.isMagnetic() ? "" : "T";
  };
  _BearingDisplay.unitTextCache = ["", ""];
  var _Input = class _Input extends GamepadUiComponent {
    constructor() {
      var _a13, _b;
      super(...arguments);
      this.uuid = import_msfs_sdk.UUID.GenerateUuid();
      this.inputRef = this.gamepadUiComponentRef;
      this.model = this.props.model || import_msfs_sdk.Subject.create(import_msfs_sdk.SubscribableUtils.toSubscribable(this.props.value || "", true).get());
      this.internalInputManager = new InternalInputManager(InternalInputActions);
      this.dispatchFocusOutEvent = this._dispatchFocusOutEvent.bind(this);
      this.setValueFromOS = this._setValueFromOS.bind(this);
      this.onKeyDown = this._onKeyDown.bind(this);
      this.onKeyUp = this._onKeyUp.bind(this);
      this.onKeyPress = this._onKeyPress.bind(this);
      this.onInput = this._onInput.bind(this);
      this.align = this.props.align || "left";
      this.debounce = new import_msfs_sdk.DebounceTimer();
      this.reloadLocalisation = this._reloadLocalisation.bind(this);
      this._isFocused = import_msfs_sdk.Subject.create(false);
      this.isFocused = this._isFocused;
      this.focusSubscription = this._isFocused.sub((focus) => {
        if (focus) {
          this.onFocusIn();
        } else {
          this.onFocusOut();
        }
      });
      this.placeholderKey = import_msfs_sdk.SubscribableUtils.toSubscribable((_a13 = this.props.placeholder) != null ? _a13 : "", true);
      this.placeholderShown = import_msfs_sdk.Subject.create(true);
      this.placeholderTranslation = import_msfs_sdk.Subject.create(this.placeholderKey.get());
      this.hidePlaceholderOnFocus = (_b = this.props.hidePlaceholderOnFocus) != null ? _b : false;
      this.subs = [];
    }
    _reloadLocalisation() {
      this.placeholderTranslation.notify();
    }
    _onKeyDown(event) {
      var _a13, _b;
      (_b = (_a13 = this.props).onKeyDown) == null ? void 0 : _b.call(_a13, event);
    }
    _onKeyUp(event) {
      var _a13, _b;
      (_b = (_a13 = this.props).onKeyUp) == null ? void 0 : _b.call(_a13, event);
    }
    _onKeyPress(event) {
      var _a13, _b;
      const keyCode = event.keyCode || event.which;
      (_b = (_a13 = this.props).onKeyPress) == null ? void 0 : _b.call(_a13, event);
      if (event.defaultPrevented) {
        return;
      }
      if (this.props.charFilter && !this.props.charFilter(String.fromCharCode(keyCode))) {
        event.preventDefault();
        return;
      }
    }
    _onInput() {
      var _a13;
      this.debounce.schedule(() => {
        const value2 = this.inputRef.instance.value;
        if (value2 === this.model.get()) {
          return;
        }
        this.model.set(value2);
      }, (_a13 = this.props.debounceDuration) != null ? _a13 : 0);
    }
    onInputUpdated(value2) {
      var _a13, _b;
      this.inputRef.instance.value = value2;
      (_b = (_a13 = this.props).onInput) == null ? void 0 : _b.call(_a13, this.inputRef.instance);
      if (!this.hidePlaceholderOnFocus && value2.length === 0) {
        this.placeholderShown.set(true);
      }
    }
    onFocusIn() {
      var _a13, _b;
      Coherent.trigger("FOCUS_INPUT_FIELD", {
        // TODO Allow the following parameters to be customized via props
        title: "Title",
        description: "",
        default_text: "",
        is_numeric: this.props.type === "number",
        is_efb: true
      });
      Coherent.on("mousePressOutsideView", this.dispatchFocusOutEvent);
      Coherent.on("SetInputTextFromOS", this.setValueFromOS);
      this.focusOutActionDestructor = this.internalInputManager.addInputAction(
        InternalInputAction.BACK,
        () => {
          this.dispatchFocusOutEvent();
          return true;
        }
      );
      this.validateInputActionDestructor = this.internalInputManager.addInputAction(
        InternalInputAction.TEXTBOX_VALID,
        () => {
          var _a22, _b2;
          (_b2 = (_a22 = this.props).onValueValidated) == null ? void 0 : _b2.call(_a22, this.inputRef.instance.value);
          this.dispatchFocusOutEvent();
          return true;
        }
      );
      if (this.hidePlaceholderOnFocus && this.inputRef.instance.value.length === 0) {
        this.placeholderShown.set(false);
      }
      (_b = (_a13 = this.props).onFocusIn) == null ? void 0 : _b.call(_a13);
    }
    onFocusOut() {
      var _a13, _b, _c, _d;
      (_a13 = this.focusOutActionDestructor) == null ? void 0 : _a13.call(this);
      (_b = this.validateInputActionDestructor) == null ? void 0 : _b.call(this);
      Coherent.trigger("UNFOCUS_INPUT_FIELD", this.uuid);
      Coherent.off("mousePressOutsideView", this.dispatchFocusOutEvent);
      Coherent.off("SetInputTextFromOS", this.setValueFromOS);
      if (this.hidePlaceholderOnFocus && this.inputRef.instance.value.length === 0) {
        this.placeholderShown.set(true);
      }
      (_d = (_c = this.props).onFocusOut) == null ? void 0 : _d.call(_c);
    }
    value() {
      return this.model.get();
    }
    clearInput() {
      this.model.set("");
    }
    focus() {
      const inputInstance = this.inputRef.getOrDefault();
      if (inputInstance !== null) {
        inputInstance.focus();
      }
    }
    blur() {
      const inputInstance = this.inputRef.getOrDefault();
      if (inputInstance !== null) {
        inputInstance.blur();
      }
    }
    _dispatchFocusOutEvent() {
      const inputInstance = this.inputRef.getOrDefault();
      if (inputInstance !== null) {
        inputInstance.blur();
        inputInstance.dispatchEvent(new InputEvent("focusout"));
      }
    }
    _setValueFromOS(text) {
      var _a13, _b;
      const inputInstance = this.inputRef.getOrDefault();
      if (inputInstance !== null) {
        inputInstance.value = text;
        inputInstance.dispatchEvent(new InputEvent("change"));
        inputInstance.dispatchEvent(new InputEvent("input"));
        inputInstance.dispatchEvent(new InputEvent("submit"));
        (_b = (_a13 = this.props).onValueValidated) == null ? void 0 : _b.call(_a13, text);
        this.dispatchFocusOutEvent();
      }
    }
    render() {
      return /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent(
        "input",
        {
          id: this.uuid,
          ref: this.inputRef,
          type: this.props.type,
          class: {
            [`align-${this.align}`]: this.align !== "left"
          },
          placeholder: import_msfs_sdk.MappedSubject.create(
            ([placeholderShown, placeholderKey]) => {
              return placeholderShown ? Utils.Translate(placeholderKey) : "";
            },
            this.placeholderShown,
            this.placeholderKey
          ),
          disabled: this.props.disabled,
          value: import_msfs_sdk.SubscribableUtils.toSubscribable(this.props.model || this.props.value || "", true).get()
        }
      );
    }
    onAfterRender(node) {
      super.onAfterRender(node);
      this.subs.push(
        this.model.sub((value2) => {
          this.onInputUpdated(value2);
        }, true),
        this.placeholderKey.sub((key) => {
          this.placeholderTranslation.set(key);
        }, true)
      );
      this.inputRef.instance.addEventListener("focus", () => this._isFocused.set(true));
      this.inputRef.instance.addEventListener("focusout", () => this._isFocused.set(false));
      this.inputRef.instance.addEventListener("input", this.onInput);
      this.inputRef.instance.addEventListener("keydown", this.onKeyDown);
      this.inputRef.instance.addEventListener("keyup", this.onKeyUp);
      this.inputRef.instance.addEventListener("keypress", this.onKeyPress);
      Coherent.on("RELOAD_LOCALISATION", this.reloadLocalisation);
      if (this.props.focusOnInit) {
        this.focus();
      }
    }
    destroy() {
      var _a13;
      this.subs.forEach((s) => s.destroy());
      this.focusSubscription.destroy();
      (_a13 = this.focusOutActionDestructor) == null ? void 0 : _a13.call(this);
      if (this._isFocused.get()) {
        Coherent.trigger("UNFOCUS_INPUT_FIELD", this.uuid);
        Coherent.off("mousePressOutsideView", this.dispatchFocusOutEvent);
        Coherent.off("SetInputTextFromOS", this.setValueFromOS);
      }
      this.inputRef.instance.removeEventListener("keydown", this.onKeyDown);
      this.inputRef.instance.removeEventListener("keyup", this.onKeyUp);
      this.inputRef.instance.removeEventListener("keypress", this.onKeyPress);
      this.inputRef.instance.removeEventListener("input", this.onInput);
      Coherent.off("RELOAD_LOCALISATION", this.reloadLocalisation);
      super.destroy();
    }
  };
  __name(_Input, "Input");
  var Input = _Input;
  var addIconPath = "coui://html_ui/efb_ui/efb_os/Assets/icons/NoMargin/Close.svg";
  var _TextBox = class _TextBox extends GamepadUiComponent {
    constructor() {
      var _a13, _b;
      super(...arguments);
      this.subscriptions = [];
      this.inputRef = import_msfs_sdk.FSComponent.createRef();
      this.model = this.props.model || import_msfs_sdk.Subject.create(import_msfs_sdk.SubscribableUtils.toSubscribable(this.props.value || "", true).get());
      this.hideDeleteTextButton = import_msfs_sdk.Subject.create(true);
      this.onDelete = this._onDelete.bind(this);
      this.onmousedown = (e) => {
        e.preventDefault();
        if (!this.inputRef.instance.isFocused.get()) {
          this.inputRef.instance.focus();
        }
      };
      this.prefix = import_msfs_sdk.SubscribableUtils.toSubscribable(
        this.props.prefix || "",
        true
      );
      this.suffix = import_msfs_sdk.SubscribableUtils.toSubscribable(
        this.props.suffix || "",
        true
      );
      this.showPrefix = import_msfs_sdk.SubscribableUtils.toSubscribable((_a13 = this.props.showPrefix) != null ? _a13 : true, true);
      this.showSuffix = import_msfs_sdk.SubscribableUtils.toSubscribable((_b = this.props.showSuffix) != null ? _b : true, true);
      this.prefixRef = import_msfs_sdk.FSComponent.createRef();
      this.suffixRef = import_msfs_sdk.FSComponent.createRef();
      this.showPrefixOrSuffixMapFunction = ([value2, show]) => {
        return !show || value2.toString().length === 0;
      };
    }
    _onDelete(event) {
      var _a13, _b;
      event.preventDefault();
      this.hideDeleteTextButton.set(true);
      this.inputRef.instance.clearInput();
      (_b = (_a13 = this.props).onDelete) == null ? void 0 : _b.call(_a13);
      if (this.props.focusOnClear) {
        this.inputRef.instance.focus();
      }
    }
    onInput(input) {
      var _a13, _b;
      (_b = (_a13 = this.props).onInput) == null ? void 0 : _b.call(_a13, input);
      if (this.props.showDeleteIcon) {
        this.hideDeleteTextButton.set(input.value.trim().length === 0);
      }
    }
    onFocusIn() {
      var _a13, _b;
      (_b = (_a13 = this.props).onFocusIn) == null ? void 0 : _b.call(_a13);
      this.gamepadUiComponentRef.instance.classList.add("textbox--focused");
    }
    onFocusOut() {
      var _a13, _b;
      (_b = (_a13 = this.props).onFocusOut) == null ? void 0 : _b.call(_a13);
      this.gamepadUiComponentRef.instance.classList.remove("textbox--focused");
    }
    render() {
      return /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent("div", { ref: this.gamepadUiComponentRef, class: "textbox" }, /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent("div", { class: "disabled-layer" }), /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent(
        "div",
        {
          ref: this.prefixRef,
          class: {
            prefix: true,
            "prefix--hidden": import_msfs_sdk.MappedSubject.create(this.prefix, this.showPrefix).map(
              this.showPrefixOrSuffixMapFunction
            )
          }
        }
      ), /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent(
        Input,
        {
          ref: this.inputRef,
          type: "text",
          align: this.props.align,
          model: this.model,
          placeholder: this.props.placeholder,
          disabled: this.props.disabled,
          hidePlaceholderOnFocus: this.props.hidePlaceholderOnFocus,
          focusOnInit: this.props.focusOnInit,
          onFocusIn: this.onFocusIn.bind(this),
          onFocusOut: this.onFocusOut.bind(this),
          onInput: this.onInput.bind(this),
          onValueValidated: this.props.onValueValidated,
          debounceDuration: this.props.debounceDuration,
          onKeyDown: this.props.onKeyDown,
          onKeyUp: this.props.onKeyUp,
          onKeyPress: this.props.onKeyPress,
          charFilter: this.props.charFilter
        }
      ), /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent(
        "div",
        {
          ref: this.suffixRef,
          class: {
            suffix: true,
            "suffix--hidden": import_msfs_sdk.MappedSubject.create(this.suffix, this.showSuffix).map(
              this.showPrefixOrSuffixMapFunction
            )
          }
        }
      ), this.props.showDeleteIcon && /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent(
        IconButton,
        {
          class: mergeClassProp("delete-text-button", { hide: this.hideDeleteTextButton }),
          iconPath: addIconPath,
          callback: this.onDelete
        }
      ));
    }
    onAfterRender(node) {
      super.onAfterRender(node);
      const prefixSuffixCb = /* @__PURE__ */ __name((reference) => {
        let previousNode = null;
        return (value2) => {
          if (previousNode) {
            import_msfs_sdk.FSComponent.shallowDestroy(previousNode);
            const instance = previousNode.instance;
            if (instance && instance instanceof import_msfs_sdk.DisplayComponent) {
              instance.destroy();
            }
            previousNode = null;
          }
          if (typeof value2 === "string") {
            reference.instance.innerText = value2;
          } else if (typeof value2 === "object" && isVNode(value2)) {
            previousNode = value2;
            reference.instance.innerHTML = "";
            import_msfs_sdk.FSComponent.render(value2, reference.instance);
          } else {
            reference.instance.innerText = value2;
          }
        };
      }, "prefixSuffixCb");
      this.subscriptions.push(
        this.prefix.sub(prefixSuffixCb(this.prefixRef), true),
        this.suffix.sub(prefixSuffixCb(this.suffixRef), true)
      );
      this.gamepadUiComponentRef.instance.addEventListener("mousedown", this.onmousedown);
    }
    destroy() {
      this.gamepadUiComponentRef.instance.removeEventListener("mousedown", this.onmousedown);
      this.subscriptions.forEach((s) => s.destroy());
      super.destroy();
    }
  };
  __name(_TextBox, "TextBox");
  var TextBox = _TextBox;
  var _a6;
  var _UnitBox = (_a6 = class extends GamepadUiComponent {
    constructor() {
      var _a13, _b;
      super(...arguments);
      this.valueNumber = this.props.value;
      this.unit = import_msfs_sdk.SubscribableUtils.toSubscribable((_a13 = this.props.unit) != null ? _a13 : null, true);
      this.showUnitSuffix = import_msfs_sdk.SubscribableUtils.toSubscribable((_b = this.props.showSuffix) != null ? _b : true, true);
      this.textValue = import_msfs_sdk.Subject.create("0");
      this.formattedTextValue = import_msfs_sdk.Subject.create("0");
      this.subs = [];
      this.canUpdateDisplay = true;
      this.suffixSmall = import_msfs_sdk.Subject.create("");
      this.suffixBig = import_msfs_sdk.Subject.create("");
    }
    static createDefaultUnitTextMap() {
      const originalMap = UnitFormatter.getUnitTextMap();
      const map = {};
      for (const family in originalMap) {
        const nameMap = map[family] = {};
        const originalNameMap = originalMap[family];
        for (const name in originalNameMap) {
          const text = nameMap[name] = ["", ""];
          const originalText = originalNameMap[name];
          if (originalText[0].startsWith("\xB0")) {
            text[0] = "\xB0";
            text[1] = originalText.substring(1);
          } else {
            text[1] = originalText;
          }
        }
      }
      return map;
    }
    setValue(value2, displayUnit) {
      var _a13;
      if (!displayUnit || !value2.unit.canConvert(displayUnit)) {
        displayUnit = value2.unit;
      }
      let numberValue = value2.asUnit(displayUnit);
      if (this.props.min && numberValue < this.props.min.asUnit(displayUnit)) {
        numberValue = this.props.min.asUnit(displayUnit);
      }
      if (this.props.max && numberValue > this.props.max.asUnit(displayUnit)) {
        numberValue = this.props.max.asUnit(displayUnit);
      }
      if (numberValue >= 9999999) {
        this.textValue.set("9999999");
        return;
      }
      const numberText = import_msfs_sdk.NumberFormatter.create(__spreadValues({
        nanString: "0"
      }, (_a13 = this.props.numberFormatterOptions) != null ? _a13 : {}))(numberValue);
      if (numberText.includes(".")) {
        const dotPos = numberText.indexOf(".");
        this.textValue.set(numberText.substring(0, dotPos + 3));
      } else {
        this.textValue.set(this.textValue.get().includes(".") ? `${numberText}.` : numberText);
      }
      const unitTexts = _a6.DEFAULT_UNIT_FORMATTER(displayUnit);
      if (unitTexts === null) {
        this.suffixSmall.set("");
        this.suffixBig.set("");
        return;
      }
      this.suffixSmall.set(unitTexts[0]);
      this.suffixBig.set(unitTexts[1]);
    }
    updateDisplay() {
      var _a13, _b;
      (_b = (_a13 = this.props).onFocusOut) == null ? void 0 : _b.call(_a13);
      if (this.canUpdateDisplay) {
        this.formattedTextValue.set(this.textValue.get());
      }
    }
    render() {
      return /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent(
        "div",
        {
          ref: this.gamepadUiComponentRef,
          class: { unitbox: true, "unitbox--disabled": this.props.disabled || false }
        },
        /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent(
          TextBox,
          {
            align: "right",
            showDeleteIcon: this.props.showDeleteIcon || false,
            customDeleteIcon: this.props.customDeleteIcon,
            focusOnClear: this.props.focusOnClear,
            onDelete: this.props.onDelete,
            model: this.formattedTextValue,
            placeholder: this.props.placeholder,
            hidePlaceholderOnFocus: this.props.hidePlaceholderOnFocus,
            disabled: this.props.disabled,
            focusOnInit: this.props.focusOnInit,
            onFocusIn: this.props.onFocusIn,
            onFocusOut: this.updateDisplay.bind(this),
            onInput: this.props.onInput,
            onKeyPress: this.props.onKeyPress,
            charFilter: /* @__PURE__ */ __name((char) => char >= "0" && char <= "9" || [",", ".", "-"].includes(char), "charFilter"),
            suffix: /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent(import_msfs_sdk.FSComponent.Fragment, null, /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent("span", null, this.suffixSmall), /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent("span", null, this.suffixBig)),
            showSuffix: this.showUnitSuffix
          }
        )
      );
    }
    onAfterRender(node) {
      super.onAfterRender(node);
      this.subs.push(
        this.formattedTextValue.sub((value2) => {
          value2 = value2.replace(",", ".").replace(/\.+$/, "");
          let displayUnit = this.unit.get();
          if (!displayUnit || !this.valueNumber.get().unit.canConvert(displayUnit)) {
            displayUnit = this.valueNumber.get().unit;
          }
          const unitValue = displayUnit.convertTo(Number(value2), this.valueNumber.get().unit);
          this.canUpdateDisplay = false;
          this.valueNumber.set(unitValue);
          this.canUpdateDisplay = true;
        }),
        this.valueNumber.sub((value2) => {
          this.setValue(value2, this.unit.get());
          this.updateDisplay();
        }, true),
        this.unit.sub((unit) => {
          this.setValue(this.valueNumber.get(), unit);
          this.updateDisplay();
        }, true)
      );
    }
    destroy() {
      this.subs.forEach((s) => s.destroy());
      super.destroy();
    }
  }, __name(_a6, "_UnitBox"), _a6);
  _UnitBox.DEFAULT_UNIT_TEXT_MAP = _UnitBox.createDefaultUnitTextMap();
  _UnitBox.DEFAULT_UNIT_FORMATTER = (unit) => {
    var _a13;
    const text = (_a13 = _UnitBox.DEFAULT_UNIT_TEXT_MAP[unit.family]) == null ? void 0 : _a13[unit.name];
    if (text) {
      return text;
    }
    return null;
  };
  var MapShim = function() {
    if (typeof Map !== "undefined") {
      return Map;
    }
    function getIndex(arr, key) {
      var result = -1;
      arr.some(function(entry, index2) {
        if (entry[0] === key) {
          result = index2;
          return true;
        }
        return false;
      });
      return result;
    }
    __name(getIndex, "getIndex");
    return (
      /** @class */
      function() {
        function class_1() {
          this.__entries__ = [];
        }
        __name(class_1, "class_1");
        Object.defineProperty(class_1.prototype, "size", {
          /**
           * @returns {boolean}
           */
          get: /* @__PURE__ */ __name(function() {
            return this.__entries__.length;
          }, "get"),
          enumerable: true,
          configurable: true
        });
        class_1.prototype.get = function(key) {
          var index2 = getIndex(this.__entries__, key);
          var entry = this.__entries__[index2];
          return entry && entry[1];
        };
        class_1.prototype.set = function(key, value2) {
          var index2 = getIndex(this.__entries__, key);
          if (~index2) {
            this.__entries__[index2][1] = value2;
          } else {
            this.__entries__.push([key, value2]);
          }
        };
        class_1.prototype.delete = function(key) {
          var entries = this.__entries__;
          var index2 = getIndex(entries, key);
          if (~index2) {
            entries.splice(index2, 1);
          }
        };
        class_1.prototype.has = function(key) {
          return !!~getIndex(this.__entries__, key);
        };
        class_1.prototype.clear = function() {
          this.__entries__.splice(0);
        };
        class_1.prototype.forEach = function(callback, ctx) {
          if (ctx === void 0) {
            ctx = null;
          }
          for (var _i = 0, _a13 = this.__entries__; _i < _a13.length; _i++) {
            var entry = _a13[_i];
            callback.call(ctx, entry[1], entry[0]);
          }
        };
        return class_1;
      }()
    );
  }();
  var isBrowser = typeof window !== "undefined" && typeof document !== "undefined" && window.document === document;
  var global$1 = function() {
    if (typeof global !== "undefined" && global.Math === Math) {
      return global;
    }
    if (typeof self !== "undefined" && self.Math === Math) {
      return self;
    }
    if (typeof window !== "undefined" && window.Math === Math) {
      return window;
    }
    return Function("return this")();
  }();
  var requestAnimationFrame$1 = function() {
    if (typeof requestAnimationFrame === "function") {
      return requestAnimationFrame.bind(global$1);
    }
    return function(callback) {
      return setTimeout(function() {
        return callback(Date.now());
      }, 1e3 / 60);
    };
  }();
  var trailingTimeout = 2;
  function throttle(callback, delay) {
    var leadingCall = false, trailingCall = false, lastCallTime = 0;
    function resolvePending() {
      if (leadingCall) {
        leadingCall = false;
        callback();
      }
      if (trailingCall) {
        proxy();
      }
    }
    __name(resolvePending, "resolvePending");
    function timeoutCallback() {
      requestAnimationFrame$1(resolvePending);
    }
    __name(timeoutCallback, "timeoutCallback");
    function proxy() {
      var timeStamp = Date.now();
      if (leadingCall) {
        if (timeStamp - lastCallTime < trailingTimeout) {
          return;
        }
        trailingCall = true;
      } else {
        leadingCall = true;
        trailingCall = false;
        setTimeout(timeoutCallback, delay);
      }
      lastCallTime = timeStamp;
    }
    __name(proxy, "proxy");
    return proxy;
  }
  __name(throttle, "throttle");
  var REFRESH_DELAY = 20;
  var transitionKeys = ["top", "right", "bottom", "left", "width", "height", "size", "weight"];
  var mutationObserverSupported = typeof MutationObserver !== "undefined";
  var ResizeObserverController = (
    /** @class */
    function() {
      function ResizeObserverController2() {
        this.connected_ = false;
        this.mutationEventsAdded_ = false;
        this.mutationsObserver_ = null;
        this.observers_ = [];
        this.onTransitionEnd_ = this.onTransitionEnd_.bind(this);
        this.refresh = throttle(this.refresh.bind(this), REFRESH_DELAY);
      }
      __name(ResizeObserverController2, "ResizeObserverController2");
      ResizeObserverController2.prototype.addObserver = function(observer) {
        if (!~this.observers_.indexOf(observer)) {
          this.observers_.push(observer);
        }
        if (!this.connected_) {
          this.connect_();
        }
      };
      ResizeObserverController2.prototype.removeObserver = function(observer) {
        var observers2 = this.observers_;
        var index2 = observers2.indexOf(observer);
        if (~index2) {
          observers2.splice(index2, 1);
        }
        if (!observers2.length && this.connected_) {
          this.disconnect_();
        }
      };
      ResizeObserverController2.prototype.refresh = function() {
        var changesDetected = this.updateObservers_();
        if (changesDetected) {
          this.refresh();
        }
      };
      ResizeObserverController2.prototype.updateObservers_ = function() {
        var activeObservers = this.observers_.filter(function(observer) {
          return observer.gatherActive(), observer.hasActive();
        });
        activeObservers.forEach(function(observer) {
          return observer.broadcastActive();
        });
        return activeObservers.length > 0;
      };
      ResizeObserverController2.prototype.connect_ = function() {
        if (!isBrowser || this.connected_) {
          return;
        }
        document.addEventListener("transitionend", this.onTransitionEnd_);
        window.addEventListener("resize", this.refresh);
        if (mutationObserverSupported) {
          this.mutationsObserver_ = new MutationObserver(this.refresh);
          this.mutationsObserver_.observe(document, {
            attributes: true,
            childList: true,
            characterData: true,
            subtree: true
          });
        } else {
          document.addEventListener("DOMSubtreeModified", this.refresh);
          this.mutationEventsAdded_ = true;
        }
        this.connected_ = true;
      };
      ResizeObserverController2.prototype.disconnect_ = function() {
        if (!isBrowser || !this.connected_) {
          return;
        }
        document.removeEventListener("transitionend", this.onTransitionEnd_);
        window.removeEventListener("resize", this.refresh);
        if (this.mutationsObserver_) {
          this.mutationsObserver_.disconnect();
        }
        if (this.mutationEventsAdded_) {
          document.removeEventListener("DOMSubtreeModified", this.refresh);
        }
        this.mutationsObserver_ = null;
        this.mutationEventsAdded_ = false;
        this.connected_ = false;
      };
      ResizeObserverController2.prototype.onTransitionEnd_ = function(_a13) {
        var _b = _a13.propertyName, propertyName = _b === void 0 ? "" : _b;
        var isReflowProperty = transitionKeys.some(function(key) {
          return !!~propertyName.indexOf(key);
        });
        if (isReflowProperty) {
          this.refresh();
        }
      };
      ResizeObserverController2.getInstance = function() {
        if (!this.instance_) {
          this.instance_ = new ResizeObserverController2();
        }
        return this.instance_;
      };
      ResizeObserverController2.instance_ = null;
      return ResizeObserverController2;
    }()
  );
  var defineConfigurable = /* @__PURE__ */ __name(function(target, props) {
    for (var _i = 0, _a13 = Object.keys(props); _i < _a13.length; _i++) {
      var key = _a13[_i];
      Object.defineProperty(target, key, {
        value: props[key],
        enumerable: false,
        writable: false,
        configurable: true
      });
    }
    return target;
  }, "defineConfigurable");
  var getWindowOf = /* @__PURE__ */ __name(function(target) {
    var ownerGlobal = target && target.ownerDocument && target.ownerDocument.defaultView;
    return ownerGlobal || global$1;
  }, "getWindowOf");
  var emptyRect = createRectInit(0, 0, 0, 0);
  function toFloat(value2) {
    return parseFloat(value2) || 0;
  }
  __name(toFloat, "toFloat");
  function getBordersSize(styles) {
    var positions = [];
    for (var _i = 1; _i < arguments.length; _i++) {
      positions[_i - 1] = arguments[_i];
    }
    return positions.reduce(function(size, position) {
      var value2 = styles["border-" + position + "-width"];
      return size + toFloat(value2);
    }, 0);
  }
  __name(getBordersSize, "getBordersSize");
  function getPaddings(styles) {
    var positions = ["top", "right", "bottom", "left"];
    var paddings = {};
    for (var _i = 0, positions_1 = positions; _i < positions_1.length; _i++) {
      var position = positions_1[_i];
      var value2 = styles["padding-" + position];
      paddings[position] = toFloat(value2);
    }
    return paddings;
  }
  __name(getPaddings, "getPaddings");
  function getSVGContentRect(target) {
    var bbox = target.getBBox();
    return createRectInit(0, 0, bbox.width, bbox.height);
  }
  __name(getSVGContentRect, "getSVGContentRect");
  function getHTMLElementContentRect(target) {
    var clientWidth = target.clientWidth, clientHeight = target.clientHeight;
    if (!clientWidth && !clientHeight) {
      return emptyRect;
    }
    var styles = getWindowOf(target).getComputedStyle(target);
    var paddings = getPaddings(styles);
    var horizPad = paddings.left + paddings.right;
    var vertPad = paddings.top + paddings.bottom;
    var width = toFloat(styles.width), height = toFloat(styles.height);
    if (styles.boxSizing === "border-box") {
      if (Math.round(width + horizPad) !== clientWidth) {
        width -= getBordersSize(styles, "left", "right") + horizPad;
      }
      if (Math.round(height + vertPad) !== clientHeight) {
        height -= getBordersSize(styles, "top", "bottom") + vertPad;
      }
    }
    if (!isDocumentElement(target)) {
      var vertScrollbar = Math.round(width + horizPad) - clientWidth;
      var horizScrollbar = Math.round(height + vertPad) - clientHeight;
      if (Math.abs(vertScrollbar) !== 1) {
        width -= vertScrollbar;
      }
      if (Math.abs(horizScrollbar) !== 1) {
        height -= horizScrollbar;
      }
    }
    return createRectInit(paddings.left, paddings.top, width, height);
  }
  __name(getHTMLElementContentRect, "getHTMLElementContentRect");
  var isSVGGraphicsElement = function() {
    if (typeof SVGGraphicsElement !== "undefined") {
      return function(target) {
        return target instanceof getWindowOf(target).SVGGraphicsElement;
      };
    }
    return function(target) {
      return target instanceof getWindowOf(target).SVGElement && typeof target.getBBox === "function";
    };
  }();
  function isDocumentElement(target) {
    return target === getWindowOf(target).document.documentElement;
  }
  __name(isDocumentElement, "isDocumentElement");
  function getContentRect(target) {
    if (!isBrowser) {
      return emptyRect;
    }
    if (isSVGGraphicsElement(target)) {
      return getSVGContentRect(target);
    }
    return getHTMLElementContentRect(target);
  }
  __name(getContentRect, "getContentRect");
  function createReadOnlyRect(_a13) {
    var x = _a13.x, y = _a13.y, width = _a13.width, height = _a13.height;
    var Constr = typeof DOMRectReadOnly !== "undefined" ? DOMRectReadOnly : Object;
    var rect = Object.create(Constr.prototype);
    defineConfigurable(rect, {
      x,
      y,
      width,
      height,
      top: y,
      right: x + width,
      bottom: height + y,
      left: x
    });
    return rect;
  }
  __name(createReadOnlyRect, "createReadOnlyRect");
  function createRectInit(x, y, width, height) {
    return { x, y, width, height };
  }
  __name(createRectInit, "createRectInit");
  var ResizeObservation = (
    /** @class */
    function() {
      function ResizeObservation2(target) {
        this.broadcastWidth = 0;
        this.broadcastHeight = 0;
        this.contentRect_ = createRectInit(0, 0, 0, 0);
        this.target = target;
      }
      __name(ResizeObservation2, "ResizeObservation2");
      ResizeObservation2.prototype.isActive = function() {
        var rect = getContentRect(this.target);
        this.contentRect_ = rect;
        return rect.width !== this.broadcastWidth || rect.height !== this.broadcastHeight;
      };
      ResizeObservation2.prototype.broadcastRect = function() {
        var rect = this.contentRect_;
        this.broadcastWidth = rect.width;
        this.broadcastHeight = rect.height;
        return rect;
      };
      return ResizeObservation2;
    }()
  );
  var ResizeObserverEntry = (
    /** @class */
    /* @__PURE__ */ function() {
      function ResizeObserverEntry2(target, rectInit) {
        var contentRect = createReadOnlyRect(rectInit);
        defineConfigurable(this, { target, contentRect });
      }
      __name(ResizeObserverEntry2, "ResizeObserverEntry2");
      return ResizeObserverEntry2;
    }()
  );
  var ResizeObserverSPI = (
    /** @class */
    function() {
      function ResizeObserverSPI2(callback, controller, callbackCtx) {
        this.activeObservations_ = [];
        this.observations_ = new MapShim();
        if (typeof callback !== "function") {
          throw new TypeError("The callback provided as parameter 1 is not a function.");
        }
        this.callback_ = callback;
        this.controller_ = controller;
        this.callbackCtx_ = callbackCtx;
      }
      __name(ResizeObserverSPI2, "ResizeObserverSPI2");
      ResizeObserverSPI2.prototype.observe = function(target) {
        if (!arguments.length) {
          throw new TypeError("1 argument required, but only 0 present.");
        }
        if (typeof Element === "undefined" || !(Element instanceof Object)) {
          return;
        }
        if (!(target instanceof getWindowOf(target).Element)) {
          throw new TypeError('parameter 1 is not of type "Element".');
        }
        var observations = this.observations_;
        if (observations.has(target)) {
          return;
        }
        observations.set(target, new ResizeObservation(target));
        this.controller_.addObserver(this);
        this.controller_.refresh();
      };
      ResizeObserverSPI2.prototype.unobserve = function(target) {
        if (!arguments.length) {
          throw new TypeError("1 argument required, but only 0 present.");
        }
        if (typeof Element === "undefined" || !(Element instanceof Object)) {
          return;
        }
        if (!(target instanceof getWindowOf(target).Element)) {
          throw new TypeError('parameter 1 is not of type "Element".');
        }
        var observations = this.observations_;
        if (!observations.has(target)) {
          return;
        }
        observations.delete(target);
        if (!observations.size) {
          this.controller_.removeObserver(this);
        }
      };
      ResizeObserverSPI2.prototype.disconnect = function() {
        this.clearActive();
        this.observations_.clear();
        this.controller_.removeObserver(this);
      };
      ResizeObserverSPI2.prototype.gatherActive = function() {
        var _this = this;
        this.clearActive();
        this.observations_.forEach(function(observation) {
          if (observation.isActive()) {
            _this.activeObservations_.push(observation);
          }
        });
      };
      ResizeObserverSPI2.prototype.broadcastActive = function() {
        if (!this.hasActive()) {
          return;
        }
        var ctx = this.callbackCtx_;
        var entries = this.activeObservations_.map(function(observation) {
          return new ResizeObserverEntry(observation.target, observation.broadcastRect());
        });
        this.callback_.call(ctx, entries, ctx);
        this.clearActive();
      };
      ResizeObserverSPI2.prototype.clearActive = function() {
        this.activeObservations_.splice(0);
      };
      ResizeObserverSPI2.prototype.hasActive = function() {
        return this.activeObservations_.length > 0;
      };
      return ResizeObserverSPI2;
    }()
  );
  var observers = typeof WeakMap !== "undefined" ? /* @__PURE__ */ new WeakMap() : new MapShim();
  var ResizeObserver = (
    /** @class */
    /* @__PURE__ */ function() {
      function ResizeObserver2(callback) {
        if (!(this instanceof ResizeObserver2)) {
          throw new TypeError("Cannot call a class as a function.");
        }
        if (!arguments.length) {
          throw new TypeError("1 argument required, but only 0 present.");
        }
        var controller = ResizeObserverController.getInstance();
        var observer = new ResizeObserverSPI(callback, controller, this);
        observers.set(this, observer);
      }
      __name(ResizeObserver2, "ResizeObserver2");
      return ResizeObserver2;
    }()
  );
  [
    "observe",
    "unobserve",
    "disconnect"
  ].forEach(function(method) {
    ResizeObserver.prototype[method] = function() {
      var _a13;
      return (_a13 = observers.get(this))[method].apply(_a13, arguments);
    };
  });
  var index = function() {
    if (typeof global$1.ResizeObserver !== "undefined") {
      return global$1.ResizeObserver;
    }
    return ResizeObserver;
  }();
  var _a7;
  var _NumberUnitDisplay = (_a7 = class extends import_msfs_sdk.AbstractNumberUnitDisplay {
    constructor() {
      var _a13, _b;
      super(...arguments);
      this.formatter = (_a13 = this.props.formatter) != null ? _a13 : import_msfs_sdk.NumberFormatter.create({
        // TODO Properly format the time
        precision: 0.01,
        maxDigits: 5,
        forceDecimalZeroes: false,
        nanString: "0"
      });
      this.unitFormatter = (_b = this.props.unitFormatter) != null ? _b : _a7.DEFAULT_UNIT_FORMATTER;
      this.unitTextBigDisplay = import_msfs_sdk.Subject.create("");
      this.unitTextSmallDisplay = import_msfs_sdk.Subject.create("");
      this.numberText = import_msfs_sdk.Subject.create("");
      this.unitTextBig = import_msfs_sdk.Subject.create("");
      this.unitTextSmall = import_msfs_sdk.Subject.create("");
    }
    /** @inheritdoc */
    onValueChanged(value2) {
      this.updateDisplay(value2, this.displayUnit.get());
    }
    /** @inheritdoc */
    onDisplayUnitChanged(displayUnit) {
      this.updateDisplay(this.value.get(), displayUnit);
    }
    /**
     * Updates this component's displayed number and unit text.
     * @param value The value to display.
     * @param displayUnit The unit type in which to display the value, or `null` if the value should be displayed in its
     * native unit type.
     */
    updateDisplay(value2, displayUnit) {
      if (!displayUnit || !value2.unit.canConvert(displayUnit)) {
        displayUnit = value2.unit;
      }
      const numberValue = value2.asUnit(displayUnit);
      const numberText = this.formatter(numberValue);
      this.numberText.set(numberText);
      _a7.unitTextCache[0] = "";
      _a7.unitTextCache[1] = "";
      this.unitFormatter(_a7.unitTextCache, displayUnit, numberValue);
      this.unitTextBig.set(_a7.unitTextCache[0]);
      this.unitTextSmall.set(_a7.unitTextCache[1]);
      this.updateUnitTextVisibility(
        numberValue,
        _a7.unitTextCache[0],
        _a7.unitTextCache[1]
      );
    }
    /**
     * Updates whether this component's unit text spans are visible.
     * @param numberValue The numeric value displayed by this component.
     * @param unitTextBig The text to display in the big text span.
     * @param unitTextSmall The text to display in the small text span.
     */
    updateUnitTextVisibility(numberValue, unitTextBig, unitTextSmall) {
      if (this.props.hideUnitWhenNaN === true && isNaN(numberValue)) {
        this.unitTextBigDisplay.set("none");
        this.unitTextSmallDisplay.set("none");
        return;
      }
      this.unitTextBigDisplay.set(unitTextBig === "" ? "none" : "");
      this.unitTextSmallDisplay.set(unitTextSmall === "" ? "none" : "");
    }
    /**
     * Creates the default mapping from unit to displayed text.
     * @returns The default mapping from unit to displayed text.
     */
    static createDefaultUnitTextMap() {
      const originalMap = UnitFormatter.getUnitTextMap();
      const map = {};
      for (const family in originalMap) {
        const nameMap = map[family] = {};
        const originalNameMap = originalMap[family];
        for (const name in originalNameMap) {
          const text = nameMap[name] = ["", ""];
          const originalText = originalNameMap[name];
          if (originalText[0] === "\xB0") {
            text[0] = "\xB0";
            text[1] = originalText.substring(1);
          } else {
            text[1] = originalText;
          }
        }
      }
      return map;
    }
    render() {
      var _a13;
      return /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent("div", { class: (_a13 = this.props.class) != null ? _a13 : "", style: "white-space: nowrap;" }, /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent("span", { class: "numberunit-num" }, this.numberText), /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent("span", { class: "numberunit-unit-big", style: { display: this.unitTextBigDisplay } }, this.unitTextBig), /* @__PURE__ */ import_msfs_sdk.FSComponent.buildComponent("span", { class: "numberunit-unit-small", style: { display: this.unitTextSmallDisplay } }, this.unitTextSmall));
    }
  }, __name(_a7, "_NumberUnitDisplay"), _a7);
  _NumberUnitDisplay.DEFAULT_UNIT_TEXT_MAP = _NumberUnitDisplay.createDefaultUnitTextMap();
  _NumberUnitDisplay.DEFAULT_UNIT_FORMATTER = (out, unit) => {
    var _a13;
    const text = (_a13 = _NumberUnitDisplay.DEFAULT_UNIT_TEXT_MAP[unit.family]) == null ? void 0 : _a13[unit.name];
    if (text) {
      out[0] = text[0];
      out[1] = text[1];
    }
  };
  _NumberUnitDisplay.unitTextCache = ["", ""];
  var _a8;
  var _FacilitySearchUtils = (_a8 = class {
    constructor(bus) {
      this.facilityLoader = null;
      this.position = new import_msfs_sdk.GeoPoint(0, 0);
      bus.getSubscriber().on("gps-position").handle((pos) => {
        this.position.set(pos.lat, pos.long);
      });
      this.facilityLoader = new import_msfs_sdk.FacilityLoader(import_msfs_sdk.FacilityRepository.getRepository(bus));
    }
    static getSearchUtils(bus) {
      var _a13;
      return (_a13 = _a8.INSTANCE) != null ? _a13 : _a8.INSTANCE = new _a8(bus);
    }
    orderByIdentsAndDistance(a, b) {
      const aIdent = a.icaoStruct.ident.trim();
      const bIdent = b.icaoStruct.ident.trim();
      if (aIdent === bIdent) {
        const aDist = this.position.distance(a.lat, a.lon);
        const bDist = this.position.distance(b.lat, b.lon);
        return aDist - bDist;
      } else {
        return aIdent.localeCompare(bIdent);
      }
    }
    /**
     * Loads facilities based on an ident to search for, a search type and whether to exclude terminal facilities
     * @param ident The ident to search for
     * @param facilitySearchType The search type. Defaults to {@link FacilitySearchType.All}
     * @param excludeTerminalFacilities Whether to exclude terminal facilities. Defaults to `true`.
     * @returns a readonly array of facilities
     */
    async loadFacilities(ident, facilitySearchType = import_msfs_sdk.FacilitySearchType.All, excludeTerminalFacilities = true) {
      if (this.facilityLoader === null) {
        return Promise.resolve([]);
      }
      const icaos = await this.facilityLoader.searchByIdentWithIcaoStructs(facilitySearchType, ident, 15);
      const facilities = (await this.facilityLoader.getFacilities(icaos)).filter(
        (fac) => fac !== null && (!excludeTerminalFacilities || fac.icaoStruct.airport.length === 0)
      );
      facilities.sort((a, b) => this.orderByIdentsAndDistance(a, b));
      return facilities;
    }
  }, __name(_a8, "_FacilitySearchUtils"), _a8);
  _FacilitySearchUtils.INSTANCE = null;
  var _a9;
  var _SearchFacilityHistoryManager = (_a9 = class {
    constructor() {
      this.MAX_ITEMS_STORED = 5;
      this.storedICAOs = import_msfs_sdk.ArraySubject.create();
      this.loadICAOsFromStorage();
    }
    /**
     * Retrieves all the stored recent searches
     */
    loadICAOsFromStorage() {
      let arrayICAOs = [];
      const stringICAOs = import_msfs_sdk.DataStore.get(_a9.DATASTORE_KEY);
      if (stringICAOs === void 0 || typeof stringICAOs !== "string") {
        this.storedICAOs.set(arrayICAOs);
        return;
      }
      try {
        arrayICAOs = JSON.parse(stringICAOs);
      } catch (e) {
        console.error("JSON failed, impossible to parse : ", stringICAOs);
      }
      this.storedICAOs.set(arrayICAOs);
    }
    saveICAOsToStorage() {
      const stringICAOs = JSON.stringify(this.storedICAOs.getArray());
      import_msfs_sdk.DataStore.set(_a9.DATASTORE_KEY, stringICAOs);
    }
    mostRecentSearch(icao) {
      const foundIndex = this.storedICAOs.getArray().findIndex((storedIcao) => storedIcao === icao);
      if (foundIndex !== -1) {
        this.storedICAOs.removeAt(foundIndex);
      }
      this.storedICAOs.insert(icao, 0);
      while (this.storedICAOs.length > this.MAX_ITEMS_STORED) {
        this.storedICAOs.removeAt(this.MAX_ITEMS_STORED);
      }
      this.saveICAOsToStorage();
    }
    /**
     * Retrieve the search facility history as an array
     * @param input the input of the search
     * @param max_items the maximum number of items returned
     * @returns the recent searches as an array of icaos
     */
    getStoredICAOs(input, max_items = this.MAX_ITEMS_STORED) {
      this.loadICAOsFromStorage();
      return this.storedICAOs.getArray().filter((icao) => import_msfs_sdk.ICAO.getIdent(icao).startsWith(input.toUpperCase())).slice(0, max_items);
    }
  }, __name(_a9, "_SearchFacilityHistoryManager"), _a9);
  _SearchFacilityHistoryManager.DATASTORE_KEY = "efb.search-bar-history";
  var _a10;
  var _OnboardingManager = (_a10 = class {
    constructor() {
      this.isStarted = false;
      this.stepIndex = 0;
      this.steps = [];
    }
    static getManager() {
      var _a13;
      return (_a13 = _a10.INSTANCE) != null ? _a13 : _a10.INSTANCE = new _a10();
    }
    bindContainer(containerRef) {
      _a10.getManager().containerRef = containerRef;
    }
    start(onboarding) {
      const onboardingManager = _a10.getManager();
      onboardingManager.steps = onboarding.steps.map((step) => {
        return __spreadProps(__spreadValues({}, step), { actions: [...step.actions] });
      });
      if (!onboardingManager.containerRef) {
        console.warn("Onboarding container not bound");
        return;
      }
      if (!onboardingManager.steps.length) {
        console.warn("No onboarding steps provided");
        return;
      }
      if (onboardingManager.isStarted) {
        console.warn("Onboarding already started");
        return;
      }
      onboardingManager.stepIndex = 0;
      onboardingManager.isStarted = true;
      onboardingManager.onFinish = onboarding.onFinish;
      onboardingManager.steps[onboardingManager.stepIndex].actions.unshift(
        {
          key: "@fs-base-efb,TT:EFB.COMMON.QUICK_TOUR_AROUND",
          callback: /* @__PURE__ */ __name(() => {
            onboardingManager.next();
          }, "callback")
        },
        {
          key: "@fs-base-efb,TT:EFB.COMMON.SKIP",
          callback: /* @__PURE__ */ __name(() => {
            onboardingManager.stop();
          }, "callback")
        }
      );
      onboardingManager.containerRef.instance.show();
      onboardingManager.containerRef.instance.setStep(onboardingManager.steps[onboardingManager.stepIndex]);
      onboardingManager.stepIndex++;
      return;
    }
    next() {
      var _a13;
      const onboardingManager = _a10.getManager();
      if (!onboardingManager.isStarted) {
        console.warn("Onboarding not started. You should call start method first");
        return;
      }
      if (onboardingManager.stepIndex >= onboardingManager.steps.length) {
        onboardingManager.stop();
        return;
      }
      onboardingManager.steps[onboardingManager.stepIndex].actions.unshift({
        key: "@fs-base-efb,TT:EFB.COMMON.NEXT",
        callback: /* @__PURE__ */ __name(() => {
          onboardingManager.next();
        }, "callback")
      });
      (_a13 = onboardingManager.containerRef) == null ? void 0 : _a13.instance.setStep(onboardingManager.steps[onboardingManager.stepIndex]);
      onboardingManager.stepIndex++;
      return;
    }
    stop() {
      var _a13, _b;
      const onboardingManager = _a10.getManager();
      onboardingManager.isStarted = false;
      onboardingManager.steps = [];
      (_a13 = onboardingManager.containerRef) == null ? void 0 : _a13.instance.hide();
      (_b = onboardingManager.onFinish) == null ? void 0 : _b.call(onboardingManager);
    }
  }, __name(_a10, "_OnboardingManager"), _a10);
  _OnboardingManager.INSTANCE = void 0;
  var _a11;
  var _EfbCommonSettingsManager = (_a11 = class extends import_msfs_sdk.DefaultUserSettingManager {
    constructor() {
      super(...arguments);
      this.debounceTimer = new import_msfs_sdk.DebounceTimer();
      this.ignoredForceSaveSettingKeys = [];
    }
    /** @inheritdoc */
    onSettingValueChanged(entry, value2) {
      super.onSettingValueChanged(entry, value2);
      if (!this.ignoredForceSaveSettingKeys.includes(entry.setting.definition.name)) {
        this.debounceTimer.schedule(() => {
          Coherent.trigger("EFB_PERSISTENT_SETTINGS_SAVE");
        }, _a11.debounceTimeout);
      }
    }
  }, __name(_a11, "_EfbCommonSettingsManager"), _a11);
  _EfbCommonSettingsManager.debounceTimeout = 5e3;
  var EfbCommonSettingsManager = _EfbCommonSettingsManager;
  var UnitsNavAngleSettingMode = /* @__PURE__ */ ((UnitsNavAngleSettingMode2) => {
    UnitsNavAngleSettingMode2["Magnetic"] = "magnetic";
    UnitsNavAngleSettingMode2["True"] = "true";
    return UnitsNavAngleSettingMode2;
  })(UnitsNavAngleSettingMode || {});
  var UnitsSpeedSettingMode = /* @__PURE__ */ ((UnitsSpeedSettingMode2) => {
    UnitsSpeedSettingMode2["Nautical"] = "KTS";
    UnitsSpeedSettingMode2["Metric"] = "KPH";
    return UnitsSpeedSettingMode2;
  })(UnitsSpeedSettingMode || {});
  var UnitsDistanceSettingMode = /* @__PURE__ */ ((UnitsDistanceSettingMode2) => {
    UnitsDistanceSettingMode2["Nautical"] = "NM";
    UnitsDistanceSettingMode2["Metric"] = "KM";
    return UnitsDistanceSettingMode2;
  })(UnitsDistanceSettingMode || {});
  var UnitsSmallDistanceSettingMode = /* @__PURE__ */ ((UnitsSmallDistanceSettingMode2) => {
    UnitsSmallDistanceSettingMode2["Feet"] = "FT";
    UnitsSmallDistanceSettingMode2["Meters"] = "M";
    return UnitsSmallDistanceSettingMode2;
  })(UnitsSmallDistanceSettingMode || {});
  var UnitsAltitudeSettingMode = /* @__PURE__ */ ((UnitsAltitudeSettingMode2) => {
    UnitsAltitudeSettingMode2["Feet"] = "FT";
    UnitsAltitudeSettingMode2["Meters"] = "M";
    return UnitsAltitudeSettingMode2;
  })(UnitsAltitudeSettingMode || {});
  var UnitsWeightSettingMode = /* @__PURE__ */ ((UnitsWeightSettingMode2) => {
    UnitsWeightSettingMode2["Pounds"] = "LBS";
    UnitsWeightSettingMode2["Kilograms"] = "KG";
    return UnitsWeightSettingMode2;
  })(UnitsWeightSettingMode || {});
  var UnitsVolumeSettingMode = /* @__PURE__ */ ((UnitsVolumeSettingMode2) => {
    UnitsVolumeSettingMode2["Gallons"] = "GAL US";
    UnitsVolumeSettingMode2["Liters"] = "L";
    return UnitsVolumeSettingMode2;
  })(UnitsVolumeSettingMode || {});
  var UnitsTemperatureSettingMode = /* @__PURE__ */ ((UnitsTemperatureSettingMode2) => {
    UnitsTemperatureSettingMode2["Fahrenheit"] = "\xB0F";
    UnitsTemperatureSettingMode2["Celsius"] = "\xB0C";
    return UnitsTemperatureSettingMode2;
  })(UnitsTemperatureSettingMode || {});
  var UnitsTimeSettingMode = /* @__PURE__ */ ((UnitsTimeSettingMode2) => {
    UnitsTimeSettingMode2["Local12"] = "local-12";
    UnitsTimeSettingMode2["Local24"] = "local-24";
    return UnitsTimeSettingMode2;
  })(UnitsTimeSettingMode || {});
  var _a12;
  var _UnitsSettingsManager = (_a12 = class extends EfbCommonSettingsManager {
    constructor(bus, settingsDefs) {
      super(bus, settingsDefs, true);
      this.navAngleUnitsSub = import_msfs_sdk.Subject.create(_a12.MAGNETIC_BEARING);
      this.navAngleUnits = this.navAngleUnitsSub;
      this.timeUnitsSub = import_msfs_sdk.Subject.create(
        "local-12"
        /* Local12 */
      );
      this._timeUnits = this.timeUnitsSub;
      this.areSubscribablesInit = false;
      this.areSubscribablesInit = true;
      for (const entry of this.settings.values()) {
        this.updateUnitsSubjects(entry.setting.definition.name, entry.setting.value);
      }
    }
    onSettingValueChanged(entry, value2) {
      if (this.areSubscribablesInit) {
        this.updateUnitsSubjects(entry.setting.definition.name, value2);
      }
      super.onSettingValueChanged(entry, value2);
    }
    /**
     * Checks if the values loaded from the datastorage correspond to the settings types.
     */
    checkLoadedValues() {
      checkUserSetting(this.getSetting("unitsNavAngle"), UnitsNavAngleSettingMode);
      checkUserSetting(this.getSetting("unitsSpeed"), UnitsSpeedSettingMode);
      checkUserSetting(this.getSetting("unitsDistance"), UnitsDistanceSettingMode);
      checkUserSetting(this.getSetting("unitsAltitude"), UnitsAltitudeSettingMode);
      checkUserSetting(this.getSetting("unitsSmallDistance"), UnitsSmallDistanceSettingMode);
      checkUserSetting(this.getSetting("unitsWeight"), UnitsWeightSettingMode);
      checkUserSetting(this.getSetting("unitsVolume"), UnitsVolumeSettingMode);
      checkUserSetting(this.getSetting("unitsTemperature"), UnitsTemperatureSettingMode);
      checkUserSetting(this.getSetting("unitsTime"), UnitsTimeSettingMode);
    }
    updateUnitsSubjects(settingName, value2) {
      switch (settingName) {
        case "unitsNavAngle":
          this.navAngleUnitsSub.set(
            value2 === "true" ? _a12.TRUE_BEARING : _a12.MAGNETIC_BEARING
          );
          break;
        case "unitsTime":
          this.timeUnitsSub.set(value2);
          break;
        case "unitsDistance":
          this.getSetting("unitsSmallDistance").set(
            value2 === "NM" ? "FT" : "M"
            /* Meters */
          );
      }
    }
    /**
     * Gets a unit type subscribable from a unit setting name
     * @param settingName the name of the unit setting
     * @returns a Subscribable containing the unit type. If the value in the dataStorage is unvalid, it returns the default unitType
     */
    getSettingUnitType(settingName) {
      const setting = this.getSetting(settingName);
      return setting.map(
        (settingValue) => {
          var _a13;
          return (_a13 = UnitTypesMap[settingValue]) != null ? _a13 : UnitTypesMap[setting.definition.defaultValue];
        }
      );
    }
  }, __name(_a12, "_UnitsSettingsManager"), _a12);
  _UnitsSettingsManager.TRUE_BEARING = import_msfs_sdk.BasicNavAngleUnit.create(false);
  _UnitsSettingsManager.MAGNETIC_BEARING = import_msfs_sdk.BasicNavAngleUnit.create(true);
  var UnitTypesMap = {
    /** Mapped speed unit types */
    KTS: import_msfs_sdk.UnitType.KNOT,
    KPH: import_msfs_sdk.UnitType.KPH,
    /** Mapped distance unit type */
    NM: import_msfs_sdk.UnitType.NMILE,
    KM: import_msfs_sdk.UnitType.KILOMETER,
    /** Mapped altitude unit type */
    FT: import_msfs_sdk.UnitType.FOOT,
    M: import_msfs_sdk.UnitType.METER,
    /** Mapped weight unit type */
    LBS: import_msfs_sdk.UnitType.POUND,
    KG: import_msfs_sdk.UnitType.KILOGRAM,
    /** Mapped volume unit type */
    "GAL US": import_msfs_sdk.UnitType.GALLON,
    L: import_msfs_sdk.UnitType.LITER,
    /** Mapped temperature unit type */
    "\xB0C": import_msfs_sdk.UnitType.CELSIUS,
    "\xB0F": import_msfs_sdk.UnitType.FAHRENHEIT
  };

// src/NavApronEFB.tsx (NavApron app — uses vendor App/Efb/AppView above)
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
const APP_COUI = "coui://html_ui/efb_ui/efb_apps/navapron_efb";
/* NAVAPRON_EFB_RUNTIME_CONFIG_INJECTED */
try{
window.NAVAPRON_EFB_PORT=8765;
window.NAVAPRON_EFB_URLS=['http://192.168.0.193:8765/', 'http://127.0.0.1:8765/', 'http://localhost:8765/'];
window.NAVAPRON_PANEL_URLS=['http://192.168.0.193:8765/', 'http://127.0.0.1:8765/', 'http://localhost:8765/'];
window.NAVAPRON_EFB_PORTS=[8765, 8766, 8767, 8768, 8769, 8770];
window.NAVAPRON_PANEL_PORTS=[8765, 8766, 8767, 8768, 8769, 8770];
}catch(e){}
var __NAVAPRON_EFB_RUNTIME_CONFIG__ = "NAVAPRON_EFB_RUNTIME_CONFIG_INJECTED";
void __NAVAPRON_EFB_RUNTIME_CONFIG__;
function getSimVar() {
  try {
    const g = typeof window !== "undefined" ? window : globalThis;
    if (g.SimVar && typeof g.SimVar.GetSimVarValue === "function") return g.SimVar;
    if (g.simvar && typeof g.simvar.GetSimVarValue === "function") return g.simvar;
    if (typeof g.GetSimVarValue === "function") {
      return { GetSimVarValue: g.GetSimVarValue.bind(g) };
    }
  } catch (_) {
  }
  return null;
}
__name(getSimVar, "getSimVar");
function sv(name, unit) {
  const api = getSimVar();
  if (!api) return NaN;
  try {
    const v = api.GetSimVarValue(name, unit);
    const n = typeof v === "number" ? v : Number(v);
    return Number.isFinite(n) ? n : NaN;
  } catch (_) {
    return NaN;
  }
}
__name(sv, "sv");
function hubCandidates() {
  const urls = [];
  const push = /* @__PURE__ */ __name((u) => {
    let s = (u || "").trim();
    if (!s) return;
    s = s.replace(/\/efb\/?$/i, "/").replace(/\/panel\/?$/i, "/");
    if (!s.endsWith("/")) s += "/";
    if (urls.indexOf(s) < 0) urls.push(s);
  }, "push");
  try {
    const g = typeof window !== "undefined" ? window : globalThis;
    const cfg = (g.NAVAPRON_PANEL_URLS || []).concat(g.NAVAPRON_EFB_URLS || []);
    for (let i = 0; i < cfg.length; i++) push(String(cfg[i]));
    const ports = g.NAVAPRON_PANEL_PORTS || g.NAVAPRON_EFB_PORTS || [8765, 8766, 8767, 8768, 8769, 8770];
    const hosts = ["127.0.0.1", "localhost"];
    for (let j = 0; j < cfg.length; j++) {
      const m = /^https?:\/\/([^/:]+)/i.exec(String(cfg[j]));
      if (m && hosts.indexOf(m[1]) < 0) hosts.unshift(m[1]);
    }
    for (let h = 0; h < hosts.length; h++) {
      for (let p = 0; p < ports.length; p++) push("http://" + hosts[h] + ":" + ports[p] + "/");
    }
  } catch (_) {
    push("http://127.0.0.1:8765/");
  }
  return urls;
}
__name(hubCandidates, "hubCandidates");
function httpJson(url, opts) {
  const method = opts && opts.method || "GET";
  const body = opts && opts.body != null ? JSON.stringify(opts.body) : null;
  const viaXhr = /* @__PURE__ */ __name(() => new Promise((resolve) => {
    try {
      const xhr = new XMLHttpRequest();
      xhr.open(method, url, true);
      xhr.timeout = method === "POST" ? 25e3 : 8e3;
      if (body != null) xhr.setRequestHeader("Content-Type", "application/json");
      xhr.onload = () => {
        let data = null;
        try {
          data = JSON.parse(xhr.responseText || "null");
        } catch (_) {
          data = null;
        }
        const okHttp = xhr.status >= 200 && xhr.status < 300;
        resolve({ ok: okHttp && !(data && data.ok === false), data });
      };
      xhr.onerror = () => resolve({ ok: false, data: null });
      xhr.ontimeout = () => resolve({ ok: false, data: null });
      xhr.send(body);
    } catch (_) {
      resolve({ ok: false, data: null });
    }
  }), "viaXhr");
  const viaFetch = /* @__PURE__ */ __name(() => {
    if (typeof fetch !== "function") return Promise.resolve({ ok: false, data: null });
    const init = { method, cache: "no-store", mode: "cors", headers: {} };
    if (body != null) {
      init.headers["Content-Type"] = "application/json";
      init.body = body;
    }
    return fetch(url, init).then(
      (r) => r.json().catch(() => null).then((data) => ({ ok: r.ok && !(data && data.ok === false), data }))
    ).catch(() => ({ ok: false, data: null }));
  }, "viaFetch");
  return viaXhr().then((res) => res.ok || res.data != null ? res : viaFetch());
}
__name(httpJson, "httpJson");
function distM(lat1, lon1, lat2, lon2) {
  const R = 6371e3;
  const toRad = Math.PI / 180;
  const dLat = (lat2 - lat1) * toRad;
  const dLon = (lon2 - lon1) * toRad;
  const a = Math.pow(Math.sin(dLat / 2), 2) + Math.cos(lat1 * toRad) * Math.cos(lat2 * toRad) * Math.pow(Math.sin(dLon / 2), 2);
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
}
__name(distM, "distM");
function bearingDeg(lat1, lon1, lat2, lon2) {
  const toRad = Math.PI / 180;
  const phi1 = lat1 * toRad;
  const phi2 = lat2 * toRad;
  const dLon = (lon2 - lon1) * toRad;
  const y = Math.sin(dLon) * Math.cos(phi2);
  const x = Math.cos(phi1) * Math.sin(phi2) - Math.sin(phi1) * Math.cos(phi2) * Math.cos(dLon);
  return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
}
__name(bearingDeg, "bearingDeg");
function norm180(deg) {
  return ((deg + 180) % 360 + 360) % 360 - 180;
}
__name(norm180, "norm180");
const _NavApronView = class _NavApronView extends AppView {
  constructor() {
    super(...arguments);
    __publicField(this, "altRef", msfssdk.FSComponent.createRef());
    __publicField(this, "gsRef", msfssdk.FSComponent.createRef());
    __publicField(this, "hdgRef", msfssdk.FSComponent.createRef());
    __publicField(this, "gndRef", msfssdk.FSComponent.createRef());
    __publicField(this, "hubDotRef", msfssdk.FSComponent.createRef());
    __publicField(this, "hubLabelRef", msfssdk.FSComponent.createRef());
    __publicField(this, "statusRef", msfssdk.FSComponent.createRef());
    __publicField(this, "depInputRef", msfssdk.FSComponent.createRef());
    __publicField(this, "depResultsRef", msfssdk.FSComponent.createRef());
    __publicField(this, "rwyChipsRef", msfssdk.FSComponent.createRef());
    __publicField(this, "clearanceRef", msfssdk.FSComponent.createRef());
    __publicField(this, "taxiMsgRef", msfssdk.FSComponent.createRef());
    __publicField(this, "arrowWrapRef", msfssdk.FSComponent.createRef());
    __publicField(this, "laneLeftRef", msfssdk.FSComponent.createRef());
    __publicField(this, "laneStrRef", msfssdk.FSComponent.createRef());
    __publicField(this, "laneRightRef", msfssdk.FSComponent.createRef());
    __publicField(this, "arrowCmdRef", msfssdk.FSComponent.createRef());
    __publicField(this, "arrowDistRef", msfssdk.FSComponent.createRef());
    __publicField(this, "arrowTwyRef", msfssdk.FSComponent.createRef());
    __publicField(this, "summaryRef", msfssdk.FSComponent.createRef());
    __publicField(this, "sbUserRef", msfssdk.FSComponent.createRef());
    __publicField(this, "sbMsgRef", msfssdk.FSComponent.createRef());
    __publicField(this, "sbSummaryRef", msfssdk.FSComponent.createRef());
    __publicField(this, "tabTaxiRef", msfssdk.FSComponent.createRef());
    __publicField(this, "tabProgRef", msfssdk.FSComponent.createRef());
    __publicField(this, "tabSbRef", msfssdk.FSComponent.createRef());
    __publicField(this, "panelTaxiRef", msfssdk.FSComponent.createRef());
    __publicField(this, "panelProgRef", msfssdk.FSComponent.createRef());
    __publicField(this, "panelSbRef", msfssdk.FSComponent.createRef());
    __publicField(this, "findBtnRef", msfssdk.FSComponent.createRef());
    __publicField(this, "showPathBtnRef", msfssdk.FSComponent.createRef());
    __publicField(this, "recheckBtnRef", msfssdk.FSComponent.createRef());
    __publicField(this, "importBtnRef", msfssdk.FSComponent.createRef());
    __publicField(this, "followPlanBtnRef", msfssdk.FSComponent.createRef());
    __publicField(this, "followAcBtnRef", msfssdk.FSComponent.createRef());
    __publicField(this, "connectSimBtnRef", msfssdk.FSComponent.createRef());
    __publicField(this, "controlsMsgRef", msfssdk.FSComponent.createRef());
    __publicField(this, "progRouteRef", msfssdk.FSComponent.createRef());
    __publicField(this, "progBarFillRef", msfssdk.FSComponent.createRef());
    __publicField(this, "progPctRef", msfssdk.FSComponent.createRef());
    __publicField(this, "progRemainRef", msfssdk.FSComponent.createRef());
    __publicField(this, "progLeftRef", msfssdk.FSComponent.createRef());
    __publicField(this, "progEtaRef", msfssdk.FSComponent.createRef());
    __publicField(this, "progGsRef", msfssdk.FSComponent.createRef());
    __publicField(this, "progPhaseRef", msfssdk.FSComponent.createRef());
    __publicField(this, "progHintRef", msfssdk.FSComponent.createRef());
    __publicField(this, "frames", 0);
    __publicField(this, "active", false);
    __publicField(this, "pollTimer", null);
    __publicField(this, "hubBase", "");
    __publicField(this, "hubOk", false);
    __publicField(this, "dep", null);
    __publicField(this, "selectedRwy", null);
    __publicField(this, "runwayEnds", []);
    __publicField(this, "parking", []);
    __publicField(this, "taxiCoords", []);
    __publicField(this, "taxiways", []);
    __publicField(this, "endLabel", "");
    __publicField(this, "searchTimer", null);
    __publicField(this, "live", { lat: NaN, lon: NaN, hdg: NaN, gs: NaN });
    __publicField(this, "routeInfo", {
      depIcao: "",
      destIcao: "",
      depLat: NaN,
      depLon: NaN,
      destLat: NaN,
      destLon: NaN,
      totalNm: NaN,
      planEteSec: NaN
    });
    __publicField(this, "sessionTimer", null);
    __publicField(this, "followPlan", false);
    __publicField(this, "simFollow", false);
    __publicField(this, "simConnected", false);
    __publicField(this, "simEnabled", false);
    /** auto | portrait | landscape — some addons force the EFB shell landscape */
    __publicField(this, "orientationPref", "auto");
    __publicField(this, "orientResizeBound", false);
    __publicField(this, "orientAutoRef", msfssdk.FSComponent.createRef());
    __publicField(this, "orientPortRef", msfssdk.FSComponent.createRef());
    __publicField(this, "orientLandRef", msfssdk.FSComponent.createRef());
  }
  render() {
    return /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb", ref: this.rootRef }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-inner" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-brand" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent(
      "img",
      {
        class: "navapron-efb-logo",
        src: `${APP_COUI}/assets/app-icon.png`,
        alt: "NavApron"
      }
    ), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", null, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-title" }, "NavApron"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-sub" }, "EFB planner remote"))), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-orient", title: "Layout for portrait or landscape EFB" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("button", { type: "button", class: "navapron-efb-orient-btn", ref: this.orientAutoRef }, "Auto"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("button", { type: "button", class: "navapron-efb-orient-btn", ref: this.orientPortRef }, "Portrait"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("button", { type: "button", class: "navapron-efb-orient-btn", ref: this.orientLandRef }, "Landscape")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-hub" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "navapron-efb-dot", ref: this.hubDotRef }), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { ref: this.hubLabelRef }, "Hub...")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-live" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-live-cell" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "k" }, "ALT"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "v", ref: this.altRef }, "-")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-live-cell" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "k" }, "GS"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "v", ref: this.gsRef }, "-")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-live-cell" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "k" }, "HDG"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "v", ref: this.hdgRef }, "-")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-live-cell" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "k" }, "STATE"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "v", ref: this.gndRef }, "-"))), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-tabs" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("button", { type: "button", class: "navapron-efb-tab active", ref: this.tabTaxiRef }, "Taxi"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("button", { type: "button", class: "navapron-efb-tab", ref: this.tabProgRef }, "Progress"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("button", { type: "button", class: "navapron-efb-tab", ref: this.tabSbRef }, "SimBrief")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-card", ref: this.panelTaxiRef }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-card-h" }, "Taxi remote"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-label" }, "Departure ICAO"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-row-input" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("input", { type: "text", placeholder: "EGLL", ref: this.depInputRef, spellcheck: false }), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("button", { type: "button", class: "navapron-efb-btn secondary", ref: this.findBtnRef }, "Find")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("ul", { class: "navapron-efb-results navapron-efb-hidden", ref: this.depResultsRef }), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-label" }, "Runway (tap)"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-chips", ref: this.rwyChipsRef }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "navapron-efb-hint" }, "Load airport first")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-label" }, "Clearance"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("input", { type: "text", placeholder: "A N S", ref: this.clearanceRef, spellcheck: false }), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-row-input" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("button", { type: "button", class: "navapron-efb-btn", ref: this.showPathBtnRef }, "Show path"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("button", { type: "button", class: "navapron-efb-btn secondary", ref: this.recheckBtnRef }, "Recheck hub")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("p", { class: "navapron-efb-msg", ref: this.taxiMsgRef }, "Pick airport, runway chip, clearance, then Show path"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-guide navapron-efb-hidden", ref: this.arrowWrapRef }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-guide-lanes" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-lane", ref: this.laneLeftRef }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-lane-sym navapron-efb-sym-left" }), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-lane-lbl" }, "LEFT")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-lane", ref: this.laneStrRef }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-lane-sym navapron-efb-sym-up" }), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-lane-lbl" }, "AHEAD")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-lane", ref: this.laneRightRef }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-lane-sym navapron-efb-sym-right" }), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-lane-lbl" }, "RIGHT"))), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-arrow-cmd", ref: this.arrowCmdRef }, "-"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-arrow-dist", ref: this.arrowDistRef }, "-"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-arrow-twy", ref: this.arrowTwyRef }, "-")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-summary navapron-efb-hidden", ref: this.summaryRef }), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("p", { class: "navapron-efb-hint" }, "Map stays on the PC NavApron window (Session sync on).")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-card navapron-efb-hidden", ref: this.panelProgRef }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-card-h" }, "Flight progress"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-prog-route", ref: this.progRouteRef }, "No route yet"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-prog-bar" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-prog-fill", ref: this.progBarFillRef })), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-prog-pct", ref: this.progPctRef }, "--"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-prog-grid" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-prog-cell" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "k" }, "REMAIN"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "v", ref: this.progRemainRef }, "-")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-prog-cell" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "k" }, "TIME LEFT"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "v", ref: this.progLeftRef }, "-")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-prog-cell" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "k" }, "ETA Z"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "v", ref: this.progEtaRef }, "-")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-prog-cell" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "k" }, "GS"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { class: "v", ref: this.progGsRef }, "-"))), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-prog-phase" }, "Phase: ", /* @__PURE__ */ msfssdk.FSComponent.buildComponent("span", { ref: this.progPhaseRef }, "-")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("p", { class: "navapron-efb-hint", ref: this.progHintRef }, "Import SimBrief or set dest on PC (Session sync) for full progress.")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-card navapron-efb-hidden", ref: this.panelSbRef }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-card-h" }, "SimBrief"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-label" }, "Username / pilot ID"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-row-input" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("input", { type: "text", ref: this.sbUserRef, spellcheck: false }), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("button", { type: "button", class: "navapron-efb-btn", ref: this.importBtnRef }, "Import")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("p", { class: "navapron-efb-msg", ref: this.sbMsgRef }, "Imports last OFP via PC hub (ID is saved)"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-summary navapron-efb-hidden", ref: this.sbSummaryRef }), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-card-h", style: "margin-top:0.5rem" }, "PC map controls"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-row-input" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("button", { type: "button", class: "navapron-efb-btn secondary", ref: this.connectSimBtnRef }, "Connect to sim")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-row-input" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("button", { type: "button", class: "navapron-efb-btn secondary", ref: this.followPlanBtnRef }, "Follow plan"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("button", { type: "button", class: "navapron-efb-btn secondary", ref: this.followAcBtnRef }, "Follow A/C")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("p", { class: "navapron-efb-msg", ref: this.controlsMsgRef }, "Connect uses the PC hub SimConnect. Follow needs Session sync on.")), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-card" }, /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { class: "navapron-efb-card-h" }, "Status"), /* @__PURE__ */ msfssdk.FSComponent.buildComponent("div", { ref: this.statusRef }, "Starting..."))));
  }
  onAfterRender(node) {
    super.onAfterRender(node);
    this.active = true;
    this.wireTabs();
    this.wireButtons();
    this.wireDepInput();
    this.wireOrientation();
    this.applyOrientation();
    this.loadPrefs(true);
    this.loadConfigScript().then(() => {
      this.refreshHub().then(() => this.loadPrefs(true));
    });
    this.refreshHub().then(() => this.loadPrefs(true));
    this.startPolling();
    this.paintLive();
  }
  onOpen() {
    this.active = true;
    this.startPolling();
    this.refreshHub();
    this.paintLive();
  }
  onResume() {
    this.active = true;
    this.startPolling();
    this.paintLive();
  }
  onPause() {
    this.active = false;
    this.stopPolling();
  }
  onClose() {
    this.active = false;
    this.stopPolling();
  }
  onUpdate(_time) {
    if (!this.active) return;
    this.frames += 1;
    if (this.frames % 15 !== 0) return;
    this.paintLive();
  }
  loadConfigScript() {
    return __async(this, null, function* () {
      return new Promise((resolve) => {
        try {
          const existing = document.querySelector(`script[data-navapron-efb-config]`);
          if (existing) {
            resolve();
            return;
          }
          const s = document.createElement("script");
          s.src = `${APP_COUI}/navapron_efb_config.js`;
          s.dataset.navapronEfbConfig = "1";
          s.onload = () => resolve();
          s.onerror = () => resolve();
          document.head.appendChild(s);
        } catch (_) {
          resolve();
        }
      });
    });
  }
  wireTabs() {
    const taxi = this.tabTaxiRef.getOrDefault();
    const prog = this.tabProgRef.getOrDefault();
    const sb = this.tabSbRef.getOrDefault();
    if (taxi) taxi.addEventListener("click", () => this.showTab("taxi"));
    if (prog) prog.addEventListener("click", () => this.showTab("progress"));
    if (sb) sb.addEventListener("click", () => this.showTab("simbrief"));
  }
  /** Coherent touch: prefer addEventListener over JSX onClick. */
  wireButtons() {
    const findBtn = this.findBtnRef.getOrDefault();
    const showBtn = this.showPathBtnRef.getOrDefault();
    const recheck = this.recheckBtnRef.getOrDefault();
    const imp = this.importBtnRef.getOrDefault();
    if (findBtn) findBtn.addEventListener("click", () => this.searchDep());
    if (showBtn) showBtn.addEventListener("click", () => this.showPath());
    if (recheck) recheck.addEventListener("click", () => this.refreshHub());
    if (imp) imp.addEventListener("click", () => this.importOfp());
    const fp = this.followPlanBtnRef.getOrDefault();
    const fac = this.followAcBtnRef.getOrDefault();
    const conn = this.connectSimBtnRef.getOrDefault();
    if (fp) fp.addEventListener("click", () => this.toggleFollowPlan());
    if (fac) fac.addEventListener("click", () => this.toggleSimFollow());
    if (conn) conn.addEventListener("click", () => this.toggleSimConnect());
    const sbInput = this.sbUserRef.getOrDefault();
    if (sbInput) {
      sbInput.addEventListener("change", () => this.persistSimbriefId(sbInput.value));
      sbInput.addEventListener("blur", () => this.persistSimbriefId(sbInput.value));
    }
  }
  showTab(name) {
    const taxiTab = this.tabTaxiRef.getOrDefault();
    const progTab = this.tabProgRef.getOrDefault();
    const sbTab = this.tabSbRef.getOrDefault();
    const taxiPanel = this.panelTaxiRef.getOrDefault();
    const progPanel = this.panelProgRef.getOrDefault();
    const sbPanel = this.panelSbRef.getOrDefault();
    if (taxiTab) taxiTab.classList.toggle("active", name === "taxi");
    if (progTab) progTab.classList.toggle("active", name === "progress");
    if (sbTab) sbTab.classList.toggle("active", name === "simbrief");
    if (taxiPanel) taxiPanel.classList.toggle("navapron-efb-hidden", name !== "taxi");
    if (progPanel) progPanel.classList.toggle("navapron-efb-hidden", name !== "progress");
    if (sbPanel) sbPanel.classList.toggle("navapron-efb-hidden", name !== "simbrief");
    if (name === "progress") {
      this.refreshSessionRoute();
      this.paintProgress();
    }
    if (name === "simbrief") {
      this.loadPrefs(true);
      this.refreshSimStatus();
      this.paintControlButtons();
    }
  }
  wireDepInput() {
    const input = this.depInputRef.getOrDefault();
    if (!input) return;
    input.addEventListener("input", () => {
      if (this.searchTimer) window.clearTimeout(this.searchTimer);
      this.searchTimer = window.setTimeout(() => this.searchDep(), 350);
    });
  }
  startPolling() {
    if (this.pollTimer !== null) return;
    this.pollTimer = window.setInterval(() => {
      if (!this.active) return;
      this.paintLive();
      this.paintProgress();
    }, 500);
    if (this.sessionTimer === null) {
      this.sessionTimer = window.setInterval(() => {
        if (!this.active) return;
        this.refreshSessionRoute();
        this.refreshSimStatus();
      }, 8e3);
      this.refreshSessionRoute();
      this.refreshSimStatus();
    }
  }
  stopPolling() {
    if (this.pollTimer !== null) {
      window.clearInterval(this.pollTimer);
      this.pollTimer = null;
    }
    if (this.sessionTimer !== null) {
      window.clearInterval(this.sessionTimer);
      this.sessionTimer = null;
    }
  }
  setText(ref, text) {
    const el = ref.getOrDefault();
    if (el) el.textContent = text;
  }
  setMsg(ref, text, kind) {
    const el = ref.getOrDefault();
    if (!el) return;
    el.textContent = text;
    el.className = "navapron-efb-msg" + (kind ? " " + kind : "");
  }
  api(path) {
    const base = this.hubBase || hubCandidates()[0] || "http://127.0.0.1:8765/";
    return base + path.replace(/^\//, "");
  }
  refreshHub() {
    return __async(this, null, function* () {
      this.setText(this.hubLabelRef, "Checking hub...");
      this.setText(this.statusRef, "Checking hub...");
      const urls = hubCandidates();
      for (let i = 0; i < urls.length; i++) {
        const base = urls[i];
        const r = yield httpJson(base + "api/health");
        if (r.ok && r.data && r.data.status === "ok") {
          this.hubBase = base;
          this.hubOk = true;
          this.paintHub(true, base);
          this.paintLive();
          return;
        }
      }
      this.hubOk = false;
      this.paintHub(false, urls[0] || "-");
      this.setText(
        this.statusRef,
        "Hub offline (" + urls.length + " URLs tried) - is NavApron running?"
      );
    });
  }
  paintHub(ok, url) {
    const dot = this.hubDotRef.getOrDefault();
    if (dot) dot.className = "navapron-efb-dot " + (ok ? "ok" : "bad");
    this.setText(
      this.hubLabelRef,
      ok ? "Hub online | " + url : "Hub offline - keep NavApron running on PC, then tap Recheck hub"
    );
  }
  readLocalSimbriefId() {
    try {
      if (typeof localStorage !== "undefined") {
        return String(localStorage.getItem(_NavApronView.SB_ID_KEY) || "").trim();
      }
    } catch (_) {
    }
    return "";
  }
  persistSimbriefId(raw) {
    const user = String(raw || "").trim();
    try {
      if (typeof localStorage !== "undefined") {
        if (user) localStorage.setItem(_NavApronView.SB_ID_KEY, user);
        else localStorage.removeItem(_NavApronView.SB_ID_KEY);
      }
    } catch (_) {
    }
    if (user && this.hubOk) {
      void httpJson(this.api("api/user/prefs"), {
        method: "POST",
        body: { simbrief_user: user }
      });
    }
  }
  normalizeOrient(raw) {
    const s = String(raw || "").trim().toLowerCase();
    if (s === "portrait" || s === "landscape" || s === "auto") return s;
    return "auto";
  }
  readLocalOrientation() {
    try {
      if (typeof localStorage !== "undefined") {
        return this.normalizeOrient(
          String(localStorage.getItem(_NavApronView.ORIENT_KEY) || "")
        );
      }
    } catch (_) {
    }
    return "auto";
  }
  persistOrientation(mode) {
    this.orientationPref = mode;
    try {
      if (typeof localStorage !== "undefined") {
        localStorage.setItem(_NavApronView.ORIENT_KEY, mode);
      }
    } catch (_) {
    }
    if (this.hubOk) {
      void httpJson(this.api("api/user/prefs"), {
        method: "POST",
        body: { efb_orientation: mode }
      });
    }
    this.applyOrientation();
  }
  wireOrientation() {
    const autoBtn = this.orientAutoRef.getOrDefault();
    const portBtn = this.orientPortRef.getOrDefault();
    const landBtn = this.orientLandRef.getOrDefault();
    if (autoBtn) {
      autoBtn.addEventListener("click", () => this.persistOrientation("auto"));
    }
    if (portBtn) {
      portBtn.addEventListener("click", () => this.persistOrientation("portrait"));
    }
    if (landBtn) {
      landBtn.addEventListener("click", () => this.persistOrientation("landscape"));
    }
    this.orientationPref = this.readLocalOrientation();
    if (!this.orientResizeBound) {
      this.orientResizeBound = true;
      try {
        if (typeof window !== "undefined" && window.addEventListener) {
          window.addEventListener("resize", () => {
            if (this.orientationPref === "auto") this.applyOrientation();
          });
        }
      } catch (_) {
      }
    }
  }
  resolvedOrientation() {
    if (this.orientationPref === "portrait") return "portrait";
    if (this.orientationPref === "landscape") return "landscape";
    try {
      const root = this.rootRef.getOrDefault();
      const w = root && root.clientWidth || (typeof window !== "undefined" ? window.innerWidth : 0) || 0;
      const h = root && root.clientHeight || (typeof window !== "undefined" ? window.innerHeight : 0) || 0;
      if (w > 0 && h > 0 && w / h >= 1.15) return "landscape";
    } catch (_) {
    }
    return "portrait";
  }
  applyOrientation() {
    const root = this.rootRef.getOrDefault();
    if (!root) return;
    const resolved = this.resolvedOrientation();
    root.classList.toggle("navapron-efb--landscape", resolved === "landscape");
    root.classList.toggle("navapron-efb--portrait", resolved === "portrait");
    const autoBtn = this.orientAutoRef.getOrDefault();
    const portBtn = this.orientPortRef.getOrDefault();
    const landBtn = this.orientLandRef.getOrDefault();
    if (autoBtn) autoBtn.classList.toggle("active", this.orientationPref === "auto");
    if (portBtn) {
      portBtn.classList.toggle("active", this.orientationPref === "portrait");
    }
    if (landBtn) {
      landBtn.classList.toggle("active", this.orientationPref === "landscape");
    }
  }
  loadPrefs(force) {
    return __async(this, null, function* () {
      const input = this.sbUserRef.getOrDefault();
      const localOrient = this.readLocalOrientation();
      if (force || this.orientationPref === "auto") {
        this.orientationPref = localOrient;
        this.applyOrientation();
      }
      if (!input) return;
      const localId = this.readLocalSimbriefId();
      if (localId && (force || !input.value)) {
        input.value = localId;
      }
      if (!this.hubOk) return;
      const r = yield httpJson(this.api("api/user/prefs"));
      const hubId = r.ok && r.data && r.data.simbrief_user != null ? String(r.data.simbrief_user).trim() : "";
      if (hubId && (force || !input.value)) {
        input.value = hubId;
        this.persistSimbriefId(hubId);
      }
      const hubOrient = r.ok && r.data && r.data.efb_orientation != null ? this.normalizeOrient(String(r.data.efb_orientation)) : "auto";
      if (localOrient === "auto" && hubOrient !== "auto") {
        this.orientationPref = hubOrient;
        try {
          if (typeof localStorage !== "undefined") {
            localStorage.setItem(_NavApronView.ORIENT_KEY, hubOrient);
          }
        } catch (_) {
        }
        this.applyOrientation();
      }
    });
  }
  paintLive() {
    const alt = sv("PLANE ALTITUDE", "feet");
    const gs = sv("GROUND VELOCITY", "knots");
    const hdg = sv("PLANE HEADING DEGREES TRUE", "degrees");
    const lat = sv("PLANE LATITUDE", "degrees");
    const lon = sv("PLANE LONGITUDE", "degrees");
    const onGnd = sv("SIM ON GROUND", "bool");
    this.live = { lat, lon, hdg, gs };
    this.setText(this.altRef, Number.isFinite(alt) ? String(Math.round(alt)) : "-");
    this.setText(this.gsRef, Number.isFinite(gs) ? String(Math.round(gs)) : "-");
    const hdgN = Number.isFinite(hdg) ? (Math.round(hdg) % 360 + 360) % 360 : NaN;
    this.setText(
      this.hdgRef,
      Number.isFinite(hdgN) ? String(hdgN).replace(/^(\d)$/, "00$1").replace(/^(\d\d)$/, "0$1") : "-"
    );
    this.setText(
      this.gndRef,
      !Number.isFinite(onGnd) ? "-" : onGnd ? "GND" : "AIR"
    );
    if (!getSimVar()) {
      this.setText(this.statusRef, "SimVar unavailable");
    } else if (this.hubOk) {
      this.setText(this.statusRef, "Live | hub OK - map on PC");
    } else {
      this.setText(this.statusRef, "Live | hub offline");
    }
    this.updateArrow();
    this.paintProgress();
  }
  searchDep() {
    return __async(this, null, function* () {
      const input = this.depInputRef.getOrDefault();
      const list = this.depResultsRef.getOrDefault();
      if (!input || !list) return;
      const q = input.value.trim();
      if (!this.hubOk) {
        this.setMsg(this.taxiMsgRef, "Hub offline", "bad");
        return;
      }
      if (q.length < 1) {
        list.classList.add("navapron-efb-hidden");
        return;
      }
      if (/^[A-Z]{4}$/i.test(q)) {
        yield this.pickDep({ icao: q.toUpperCase() });
        return;
      }
      const r = yield httpJson(this.api(`api/airports/search?q=${encodeURIComponent(q)}&limit=10`));
      const rows = Array.isArray(r.data) ? r.data : [];
      list.innerHTML = "";
      if (!rows.length) {
        list.classList.add("navapron-efb-hidden");
        return;
      }
      for (const ap of rows) {
        const li = document.createElement("li");
        li.innerHTML = `<span class="code">${ap.icao || ""}</span>${ap.name || ""}`;
        li.addEventListener("click", () => this.pickDep(ap));
        list.appendChild(li);
      }
      list.classList.remove("navapron-efb-hidden");
    });
  }
  pickDep(ap) {
    return __async(this, null, function* () {
      this.dep = ap;
      const icao = String(ap.icao || "").toUpperCase();
      const input = this.depInputRef.getOrDefault();
      if (input) input.value = icao;
      const list = this.depResultsRef.getOrDefault();
      list == null ? void 0 : list.classList.add("navapron-efb-hidden");
      this.setMsg(this.taxiMsgRef, `Loading ${icao}...`, "busy");
      const r = yield httpJson(this.api(`api/airports/${encodeURIComponent(icao)}/layout`));
      if (!r.ok || !r.data) {
        this.setMsg(this.taxiMsgRef, "Layout failed", "bad");
        return;
      }
      this.runwayEnds = r.data.runway_ends || [];
      const layout = r.data.layout || {};
      this.parking = layout.parking || layout.stands || [];
      this.renderRwyChips();
      this.setMsg(this.taxiMsgRef, `${icao} loaded - tap a runway`, "ok");
    });
  }
  renderRwyChips() {
    var _a;
    const row = this.rwyChipsRef.getOrDefault();
    if (!row) return;
    row.innerHTML = "";
    if (!this.runwayEnds.length) {
      row.innerHTML = '<span class="navapron-efb-hint">No runways</span>';
      this.selectedRwy = null;
      return;
    }
    this.runwayEnds.forEach((e, idx) => {
      const name = String(e.name || e.runway || "").replace(/^RWY\s*/i, "");
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "navapron-efb-chip";
      btn.textContent = name || `R${idx}`;
      btn.addEventListener("click", () => {
        this.selectedRwy = e;
        row.querySelectorAll(".navapron-efb-chip").forEach((c, i) => {
          c.classList.toggle("active", i === idx);
        });
        this.setMsg(this.taxiMsgRef, `Runway ${name} selected`, "ok");
      });
      row.appendChild(btn);
    });
    if (this.runwayEnds.length === 1) {
      this.selectedRwy = this.runwayEnds[0];
      (_a = row.querySelector(".navapron-efb-chip")) == null ? void 0 : _a.classList.add("active");
    }
  }
  parseClearance() {
    const el = this.clearanceRef.getOrDefault();
    const raw = el ? el.value : "";
    return raw.toUpperCase().replace(/[,;|/]+/g, " ").split(/\s+/).map((t) => t.trim()).filter(Boolean);
  }
  showPath() {
    return __async(this, null, function* () {
      var _a, _b, _c, _d;
      if (!this.hubOk) {
        this.setMsg(this.taxiMsgRef, "Hub offline - start NavApron on PC", "bad");
        return;
      }
      const icao = String(((_a = this.dep) == null ? void 0 : _a.icao) || "").toUpperCase();
      if (!icao) {
        this.setMsg(this.taxiMsgRef, "Pick departure first", "bad");
        return;
      }
      if (!this.selectedRwy || this.selectedRwy.lat == null) {
        this.setMsg(this.taxiMsgRef, "Tap a runway chip first", "bad");
        return;
      }
      if (!Number.isFinite(this.live.lat) || !Number.isFinite(this.live.lon)) {
        this.setMsg(this.taxiMsgRef, "No aircraft position yet", "bad");
        return;
      }
      const clearance = this.parseClearance();
      this.setMsg(this.taxiMsgRef, "Routing...", "busy");
      const body = {
        icao,
        start_lat: this.live.lat,
        start_lon: this.live.lon,
        end_lat: this.selectedRwy.lat,
        end_lon: this.selectedRwy.lon,
        clearance,
        end_is_runway_threshold: true,
        start_heading_deg: Number.isFinite(this.live.hdg) ? this.live.hdg : null
      };
      const r = yield httpJson(this.api("api/route"), { method: "POST", body });
      if (!r.ok || !r.data) {
        this.setMsg(this.taxiMsgRef, ((_b = r.data) == null ? void 0 : _b.error) || ((_c = r.data) == null ? void 0 : _c.message) || "Route failed", "bad");
        return;
      }
      const route = r.data;
      this.taxiCoords = route.coords || [];
      this.taxiways = route.taxiways_used || [];
      this.endLabel = String(this.selectedRwy.name || this.selectedRwy.runway || "RWY");
      const nm = route.distance_nm != null ? Number(route.distance_nm).toFixed(2) : "?";
      const tw = this.taxiways.join(", ") || "(unnamed)";
      const sum = this.summaryRef.getOrDefault();
      if (sum) {
        sum.textContent = `To ${this.endLabel}
${nm} nm
Via: ${tw}`;
        sum.classList.remove("navapron-efb-hidden");
      }
      (_d = this.arrowWrapRef.getOrDefault()) == null ? void 0 : _d.classList.remove("navapron-efb-hidden");
      this.updateArrow();
      this.setMsg(this.taxiMsgRef, "Path ready - follow arrow; PC map updates if sync on", "ok");
      yield httpJson(this.api("api/session"), {
        method: "POST",
        body: {
          client_id: "navapron-efb",
          payload: {
            mode: "taxi",
            journeyStep: "taxi-out",
            depIcao: icao,
            clearance,
            start: { lat: this.live.lat, lon: this.live.lon, label: "Aircraft" },
            end: {
              lat: this.selectedRwy.lat,
              lon: this.selectedRwy.lon,
              label: "RWY " + this.endLabel
            },
            runway: this.selectedRwy,
            pathSnapshots: {
              route: {
                data: route,
                start: { lat: this.live.lat, lon: this.live.lon, label: "Aircraft" },
                end: this.selectedRwy
              },
              taxiIn: null,
              departure: null,
              arrival: null
            },
            fromAircraft: true,
            source: "navapron-efb"
          }
        }
      });
    });
  }
  setLane(active) {
    const left = this.laneLeftRef.getOrDefault();
    const str = this.laneStrRef.getOrDefault();
    const right = this.laneRightRef.getOrDefault();
    left == null ? void 0 : left.classList.toggle("active", active === "left");
    str == null ? void 0 : str.classList.toggle("active", active === "straight");
    right == null ? void 0 : right.classList.toggle("active", active === "right");
  }
  updateArrow() {
    const wrap = this.arrowWrapRef.getOrDefault();
    if (!wrap || !this.taxiCoords.length) return;
    const { lat, lon, hdg } = this.live;
    if (!Number.isFinite(lat) || !Number.isFinite(lon) || !Number.isFinite(hdg)) return;
    wrap.classList.remove("navapron-efb-hidden");
    let bestI = 0;
    let bestD = Infinity;
    for (let i = 0; i < this.taxiCoords.length; i++) {
      const c = this.taxiCoords[i];
      if (!c || c.length < 2) continue;
      const d = distM(lat, lon, c[0], c[1]);
      if (d < bestD) {
        bestD = d;
        bestI = i;
      }
    }
    let target = this.taxiCoords[this.taxiCoords.length - 1];
    let tIdx = this.taxiCoords.length - 1;
    for (let j = bestI; j < this.taxiCoords.length; j++) {
      const p = this.taxiCoords[j];
      if (p && p.length >= 2 && distM(lat, lon, p[0], p[1]) >= 25) {
        target = p;
        tIdx = j;
        break;
      }
    }
    if (!target || target.length < 2) return;
    let remain = distM(lat, lon, target[0], target[1]);
    for (let i = tIdx; i < this.taxiCoords.length - 1; i++) {
      const a = this.taxiCoords[i];
      const b = this.taxiCoords[i + 1];
      if (a && b) remain += distM(a[0], a[1], b[0], b[1]);
    }
    if (remain < 15) {
      this.setLane("straight");
      this.setText(this.arrowCmdRef, "ARRIVED");
      this.setText(this.arrowDistRef, "At runway / end");
      this.setText(this.arrowTwyRef, this.endLabel || "");
      return;
    }
    const brng = bearingDeg(lat, lon, target[0], target[1]);
    const rel = norm180(brng - hdg);
    const abs = Math.abs(rel);
    let lane = "straight";
    let cmd = "GO AHEAD";
    if (abs >= 25) {
      if (rel < 0) {
        lane = "left";
        cmd = abs >= 90 ? "HARD LEFT" : abs >= 50 ? "TURN LEFT" : "BEAR LEFT";
      } else {
        lane = "right";
        cmd = abs >= 90 ? "HARD RIGHT" : abs >= 50 ? "TURN RIGHT" : "BEAR RIGHT";
      }
    }
    this.setLane(lane);
    this.setText(this.arrowCmdRef, cmd + " (" + Math.round(abs) + " deg)");
    this.setText(
      this.arrowDistRef,
      remain >= 1852 ? `${(remain / 1852).toFixed(2)} nm remaining` : `${Math.round(remain)} m remaining`
    );
    this.setText(
      this.arrowTwyRef,
      `To ${this.endLabel}` + (this.taxiways.length ? ` | via ${this.taxiways.join(" -> ")}` : "")
    );
  }
  formatDuration(sec) {
    if (!Number.isFinite(sec) || sec < 0) return "-";
    const s = Math.round(sec);
    const h = Math.floor(s / 3600);
    const m = Math.floor(s % 3600 / 60);
    if (h > 0) return h + "h " + String(m).replace(/^(\d)$/, "0$1") + "m";
    if (m > 0) return m + "m";
    return s + "s";
  }
  formatZuluEta(secLeft) {
    if (!Number.isFinite(secLeft) || secLeft < 0) return "-";
    let zulu = sv("ZULU TIME", "seconds");
    if (!Number.isFinite(zulu)) {
      const d = /* @__PURE__ */ new Date();
      zulu = d.getUTCHours() * 3600 + d.getUTCMinutes() * 60 + d.getUTCSeconds();
    }
    let t = (Math.floor(zulu) + Math.round(secLeft)) % 86400;
    if (t < 0) t += 86400;
    const hh = Math.floor(t / 3600);
    const mm = Math.floor(t % 3600 / 60);
    const pad = /* @__PURE__ */ __name((n) => n < 10 ? "0" + n : String(n), "pad");
    return pad(hh) + ":" + pad(mm) + "Z";
  }
  parseEteSeconds(raw) {
    if (raw == null || raw === "") return NaN;
    if (typeof raw === "number" && Number.isFinite(raw)) {
      if (raw > 400) return raw;
      if (raw > 0 && raw < 30) return raw * 3600;
      return raw * 60;
    }
    const s = String(raw).trim();
    const m1 = /^(\d{1,2}):(\d{2})$/.exec(s);
    if (m1) return parseInt(m1[1], 10) * 3600 + parseInt(m1[2], 10) * 60;
    const m2 = /^(\d{3,4})$/.exec(s);
    if (m2) {
      const n2 = parseInt(m2[1], 10);
      const hh = Math.floor(n2 / 100);
      const mm = n2 % 100;
      if (mm < 60) return hh * 3600 + mm * 60;
    }
    const n = Number(s);
    return Number.isFinite(n) ? this.parseEteSeconds(n) : NaN;
  }
  ensureAirportCoords(icao, which) {
    return __async(this, null, function* () {
      const code = String(icao || "").toUpperCase();
      if (!code || !this.hubOk) return;
      const have = which === "dep" ? Number.isFinite(this.routeInfo.depLat) && Number.isFinite(this.routeInfo.depLon) : Number.isFinite(this.routeInfo.destLat) && Number.isFinite(this.routeInfo.destLon);
      if (have) return;
      const r = yield httpJson(this.api("api/airports/search?q=" + encodeURIComponent(code) + "&limit=5"));
      const rows = Array.isArray(r.data) ? r.data : [];
      let ap = null;
      for (let i = 0; i < rows.length; i++) {
        if (String(rows[i].icao || "").toUpperCase() === code) {
          ap = rows[i];
          break;
        }
      }
      if (!ap && rows.length) ap = rows[0];
      if (!ap || ap.lat == null || ap.lon == null) return;
      if (which === "dep") {
        this.routeInfo.depLat = Number(ap.lat);
        this.routeInfo.depLon = Number(ap.lon);
      } else {
        this.routeInfo.destLat = Number(ap.lat);
        this.routeInfo.destLon = Number(ap.lon);
      }
    });
  }
  refreshSessionRoute() {
    return __async(this, null, function* () {
      if (!this.hubOk) return;
      const r = yield httpJson(this.api("api/session"));
      if (!r.ok || !r.data || !r.data.payload) return;
      const p = r.data.payload || {};
      const fp = p.flightPlan || {};
      const depIcao = String(p.depIcao || fp.dep && fp.dep.icao || this.dep && this.dep.icao || "").toUpperCase();
      const destIcao = String(
        p.destIcao || p.arrIcao || fp.dest && fp.dest.icao || ""
      ).toUpperCase();
      if (depIcao) this.routeInfo.depIcao = depIcao;
      if (destIcao) this.routeInfo.destIcao = destIcao;
      if (fp.dep && fp.dep.lat != null) {
        this.routeInfo.depLat = Number(fp.dep.lat);
        this.routeInfo.depLon = Number(fp.dep.lon);
      }
      if (fp.dest && fp.dest.lat != null) {
        this.routeInfo.destLat = Number(fp.dest.lat);
        this.routeInfo.destLon = Number(fp.dest.lon);
      }
      const dist = Number(fp.distance_nm);
      if (Number.isFinite(dist) && dist > 0) this.routeInfo.totalNm = dist;
      const ofp = p.ofpSummary || p.ofp_summary || {};
      const ete = this.parseEteSeconds(ofp.flight_time || ofp.ete || ofp.est_ete || ofp.time);
      if (Number.isFinite(ete)) this.routeInfo.planEteSec = ete;
      const ofpDist = Number(ofp.distance_nm || ofp.route_nm || ofp.gc_distance);
      if (Number.isFinite(ofpDist) && ofpDist > 0) this.routeInfo.totalNm = ofpDist;
      yield this.ensureAirportCoords(this.routeInfo.depIcao, "dep");
      yield this.ensureAirportCoords(this.routeInfo.destIcao, "dest");
      if (!Number.isFinite(this.routeInfo.totalNm) && Number.isFinite(this.routeInfo.depLat) && Number.isFinite(this.routeInfo.destLat)) {
        this.routeInfo.totalNm = distM(
          this.routeInfo.depLat,
          this.routeInfo.depLon,
          this.routeInfo.destLat,
          this.routeInfo.destLon
        ) / 1852;
      }
      if (p.followPlan != null) this.followPlan = !!p.followPlan;
      if (p.simFollow != null) this.simFollow = !!p.simFollow;
      if (p.controls) {
        if (p.controls.followPlan != null) this.followPlan = !!p.controls.followPlan;
        if (p.controls.simFollow != null) this.simFollow = !!p.controls.simFollow;
      }
      this.paintControlButtons();
    });
  }
  paintProgress() {
    const ri = this.routeInfo;
    const routeEl = this.progRouteRef.getOrDefault();
    if (routeEl) {
      routeEl.textContent = ri.depIcao || ri.destIcao ? (ri.depIcao || "????") + "  ->  " + (ri.destIcao || "????") : "No route yet";
    }
    const gs = Number.isFinite(this.live.gs) ? this.live.gs : sv("GROUND VELOCITY", "knots");
    this.setText(this.progGsRef, Number.isFinite(gs) ? String(Math.round(gs)) + " kt" : "-");
    const onGnd = sv("SIM ON GROUND", "bool");
    const alt = sv("PLANE ALTITUDE", "feet");
    let phase = "-";
    if (Number.isFinite(onGnd) && onGnd) phase = "On ground";
    else if (Number.isFinite(alt) && alt < 1e4) phase = "Climb / descent";
    else if (Number.isFinite(alt)) phase = "Cruise";
    this.setText(this.progPhaseRef, phase);
    let remainNm = NaN;
    if (Number.isFinite(this.live.lat) && Number.isFinite(this.live.lon) && Number.isFinite(ri.destLat) && Number.isFinite(ri.destLon)) {
      remainNm = distM(this.live.lat, this.live.lon, ri.destLat, ri.destLon) / 1852;
    }
    if (!Number.isFinite(remainNm)) {
      const gpsM = sv("GPS WP DISTANCE", "meters");
      if (Number.isFinite(gpsM) && gpsM > 0) remainNm = gpsM / 1852;
    }
    this.setText(
      this.progRemainRef,
      Number.isFinite(remainNm) ? remainNm.toFixed(remainNm >= 100 ? 0 : 1) + " nm" : "-"
    );
    let leftSec = sv("GPS ETE", "seconds");
    if (!Number.isFinite(leftSec) || leftSec <= 0 || leftSec > 48 * 3600) {
      leftSec = NaN;
    }
    if (!Number.isFinite(leftSec) && Number.isFinite(remainNm) && Number.isFinite(gs) && gs > 40) {
      leftSec = remainNm / gs * 3600;
    }
    if (!Number.isFinite(leftSec) && Number.isFinite(onGnd) && onGnd && Number.isFinite(ri.planEteSec)) {
      leftSec = ri.planEteSec;
    }
    this.setText(this.progLeftRef, this.formatDuration(leftSec));
    this.setText(this.progEtaRef, this.formatZuluEta(leftSec));
    let pct = NaN;
    const total = ri.totalNm;
    if (Number.isFinite(total) && total > 1 && Number.isFinite(remainNm)) {
      pct = Math.max(0, Math.min(100, (total - remainNm) / total * 100));
    } else if (Number.isFinite(ri.planEteSec) && ri.planEteSec > 0 && Number.isFinite(leftSec)) {
      pct = Math.max(0, Math.min(100, (ri.planEteSec - leftSec) / ri.planEteSec * 100));
    }
    const fill = this.progBarFillRef.getOrDefault();
    if (fill) {
      fill.style.width = Number.isFinite(pct) ? pct.toFixed(1) + "%" : "0%";
    }
    this.setText(
      this.progPctRef,
      Number.isFinite(pct) ? Math.round(pct) + "% complete" : "Progress unavailable"
    );
    const hint = this.progHintRef.getOrDefault();
    if (hint) {
      if (!ri.destIcao) {
        hint.textContent = "Import SimBrief or set destination on PC (Session sync) for full progress.";
      } else if (!Number.isFinite(remainNm)) {
        hint.textContent = "Waiting for aircraft position / destination coordinates...";
      } else if (Number.isFinite(onGnd) && onGnd) {
        hint.textContent = "On ground \u2014 time left uses plan ETE until airborne.";
      } else {
        hint.textContent = "ETA uses ground speed" + (Number.isFinite(total) ? " | plan " + total.toFixed(0) + " nm" : "") + ".";
      }
    }
  }
  paintControlButtons() {
    const fp = this.followPlanBtnRef.getOrDefault();
    const fac = this.followAcBtnRef.getOrDefault();
    const conn = this.connectSimBtnRef.getOrDefault();
    if (fp) {
      if (this.followPlan) fp.classList.add("active");
      else fp.classList.remove("active");
    }
    if (fac) {
      if (this.simFollow) fac.classList.add("active");
      else fac.classList.remove("active");
    }
    if (conn) {
      if (this.simConnected || this.simEnabled) conn.classList.add("active");
      else conn.classList.remove("active");
      conn.textContent = this.simConnected ? "Sim connected" : this.simEnabled ? "Connecting\u2026" : "Connect to sim";
    }
  }
  refreshSimStatus() {
    return __async(this, null, function* () {
      if (!this.hubOk) return;
      const r = yield httpJson(this.api("api/sim/status"));
      if (!r.ok || !r.data) return;
      this.simEnabled = !!r.data.enabled;
      this.simConnected = !!r.data.connected;
      this.paintControlButtons();
    });
  }
  toggleSimConnect() {
    return __async(this, null, function* () {
      if (!this.hubOk) {
        this.setMsg(this.controlsMsgRef, "Hub offline - start NavApron on PC", "bad");
        return;
      }
      const wantDisconnect = this.simConnected || this.simEnabled;
      this.setMsg(
        this.controlsMsgRef,
        wantDisconnect ? "Disconnecting\u2026" : "Connecting to MSFS\u2026",
        "busy"
      );
      const path = wantDisconnect ? "api/sim/disconnect" : "api/sim/connect";
      const r = yield httpJson(this.api(path), { method: "POST" });
      if (!r.ok && !(r.data && r.data.available === false)) {
        this.setMsg(this.controlsMsgRef, "Sim connect request failed", "bad");
        return;
      }
      this.simEnabled = !!(r.data && r.data.enabled);
      this.simConnected = !!(r.data && r.data.connected);
      if (r.data && r.data.error && !r.data.available) {
        this.setMsg(this.controlsMsgRef, String(r.data.error), "bad");
        this.paintControlButtons();
        return;
      }
      this.paintControlButtons();
      yield this.pushControls({
        panelCommand: wantDisconnect ? "disconnectSim" : "connectSim",
        simEnabled: this.simEnabled,
        simConnected: this.simConnected
      });
      this.setMsg(
        this.controlsMsgRef,
        this.simConnected ? "Connected to MSFS" : this.simEnabled ? "Looking for MSFS - start a flight if needed" : "Disconnected from MSFS",
        this.simEnabled || this.simConnected ? "ok" : "ok"
      );
      if (this.simEnabled && !this.simConnected) {
        const self = this;
        window.setTimeout(function() {
          self.refreshSimStatus();
        }, 1500);
      }
    });
  }
  pushControls(extra) {
    return __async(this, null, function* () {
      if (!this.hubOk) {
        this.setMsg(this.controlsMsgRef, "Hub offline - start NavApron on PC", "bad");
        return;
      }
      const body = {
        client_id: "navapron-efb",
        payload: Object.assign(
          {
            source: "navapron-efb",
            // Controls only — do not force mode/journeyStep (avoids PC UI resets)
            followPlan: this.followPlan,
            simFollow: this.simFollow,
            controls: {
              followPlan: this.followPlan,
              simFollow: this.simFollow
            }
          },
          extra || {}
        )
      };
      const r = yield httpJson(this.api("api/session"), { method: "POST", body });
      if (!r.ok) {
        this.setMsg(this.controlsMsgRef, "Could not reach PC session", "bad");
        return;
      }
      this.setMsg(
        this.controlsMsgRef,
        this.followPlan ? "Follow plan ON" : this.simFollow ? "Follow aircraft ON" : "Follow OFF",
        "ok"
      );
    });
  }
  toggleFollowPlan() {
    this.followPlan = !this.followPlan;
    if (this.followPlan) this.simFollow = false;
    this.paintControlButtons();
    void this.pushControls();
  }
  toggleSimFollow() {
    this.simFollow = !this.simFollow;
    if (this.simFollow) this.followPlan = false;
    this.paintControlButtons();
    void this.pushControls();
  }
  importOfp() {
    return __async(this, null, function* () {
      var _a, _b, _c, _d, _e;
      const input = this.sbUserRef.getOrDefault();
      const user = input && input.value.trim() || "";
      if (!user) {
        this.setMsg(this.sbMsgRef, "Enter SimBrief ID", "bad");
        return;
      }
      if (!this.hubOk) {
        this.setMsg(this.sbMsgRef, "Hub offline", "bad");
        return;
      }
      this.persistSimbriefId(user);
      this.setMsg(this.sbMsgRef, "Importing...", "busy");
      yield httpJson(this.api("api/user/prefs"), {
        method: "POST",
        body: { simbrief_user: user }
      });
      const r = yield httpJson(this.api("api/simbrief/import"), {
        method: "POST",
        body: { username: user }
      });
      if (!r.ok || !r.data) {
        this.setMsg(this.sbMsgRef, ((_a = r.data) == null ? void 0 : _a.detail) || ((_b = r.data) == null ? void 0 : _b.error) || "Import failed", "bad");
        return;
      }
      const data = r.data;
      if ((_c = data.dep) == null ? void 0 : _c.icao) {
        yield this.pickDep(data.dep);
        const want = String(data.dep_rwy || "").replace(/^RWY\s*/i, "").toUpperCase();
        if (want) {
          const idx = this.runwayEnds.findIndex(
            (e) => String(e.name || e.runway || "").replace(/^RWY\s*/i, "").toUpperCase() === want
          );
          if (idx >= 0) {
            this.selectedRwy = this.runwayEnds[idx];
            const row = this.rwyChipsRef.getOrDefault();
            row == null ? void 0 : row.querySelectorAll(".navapron-efb-chip").forEach((c, i) => {
              c.classList.toggle("active", i === idx);
            });
          }
        }
      }
      const sum = this.sbSummaryRef.getOrDefault();
      if (sum) {
        sum.textContent = `${((_d = data.dep) == null ? void 0 : _d.icao) || "?"} -> ${((_e = data.dest) == null ? void 0 : _e.icao) || "?"}
${data.route_text || data.icao_route || ""}`;
        sum.classList.remove("navapron-efb-hidden");
      }
      this.setMsg(this.sbMsgRef, data.message || "OFP imported", "ok");
      if (data.dep && data.dep.icao) {
        this.routeInfo.depIcao = String(data.dep.icao).toUpperCase();
        if (data.dep.lat != null) {
          this.routeInfo.depLat = Number(data.dep.lat);
          this.routeInfo.depLon = Number(data.dep.lon);
        }
      }
      if (data.dest && data.dest.icao) {
        this.routeInfo.destIcao = String(data.dest.icao).toUpperCase();
        if (data.dest.lat != null) {
          this.routeInfo.destLat = Number(data.dest.lat);
          this.routeInfo.destLon = Number(data.dest.lon);
        }
      }
      if (Number.isFinite(Number(data.distance_nm))) {
        this.routeInfo.totalNm = Number(data.distance_nm);
      }
      const ofp = data.ofp_summary || {};
      const ete = this.parseEteSeconds(ofp.flight_time || ofp.ete || ofp.est_ete);
      if (Number.isFinite(ete)) this.routeInfo.planEteSec = ete;
      this.paintProgress();
      const depIcao = data.dep && data.dep.icao ? String(data.dep.icao).toUpperCase() : "";
      const destIcao = data.dest && data.dest.icao ? String(data.dest.icao).toUpperCase() : "";
      yield httpJson(this.api("api/session"), {
        method: "POST",
        body: {
          client_id: "navapron-efb",
          payload: {
            mode: "journey",
            depIcao: depIcao || null,
            destIcao: destIcao || null,
            fpFields: {
              dep: depIcao,
              dest: destIcao,
              route: data.route_text || data.icao_route || ""
            },
            flightPlan: {
              dep: data.dep,
              dest: data.dest,
              coords: data.coords,
              legs: data.legs,
              distance_nm: data.distance_nm,
              icao_route: data.icao_route,
              route_text: data.route_text,
              linked: true,
              source: "simbrief",
              // Full import payload so PC can run applySimBriefPlan (loads BOTH charts)
              _raw: data
            },
            ofpSummary: data.ofp_summary,
            source: "navapron-efb"
          }
        }
      });
    });
  }
};
__name(_NavApronView, "NavApronView");
__publicField(_NavApronView, "SB_ID_KEY", "navapron_efb_simbrief_user");
__publicField(_NavApronView, "ORIENT_KEY", "navapron_efb_orientation");
let NavApronView = _NavApronView;
const _NAVAPRON_EFB = class _NAVAPRON_EFB extends App {
  constructor() {
    super(...arguments);
    __publicField(this, "BootMode", AppBootMode.COLD);
    __publicField(this, "SuspendMode", AppSuspendMode.SLEEP);
  }
  get name() {
    return "NavApron";
  }
  get icon() {
    return `${APP_COUI}/assets/app-icon.png`;
  }
  /** Shown on the stock MSFS EFB Apps list (open with TAB even on payware aircraft). */
  get compatibleAircraftModels() {
    return void 0;
  }
  install() {
    return __async(this, null, function* () {
      Efb.loadCss(`${APP_COUI}/navapron_efb.css`);
      return Promise.resolve();
    });
  }
  render() {
    return /* @__PURE__ */ msfssdk.FSComponent.buildComponent(NavApronView, { bus: this.bus });
  }
};
__name(_NAVAPRON_EFB, "NAVAPRON_EFB");
let NAVAPRON_EFB = _NAVAPRON_EFB;
Efb.use(NAVAPRON_EFB);

})();
