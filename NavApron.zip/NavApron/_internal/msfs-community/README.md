# NavApron MSFS 2024 Community packages

## `navapron-panel` (in-sim planner)

Native **toolbar remote** (Coherent HTML/JS) so you can drive NavApron without Alt-Tab:

- Live ALT / GS / HDG / ground state (**SimVar**)
- Mode buttons (Taxi / Journey / Plan) + **Follow** for the PC map
- Airport search, runway + stand picks
- **Clearance** text + **Show path** (routes via hub, updates PC map when Session sync is on)
- Nose-relative **taxi arrow** + distance / taxiway callout
- **Taxi-in** one-shot (OFP gate / stand)
- **SimBrief** import last OFP

**Map & charts** stay in the **NavApron desktop / browser** window. MSFS 2024 does
not paint `http://` iframes in custom toolbar panels.

### Install

1. Run **NavApron**
2. Hub → **Settings** → **MSFS 2024 in-sim panel** → **Install / Update panel**
3. **Restart NavApron** (binds LAN + writes URL config)
4. Fully restart **MSFS 2024**
5. In a flight, open the **stock MSFS EFB** (usually **TAB**, or the toolbar tablet icon)
   → **Apps** → **NavApron**
6. Keep NavApron running on the PC; enable **Session sync** so the map follows Show path

Payware aircraft (PMDG, Fenix, etc.) often have their **own** cockpit tablet for aircraft
functions. You can still open the **stock MSFS EFB** (TAB / toolbar) on those planes —
community apps like NavApron live there, not inside the payware tablet UI.

Optional: the toolbar **Custom Panel / NavApron** remote works on any aircraft if you
prefer that over the stock EFB.

Stock EFB tip: open **Apps** (not only Planner / Aircraft). After installing or updating
the EFB package, **fully quit and restart MSFS** so the Apps list rescans Community packages.

## `navapron-efb`

Native **EFB tablet** app (recommended for touch):

- Live ALT / GS / HDG
- Departure search, **runway tap chips**, clearance, **Show path**
- Taxi direction arrow
- SimBrief import
- Pushes paths to the PC hub (Session sync)

Same limits as the toolbar: no embedded Leaflet map — map stays on the PC.

### Rebuild EFB companion JS (developers)

```bat
cd efb-app
npm install
npm run build
python ..\tools\build_efb_layout.py
```
