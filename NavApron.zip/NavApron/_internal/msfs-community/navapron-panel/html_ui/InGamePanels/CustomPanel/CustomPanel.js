class IngamePanelCustomPanel extends TemplateElement {
    constructor() {
        super(...arguments);
        this.panelActive = false;
        this.started = false;
        this.ingameUi = null;
        this._unhideObserver = null;
        this._unhideTimer = null;
        this._simTimer = null;
        this._hubTimer = null;
        this._searchTimers = { dep: null, dest: null };
        this.hubBase = "";
        this.hubOk = false;
        this.dep = null;
        this.dest = null;
        this.ofp = null;
        this.layoutCache = {}; // icao -> { runway_ends, parking }
        this.selectedRwy = null;
        this.selectedStand = null;
        this.useAircraftStart = true;
        this.followOn = false;
        this.remoteMode = "taxi";
        this.live = { alt: NaN, gs: NaN, hdg: NaN, lat: NaN, lon: NaN, onGround: null };
        this.taxiRoute = null;
        this.initialize();
    }

    connectedCallback() {
        super.connectedCallback();
        var self = this;
        this.ingameUi = this.querySelector("ingame-ui");
        var main = document.querySelector("#MainDisplay");
        if (main) main.classList.add("hidden");
        var footer = document.querySelector("#Footer");
        if (footer) footer.classList.add("hidden");

        this.startUnhideWatch();
        this.unhidePanel();
        this.bindUi();
        this.setStatus("In-sim remote ready");
        this.refreshHub(true);
        this.startSimPoll();
        this.startHubPoll();

        if (this.ingameUi) {
            this.ingameUi.addEventListener("panelActive", function () {
                self.panelActive = true;
                self.unhidePanel();
                self.refreshHub(false);
            });
            this.ingameUi.addEventListener("panelInactive", function () {
                self.panelActive = false;
            });
        }
        setTimeout(function () {
            self.unhidePanel();
            self.refreshHub(true);
        }, 700);
    }

    initialize() {
        if (this.started) return;
        this.started = true;
        var self = this;
        setTimeout(function () { self.unhidePanel(); }, 200);
        setTimeout(function () { self.unhidePanel(); }, 1500);
    }

    disconnectedCallback() {
        this.stopUnhideWatch();
        if (this._simTimer) clearInterval(this._simTimer);
        if (this._hubTimer) clearInterval(this._hubTimer);
        super.disconnectedCallback();
    }

    /* -- DOM helpers --------------------------------------------- */

    bindUi() {
        var self = this;
        this.onClick("na-btn-recheck", function () { self.refreshHub(true); });
        this.onClick("na-btn-sb-import", function () { self.importSimBrief(); });
        this.onClick("na-btn-show-path", function () { self.showPath(false); });
        this.onClick("na-btn-taxi-in", function () { self.taxiIn(); });
        this.onClick("na-btn-use-ac", function () {
            self.useAircraftStart = true;
            self.selectedStand = null;
            var st = document.getElementById("na-stand");
            if (st) st.value = "";
            self.setMsg("na-taxi-msg", "Start = live aircraft position", "ok");
        });
        this.onClick("na-btn-follow", function () {
            self.followOn = !self.followOn;
            self.paintFollowBtn();
            self.pushSession({ followPlan: self.followOn, panelCommand: null });
            self.setStatus(self.followOn ? "Follow ON (PC map)" : "Follow OFF");
        });

        var tabs = document.querySelectorAll(".na-tab");
        for (var i = 0; i < tabs.length; i++) {
            (function (btn) {
                btn.addEventListener("click", function () {
                    self.showTab(btn.getAttribute("data-tab"));
                });
            })(tabs[i]);
        }

        var modes = document.querySelectorAll(".na-btn-mode[data-mode]");
        for (var m = 0; m < modes.length; m++) {
            (function (btn) {
                btn.addEventListener("click", function () {
                    self.setRemoteMode(btn.getAttribute("data-mode"));
                });
            })(modes[m]);
        }

        this.wireSearch("dep");
        this.wireSearch("dest");

        var stand = document.getElementById("na-stand");
        if (stand) {
            stand.addEventListener("change", function () {
                self.onStandChange();
            });
            stand.addEventListener("blur", function () {
                self.onStandChange();
            });
        }

        var sb = document.getElementById("na-sb-user");
        if (sb) {
            sb.addEventListener("change", function () { self.saveSimBriefUser(sb.value); });
            sb.addEventListener("blur", function () { self.saveSimBriefUser(sb.value); });
        }
        this.paintFollowBtn();
        this.paintModeBtns();
    }

    onClick(id, fn) {
        var el = document.getElementById(id);
        if (el) el.addEventListener("click", fn);
    }

    showTab(name) {
        var tabs = document.querySelectorAll(".na-tab");
        for (var i = 0; i < tabs.length; i++) {
            var on = tabs[i].getAttribute("data-tab") === name;
            if (on) tabs[i].classList.add("active");
            else tabs[i].classList.remove("active");
        }
        var names = ["plan", "taxi", "simbrief"];
        for (var j = 0; j < names.length; j++) {
            var p = document.getElementById("na-tab-" + names[j]);
            if (!p) continue;
            p.hidden = names[j] !== name;
        }
    }

    setStatus(msg) {
        var el = document.getElementById("NavApronStatus");
        if (el) el.textContent = msg;
    }

    setMsg(id, text, kind) {
        var el = document.getElementById(id);
        if (!el) return;
        el.textContent = text || "";
        el.className = "na-msg" + (kind ? " " + kind : "");
    }

    setText(id, text) {
        var el = document.getElementById(id);
        if (el) el.textContent = text;
    }

    pad3(n) {
        var s = String(n);
        while (s.length < 3) s = "0" + s;
        return s;
    }

    esc(s) {
        return String(s == null ? "" : s)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");
    }

    paintFollowBtn() {
        var btn = document.getElementById("na-btn-follow");
        if (!btn) return;
        if (this.followOn) btn.classList.add("active");
        else btn.classList.remove("active");
        btn.textContent = this.followOn ? "Follow ON" : "Follow";
    }

    paintModeBtns() {
        var btns = document.querySelectorAll(".na-btn-mode[data-mode]");
        for (var i = 0; i < btns.length; i++) {
            var on = btns[i].getAttribute("data-mode") === this.remoteMode;
            if (on) btns[i].classList.add("active");
            else btns[i].classList.remove("active");
        }
    }

    setRemoteMode(mode) {
        this.remoteMode = mode || "taxi";
        this.paintModeBtns();
        var step = mode === "flightplan" ? "flightplan" : mode === "journey" ? "taxi-out" : "taxi-out";
        var payloadMode = mode === "flightplan" ? "flightplan" : mode === "journey" ? "journey" : "taxi";
        this.pushSession({
            mode: payloadMode,
            journeyStep: mode === "journey" ? "taxi-out" : step,
            panelCommand: null,
        });
        this.setStatus("PC mode -> " + mode);
        if (mode === "taxi" || mode === "journey") this.showTab("taxi");
    }

    /* -- Unhide -------------------------------------------------- */

    startUnhideWatch() {
        var self = this;
        this.stopUnhideWatch();
        this._unhideTimer = setInterval(function () { self.unhidePanel(); }, 500);
        try {
            var panel = document.getElementById("CustomPanel") || this.ingameUi || document.body;
            if (!panel || typeof MutationObserver === "undefined") return;
            this._unhideObserver = new MutationObserver(function () { self.unhidePanel(); });
            this._unhideObserver.observe(panel, {
                attributes: true,
                attributeFilter: ["class", "style"],
                subtree: true,
            });
        } catch (e) {}
    }

    stopUnhideWatch() {
        if (this._unhideTimer) {
            clearInterval(this._unhideTimer);
            this._unhideTimer = null;
        }
        if (this._unhideObserver) {
            try { this._unhideObserver.disconnect(); } catch (e) {}
            this._unhideObserver = null;
        }
    }

    unhidePanel() {
        var panel = document.getElementById("CustomPanel") || this.ingameUi;
        var roots = [panel, document.querySelector("ingamepanel-custom"), document.body];
        for (var r = 0; r < roots.length; r++) {
            var el = roots[r];
            if (!el || !el.classList) continue;
            try {
                if (el.classList.contains("hide")) el.classList.remove("hide");
                if (el.classList.contains("panelInvisible")) el.classList.remove("panelInvisible");
                el.style.setProperty("visibility", "visible", "important");
                el.style.setProperty("opacity", "1", "important");
                el.style.setProperty("display", "flex", "important");
            } catch (e) {}
        }
        if (panel) {
            try {
                panel.setAttribute("title", "NavApron");
                panel.title = "NavApron";
            } catch (e2) {}
        }
    }

    /* -- Hub HTTP ------------------------------------------------ */

    hubCandidates() {
        var urls = [];
        var push = function (u) {
            u = (u || "").trim();
            if (!u) return;
            u = u.replace(/\/efb\/?$/i, "/").replace(/\/panel\/?$/i, "/");
            if (u.charAt(u.length - 1) !== "/") u += "/";
            if (urls.indexOf(u) < 0) urls.push(u);
        };
        try {
            var cfg = window.NAVAPRON_PANEL_URLS || window.NAVAPRON_EFB_URLS || [];
            for (var i = 0; i < cfg.length; i++) push(String(cfg[i]));
        } catch (e1) {}
        var ports = window.NAVAPRON_PANEL_PORTS || [8765, 8766, 8767, 8768, 8769, 8770];
        var hosts = ["127.0.0.1", "localhost"];
        try {
            var configured = window.NAVAPRON_PANEL_URLS || [];
            for (var j = 0; j < configured.length; j++) {
                var m = /^https?:\/\/([^/:]+)/i.exec(String(configured[j]));
                if (m && hosts.indexOf(m[1]) < 0) hosts.unshift(m[1]);
            }
        } catch (e2) {}
        for (var h = 0; h < hosts.length; h++) {
            for (var p = 0; p < ports.length; p++) push("http://" + hosts[h] + ":" + ports[p] + "/");
        }
        return urls;
    }

    api(path) {
        var base = this.hubBase || this.hubCandidates()[0] || "http://127.0.0.1:8765/";
        if (path.charAt(0) === "/") path = path.slice(1);
        return base + path;
    }

    getJson(path, cb) {
        var url = this.api(path);
        try {
            if (typeof fetch === "function") {
                fetch(url, { cache: "no-store", mode: "cors" })
                    .then(function (r) {
                        return r.json().catch(function () { return null; }).then(function (data) {
                            cb(r.ok, data, null);
                        });
                    })
                    .catch(function (e) { cb(false, null, e); });
                return;
            }
        } catch (e0) {}
        try {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", url, true);
            xhr.timeout = 15000;
            xhr.onload = function () {
                var data = null;
                try { data = JSON.parse(xhr.responseText || "null"); } catch (e1) {}
                cb(xhr.status >= 200 && xhr.status < 300, data, null);
            };
            xhr.onerror = function () { cb(false, null, "xhr"); };
            xhr.ontimeout = function () { cb(false, null, "timeout"); };
            xhr.send();
        } catch (e2) {
            cb(false, null, e2);
        }
    }

    postJson(path, body, cb) {
        var url = this.api(path);
        try {
            if (typeof fetch === "function") {
                fetch(url, {
                    method: "POST",
                    cache: "no-store",
                    mode: "cors",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(body),
                })
                    .then(function (r) {
                        return r.json().catch(function () { return {}; }).then(function (data) {
                            cb(r.ok && data.ok !== false, data, null);
                        });
                    })
                    .catch(function (e) { cb(false, null, e); });
                return;
            }
        } catch (e0) {}
        try {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", url, true);
            xhr.timeout = 25000;
            xhr.setRequestHeader("Content-Type", "application/json");
            xhr.onload = function () {
                var data = {};
                try { data = JSON.parse(xhr.responseText || "{}"); } catch (e1) {}
                cb(xhr.status >= 200 && xhr.status < 300 && data.ok !== false, data, null);
            };
            xhr.onerror = function () { cb(false, null, "xhr"); };
            xhr.ontimeout = function () { cb(false, null, "timeout"); };
            xhr.send(JSON.stringify(body));
        } catch (e2) {
            cb(false, null, e2);
        }
    }

    startHubPoll() {
        var self = this;
        if (this._hubTimer) clearInterval(this._hubTimer);
        this._hubTimer = setInterval(function () { self.refreshHub(false); }, 10000);
    }

    refreshHub(loadPrefs) {
        var self = this;
        var urls = this.hubCandidates();
        var idx = 0;
        var tryNext = function () {
            if (idx >= urls.length) {
                self.hubOk = false;
                self.paintHub(false, self.hubBase || urls[0] || "-");
                self.setStatus("Hub offline - start NavApron on PC");
                return;
            }
            var base = urls[idx++];
            self.probeHealth(base, function (ok) {
                if (ok) {
                    self.hubBase = base;
                    self.hubOk = true;
                    self.paintHub(true, base);
                    if (loadPrefs) self.loadPrefs();
                } else tryNext();
            });
        };
        tryNext();
    }

    probeHealth(base, cb) {
        var url = base.replace(/\/?$/, "/") + "api/health";
        try {
            if (typeof fetch === "function") {
                fetch(url, { cache: "no-store", mode: "cors" })
                    .then(function (r) {
                        return r.json().then(function (d) {
                            cb(r.ok && d && d.status === "ok");
                        }).catch(function () { cb(r.ok); });
                    })
                    .catch(function () { cb(false); });
                return;
            }
        } catch (e) {}
        try {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", url, true);
            xhr.timeout = 4000;
            xhr.onload = function () {
                try {
                    var d = JSON.parse(xhr.responseText || "{}");
                    cb(xhr.status >= 200 && xhr.status < 300 && d.status === "ok");
                } catch (e2) {
                    cb(xhr.status >= 200 && xhr.status < 300);
                }
            };
            xhr.onerror = function () { cb(false); };
            xhr.ontimeout = function () { cb(false); };
            xhr.send();
        } catch (e3) {
            cb(false);
        }
    }

    paintHub(ok, url) {
        var dot = document.getElementById("na-hub-dot");
        var label = document.getElementById("na-hub-label");
        var urlEl = document.getElementById("na-hub-url");
        if (dot) dot.className = "na-hub-dot " + (ok ? "ok" : "bad");
        if (label) label.textContent = ok ? "Hub online" : "Hub offline";
        if (urlEl) urlEl.textContent = url || "-";
    }

    loadPrefs() {
        var self = this;
        if (!this.hubOk) return;
        this.getJson("api/user/prefs", function (ok, data) {
            if (!ok || !data) return;
            var el = document.getElementById("na-sb-user");
            if (el && data.simbrief_user && !el.value) el.value = data.simbrief_user;
        });
    }

    saveSimBriefUser(raw) {
        var v = String(raw || "").trim();
        if (!v || !this.hubOk) return;
        this.postJson("api/user/prefs", { simbrief_user: v }, function () {});
    }

    /* -- SimVar -------------------------------------------------- */

    getSimVarApi() {
        try {
            if (window.SimVar && typeof window.SimVar.GetSimVarValue === "function") return window.SimVar;
            if (window.simvar && typeof window.simvar.GetSimVarValue === "function") return window.simvar;
        } catch (e) {}
        return null;
    }

    sv(name, unit) {
        var api = this.getSimVarApi();
        if (!api) return NaN;
        try {
            var v = api.GetSimVarValue(name, unit);
            var n = typeof v === "number" ? v : Number(v);
            return isFinite(n) ? n : NaN;
        } catch (e) {
            return NaN;
        }
    }

    startSimPoll() {
        var self = this;
        if (this._simTimer) clearInterval(this._simTimer);
        this.tickSim();
        this._simTimer = setInterval(function () { self.tickSim(); }, 500);
    }

    tickSim() {
        if (!this.getSimVarApi()) {
            this.setText("na-gnd", "no SimVar");
            return;
        }
        var alt = this.sv("PLANE ALTITUDE", "feet");
        var gs = this.sv("GROUND VELOCITY", "knots");
        var hdg = this.sv("PLANE HEADING DEGREES TRUE", "degrees");
        var lat = this.sv("PLANE LATITUDE", "degrees");
        var lon = this.sv("PLANE LONGITUDE", "degrees");
        var gnd = this.sv("SIM ON GROUND", "bool");
        this.live = { alt: alt, gs: gs, hdg: hdg, lat: lat, lon: lon, onGround: gnd };
        this.setText("na-alt", isFinite(alt) ? Math.round(alt).toString() : "-");
        this.setText("na-gs", isFinite(gs) ? Math.round(gs).toString() : "-");
        this.setText("na-hdg", isFinite(hdg) ? this.pad3(Math.round(hdg) % 360) : "-");
        this.setText("na-gnd", gnd ? "GND" : gnd === 0 || gnd === false ? "AIR" : "-");
        this.updateTaxiArrow();
    }

    /* -- Geometry for arrow -------------------------------------- */

    distM(lat1, lon1, lat2, lon2) {
        var R = 6371000;
        var toRad = Math.PI / 180;
        var dLat = (lat2 - lat1) * toRad;
        var dLon = (lon2 - lon1) * toRad;
        var a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * toRad) * Math.cos(lat2 * toRad) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
    }

    bearingDeg(lat1, lon1, lat2, lon2) {
        var toRad = Math.PI / 180;
        var φ1 = lat1 * toRad;
        var φ2 = lat2 * toRad;
        var Δλ = (lon2 - lon1) * toRad;
        var y = Math.sin(Δλ) * Math.cos(φ2);
        var x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
        return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
    }

    norm180(deg) {
        return ((deg + 180) % 360 + 360) % 360 - 180;
    }

    nextRouteTarget(lat, lon, coords) {
        if (!coords || !coords.length) return null;
        var bestI = 0;
        var bestD = Infinity;
        for (var i = 0; i < coords.length; i++) {
            var c = coords[i];
            if (!c || c.length < 2) continue;
            var d = this.distM(lat, lon, c[0], c[1]);
            if (d < bestD) {
                bestD = d;
                bestI = i;
            }
        }
        for (var j = bestI; j < coords.length; j++) {
            var p = coords[j];
            if (!p || p.length < 2) continue;
            if (this.distM(lat, lon, p[0], p[1]) >= 25) {
                return { lat: p[0], lon: p[1], index: j, along: this.distM(lat, lon, p[0], p[1]) };
            }
        }
        var last = coords[coords.length - 1];
        if (!last || last.length < 2) return null;
        return { lat: last[0], lon: last[1], index: coords.length - 1, along: this.distM(lat, lon, last[0], last[1]) };
    }

    remainingRouteM(lat, lon, coords) {
        var t = this.nextRouteTarget(lat, lon, coords);
        if (!t) return 0;
        var sum = t.along;
        for (var i = t.index; i < coords.length - 1; i++) {
            var a = coords[i];
            var b = coords[i + 1];
            if (!a || !b) continue;
            sum += this.distM(a[0], a[1], b[0], b[1]);
        }
        return sum;
    }

    setLane(active) {
        var left = document.getElementById("na-lane-left");
        var str = document.getElementById("na-lane-str");
        var right = document.getElementById("na-lane-right");
        if (left) {
            if (active === "left") left.classList.add("active");
            else left.classList.remove("active");
        }
        if (str) {
            if (active === "straight") str.classList.add("active");
            else str.classList.remove("active");
        }
        if (right) {
            if (active === "right") right.classList.add("active");
            else right.classList.remove("active");
        }
    }

    updateTaxiArrow() {
        var wrap = document.getElementById("na-arrow-wrap");
        if (!wrap || !this.taxiRoute || !this.taxiRoute.coords) return;
        var lat = this.live.lat;
        var lon = this.live.lon;
        var hdg = this.live.hdg;
        if (!isFinite(lat) || !isFinite(lon) || !isFinite(hdg)) return;
        wrap.hidden = false;
        var target = this.nextRouteTarget(lat, lon, this.taxiRoute.coords);
        if (!target) return;
        var remain = this.remainingRouteM(lat, lon, this.taxiRoute.coords);
        if (remain < 15) {
            this.setLane("straight");
            this.setText("na-arrow-cmd", "ARRIVED");
            this.setText("na-arrow-dist", "At runway / end");
            this.setText("na-arrow-twy", this.taxiRoute.endLabel || "");
            return;
        }
        var brng = this.bearingDeg(lat, lon, target.lat, target.lon);
        var rel = this.norm180(brng - hdg);
        var abs = Math.abs(rel);
        var lane = "straight";
        var cmd = "GO AHEAD";
        if (abs >= 25) {
            if (rel < 0) {
                lane = "left";
                cmd = abs >= 90 ? "HARD LEFT" : abs >= 50 ? "TURN LEFT" : "BEAR LEFT";
            } else {
                lane = "right";
                cmd = abs >= 90 ? "HARD RIGHT" : abs >= 50 ? "TURN RIGHT" : "BEAR RIGHT";
            }
        }
        this.setLane(lane);
        this.setText("na-arrow-cmd", cmd + "  (" + Math.round(abs) + "°)");
        this.setText(
            "na-arrow-dist",
            remain >= 1852
                ? (remain / 1852).toFixed(2) + " nm remaining"
                : Math.round(remain) + " m remaining"
        );
        var tw = (this.taxiRoute.taxiways || []).join(" -> ");
        this.setText(
            "na-arrow-twy",
            (this.taxiRoute.endLabel ? "To " + this.taxiRoute.endLabel : "") + (tw ? " | via " + tw : "")
        );
    }

    /* -- Airports / layout --------------------------------------- */

    wireSearch(role) {
        var self = this;
        var input = document.getElementById("na-" + role + "-q");
        if (!input) return;
        input.addEventListener("input", function () {
            if (self._searchTimers[role]) clearTimeout(self._searchTimers[role]);
            self._searchTimers[role] = setTimeout(function () {
                self.runSearch(role, input.value);
            }, 280);
        });
    }

    runSearch(role, q) {
        var self = this;
        var list = document.getElementById("na-" + role + "-results");
        if (!list || !this.hubOk) {
            if (list) list.hidden = true;
            return;
        }
        q = String(q || "").trim();
        if (q.length < 1) {
            list.innerHTML = "";
            list.hidden = true;
            return;
        }
        this.getJson("api/airports/search?q=" + encodeURIComponent(q) + "&limit=12", function (ok, data) {
            var rows = Array.isArray(data) ? data : [];
            list.innerHTML = "";
            if (!ok || !rows.length) {
                list.hidden = true;
                return;
            }
            for (var i = 0; i < rows.length; i++) {
                (function (ap) {
                    var li = document.createElement("li");
                    li.innerHTML =
                        '<span class="code">' + self.esc(ap.icao || "") + "</span>" +
                        '<span class="meta">' + self.esc([ap.name, ap.city].filter(Boolean).join(" | ")) + "</span>";
                    li.addEventListener("click", function () { self.pickAirport(role, ap); });
                    list.appendChild(li);
                })(rows[i]);
            }
            list.hidden = false;
        });
    }

    pickAirport(role, ap) {
        if (role === "dep") this.dep = ap;
        else this.dest = ap;
        var icao = (ap.icao || "").toUpperCase();
        this.setText("na-" + role + "-picked", icao || "-");
        var input = document.getElementById("na-" + role + "-q");
        if (input) input.value = icao;
        var list = document.getElementById("na-" + role + "-results");
        if (list) {
            list.innerHTML = "";
            list.hidden = true;
        }
        if (role === "dep" && icao) this.loadLayout(icao);
        this.pushSession({ panelCommand: null });
    }

    loadLayout(icao, cb) {
        var self = this;
        icao = String(icao || "").toUpperCase();
        if (!icao || !this.hubOk) {
            if (cb) cb(false);
            return;
        }
        if (this.layoutCache[icao]) {
            this.fillRwyStand(icao);
            if (cb) cb(true, this.layoutCache[icao]);
            return;
        }
        this.getJson("api/airports/" + encodeURIComponent(icao) + "/layout", function (ok, data) {
            if (!ok || !data) {
                if (cb) cb(false);
                return;
            }
            var parking = [];
            try {
                var layout = data.layout || {};
                var raw = layout.parking || layout.stands || layout.gates || [];
                if (Array.isArray(raw)) parking = raw;
            } catch (e) {}
            self.layoutCache[icao] = {
                runway_ends: data.runway_ends || [],
                parking: parking,
                airport: data.airport || null,
            };
            self.fillRwyStand(icao);
            if (cb) cb(true, self.layoutCache[icao]);
        });
    }

    fillRwyStand(icao) {
        var self = this;
        var cache = this.layoutCache[icao];
        if (!cache) return;
        var row = document.getElementById("na-rwy-chips");
        if (row) {
            row.innerHTML = "";
            var ends = cache.runway_ends || [];
            if (!ends.length) {
                row.innerHTML = '<span class="na-hint">No runways in layout</span>';
                this.selectedRwy = null;
            } else {
                var want = (this.ofp && this.ofp.dep_rwy) || "";
                want = String(want).replace(/^RWY\s*/i, "").toUpperCase();
                var picked = null;
                for (var i = 0; i < ends.length; i++) {
                    (function (e, idx) {
                        var name = String(e.name || e.runway || "").replace(/^RWY\s*/i, "");
                        var btn = document.createElement("button");
                        btn.type = "button";
                        btn.className = "na-chip";
                        btn.textContent = name || ("R" + idx);
                        btn.setAttribute("data-idx", String(idx));
                        if (want && name.toUpperCase() === want) {
                            btn.classList.add("active");
                            picked = e;
                        }
                        btn.addEventListener("click", function () {
                            self.selectRwy(idx);
                        });
                        row.appendChild(btn);
                    })(ends[i], i);
                }
                if (picked) this.selectedRwy = picked;
                else if (ends.length === 1) this.selectRwy(0);
                else this.selectedRwy = null;
            }
        }
        var dl = document.getElementById("na-stand-list");
        if (dl) {
            dl.innerHTML = "";
            var parks = cache.parking || [];
            for (var j = 0; j < parks.length; j++) {
                var p = parks[j];
                var label = p.ref || p.name || p.label || "";
                if (!label) continue;
                var o = document.createElement("option");
                o.value = label;
                dl.appendChild(o);
            }
        }
    }

    selectRwy(idx) {
        var icao = this.depIcao();
        var cache = icao && this.layoutCache[icao];
        if (!cache) {
            this.selectedRwy = null;
            return;
        }
        var ends = cache.runway_ends || [];
        this.selectedRwy = ends[idx] || null;
        var row = document.getElementById("na-rwy-chips");
        if (row) {
            var chips = row.querySelectorAll(".na-chip");
            for (var i = 0; i < chips.length; i++) {
                if (String(i) === String(idx)) chips[i].classList.add("active");
                else chips[i].classList.remove("active");
            }
        }
        var name = this.selectedRwy && (this.selectedRwy.name || this.selectedRwy.runway);
        this.setMsg("na-taxi-msg", name ? ("Runway " + name + " selected") : "Runway selected", "ok");
        this.setStatus(name ? ("RWY " + name) : "Runway set");
    }

    onRwyChange() {
        // legacy no-op - chips call selectRwy
    }

    onStandChange() {
        var icao = this.depIcao();
        var cache = icao && this.layoutCache[icao];
        var input = document.getElementById("na-stand");
        var q = input ? String(input.value || "").trim().toUpperCase() : "";
        this.selectedStand = null;
        this.useAircraftStart = !q;
        if (!q || !cache) return;
        var parks = cache.parking || [];
        for (var i = 0; i < parks.length; i++) {
            var p = parks[i];
            var label = String(p.ref || p.name || p.label || "").toUpperCase();
            if (label === q || label.replace(/\s+/g, "") === q.replace(/\s+/g, "")) {
                if (p.lat != null && p.lon != null) {
                    this.selectedStand = {
                        lat: Number(p.lat),
                        lon: Number(p.lon),
                        label: p.ref || p.name || p.label || "Stand",
                    };
                    this.useAircraftStart = false;
                }
                break;
            }
        }
    }

    depIcao() {
        return (
            (this.dep && (this.dep.icao || this.dep.ident)) ||
            (this.ofp && this.ofp.dep && this.ofp.dep.icao) ||
            ""
        ).toString().toUpperCase();
    }

    destIcao() {
        return (
            (this.dest && (this.dest.icao || this.dest.ident)) ||
            (this.ofp && this.ofp.dest && this.ofp.dest.icao) ||
            ""
        ).toString().toUpperCase();
    }

    parseClearance() {
        var el = document.getElementById("na-clearance");
        var raw = el ? String(el.value || "") : "";
        return raw
            .toUpperCase()
            .replace(/[,;|/]+/g, " ")
            .split(/\s+/)
            .map(function (t) { return t.trim(); })
            .filter(Boolean);
    }

    startPoint() {
        if (!this.useAircraftStart && this.selectedStand) return this.selectedStand;
        if (isFinite(this.live.lat) && isFinite(this.live.lon)) {
            return { lat: this.live.lat, lon: this.live.lon, label: "Aircraft" };
        }
        if (this.selectedStand) return this.selectedStand;
        return null;
    }

    /* -- Show path / taxi-in ------------------------------------- */

    showPath() {
        var self = this;
        if (!this.hubOk) {
            this.setMsg("na-taxi-msg", "Hub offline - start NavApron on PC", "bad");
            return;
        }
        var icao = this.depIcao();
        if (!icao) {
            this.setMsg("na-taxi-msg", "Pick a departure airport first", "bad");
            return;
        }
        this.onRwyChange();
        this.onStandChange();
        var start = this.startPoint();
        if (!start) {
            this.setMsg("na-taxi-msg", "No start - need SimVar position or a stand", "bad");
            return;
        }
        var ensure = function (cb) {
            if (self.layoutCache[icao]) cb(true);
            else self.loadLayout(icao, cb);
        };
        this.setMsg("na-taxi-msg", "Routing...", "busy");
        var btn = document.getElementById("na-btn-show-path");
        if (btn) btn.disabled = true;

        ensure(function (ok) {
            if (!ok) {
                if (btn) btn.disabled = false;
                self.setMsg("na-taxi-msg", "Could not load layout", "bad");
                return;
            }
            self.onRwyChange();
            var end = self.selectedRwy;
            if (!end || end.lat == null) {
                if (btn) btn.disabled = false;
                self.setMsg("na-taxi-msg", "Select a departure runway", "bad");
                return;
            }
            var clearance = self.parseClearance();
            var body = {
                icao: icao,
                start_lat: start.lat,
                start_lon: start.lon,
                end_lat: end.lat,
                end_lon: end.lon,
                clearance: clearance,
                end_is_runway_threshold: true,
                start_heading_deg: self.useAircraftStart && isFinite(self.live.hdg) ? self.live.hdg : null,
            };
            self.postJson("api/route", body, function (rok, route) {
                if (btn) btn.disabled = false;
                if (!rok || !route || route.ok === false) {
                    self.setMsg("na-taxi-msg", (route && (route.error || route.message)) || "Route failed", "bad");
                    return;
                }
                self.applyRouteResult(route, end.name || "RWY", clearance, start, end, "taxi-out");
            });
        });
    }

    taxiIn() {
        var self = this;
        if (!this.hubOk) {
            this.setMsg("na-taxi-msg", "Hub offline", "bad");
            return;
        }
        var icao = this.destIcao() || this.depIcao();
        if (!icao) {
            this.setMsg("na-taxi-msg", "Need arrival (or dep) airport", "bad");
            return;
        }
        var land = (this.ofp && this.ofp.arr_rwy) || "";
        land = String(land).replace(/^RWY\s*/i, "");
        var standLat = null;
        var standLon = null;
        var standLabel = "Stand";
        // Prefer OFP gate match in dest layout; else selected stand; else prompt
        var finish = function () {
            if (standLat == null) {
                self.setMsg("na-taxi-msg", "Set arrival stand on Taxi tab (or import OFP with gate)", "bad");
                return;
            }
            if (!land) {
                // pick first runway as fallback after layout
                var cache = self.layoutCache[icao];
                if (cache && cache.runway_ends && cache.runway_ends[0]) {
                    land = cache.runway_ends[0].name || "";
                }
            }
            if (!land) {
                self.setMsg("na-taxi-msg", "Need arrival runway (from OFP)", "bad");
                return;
            }
            var btn = document.getElementById("na-btn-taxi-in");
            if (btn) btn.disabled = true;
            self.setMsg("na-taxi-msg", "Taxi-in routing...", "busy");
            var body = {
                icao: icao,
                land_runway: land,
                stand_lat: standLat,
                stand_lon: standLon,
                clearance: self.parseClearance(),
                aircraft_lat: isFinite(self.live.lat) ? self.live.lat : null,
                aircraft_lon: isFinite(self.live.lon) ? self.live.lon : null,
                aircraft_heading_deg: isFinite(self.live.hdg) ? self.live.hdg : null,
            };
            self.postJson("api/route/taxi-in", body, function (ok, route) {
                if (btn) btn.disabled = false;
                if (!ok || !route || route.ok === false) {
                    self.setMsg("na-taxi-msg", (route && (route.error || route.message)) || "Taxi-in failed", "bad");
                    return;
                }
                self.applyRouteResult(
                    route,
                    standLabel,
                    self.parseClearance(),
                    { lat: route.exit_lat || self.live.lat, lon: route.exit_lon || self.live.lon, label: "Exit" },
                    { lat: standLat, lon: standLon, label: standLabel },
                    "taxi-in"
                );
            });
        };

        this.loadLayout(icao, function (ok, cache) {
            var gate = (self.ofp && (self.ofp.arr_gate || (self.ofp.simbriefMeta && self.ofp.simbriefMeta.arr_gate))) || "";
            gate = String(gate || "").trim().toUpperCase();
            if (ok && cache && gate) {
                var parks = cache.parking || [];
                for (var i = 0; i < parks.length; i++) {
                    var p = parks[i];
                    var label = String(p.ref || p.name || p.label || "").toUpperCase();
                    if (label === gate || label.indexOf(gate) >= 0) {
                        standLat = Number(p.lat);
                        standLon = Number(p.lon);
                        standLabel = p.ref || p.name || gate;
                        break;
                    }
                }
            }
            if (standLat == null && self.selectedStand) {
                standLat = self.selectedStand.lat;
                standLon = self.selectedStand.lon;
                standLabel = self.selectedStand.label;
            }
            // Also try typing in stand field against dest layout
            if (standLat == null) {
                var input = document.getElementById("na-stand");
                var q = input ? String(input.value || "").trim().toUpperCase() : "";
                if (q && cache) {
                    var parks2 = cache.parking || [];
                    for (var j = 0; j < parks2.length; j++) {
                        var p2 = parks2[j];
                        var lab2 = String(p2.ref || p2.name || p2.label || "").toUpperCase();
                        if (lab2 === q) {
                            standLat = Number(p2.lat);
                            standLon = Number(p2.lon);
                            standLabel = p2.ref || p2.name || q;
                            break;
                        }
                    }
                }
            }
            finish();
        });
    }

    applyRouteResult(route, endLabel, clearance, start, end, step) {
        var twList = route.taxiways_used || [];
        var tw = twList.join(", ") || "(unnamed)";
        var nm = route.distance_nm != null ? Number(route.distance_nm).toFixed(2) : "?";
        var summary =
            "To " + endLabel + "\n" +
            nm + " nm\n" +
            "Via: " + tw +
            (clearance.length ? "\nClearance: " + clearance.join(" ") : "") +
            (route.message ? "\n" + route.message : "");
        var box = document.getElementById("na-taxi-summary");
        if (box) {
            box.textContent = summary;
            box.hidden = false;
        }
        this.taxiRoute = {
            coords: route.coords || [],
            taxiways: twList,
            endLabel: endLabel,
        };
        this.showTab("taxi");
        this.updateTaxiArrow();
        this.setMsg("na-taxi-msg", "Path ready - arrow guides you; PC map updates if sync is on", "ok");
        this.setStatus("Taxi " + nm + " nm via " + tw);

        var isIn = step === "taxi-in";
        var snapKey = isIn ? "taxiIn" : "route";
        var snapshots = { route: null, taxiIn: null, departure: null, arrival: null };
        if (isIn) {
            snapshots.taxiIn = { data: route, startInfo: start };
        } else {
            snapshots.route = { data: route, start: start, end: end };
        }
        this.pushSession({
            mode: this.remoteMode === "flightplan" ? "flightplan" : this.remoteMode === "journey" ? "journey" : "taxi",
            journeyStep: isIn ? "taxi-in" : "taxi-out",
            clearance: isIn ? [] : clearance,
            arrClearance: isIn ? clearance : [],
            start: !isIn ? start : null,
            end: !isIn ? { lat: end.lat, lon: end.lon, label: endLabel } : null,
            runway: !isIn ? end : null,
            arrivalStand: isIn ? { lat: end.lat, lon: end.lon, label: endLabel } : null,
            pathSnapshots: snapshots,
            followPlan: this.followOn,
            fromAircraft: this.useAircraftStart,
            panelCommand: null,
            source: "navapron-panel",
        });
    }

    /* -- SimBrief ------------------------------------------------ */

    importSimBrief() {
        var self = this;
        var userEl = document.getElementById("na-sb-user");
        var user = userEl ? String(userEl.value || "").trim() : "";
        if (!user) {
            this.setMsg("na-sb-msg", "Enter SimBrief username or pilot ID", "bad");
            return;
        }
        if (!this.hubOk) {
            this.setMsg("na-sb-msg", "Hub offline", "bad");
            return;
        }
        this.saveSimBriefUser(user);
        this.setMsg("na-sb-msg", "Importing...", "busy");
        var btn = document.getElementById("na-btn-sb-import");
        if (btn) btn.disabled = true;
        this.postJson("api/simbrief/import", { username: user }, function (ok, data) {
            if (btn) btn.disabled = false;
            if (!ok || !data) {
                var msg = (data && (data.detail || data.error)) || "Import failed";
                self.setMsg("na-sb-msg", typeof msg === "string" ? msg : "Import failed", "bad");
                return;
            }
            self.ofp = data;
            if (data.dep && data.dep.icao) {
                self.dep = data.dep;
                self.setText("na-dep-picked", data.dep.icao);
                var depQ = document.getElementById("na-dep-q");
                if (depQ) depQ.value = data.dep.icao;
                self.loadLayout(data.dep.icao);
            }
            if (data.dest && data.dest.icao) {
                self.dest = data.dest;
                self.setText("na-dest-picked", data.dest.icao);
                var destQ = document.getElementById("na-dest-q");
                if (destQ) destQ.value = data.dest.icao;
            }
            self.paintOfpSummary(data);
            self.setMsg("na-sb-msg", data.message || "OFP imported", "ok");
            self.pushSession({
                mode: "journey",
                journeyStep: "flightplan",
                flightPlan: {
                    dep: data.dep,
                    dest: data.dest,
                    coords: data.coords,
                    legs: data.legs,
                    distance_nm: data.distance_nm,
                    icao_route: data.icao_route,
                    route_text: data.route_text,
                },
                ofpSummary: data.ofp_summary || null,
                panelCommand: null,
            });
        });
    }

    paintOfpSummary(data) {
        var el = document.getElementById("na-sb-summary");
        if (!el) return;
        var lines = [];
        lines.push(((data.dep && data.dep.icao) || "?") + " -> " + ((data.dest && data.dest.icao) || "?"));
        if (data.aircraft) lines.push("AC: " + data.aircraft);
        if (data.dep_rwy || data.arr_rwy) lines.push("RWY: " + (data.dep_rwy || "-") + " / " + (data.arr_rwy || "-"));
        if (data.sid_ident || data.star_ident) lines.push("SID/STAR: " + (data.sid_ident || "-") + " / " + (data.star_ident || "-"));
        if (data.route_text || data.icao_route) lines.push("Route: " + (data.route_text || data.icao_route));
        if (data.distance_nm) lines.push(Number(data.distance_nm).toFixed(1) + " nm");
        el.textContent = lines.join("\n");
        el.hidden = false;
    }

    /* -- Session push to PC -------------------------------------- */

    pushSession(extra) {
        if (!this.hubOk) return;
        var clearance = this.parseClearance();
        var start = this.startPoint();
        var rwy = this.selectedRwy;
        var payload = {
            mode: this.remoteMode === "journey" ? "journey" : this.remoteMode === "flightplan" ? "flightplan" : "taxi",
            journeyStep: extra && extra.journeyStep ? extra.journeyStep : "taxi-out",
            depIcao: this.depIcao() || null,
            destIcao: this.destIcao() || null,
            clearance: clearance,
            arrClearance: [],
            followPlan: this.followOn,
            start: start,
            end: rwy ? { lat: rwy.lat, lon: rwy.lon, label: rwy.name ? "RWY " + rwy.name : "Runway" } : null,
            runway: rwy,
            arrivalStand: this.selectedStand,
            pathSnapshots: null,
            flightPlan: this.ofp
                ? {
                    dep: this.ofp.dep,
                    dest: this.ofp.dest,
                    coords: this.ofp.coords,
                    legs: this.ofp.legs,
                    distance_nm: this.ofp.distance_nm,
                    icao_route: this.ofp.icao_route,
                    route_text: this.ofp.route_text,
                }
                : null,
            ofpSummary: (this.ofp && this.ofp.ofp_summary) || null,
            source: "navapron-panel",
            fromAircraft: this.useAircraftStart,
            panelCommand: null,
        };
        if (extra) {
            for (var k in extra) {
                if (Object.prototype.hasOwnProperty.call(extra, k)) payload[k] = extra[k];
            }
        }
        this.postJson(
            "api/session",
            { client_id: "navapron-panel", payload: payload },
            function () {}
        );
    }
}

window.customElements.define("ingamepanel-custom", IngamePanelCustomPanel);
checkAutoload();
