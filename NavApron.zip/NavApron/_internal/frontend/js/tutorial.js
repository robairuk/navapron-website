/**
 * NavApron — first-run guided tutorial (DIY full journey).
 * User does the clicks; we spotlight every control for the step.
 * Optional “Do this step for me” if stuck. Skip anytime.
 */
(function () {
  const STORAGE_KEY = "navapron_tutorial_v1_done";
  const DEMO_DEP = "EGNM";
  const DEMO_DEST = "EGLL";

  const $ = (sel) => document.querySelector(sel);

  let active = false;
  let stepIndex = 0;
  let overlayEl = null;
  let spotsEl = null;
  let cardEl = null;
  let pollTimer = null;
  let completeArmed = false;
  /** Disk-backed done flag from /api/user/prefs (survives WebView localStorage wipes) */
  let serverDone = null;
  let prefsReady = false;
  /** Last spotlight layout signature — skip DOM rebuild when unchanged */
  let lastSpotSig = "";
  let lastCardSig = "";

  /** Normalise step.anchors | step.anchor → string[] */
  function stepAnchors(step) {
    if (!step) return [];
    if (Array.isArray(step.anchors) && step.anchors.length) {
      return step.anchors.filter(Boolean);
    }
    if (step.anchor) return [step.anchor];
    return [];
  }

  /**
   * waitFor: function(state) => boolean — when true, step completes.
   * anchors: every control to highlight this step.
   */
  const STEPS = [
    {
      id: "welcome",
      title: "Welcome to NavApron",
      body:
        "You’ll plan a <strong>full flight</strong> yourself: taxi out → enroute → taxi in. " +
        "We’ll highlight every box to use — you click/type in the real UI. " +
        "<strong>Skip</strong> anytime.",
      anchors: [],
      primary: "Let’s go",
      waitFor: null,
    },
    {
      id: "hub-journey",
      title: "Open Full journey",
      body:
        "Click the highlighted <strong>Full journey</strong> card " +
        "(taxi + plan + taxi-in on one map). Wait a moment for the map to start.",
      tip: "Demo route later: " + DEMO_DEP + " → " + DEMO_DEST + ".",
      anchors: ['.hub-card[data-mode="journey"]'],
      waitFor: function (s) {
        return !!(s && s.mode === "journey" && s.mapReady);
      },
      assist: "openJourney",
      assistLabel: "Open Full journey for me",
    },
    {
      id: "load-dep",
      title: "Load departure airport",
      body:
        "Use the highlighted <strong>search box</strong>. Type <strong>" +
        DEMO_DEP +
        "</strong> (or any departure), then click it in the results list.",
      tip: "Airport search is at the top of the left panel.",
      anchors: ["#airport-search", "#search-results"],
      waitFor: function (s) {
        return !!(s && s.depIcao);
      },
      assist: "loadDemoDep",
      assistLabel: "Load " + DEMO_DEP + " for me",
    },
    {
      id: "open-fp-step",
      title: "Open Flight plan",
      body:
        "Click the highlighted journey step <strong>2 · Flight plan</strong>. " +
        "Dest and Load both airports are only on that step.",
      tip: "Top of the window: Taxi out · Flight plan · Taxi in.",
      anchors: ['.journey-step[data-journey-step="flightplan"]'],
      waitFor: function (s) {
        return !!(s && s.journeyStep === "flightplan");
      },
      assist: "openFlightPlanStep",
      assistLabel: "Open Flight plan for me",
    },
    {
      id: "load-dest",
      title: "Destination + load both",
      body:
        "1) Type <strong>" +
        DEMO_DEST +
        "</strong> in the highlighted <strong>Destination ICAO</strong> box.<br>" +
        "2) Click highlighted <strong>Load both airports</strong>.<br>" +
        "Typing alone does nothing until you load.",
      tip: "Dep should already show your departure — scroll the left panel if needed.",
      anchors: ["#fp-dep", "#fp-dest", "#btn-fp-both"],
      waitFor: function (s) {
        return !!(s && s.depIcao && s.destIcao && s.depIcao !== s.destIcao);
      },
      assist: "loadDemoAirports",
      assistLabel: "Load " + DEMO_DEP + " → " + DEMO_DEST + " for me",
    },
    {
      id: "taxi-out",
      title: "Taxi out path",
      body:
        "1) Click <strong>1 · Taxi out</strong>.<br>" +
        "2) Choose <strong>Starting position</strong> (stand).<br>" +
        "3) Choose <strong>Departure runway</strong> (METAR Use is optional).<br>" +
        "4) Click <strong>Show path</strong> or <strong>Best route</strong>.",
      tip: "You want a cyan taxi line on the map.",
      anchors: [
        '.journey-step[data-journey-step="taxi-out"]',
        "#start-select",
        "#runway-select",
        ".rwy-suggest-use",
        "#btn-auto-route",
        "#btn-route",
      ],
      waitFor: function (s) {
        return !!(s && s.hasTaxiOut);
      },
      assist: "demoTaxiOut",
      assistLabel: "Build a taxi-out path for me",
    },
    {
      id: "flight-plan",
      title: "Draw enroute plan",
      body:
        "1) Click <strong>2 · Flight plan</strong> again.<br>" +
        "2) Confirm Dep / Dest (highlighted).<br>" +
        "3) Leave <strong>Route</strong> as DCT (or type fixes).<br>" +
        "4) Click <strong>Show plan</strong> for the pink line.",
      tip: "Later: SimBrief → Full journey imports a real OFP.",
      anchors: [
        '.journey-step[data-journey-step="flightplan"]',
        "#fp-dep",
        "#fp-dest",
        "#fp-route",
        "#btn-fp-build",
      ],
      waitFor: function (s) {
        return !!(s && s.hasFlightPlan);
      },
      assist: "demoFlightPlan",
      assistLabel: "Build a DCT plan for me",
    },
    {
      id: "taxi-in",
      title: "Taxi in",
      body:
        "1) Click <strong>3 · Taxi in</strong>.<br>" +
        "2) Pick <strong>Landing runway</strong>.<br>" +
        "3) Pick <strong>Gate / stand</strong>.<br>" +
        "Optional: Show STAR / Best taxi-in / Show taxi-in.",
      tip: "For the tour, runway + stand is enough.",
      anchors: [
        '.journey-step[data-journey-step="taxi-in"]',
        "#arr-runway-select",
        "#arr-stand-select",
        ".rwy-suggest-use",
        "#btn-arr-show",
        "#btn-arr-taxi-best",
        "#btn-arr-taxi-show",
      ],
      waitFor: function (s) {
        return !!(
          s &&
          s.journeyStep === "taxi-in" &&
          (s.hasArrRunway || s.hasArrStand)
        );
      },
      assist: "demoTaxiIn",
      assistLabel: "Open Taxi in & pick for me",
    },
    {
      id: "live",
      title: "When you fly",
      body:
        "With MSFS running, use the highlighted <strong>Connect MSFS</strong> control " +
        "for your aircraft, Follow, and auto re-route. Second monitor + Keep on top works well.",
      anchors: ["#btn-sim-connect", "#btn-sim-follow", "#btn-always-on-top"],
      primary: "Finish",
      waitFor: null,
    },
    {
      id: "done",
      title: "Nice work",
      body:
        "You drove the UI yourself. Replay anytime: Home → <strong>Tutorial</strong>.",
      anchors: [],
      primary: "Done",
      waitFor: null,
    },
  ];

  function isDoneLocal() {
    try {
      return localStorage.getItem(STORAGE_KEY) === "1";
    } catch (_) {
      return false;
    }
  }

  function isDone() {
    if (serverDone === true) return true;
    if (serverDone === false) return false;
    return isDoneLocal();
  }

  function _prefsUrl(path) {
    try {
      if (typeof window.apiUrl === "function") return window.apiUrl(path);
    } catch (_) {}
    return path;
  }

  function markDone() {
    serverDone = true;
    try {
      localStorage.setItem(STORAGE_KEY, "1");
    } catch (_) {}
    // Persist on disk — WebView localStorage alone is wiped across some boots
    try {
      fetch(_prefsUrl("/api/user/prefs"), {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tutorial_v1_done: true }),
      }).catch(function () {});
    } catch (_) {}
  }

  function clearDone() {
    serverDone = false;
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch (_) {}
    try {
      fetch(_prefsUrl("/api/user/prefs"), {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tutorial_v1_done: false }),
      }).catch(function () {});
    } catch (_) {}
  }

  async function syncDoneFromServer() {
    try {
      const res = await fetch(_prefsUrl("/api/user/prefs"), {
        credentials: "same-origin",
      });
      if (!res.ok) {
        prefsReady = true;
        return isDone();
      }
      const data = await res.json();
      if (data && data.tutorial_v1_done) {
        serverDone = true;
        try {
          localStorage.setItem(STORAGE_KEY, "1");
        } catch (_) {}
      } else if (isDoneLocal()) {
        // Migrate old localStorage-only skip onto disk
        serverDone = true;
        try {
          await fetch(_prefsUrl("/api/user/prefs"), {
            method: "POST",
            credentials: "same-origin",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ tutorial_v1_done: true }),
          });
        } catch (_) {}
      } else {
        serverDone = false;
      }
    } catch (_) {
      /* keep localStorage fallback */
    }
    prefsReady = true;
    return isDone();
  }

  function api() {
    return window.navapronTutorialApi || {};
  }

  function readState() {
    try {
      if (typeof api().getState === "function") return api().getState() || {};
    } catch (_) {}
    return {};
  }

  function ensureDom() {
    if (overlayEl) return;
    overlayEl = document.createElement("div");
    overlayEl.id = "tutorial-root";
    overlayEl.className = "tutorial-root";
    overlayEl.setAttribute("aria-hidden", "true");
    overlayEl.innerHTML =
      '<div class="tutorial-dim" id="tutorial-dim" hidden></div>' +
      '<div class="tutorial-spots" id="tutorial-spots"></div>' +
      '<div class="tutorial-card" id="tutorial-card" role="dialog" aria-modal="true" aria-labelledby="tutorial-title">' +
      '<div class="tutorial-progress" id="tutorial-progress"></div>' +
      '<h2 class="tutorial-title" id="tutorial-title"></h2>' +
      '<div class="tutorial-body" id="tutorial-body"></div>' +
      '<p class="tutorial-tip" id="tutorial-tip" hidden></p>' +
      '<p class="tutorial-wait" id="tutorial-wait" hidden></p>' +
      '<div class="tutorial-actions">' +
      '<button type="button" class="btn btn-ghost" id="tutorial-skip">Skip tour</button>' +
      '<button type="button" class="tutorial-assist" id="tutorial-assist" hidden>Do this step for me</button>' +
      '<button type="button" class="btn btn-primary" id="tutorial-next">Next</button>' +
      "</div></div>";
    document.body.appendChild(overlayEl);
    spotsEl = overlayEl.querySelector("#tutorial-spots");
    cardEl = overlayEl.querySelector("#tutorial-card");

    overlayEl.querySelector("#tutorial-skip").addEventListener("click", function (e) {
      if (e && e.preventDefault) e.preventDefault();
      skipTutorial();
    });
    overlayEl.querySelector("#tutorial-next").addEventListener("click", function (e) {
      if (e && e.preventDefault) e.preventDefault();
      onPrimary();
    });
    overlayEl.querySelector("#tutorial-assist").addEventListener("click", function (e) {
      if (e && e.preventDefault) e.preventDefault();
      onAssist();
    });
  }

  function clearSpots() {
    if (!spotsEl) return;
    spotsEl.innerHTML = "";
    lastSpotSig = "";
  }

  function collectSpotRects(selectors) {
    const pad = 5;
    const out = [];
    const list = selectors || [];
    for (let i = 0; i < list.length; i++) {
      const nodes = document.querySelectorAll(list[i]);
      for (let j = 0; j < nodes.length; j++) {
        const el = nodes[j];
        if (isEffectivelyHidden(el)) continue;
        const r = visibleRect(el);
        if (!r) continue;
        out.push({
          top: Math.round(Math.max(0, r.top - pad)),
          left: Math.round(Math.max(0, r.left - pad)),
          width: Math.round(Math.min(window.innerWidth, r.width + pad * 2)),
          height: Math.round(Math.min(window.innerHeight, r.height + pad * 2)),
        });
      }
    }
    return out;
  }

  function spotSignature(rects) {
    let s = String(rects.length);
    for (let i = 0; i < rects.length; i++) {
      const r = rects[i];
      s += "|" + r.top + "," + r.left + "," + r.width + "," + r.height;
    }
    return s;
  }

  function isEffectivelyHidden(el) {
    if (!el) return true;
    if (el.closest && el.closest("[hidden]")) return true;
    if (el.classList && el.classList.contains("hidden")) return true;
    try {
      const st = window.getComputedStyle(el);
      if (!st || st.display === "none" || st.visibility === "hidden") return true;
      if (Number(st.opacity) === 0) return true;
    } catch (_) {}
    return false;
  }

  function visibleRect(el) {
    if (!el || isEffectivelyHidden(el)) return null;
    try {
      const r = el.getBoundingClientRect();
      if (r.width < 2 && r.height < 2) return null;
      // Skip if essentially off-screen
      if (r.bottom < 0 || r.right < 0) return null;
      if (r.top > window.innerHeight || r.left > window.innerWidth) return null;
      return r;
    } catch (_) {
      return null;
    }
  }

  /** Close leftover search dropdown; keep flight-plan scroll area usable. */
  function prepareSidebarForStep(step) {
    if (!step) return;
    try {
      const list = document.querySelector("#search-results");
      if (list) list.classList.remove("open");
    } catch (_) {}
    // load-dest / flight-plan need the FP form — compact airport strip via journey step
    if (
      (step.id === "load-dest" || step.id === "flight-plan") &&
      typeof api().setJourneyStep === "function"
    ) {
      try {
        const st = readState();
        if (!st || st.journeyStep !== "flightplan") {
          api().setJourneyStep("flightplan", { skipFit: true });
        } else {
          // Already on flightplan — still force compact (in case class was lost)
          const ap = document.querySelector(".panel-airport");
          if (ap) ap.classList.add("is-compact");
        }
      } catch (_) {}
    }
  }

  /** Prefer scrolling FP / taxi controls into the sidebar scroll-area. */
  function revealAnchors(selectors) {
    const list = selectors || [];
    const scrollRoot = document.querySelector(".scroll-area");
    for (let i = 0; i < list.length; i++) {
      const el = document.querySelector(list[i]);
      if (!el || isEffectivelyHidden(el)) continue;
      try {
        if (scrollRoot && scrollRoot.contains(el)) {
          const rootR = scrollRoot.getBoundingClientRect();
          const r = el.getBoundingClientRect();
          const fullyVisible =
            r.top >= rootR.top + 4 && r.bottom <= rootR.bottom - 4;
          if (!fullyVisible) {
            el.scrollIntoView({ block: "center", inline: "nearest" });
          }
        } else if (!visibleRect(el)) {
          el.scrollIntoView({ block: "nearest", inline: "nearest" });
        }
      } catch (_) {}
      // One primary scroll is enough; rings refresh on next frame / poll
      break;
    }
  }

  /**
   * Highlight every selector that currently exists & is visible.
   * Static rings — only rewrite DOM when positions actually change.
   */
  function placeSpotlights(selectors) {
    if (!spotsEl) return false;
    const dim = overlayEl && overlayEl.querySelector("#tutorial-dim");
    const list = selectors || [];
    const rects = collectSpotRects(list);
    const sig = spotSignature(rects);
    if (dim) dim.hidden = list.length === 0;
    if (sig === lastSpotSig) return rects.length > 0;
    lastSpotSig = sig;
    spotsEl.innerHTML = "";
    for (let i = 0; i < rects.length; i++) {
      const r = rects[i];
      const ring = document.createElement("div");
      ring.className = "tutorial-spot-ring";
      ring.style.top = r.top + "px";
      ring.style.left = r.left + "px";
      ring.style.width = r.width + "px";
      ring.style.height = r.height + "px";
      spotsEl.appendChild(ring);
    }
    return rects.length > 0;
  }

  function unionAvoidRect(selectors) {
    let avoid = null;
    const list = selectors || [];
    for (let i = 0; i < list.length; i++) {
      const nodes = document.querySelectorAll(list[i]);
      for (let j = 0; j < nodes.length; j++) {
        const r = visibleRect(nodes[j]);
        if (!r) continue;
        const box = {
          top: r.top - 8,
          left: r.left - 8,
          right: r.right + 8,
          bottom: r.bottom + 8,
        };
        if (!avoid) avoid = box;
        else {
          avoid = {
            top: Math.min(avoid.top, box.top),
            left: Math.min(avoid.left, box.left),
            right: Math.max(avoid.right, box.right),
            bottom: Math.max(avoid.bottom, box.bottom),
          };
        }
      }
    }
    return avoid;
  }

  function _rectsOverlap(a, b, pad) {
    pad = pad || 10;
    return !(
      a.right + pad < b.left ||
      a.left - pad > b.right ||
      a.bottom + pad < b.top ||
      a.top - pad > b.bottom
    );
  }

  function placeCard(selectors) {
    if (!cardEl) return;
    const margin = 12;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const cardW = Math.min(320, vw - margin * 2);
    cardEl.style.width = cardW + "px";
    const measuredH = Math.max(cardEl.offsetHeight || 0, 200);
    const cardH = Math.min(measuredH, vh - margin * 2);
    const avoid = unionAvoidRect(selectors);
    const sidebar = Math.min(360, vw * 0.42);
    const avoidSig = avoid
      ? [
          Math.round(avoid.top),
          Math.round(avoid.left),
          Math.round(avoid.right),
          Math.round(avoid.bottom),
        ].join(",")
      : "-";
    const layoutSig = vw + "x" + vh + "|" + cardH + "|" + avoidSig;
    if (layoutSig === lastCardSig) return;

    const candidates = [
      { top: vh - cardH - margin, left: vw - cardW - margin },
      { top: margin + 56, left: vw - cardW - margin },
      { top: vh - cardH - margin, left: Math.max(margin, sidebar + 8) },
      { top: (vh - cardH) / 2, left: vw - cardW - margin },
      { top: vh - cardH - margin, left: margin },
      { top: margin + 56, left: margin },
    ];

    function fits(pos) {
      if (pos.top < margin || pos.left < margin) return false;
      if (pos.top + cardH > vh - margin) return false;
      if (pos.left + cardW > vw - margin) return false;
      if (!avoid) return true;
      return !_rectsOverlap(
        {
          top: pos.top,
          left: pos.left,
          right: pos.left + cardW,
          bottom: pos.top + cardH,
        },
        avoid,
        14
      );
    }

    let chosen = null;
    for (let i = 0; i < candidates.length; i++) {
      if (fits(candidates[i])) {
        chosen = candidates[i];
        break;
      }
    }
    if (!chosen) {
      chosen = { top: vh - cardH - margin, left: vw - cardW - margin };
    }
    cardEl.style.top = Math.round(chosen.top) + "px";
    cardEl.style.left = Math.round(chosen.left) + "px";
    cardEl.classList.toggle(
      "tutorial-card-compact",
      !!avoid && avoid.left < sidebar
    );
    lastCardSig = layoutSig;
  }

  function stopPoll() {
    if (pollTimer) {
      clearInterval(pollTimer);
      pollTimer = null;
    }
  }

  function startPoll() {
    stopPoll();
    pollTimer = setInterval(function () {
      if (!active) return;
      const st = readState();
      checkWait();
      if (st && st.mapCreating) return;
      const step = STEPS[stepIndex];
      if (step) {
        const anchors = stepAnchors(step);
        placeSpotlights(anchors);
        placeCard(anchors);
      }
    }, 900);
  }

  function softHideCoach() {
    if (cardEl) cardEl.classList.add("is-dimmed");
    clearSpots();
    lastCardSig = "";
    const dim = overlayEl && overlayEl.querySelector("#tutorial-dim");
    if (dim) dim.hidden = true;
  }

  function softShowCoach() {
    if (cardEl) cardEl.classList.remove("is-dimmed");
  }

  function checkWait() {
    const step = STEPS[stepIndex];
    if (!step || !step.waitFor || completeArmed) return;
    const st = readState();
    if (st && st.mapCreating) {
      softHideCoach();
      const waitEl = overlayEl && overlayEl.querySelector("#tutorial-wait");
      if (waitEl) {
        waitEl.hidden = false;
        waitEl.classList.remove("is-ok");
        waitEl.textContent = "Starting map — please wait…";
      }
      return;
    }
    softShowCoach();

    let ok = false;
    try {
      ok = !!step.waitFor(st);
    } catch (_) {
      ok = false;
    }
    const waitEl = overlayEl && overlayEl.querySelector("#tutorial-wait");
    if (ok) {
      completeArmed = true;
      if (waitEl) {
        waitEl.hidden = false;
        waitEl.textContent = "Nice — continuing…";
        waitEl.classList.add("is-ok");
      }
      setTimeout(function () {
        completeArmed = false;
        advance();
      }, 700);
    } else if (waitEl) {
      waitEl.hidden = false;
      waitEl.classList.remove("is-ok");
      waitEl.textContent = "Waiting for you to do this in the app…";
    }
  }

  function renderStep() {
    ensureDom();
    completeArmed = false;
    const step = STEPS[stepIndex];
    if (!step) {
      finishTutorial();
      return;
    }
    overlayEl.classList.add("is-open");
    overlayEl.setAttribute("aria-hidden", "false");
    document.body.classList.add("tutorial-open");

    const prog = overlayEl.querySelector("#tutorial-progress");
    const title = overlayEl.querySelector("#tutorial-title");
    const body = overlayEl.querySelector("#tutorial-body");
    const tip = overlayEl.querySelector("#tutorial-tip");
    const waitEl = overlayEl.querySelector("#tutorial-wait");
    const nextBtn = overlayEl.querySelector("#tutorial-next");
    const skipBtn = overlayEl.querySelector("#tutorial-skip");
    const assistBtn = overlayEl.querySelector("#tutorial-assist");

    if (prog) {
      prog.textContent = "Step " + (stepIndex + 1) + " of " + STEPS.length;
    }
    if (title) title.textContent = step.title || "";
    if (body) body.innerHTML = step.body || "";
    if (tip) {
      if (step.tip) {
        tip.hidden = false;
        tip.textContent = step.tip;
      } else {
        tip.hidden = true;
        tip.textContent = "";
      }
    }
    if (waitEl) {
      waitEl.classList.remove("is-ok");
      if (step.waitFor) {
        waitEl.hidden = false;
        waitEl.textContent = "Waiting for you to do this in the app…";
      } else {
        waitEl.hidden = true;
      }
    }

    if (nextBtn) {
      if (step.waitFor) {
        nextBtn.hidden = true;
      } else {
        nextBtn.hidden = false;
        nextBtn.textContent = step.primary || "Next";
      }
    }
    if (skipBtn) {
      skipBtn.hidden = false;
      skipBtn.textContent = "Skip tour";
    }
    if (assistBtn) {
      if (step.assist) {
        assistBtn.hidden = false;
        assistBtn.textContent = step.assistLabel || "Do this step for me";
      } else {
        assistBtn.hidden = true;
      }
    }

    prepareSidebarForStep(step);
    const anchors = stepAnchors(step);
    lastSpotSig = "";
    lastCardSig = "";
    revealAnchors(anchors);
    placeSpotlights(anchors);
    placeCard(anchors);
    requestAnimationFrame(function () {
      prepareSidebarForStep(step);
      revealAnchors(anchors);
      placeSpotlights(anchors);
      placeCard(anchors);
    });
    startPoll();
  }

  async function runAssist(name) {
    const a = api();
    try {
      if (name === "openJourney" && typeof a.enterMode === "function") {
        softHideCoach();
        a.enterMode("journey");
        const deadline = Date.now() + 12000;
        while (Date.now() < deadline) {
          await wait(400);
          const st = readState();
          if (st.mapReady && st.mode === "journey") break;
        }
        return;
      }
      if (name === "openFlightPlanStep" && typeof a.setJourneyStep === "function") {
        a.setJourneyStep("flightplan", { skipFit: true });
        await wait(400);
        return;
      }
      if (name === "loadDemoDep" && typeof a.loadDemoDep === "function") {
        await a.loadDemoDep(DEMO_DEP);
        return;
      }
      if (name === "loadDemoAirports" && typeof a.loadDemoAirports === "function") {
        await a.loadDemoAirports(DEMO_DEP, DEMO_DEST);
        return;
      }
      if (name === "demoTaxiOut" && typeof a.demoTaxiOut === "function") {
        await a.demoTaxiOut();
        return;
      }
      if (name === "demoFlightPlan" && typeof a.demoFlightPlan === "function") {
        await a.demoFlightPlan();
        return;
      }
      if (name === "demoTaxiIn" && typeof a.demoTaxiIn === "function") {
        await a.demoTaxiIn();
        return;
      }
    } catch (err) {
      console.warn("tutorial assist", name, err);
      try {
        if (typeof window.setStatus === "function") {
          window.setStatus(
            "Couldn’t auto-complete that step — try the UI or Skip",
            "err"
          );
        }
      } catch (_) {}
    }
  }

  function wait(ms) {
    return new Promise(function (resolve) {
      setTimeout(resolve, ms);
    });
  }

  async function onAssist() {
    const step = STEPS[stepIndex];
    if (!step || !step.assist) return;
    const btn = overlayEl && overlayEl.querySelector("#tutorial-assist");
    if (btn) btn.disabled = true;
    try {
      await runAssist(step.assist);
    } finally {
      if (btn) btn.disabled = false;
    }
    checkWait();
  }

  function onPrimary() {
    const step = STEPS[stepIndex];
    if (!step) return;
    if (step.waitFor) return;
    if (step.id === "done" || stepIndex >= STEPS.length - 1) {
      finishTutorial();
      return;
    }
    advance();
  }

  function advance() {
    if (stepIndex >= STEPS.length - 1) {
      finishTutorial();
      return;
    }
    stepIndex += 1;
    renderStep();
  }

  function skipTutorial() {
    markDone();
    closeOverlay();
    try {
      if (typeof window.setStatus === "function") {
        window.setStatus("Tutorial skipped — Home → Tutorial to replay", "ok");
      }
    } catch (_) {}
  }

  function finishTutorial() {
    markDone();
    closeOverlay();
    try {
      if (typeof window.setStatus === "function") {
        window.setStatus("Tutorial complete — happy flying", "ok");
      }
    } catch (_) {}
  }

  function closeOverlay() {
    active = false;
    stopPoll();
    document.body.classList.remove("tutorial-open");
    if (overlayEl) {
      overlayEl.classList.remove("is-open");
      overlayEl.setAttribute("aria-hidden", "true");
    }
    clearSpots();
    const dim = overlayEl && overlayEl.querySelector("#tutorial-dim");
    if (dim) dim.hidden = true;
  }

  function startTutorial(opts) {
    opts = opts || {};
    ensureDom();
    active = true;
    stepIndex = 0;
    completeArmed = false;
    if (opts.restart) clearDone();
    try {
      if (typeof api().showHub === "function") api().showHub();
    } catch (_) {}
    renderStep();
  }

  function maybeAutoStart() {
    // Wait for disk prefs before auto-start so Skip survives WebView wipes
    syncDoneFromServer().then(function (done) {
      if (done || isDone()) return;
      setTimeout(function () {
        if (isDone() || active) return;
        if (document.querySelector(".update-modal.is-open")) return;
        if (document.querySelector(".whats-new-modal.is-open")) return;
        // Avoid overlapping "Starting map…" coach while the map is still booting
        try {
          const st = readState();
          if (st && st.mapCreating) {
            setTimeout(function () {
              if (isDone() || active) return;
              startTutorial();
            }, 2500);
            return;
          }
        } catch (_) {}
        startTutorial();
      }, 2000);
    });
  }

  function onResize() {
    if (!active) return;
    const step = STEPS[stepIndex];
    if (!step) return;
    const anchors = stepAnchors(step);
    placeSpotlights(anchors);
    placeCard(anchors);
  }

  window.addEventListener("resize", onResize);
  window.addEventListener("orientationchange", onResize);

  function wireHubButton() {
    const btn = $("#btn-tutorial-hub");
    if (!btn) return;
    btn.addEventListener("click", function (e) {
      if (e && e.preventDefault) e.preventDefault();
      startTutorial({ restart: true });
    });
  }

  window.navapronStartTutorial = function () {
    startTutorial({ restart: true });
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () {
      wireHubButton();
      maybeAutoStart();
    });
  } else {
    wireHubButton();
    maybeAutoStart();
  }
})();
