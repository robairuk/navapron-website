/**
 * NavApron — virtual airline panel (roleplay logbook + live flight tracking)
 * Loaded after app.js. Uses classic scripts (no modules).
 */
(function () {
  const $ = (sel) => document.querySelector(sel);

  function escapeHtml(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function setStatus(text, mode) {
    if (typeof window.setStatus === "function") {
      window.setStatus(text, mode);
      return;
    }
    // app.js setStatus is not global — mirror minimal status update
    const el = $("#status-text");
    const dot = $("#status-dot");
    if (el) el.textContent = text;
    if (dot) {
      dot.classList.remove("busy", "err");
      if (mode === "busy") dot.classList.add("busy");
      if (mode === "err") dot.classList.add("err");
    }
  }

  function fixMap() {
    try {
      if (typeof map !== "undefined" && map && map.invalidateSize) {
        map.invalidateSize(true);
      }
    } catch (_) {}
  }

  function setAirlineCollapsed(collapsed, { persist = true, quiet = false } = {}) {
    const app = $("#app");
    if (!app) return;
    const on = !!collapsed;
    app.classList.toggle("airline-collapsed", on);
    const hideBtn = $("#btn-airline-collapse");
    const openBtn = $("#btn-airline-open");
    if (hideBtn) hideBtn.setAttribute("aria-expanded", on ? "false" : "true");
    if (openBtn) {
      openBtn.setAttribute("aria-expanded", on ? "false" : "true");
      openBtn.setAttribute("aria-hidden", on ? "false" : "true");
    }
    // Opening Airline takes the single right-dock slot
    if (!on) {
      try {
        if (window.NavApronPlates && typeof window.NavApronPlates.close === "function") {
          window.NavApronPlates.close({ quiet: true });
        }
      } catch (_) {}
      try {
        if (typeof window.setCareerPanelOpen === "function") {
          window.setCareerPanelOpen(false, { quiet: true });
        }
      } catch (_) {}
      // Re-apply dock width so Logbook gets a bounded height and can scroll
      try {
        if (typeof window.applyRightDockWidth === "function") {
          const cur =
            getComputedStyle(app).getPropertyValue("--right-dock-w").trim() ||
            "360px";
          const n = parseInt(cur, 10);
          if (Number.isFinite(n)) window.applyRightDockWidth(n, { persist: false });
        }
      } catch (_) {}
    }
    if (persist) {
      try {
        localStorage.setItem("navapron_airline_collapsed", on ? "1" : "0");
      } catch (_) {}
    }
    fixMap();
    setTimeout(fixMap, 80);
    setTimeout(fixMap, 260);
    if (!quiet) {
      setStatus(on ? "Logbook panel hidden" : "Logbook panel shown", "ok");
    }
  }

  window.setAirlineCollapsed = setAirlineCollapsed;

  function fmtDuration(sec) {
    const s = Math.max(0, Math.floor(Number(sec) || 0));
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const r = s % 60;
    if (h > 0) return h + ":" + String(m).padStart(2, "0") + ":" + String(r).padStart(2, "0");
    return m + ":" + String(r).padStart(2, "0");
  }

  function phaseLabel(p) {
    const map = {
      gate: "Gate",
      taxi_out: "Taxi out",
      airborne: "Airborne",
      taxi_in: "Taxi in",
    };
    return map[p] || p || "—";
  }

  /** Landing rate ft/min (negative = descending). */
  function fmtLandingFpm(v) {
    if (v == null || v === "" || Number.isNaN(Number(v))) return "—";
    const n = Math.round(Number(v));
    const sign = n > 0 ? "+" : "";
    return sign + n + " fpm";
  }

  let overview = null;
  let pollTimer = null;
  /** false = show saved card; true = create/edit form. Never force create when profile exists. */
  let editingProfile = false;

  /** Cached logbook rows for detail/delete (id → flight). */
  let logbookById = {};
  let logbookFlights = [];
  let logbookTotal = 0;
  let logbookOffset = 0;
  const LOGBOOK_PAGE = 25;
  let selectedLogId = null;
  // Community totals from Cloudflare — GET only after a flight is posted
  let _communityCache = null; // { text } | { hidden: true }
  let _communityInflight = null;

  function hasProfile() {
    return !!(overview && overview.profile);
  }

  function hasActive() {
    return !!(overview && overview.active);
  }

  function aircraftLabel(f) {
    if (!f) return "";
    const title = (f.aircraft_title || "").trim();
    const type = (f.aircraft_type || "").trim();
    const ac = (f.aircraft || "").trim();
    if (type && title && title.toUpperCase().indexOf(type.toUpperCase()) === -1) {
      return type + " · " + title;
    }
    return ac || type || title || "";
  }

  function prefillAircraft() {
    const acEl = $("#al-aircraft");
    if (!acEl || acEl.value.trim()) return;
    let ac = "";
    try {
      if ($("#fp-ac") && $("#fp-ac").value) ac = $("#fp-ac").value.trim();
      if (!ac && $("#sb-ac") && $("#sb-ac").value) ac = $("#sb-ac").value.trim();
      if (
        !ac &&
        typeof getRememberedAircraftType === "function"
      ) {
        ac = getRememberedAircraftType() || "";
      }
      if (
        !ac &&
        typeof state !== "undefined" &&
        state &&
        state.flightPlan &&
        state.flightPlan.aircraft
      ) {
        ac = state.flightPlan.aircraft;
      }
    } catch (_) {}
    if (ac) acEl.value = String(ac).toUpperCase();
  }

  function prefillFromPlan() {
    const depEl = $("#al-dep");
    const destEl = $("#al-dest");
    if (!depEl || !destEl) return;
    if (!(depEl.value && destEl.value)) {
      let dep = ($("#fp-dep") && $("#fp-dep").value) || "";
      let dest = ($("#fp-dest") && $("#fp-dest").value) || "";
      try {
        if (typeof state !== "undefined" && state) {
          if (!dep && state.flightPlan && state.flightPlan.dep) dep = state.flightPlan.dep.icao || "";
          if (!dest && state.flightPlan && state.flightPlan.dest) dest = state.flightPlan.dest.icao || "";
          if (!dep && state.depChart && state.depChart.airport) dep = state.depChart.airport.icao || "";
          if (!dest && state.destChart && state.destChart.airport) dest = state.destChart.airport.icao || "";
          if (!dep && state.airport) dep = state.airport.icao || "";
        }
      } catch (_) {}
      if (!depEl.value && dep) depEl.value = String(dep).toUpperCase();
      if (!destEl.value && dest) destEl.value = String(dest).toUpperCase();
    }
    prefillAircraft();
  }

  function fillProfileForm(p) {
    const name = $("#al-name");
    const code = $("#al-code");
    const cs = $("#al-callsign");
    const color = $("#al-color");
    const motto = $("#al-motto");
    if (name) name.value = (p && p.name) || "";
    if (code) code.value = (p && p.code) || "";
    if (cs) cs.value = (p && p.callsign) || "";
    if (color) color.value = (p && p.color) || "#3b82f6";
    if (motto) motto.value = (p && p.motto) || "";
  }

  function renderProfile() {
    const view = $("#airline-profile-view");
    const form = $("#airline-profile-form");
    const actions = $("#airline-profile-actions");
    const btnCancel = $("#btn-al-cancel-edit");
    const btnSave = $("#btn-al-save");
    const p = overview && overview.profile;

    // No airline yet → create form until first permanent save
    if (!p) {
      editingProfile = true;
      if (view) {
        view.classList.add("hidden");
        view.innerHTML = "";
      }
      if (actions) actions.classList.add("hidden");
      if (form) form.classList.remove("hidden");
      if (btnCancel) btnCancel.classList.add("hidden");
      if (btnSave) btnSave.textContent = "Create airline";
      return;
    }

    // Saved airline: card + Edit by default; form only while editing
    if (view) {
      view.innerHTML =
        '<div class="al-profile-card">' +
        '<div class="al-profile-swatch" style="background:' +
        escapeHtml(p.color || "#3b82f6") +
        '"></div>' +
        "<div>" +
        '<div class="al-profile-name">' +
        escapeHtml(p.name) +
        "</div>" +
        '<div class="al-profile-meta">' +
        escapeHtml(p.code || "—") +
        " · " +
        escapeHtml(p.callsign || "—") +
        "</div>" +
        (p.motto
          ? '<div class="al-profile-motto">“' + escapeHtml(p.motto) + "”</div>"
          : "") +
        "</div></div>";
      view.classList.toggle("hidden", editingProfile);
    }
    if (actions) actions.classList.toggle("hidden", editingProfile);
    if (form) form.classList.toggle("hidden", !editingProfile);
    if (btnCancel) btnCancel.classList.toggle("hidden", !editingProfile);
    if (btnSave) btnSave.textContent = "Save changes";

    if (editingProfile) fillProfileForm(p);
  }

  function renderLive() {
    const hint = $("#al-live-hint");
    const form = $("#al-flight-form");
    const live = $("#al-flight-live");
    const startBtn = $("#btn-al-start");
    const active = overview && overview.active;

    if (!hasProfile()) {
      if (hint)
        hint.textContent =
          "Create your airline above, then connect MSFS and start a flight to build your logbook.";
      if (form) form.classList.remove("hidden");
      if (live) live.classList.add("hidden");
      if (startBtn) startBtn.disabled = true;
      return;
    }

    if (active) {
      if (hint)
        hint.textContent = active.sim_connected
          ? "Tracking via SimConnect — fly your route, then End flight to log it."
          : "Flight open — Connect MSFS to track position, distance and phase.";
      if (form) form.classList.add("hidden");
      if (live) live.classList.remove("hidden");

      const fn = $("#al-live-fn");
      const phase = $("#al-live-phase");
      const route = $("#al-live-route");
      if (fn) fn.textContent = active.flight_number || "—";
      if (phase) {
        phase.textContent = phaseLabel(active.phase);
        phase.className = "al-phase-badge phase-" + (active.phase || "gate");
      }
      if (route)
        route.textContent =
          (active.dep_icao || "????") + " → " + (active.dest_icao || "????");
      const acLive = $("#al-live-aircraft");
      if (acLive) {
        const label = aircraftLabel(active);
        acLive.textContent = label || "Aircraft: waiting for MSFS…";
        acLive.classList.toggle("is-empty", !label);
      }
      const block = $("#al-live-block");
      const air = $("#al-live-air");
      const nm = $("#al-live-nm");
      const alt = $("#al-live-alt");
      const gs = $("#al-live-gs");
      const track = $("#al-live-track");
      if (block) block.textContent = fmtDuration(active.block_time_s);
      if (air) air.textContent = fmtDuration(active.airborne_time_s);
      if (nm) nm.textContent = (active.distance_nm != null ? active.distance_nm : 0) + " NM";
      if (alt)
        alt.textContent =
          active.max_alt_ft != null ? Math.round(active.max_alt_ft) + " ft" : "—";
      const last = active.last || {};
      if (gs)
        gs.textContent =
          last.gs_kt != null
            ? Math.round(last.gs_kt) + " kt"
            : active.max_gs_kt != null
              ? "max " + Math.round(active.max_gs_kt) + " kt"
              : "—";
      const landing = $("#al-live-landing");
      if (landing) landing.textContent = fmtLandingFpm(active.landing_fpm);
      if (track)
        track.textContent = active.tracking
          ? "Live"
          : active.sim_connected
            ? "Waiting…"
            : "MSFS off";
      // Live flown path on the map while tracking
      try {
        if (
          active.tracking &&
          typeof window.updateLiveTrackingTrace === "function"
        ) {
          window.updateLiveTrackingTrace(active, {
            owner: "airline",
            label:
              (active.flight_number || "Flight") +
              " · " +
              (active.dep_icao || "?") +
              " → " +
              (active.dest_icao || "?"),
          });
        }
      } catch (_) {}
    } else {
      if (hint)
        hint.textContent =
          "Connect MSFS (map toolbar), set dep/dest, then Start flight. Tracking runs on the server while you fly.";
      if (form) form.classList.remove("hidden");
      if (live) live.classList.add("hidden");
      if (startBtn) startBtn.disabled = false;
      prefillFromPlan();
      // Only clear Airline's own live path — never wipe a Career trace
      try {
        if (typeof window.clearLiveTrackingTrace === "function") {
          window.clearLiveTrackingTrace("airline");
        }
      } catch (_) {}
    }
  }

  function renderStats() {
    const st = (overview && overview.stats) || {};
    const set = (id, v) => {
      const el = $(id);
      if (el) el.textContent = v != null ? String(v) : "0";
    };
    set("#al-st-flights", st.flights_completed || 0);
    set("#al-st-hours", st.block_hours || 0);
    set("#al-st-air", st.airborne_hours || 0);
    set("#al-st-nm", st.distance_nm || 0);
    set("#al-st-apt", st.unique_airports || 0);
    set("#al-st-ac", st.unique_aircraft || 0);
    set("#al-st-long", st.longest_flight_nm || 0);
    set("#al-st-avg-ldg", fmtLandingFpm(st.avg_landing_fpm));
    set("#al-st-soft-ldg", fmtLandingFpm(st.softest_landing_fpm));
    // Re-paint last known community line — never hits Cloudflare here
    applyCommunityCache();
  }

  function applyCommunityCache() {
    const el = $("#al-community-line");
    if (!el) return;
    if (!_communityCache || _communityCache.hidden || !_communityCache.text) {
      el.hidden = true;
      return;
    }
    el.textContent = _communityCache.text;
    el.hidden = false;
  }

  /**
   * Fetch community totals from Cloudflare — only call after posting a flight.
   */
  async function refreshCommunityLineAfterPost() {
    const el = $("#al-community-line");
    if (!el) return;
    if (_communityInflight) {
      try {
        await _communityInflight;
      } catch (_) {}
      return;
    }
    _communityInflight = (async function () {
      try {
        // Local backend only — does not hit Cloudflare
        const statusRes = await fetch("/api/community/status", {
          cache: "no-store",
        });
        const status = await statusRes.json().catch(function () {
          return null;
        });
        if (!status || !status.enabled || !status.share_community_stats) {
          el.hidden = true;
          _communityCache = { hidden: true };
          return;
        }
        // One GET to Cloudflare after this flight was POSTed
        const res = await fetch("/api/community/stats", { cache: "no-store" });
        const data = await res.json().catch(function () {
          return null;
        });
        if (!data || data.ok === false) {
          el.hidden = true;
          _communityCache = { hidden: true };
          return;
        }
        const flights =
          data.flights_completed != null ? data.flights_completed : "—";
        const hrs =
          data.airborne_hours != null
            ? Number(data.airborne_hours).toLocaleString(undefined, {
                maximumFractionDigits: 0,
              })
            : "—";
        const nm =
          data.nm_flown != null
            ? " · " +
              Math.round(Number(data.nm_flown) || 0).toLocaleString() +
              " NM"
            : "";
        const plans =
          data.flight_plans != null
            ? " · " + Number(data.flight_plans).toLocaleString() + " plans"
            : "";
        const text =
          "Community: " +
          hrs +
          " airborne hrs · " +
          flights +
          " flights" +
          nm +
          plans +
          (data.airports_seen != null
            ? " · " + data.airports_seen + " airports"
            : "");
        el.textContent = text;
        el.hidden = false;
        _communityCache = { text: text, hidden: false };
      } catch (_) {
        el.hidden = true;
      } finally {
        _communityInflight = null;
      }
    })();
    return _communityInflight;
  }

  function fmtDateTime(iso) {
    if (!iso) return "—";
    try {
      const d = new Date(iso);
      if (isNaN(d.getTime())) return String(iso);
      return d.toLocaleString(undefined, {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch (_) {
      return String(iso);
    }
  }

  function renderLogbook() {
    const list = $("#al-logbook-list");
    const countEl = $("#al-logbook-count");
    const moreBtn = $("#btn-al-log-more");
    if (!list) return;

    if (countEl) {
      countEl.textContent =
        logbookTotal > 0
          ? logbookTotal === 1
            ? "1 flight"
            : logbookTotal + " flights"
          : "";
    }

    if (!logbookFlights.length) {
      list.innerHTML =
        '<p class="airline-hint">No flights yet. Log a free flight here, or settle a Pilot Career mission — both appear in this history.</p>';
      if (moreBtn) moreBtn.classList.add("hidden");
      return;
    }

    list.innerHTML = logbookFlights
      .map(function (f) {
        const cancelled = f.outcome === "cancelled";
        const fromCareer = f.source === "career";
        const id = escapeHtml(f.id || "");
        const route =
          escapeHtml(f.dep_icao || "????") + " → " + escapeHtml(f.dest_icao || "????");
        const plane = aircraftLabel(f);
        const careerTag =
          fromCareer
            ? f.career_kind === "airline"
              ? "Career airline"
              : "Career"
            : "";
        const meta =
          (careerTag ? careerTag + " · " : "") +
          (plane ? plane + " · " : "") +
          (f.distance_nm != null ? f.distance_nm + " NM" : "—") +
          " · " +
          fmtDuration(f.block_time_s) +
          (f.landing_fpm != null ? " · " + fmtLandingFpm(f.landing_fpm) : "") +
          (cancelled ? " · cancelled" : "") +
          (f.ended_at ? " · " + fmtDateTime(f.ended_at) : "");
        return (
          '<div class="al-log-item' +
          (cancelled ? " cancelled" : "") +
          (fromCareer ? " is-career" : "") +
          '" data-flight-id="' +
          id +
          '" role="button" tabindex="0" title="View flight details">' +
          '<div class="al-log-main">' +
          '<div class="al-log-top">' +
          '<span class="al-log-fn">' +
          escapeHtml(f.flight_number || "—") +
          "</span>" +
          (fromCareer
            ? '<span class="al-log-badge" title="Pilot Career mission">Career</span>'
            : "") +
          "<span>" +
          route +
          "</span>" +
          "</div>" +
          '<div class="al-log-meta">' +
          escapeHtml(meta) +
          "</div>" +
          "</div>" +
          '<button type="button" class="al-log-del" data-delete-id="' +
          id +
          '" title="Delete this flight" aria-label="Delete flight">×</button>' +
          "</div>"
        );
      })
      .join("");

    if (moreBtn) {
      moreBtn.classList.toggle("hidden", logbookFlights.length >= logbookTotal);
    }
  }

  function openLogModal(flight) {
    if (!flight) return;
    selectedLogId = flight.id || null;
    const modal = $("#al-log-modal");
    if (!modal) return;

    const set = function (sel, text) {
      const el = $(sel);
      if (el) el.textContent = text;
    };
    set("#al-log-fn", flight.flight_number || "—");
    set(
      "#al-log-route",
      (flight.dep_icao || "????") + " → " + (flight.dest_icao || "????")
    );
    set("#al-log-aircraft", aircraftLabel(flight) || "Aircraft not recorded");
    set("#al-log-block", fmtDuration(flight.block_time_s));
    set("#al-log-air", fmtDuration(flight.airborne_time_s));
    set(
      "#al-log-nm",
      (flight.distance_nm != null ? flight.distance_nm : 0) + " NM"
    );
    set(
      "#al-log-alt",
      flight.max_alt_ft != null ? Math.round(flight.max_alt_ft) + " ft" : "—"
    );
    set(
      "#al-log-gs",
      flight.max_gs_kt != null ? Math.round(flight.max_gs_kt) + " kt" : "—"
    );
    set("#al-log-landing", fmtLandingFpm(flight.landing_fpm));
    set("#al-log-phase", phaseLabel(flight.phase_end || flight.phase));

    const outcomeEl = $("#al-log-outcome");
    if (outcomeEl) {
      const o = flight.outcome || "completed";
      outcomeEl.textContent = o;
      outcomeEl.className =
        "al-log-outcome" + (o === "cancelled" ? " is-cancelled" : "");
      outcomeEl.classList.remove("hidden");
    }

    const sub = $("#al-log-sub");
    if (sub) {
      if (flight.source === "career") {
        const kind =
          flight.career_kind === "airline"
            ? "Career airline mission"
            : "Pilot Career mission";
        sub.textContent =
          kind +
          (flight.career_title ? " · " + flight.career_title : "") +
          (flight.ended_at ? " · " + fmtDateTime(flight.ended_at) : "");
      } else {
        sub.textContent =
          (flight.airline_name || flight.airline_code || "Logbook") +
          (flight.outcome === "cancelled" ? " · cancelled" : "");
      }
    }
    const when = $("#al-log-when");
    if (when) {
      when.textContent =
        "Started " +
        fmtDateTime(flight.started_at) +
        " · Ended " +
        fmtDateTime(flight.ended_at);
    }

    const traceBtn = $("#btn-al-log-show-trace");
    if (traceBtn) {
      const has =
        !!flight.has_trace ||
        (Array.isArray(flight.trace) && flight.trace.length >= 2) ||
        Number(flight.trace_points || 0) >= 2;
      traceBtn.hidden = !has;
      traceBtn.disabled = !has;
    }

    modal.classList.add("is-open");
    modal.setAttribute("aria-hidden", "false");
    modal.removeAttribute("hidden");
  }

  async function showLogFlownTrace() {
    const id = selectedLogId;
    if (!id) return;
    const btn = $("#btn-al-log-show-trace");
    if (btn) btn.disabled = true;
    try {
      let flight = logbookById[id];
      let trace =
        flight && Array.isArray(flight.trace) && flight.trace.length >= 2
          ? flight.trace
          : null;
      if (!trace) {
        const res = await fetch(
          "/api/airline/logbook/" + encodeURIComponent(id),
          { cache: "no-store" }
        );
        const data = await res.json();
        if (!data.ok || !data.flight) {
          throw new Error(data.error || "Flight not found");
        }
        flight = data.flight;
        logbookById[id] = Object.assign({}, logbookById[id] || {}, flight);
        trace = flight.trace;
      }
      if (!Array.isArray(trace) || trace.length < 2) {
        throw new Error("No flown path recorded for this flight");
      }
      const label =
        (flight.flight_number || "Flight") +
        " · " +
        (flight.dep_icao || "?") +
        " → " +
        (flight.dest_icao || "?");
      closeLogModal();
      setAirlineCollapsed(true, { persist: false, quiet: true });
      if (typeof window.showFlownTrace === "function") {
        window.showFlownTrace(trace, { fit: true, label: label });
      } else {
        throw new Error("Map helper missing — restart NavApron");
      }
    } catch (err) {
      setStatus(err.message || String(err), "err");
    } finally {
      if (btn) {
        const f = logbookById[id];
        const has =
          f &&
          (!!f.has_trace ||
            (Array.isArray(f.trace) && f.trace.length >= 2) ||
            Number(f.trace_points || 0) >= 2);
        btn.disabled = !has;
      }
    }
  }

  function closeLogModal() {
    const modal = $("#al-log-modal");
    if (!modal) return;
    modal.classList.remove("is-open");
    modal.setAttribute("aria-hidden", "true");
    modal.setAttribute("hidden", "");
    selectedLogId = null;
  }

  async function refreshLogbook(opts) {
    const append = !!(opts && opts.append);
    try {
      if (!append) {
        logbookOffset = 0;
        logbookFlights = [];
        logbookById = {};
      }
      const res = await fetch(
        "/api/airline/logbook?limit=" +
          LOGBOOK_PAGE +
          "&offset=" +
          logbookOffset
      );
      const data = await res.json();
      if (!data.ok) return;
      logbookTotal = data.total || 0;
      const page = data.flights || [];
      page.forEach(function (f) {
        if (f && f.id) logbookById[f.id] = f;
      });
      if (append) {
        logbookFlights = logbookFlights.concat(page);
      } else {
        logbookFlights = page;
      }
      logbookOffset = logbookFlights.length;
      renderLogbook();
    } catch (_) {
      /* ignore */
    }
  }

  async function deleteLogFlight(flightId, { fromModal } = {}) {
    if (!flightId) return;
    const cached = logbookById[flightId];
    const label =
      (cached && cached.flight_number) ||
      (cached &&
        (cached.dep_icao || "????") + " → " + (cached.dest_icao || "????")) ||
      "this flight";
    if (
      !confirm(
        "Delete " +
          label +
          " from your logbook?\n\nCareer stats will update. This cannot be undone."
      )
    ) {
      return;
    }
    try {
      const res = await fetch(
        "/api/airline/logbook/" + encodeURIComponent(flightId),
        { method: "DELETE" }
      );
      const data = await res.json().catch(function () {
        return {};
      });
      if (!res.ok) {
        throw new Error(
          typeof data.detail === "string"
            ? data.detail
            : data.error || "Delete failed"
        );
      }
      if (fromModal) closeLogModal();
      setStatus("Deleted " + label + " from logbook", "ok");
      await refreshLogbook();
      await refreshOverview();
    } catch (err) {
      setStatus(err.message || "Could not delete flight", "err");
    }
  }

  async function refreshOverview() {
    try {
      const res = await fetch("/api/airline");
      if (!res.ok) return;
      overview = await res.json();
      renderProfile();
      renderLive();
      renderStats();
    } catch (_) {
      /* ignore */
    }
  }

  async function saveProfile(ev) {
    if (ev) ev.preventDefault();
    const name = ($("#al-name") && $("#al-name").value.trim()) || "";
    if (!name) {
      setStatus("Enter an airline name", "err");
      return;
    }
    const body = {
      name: name,
      code: ($("#al-code") && $("#al-code").value.trim()) || null,
      callsign: ($("#al-callsign") && $("#al-callsign").value.trim()) || null,
      color: ($("#al-color") && $("#al-color").value) || "#3b82f6",
      motto: ($("#al-motto") && $("#al-motto").value.trim()) || null,
    };
    try {
      const res = await fetch("/api/airline", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json().catch(function () {
        return {};
      });
      if (!res.ok) {
        throw new Error(
          (data.detail && (typeof data.detail === "string" ? data.detail : data.detail[0])) ||
            data.error ||
            "Save failed"
        );
      }
      editingProfile = false;
      setStatus("Airline saved — " + (data.profile && data.profile.name), "ok");
      await refreshOverview();
      await refreshLogbook();
    } catch (err) {
      setStatus(err.message || "Could not save airline", "err");
    }
  }

  async function startFlight() {
    prefillFromPlan();
    const acRaw =
      ($("#al-aircraft") && $("#al-aircraft").value.trim()) || "";
    const body = {
      dep_icao: ($("#al-dep") && $("#al-dep").value.trim().toUpperCase()) || null,
      dest_icao: ($("#al-dest") && $("#al-dest").value.trim().toUpperCase()) || null,
      flight_number: ($("#al-fn") && $("#al-fn").value.trim().toUpperCase()) || null,
      aircraft: acRaw || null,
      aircraft_type: acRaw || null,
    };
    try {
      const res = await fetch("/api/airline/flight/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json().catch(function () {
        return {};
      });
      if (!res.ok) {
        const detail = data.detail;
        throw new Error(
          typeof detail === "string" ? detail : data.error || "Could not start flight"
        );
      }
      setStatus(
        "Flight " +
          ((data.active && data.active.flight_number) || "") +
          " started — connect MSFS to track",
        "ok"
      );
      await refreshOverview();
    } catch (err) {
      setStatus(err.message || "Start flight failed", "err");
    }
  }

  let _shareCardBlob = null;
  let _shareLogoImg = null;

  function loadShareLogo() {
    return new Promise(function (resolve) {
      if (_shareLogoImg && _shareLogoImg.complete) {
        resolve(_shareLogoImg);
        return;
      }
      const img = new Image();
      img.onload = function () {
        _shareLogoImg = img;
        resolve(img);
      };
      img.onerror = function () {
        resolve(null);
      };
      img.src = "/img/logo.png?v=5";
    });
  }

  function fmtShareDate(iso) {
    try {
      const d = iso ? new Date(iso) : new Date();
      if (Number.isNaN(d.getTime())) return new Date().toLocaleDateString();
      return d.toLocaleDateString(undefined, {
        year: "numeric",
        month: "short",
        day: "numeric",
      });
    } catch (_) {
      return "";
    }
  }

  function setShareStatus(text, ok) {
    const el = $("#al-share-status");
    if (!el) return;
    el.textContent = text || "";
    el.style.color = ok === false ? "#fca5a5" : "#7dd3fc";
  }

  function roundRect(ctx, x, y, w, h, r) {
    const radius = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.arcTo(x + w, y, x + w, y + h, radius);
    ctx.arcTo(x + w, y + h, x, y + h, radius);
    ctx.arcTo(x, y + h, x, y, radius);
    ctx.arcTo(x, y, x + w, y, radius);
    ctx.closePath();
  }

  async function renderShareCard(active) {
    const canvas = $("#al-share-canvas");
    if (!canvas || !canvas.getContext) return;
    const a = active || {};
    const profile = (overview && overview.profile) || {};
    const ctx = canvas.getContext("2d");
    const W = canvas.width;
    const H = canvas.height;
    const logo = await loadShareLogo();

    // Background
    const bg = ctx.createLinearGradient(0, 0, W, H);
    bg.addColorStop(0, "#0b1220");
    bg.addColorStop(0.45, "#111c33");
    bg.addColorStop(1, "#0a1628");
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    // Accent glow
    const glow = ctx.createRadialGradient(W * 0.2, H * 0.15, 40, W * 0.2, H * 0.15, 420);
    glow.addColorStop(0, "rgba(59,130,246,0.35)");
    glow.addColorStop(1, "rgba(59,130,246,0)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, W, H);

    const glow2 = ctx.createRadialGradient(W * 0.85, H * 0.75, 20, W * 0.85, H * 0.75, 380);
    glow2.addColorStop(0, "rgba(45,212,191,0.18)");
    glow2.addColorStop(1, "rgba(45,212,191,0)");
    ctx.fillStyle = glow2;
    ctx.fillRect(0, 0, W, H);

    // Border frame
    ctx.strokeStyle = "rgba(148,163,184,0.28)";
    ctx.lineWidth = 4;
    roundRect(ctx, 28, 28, W - 56, H - 56, 36);
    ctx.stroke();

    // Header brand
    const padX = 72;
    let y = 88;
    const logoSize = logo ? 104 : 0;
    const textLeft = padX + (logo ? logoSize + 28 : 0);
    if (logo) {
      roundRect(ctx, padX, y, logoSize, logoSize, 20);
      ctx.save();
      ctx.clip();
      ctx.drawImage(logo, padX, y, logoSize, logoSize);
      ctx.restore();
      ctx.strokeStyle = "rgba(148,163,184,0.35)";
      ctx.lineWidth = 2;
      roundRect(ctx, padX, y, logoSize, logoSize, 20);
      ctx.stroke();
    }
    ctx.fillStyle = "#7dd3fc";
    ctx.font = "700 32px Segoe UI, system-ui, sans-serif";
    ctx.fillText("NAVAPRON", textLeft, y + 40);
    ctx.fillStyle = "#94a3b8";
    ctx.font = "600 24px Segoe UI, system-ui, sans-serif";
    const airlineLine =
      (profile.code ? profile.code + " · " : "") +
      (profile.name || "Virtual airline");
    ctx.fillText(airlineLine, textLeft, y + 78);

    // Flight number badge
    y = 220;
    const fn = String(a.flight_number || "FLIGHT");
    ctx.font = "700 26px Segoe UI, system-ui, sans-serif";
    const fnW = Math.max(160, ctx.measureText(fn).width + 48);
    const badgeGrad = ctx.createLinearGradient(padX, y, padX + fnW, y + 52);
    badgeGrad.addColorStop(0, "#2563eb");
    badgeGrad.addColorStop(1, "#0d9488");
    ctx.fillStyle = badgeGrad;
    roundRect(ctx, padX, y, fnW, 52, 14);
    ctx.fill();
    ctx.fillStyle = "#f8fafc";
    ctx.fillText(fn, padX + 24, y + 35);

    // Route: DEP → DEST
    y = 360;
    const dep = String(a.dep_icao || "????").toUpperCase();
    const dest = String(a.dest_icao || "????").toUpperCase();
    ctx.fillStyle = "#f8fafc";
    ctx.font = "800 96px Segoe UI, system-ui, sans-serif";
    ctx.fillText(dep, padX, y);
    const depW = ctx.measureText(dep).width;
    ctx.fillStyle = "#38bdf8";
    ctx.font = "700 56px Segoe UI, system-ui, sans-serif";
    const arrow = "→";
    const arrowW = ctx.measureText(arrow).width;
    ctx.fillText(arrow, padX + depW + 28, y - 10);
    ctx.fillStyle = "#f8fafc";
    ctx.font = "800 96px Segoe UI, system-ui, sans-serif";
    ctx.fillText(dest, padX + depW + 28 + arrowW + 28, y);

    // Date + aircraft
    y = 430;
    ctx.fillStyle = "#94a3b8";
    ctx.font = "600 28px Segoe UI, system-ui, sans-serif";
    const plane = aircraftLabel(a);
    const dateLine =
      fmtShareDate(a.started_at || a.ended_at) +
      (plane
        ? "  ·  " + (plane.length > 36 ? plane.slice(0, 34) + "…" : plane)
        : "");
    ctx.fillText(dateLine, padX, y);

    // Stat cards — 2×3 grid (even)
    y = 500;
    const gapX = 28;
    const gapY = 22;
    const cardW = (W - padX * 2 - gapX) / 2;
    const cardH = 148;
    const stats = [
      { label: "BLOCK TIME", value: fmtDuration(a.block_time_s) },
      {
        label: "DISTANCE",
        value: (a.distance_nm != null ? Number(a.distance_nm).toFixed(0) : "0") + " NM",
      },
      { label: "AIRBORNE", value: fmtDuration(a.airborne_time_s) },
      {
        label: "MAX ALTITUDE",
        value:
          a.max_alt_ft != null
            ? Math.round(Number(a.max_alt_ft)).toLocaleString() + " ft"
            : "—",
      },
      {
        label: "MAX SPEED",
        value:
          a.max_gs_kt != null ? Math.round(Number(a.max_gs_kt)) + " kt" : "—",
      },
      { label: "LANDING RATE", value: fmtLandingFpm(a.landing_fpm) },
    ];
    stats.forEach(function (st, i) {
      const col = i % 2;
      const row = Math.floor(i / 2);
      const x = padX + col * (cardW + gapX);
      const cy = y + row * (cardH + gapY);
      ctx.fillStyle = "rgba(15, 23, 42, 0.72)";
      roundRect(ctx, x, cy, cardW, cardH, 20);
      ctx.fill();
      ctx.strokeStyle = "rgba(148,163,184,0.22)";
      ctx.lineWidth = 2;
      roundRect(ctx, x, cy, cardW, cardH, 20);
      ctx.stroke();
      ctx.fillStyle = "#64748b";
      ctx.font = "700 20px Segoe UI, system-ui, sans-serif";
      ctx.fillText(st.label, x + 24, cy + 42);
      ctx.fillStyle = "#f1f5f9";
      ctx.font = "800 42px Segoe UI, system-ui, sans-serif";
      ctx.fillText(st.value, x + 24, cy + 108);
    });

    // Footer
    ctx.fillStyle = "rgba(148,163,184,0.85)";
    ctx.font = "600 24px Segoe UI, system-ui, sans-serif";
    ctx.fillText("Tracked with NavApron", padX, H - 78);
    ctx.fillStyle = "#475569";
    ctx.font = "500 20px Segoe UI, system-ui, sans-serif";
    ctx.fillText("navapron.com", padX, H - 48);

    // Store blob for download/copy
    return new Promise(function (resolve) {
      canvas.toBlob(
        function (blob) {
          _shareCardBlob = blob;
          resolve(blob);
        },
        "image/png",
        0.95
      );
    });
  }

  function fillEndModal(active) {
    const a = active || {};
    const fn = $("#al-end-fn");
    const route = $("#al-end-route");
    const block = $("#al-end-block");
    const air = $("#al-end-air");
    const nm = $("#al-end-nm");
    const alt = $("#al-end-alt");
    const gs = $("#al-end-gs");
    const landing = $("#al-end-landing");
    const phase = $("#al-end-phase");
    if (fn) fn.textContent = a.flight_number || "—";
    if (route)
      route.textContent =
        (a.dep_icao || "????") + " → " + (a.dest_icao || "????");
    const acEnd = $("#al-end-aircraft");
    if (acEnd) {
      const label = aircraftLabel(a);
      acEnd.textContent = label || "Aircraft not recorded";
      acEnd.classList.toggle("is-empty", !label);
    }
    if (block) block.textContent = fmtDuration(a.block_time_s);
    if (air) air.textContent = fmtDuration(a.airborne_time_s);
    if (nm)
      nm.textContent =
        (a.distance_nm != null ? a.distance_nm : 0) + " NM";
    if (alt)
      alt.textContent =
        a.max_alt_ft != null ? Math.round(a.max_alt_ft) + " ft" : "—";
    if (gs)
      gs.textContent =
        a.max_gs_kt != null ? Math.round(a.max_gs_kt) + " kt" : "—";
    if (landing) landing.textContent = fmtLandingFpm(a.landing_fpm);
    if (phase) phase.textContent = phaseLabel(a.phase);
    setShareStatus("Building share card…");
    renderShareCard(a)
      .then(function () {
        setShareStatus("Ready to share");
      })
      .catch(function () {
        setShareStatus("Could not build share card", false);
      });
  }

  function blobToBase64(blob) {
    return new Promise(function (resolve, reject) {
      const reader = new FileReader();
      reader.onload = function () {
        resolve(String(reader.result || ""));
      };
      reader.onerror = function () {
        reject(new Error("Could not read image"));
      };
      reader.readAsDataURL(blob);
    });
  }

  async function downloadShareCard() {
    if (!_shareCardBlob) {
      setShareStatus("Card not ready yet", false);
      return;
    }
    const a = (overview && overview.active) || {};
    const name =
      "NavApron-" +
      (a.dep_icao || "DEP") +
      "-" +
      (a.dest_icao || "DEST") +
      ".png";
    setShareStatus("Saving to Documents\\NavApron\\Share cards…");
    try {
      const dataUrl = await blobToBase64(_shareCardBlob);
      const res = await fetch("/api/share-card/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filename: name, image_base64: dataUrl }),
      });
      const data = await res.json().catch(function () {
        return {};
      });
      if (!res.ok || data.ok === false) {
        throw new Error(data.error || data.detail || "Save failed");
      }
      setShareStatus("Saved: " + (data.path || name));
      // Also try a normal browser download as a backup
      try {
        const url = URL.createObjectURL(_shareCardBlob);
        const link = document.createElement("a");
        link.href = url;
        link.download = data.filename || name;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setTimeout(function () {
          URL.revokeObjectURL(url);
        }, 1500);
      } catch (_) {}
    } catch (err) {
      console.warn("downloadShareCard", err);
      setShareStatus(
        (err && err.message) || "Save failed — try Copy image instead",
        false
      );
    }
  }

  async function openShareCardsFolder() {
    try {
      const res = await fetch("/api/share-card/open-folder", { method: "POST" });
      const data = await res.json().catch(function () {
        return {};
      });
      if (data.folder) {
        setShareStatus(
          data.ok
            ? "Opened folder: " + data.folder
            : "Folder: " + data.folder + " (open it in File Explorer)"
        );
      }
    } catch (_) {
      setShareStatus(
        "Look in Documents\\NavApron\\Share cards",
        false
      );
    }
  }

  async function copyShareCard() {
    if (!_shareCardBlob) {
      setShareStatus("Card not ready yet", false);
      return;
    }
    try {
      if (
        navigator.clipboard &&
        window.ClipboardItem &&
        navigator.clipboard.write
      ) {
        await navigator.clipboard.write([
          new ClipboardItem({ "image/png": _shareCardBlob }),
        ]);
        setShareStatus("Copied — paste into Discord / chat");
        return;
      }
    } catch (err) {
      console.warn("copyShareCard", err);
    }
    // Fallback: download
    downloadShareCard();
    setShareStatus("Copy not supported here — PNG downloaded instead", false);
  }

  function setEndModalBusy(busy) {
    const logBtn = $("#btn-al-end-log");
    const discardBtn = $("#btn-al-end-discard");
    if (logBtn) logBtn.disabled = !!busy;
    if (discardBtn) discardBtn.disabled = !!busy;
  }

  function openEndModal() {
    const modal = $("#al-end-modal");
    if (!modal) return;
    fillEndModal(overview && overview.active);
    modal.classList.add("is-open");
    modal.setAttribute("aria-hidden", "false");
    modal.removeAttribute("hidden");
    setEndModalBusy(false);
  }

  function closeEndModal() {
    const modal = $("#al-end-modal");
    if (!modal) return;
    modal.classList.remove("is-open");
    modal.setAttribute("aria-hidden", "true");
    modal.setAttribute("hidden", "");
    setEndModalBusy(false);
  }

  async function endFlight() {
    // Refresh so the summary uses the latest tracked stats
    await refreshOverview();
    if (!hasActive()) {
      setStatus("No flight in progress", "err");
      return;
    }
    openEndModal();
  }

  async function logEndedFlight() {
    setEndModalBusy(true);
    try {
      const res = await fetch("/api/airline/flight/end", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const data = await res.json().catch(function () {
        return {};
      });
      if (!res.ok) {
        throw new Error(
          typeof data.detail === "string" ? data.detail : data.error || "End failed"
        );
      }
      const f = data.flight || {};
      closeEndModal();
      try {
        if (typeof window.clearLiveTrackingTrace === "function") {
          window.clearLiveTrackingTrace("airline");
        }
      } catch (_) {}
      setStatus(
        "Logged " +
          (f.flight_number || "flight") +
          " · " +
          (f.distance_nm || 0) +
          " NM · " +
          fmtDuration(f.block_time_s),
        "ok"
      );
      await refreshOverview();
      await refreshLogbook();
      // Cloudflare GET only paired with a posted flight (sharing on)
      try {
        await refreshCommunityLineAfterPost();
      } catch (_) {}
    } catch (err) {
      setEndModalBusy(false);
      setStatus(err.message || "End flight failed", "err");
    }
  }

  async function discardEndedFlight() {
    setEndModalBusy(true);
    try {
      const res = await fetch("/api/airline/flight/discard", { method: "POST" });
      const data = await res.json().catch(function () {
        return {};
      });
      if (!res.ok) {
        throw new Error(
          typeof data.detail === "string"
            ? data.detail
            : data.error || "Discard failed"
        );
      }
      const f = data.flight || {};
      closeEndModal();
      try {
        if (typeof window.clearLiveTrackingTrace === "function") {
          window.clearLiveTrackingTrace("airline");
        }
      } catch (_) {}
      setStatus(
        "Discarded " +
          (f.flight_number || "flight") +
          " — not added to logbook",
        "ok"
      );
      await refreshOverview();
      await refreshLogbook();
    } catch (err) {
      setEndModalBusy(false);
      setStatus(err.message || "Discard failed", "err");
    }
  }

  async function cancelFlight() {
    if (!confirm("Cancel this flight and log it as cancelled?")) return;
    try {
      const res = await fetch("/api/airline/flight/cancel", { method: "POST" });
      const data = await res.json().catch(function () {
        return {};
      });
      if (!res.ok) {
        throw new Error(
          typeof data.detail === "string" ? data.detail : data.error || "Cancel failed"
        );
      }
      closeEndModal();
      try {
        if (typeof window.clearLiveTrackingTrace === "function") {
          window.clearLiveTrackingTrace("airline");
        }
      } catch (_) {}
      setStatus("Flight cancelled and logged", "ok");
      await refreshOverview();
      await refreshLogbook();
    } catch (err) {
      setStatus(err.message || "Cancel failed", "err");
    }
  }

  async function resetAirline() {
    if (
      !confirm(
        "Delete your airline and clear the logbook? This cannot be undone."
      )
    )
      return;
    try {
      const res = await fetch("/api/airline?wipe_logbook=true", { method: "DELETE" });
      if (!res.ok) throw new Error("Reset failed");
      editingProfile = true;
      const name = $("#al-name");
      if (name) name.value = "";
      setStatus("Airline reset", "ok");
      await refreshOverview();
      await refreshLogbook();
    } catch (err) {
      setStatus(err.message || "Reset failed", "err");
    }
  }

  function bind() {
    $("#btn-airline-collapse")?.addEventListener("click", function () {
      setAirlineCollapsed(true);
    });
    $("#btn-airline-open")?.addEventListener("click", function () {
      setAirlineCollapsed(false);
    });

    $("#airline-profile-form")?.addEventListener("submit", saveProfile);
    $("#btn-al-edit")?.addEventListener("click", function () {
      editingProfile = true;
      renderProfile();
    });
    $("#btn-al-cancel-edit")?.addEventListener("click", function () {
      editingProfile = false;
      renderProfile();
    });
    $("#btn-al-reset")?.addEventListener("click", resetAirline);
    $("#btn-al-start")?.addEventListener("click", startFlight);
    $("#btn-al-end")?.addEventListener("click", endFlight);
    $("#btn-al-cancel")?.addEventListener("click", cancelFlight);
    $("#btn-al-end-log")?.addEventListener("click", logEndedFlight);
    $("#btn-al-end-discard")?.addEventListener("click", discardEndedFlight);
    $("#btn-al-share-download")?.addEventListener("click", function () {
      downloadShareCard().catch(function () {});
    });
    $("#btn-al-share-copy")?.addEventListener("click", function () {
      copyShareCard().catch(function () {});
    });
    $("#btn-al-share-folder")?.addEventListener("click", function () {
      openShareCardsFolder().catch(function () {});
    });
    document.querySelectorAll("[data-al-end-close]").forEach(function (el) {
      el.addEventListener("click", closeEndModal);
    });
    document.querySelectorAll("[data-al-log-close]").forEach(function (el) {
      el.addEventListener("click", closeLogModal);
    });
    $("#btn-al-log-show-trace")?.addEventListener("click", function () {
      showLogFlownTrace().catch(function (err) {
        console.error("showLogFlownTrace", err);
      });
    });
    $("#btn-al-log-delete")?.addEventListener("click", function () {
      if (selectedLogId) deleteLogFlight(selectedLogId, { fromModal: true });
    });
    $("#btn-al-log-more")?.addEventListener("click", function () {
      refreshLogbook({ append: true });
    });

    // Logbook list: open detail or delete (event delegation)
    $("#al-logbook-list")?.addEventListener("click", function (e) {
      const del = e.target.closest("[data-delete-id]");
      if (del) {
        e.preventDefault();
        e.stopPropagation();
        deleteLogFlight(del.getAttribute("data-delete-id"));
        return;
      }
      const item = e.target.closest(".al-log-item[data-flight-id]");
      if (!item) return;
      const id = item.getAttribute("data-flight-id");
      const f = id && logbookById[id];
      if (f) openLogModal(f);
    });
    $("#al-logbook-list")?.addEventListener("keydown", function (e) {
      if (e.key !== "Enter" && e.key !== " ") return;
      const item = e.target.closest(".al-log-item[data-flight-id]");
      if (!item) return;
      e.preventDefault();
      const id = item.getAttribute("data-flight-id");
      const f = id && logbookById[id];
      if (f) openLogModal(f);
    });

    document.addEventListener("keydown", function (e) {
      if (e.key !== "Escape") return;
      const logModal = $("#al-log-modal");
      if (logModal && logModal.classList.contains("is-open")) {
        closeLogModal();
        return;
      }
      const modal = $("#al-end-modal");
      if (modal && modal.classList.contains("is-open")) closeEndModal();
    });

    // Uppercase ICAO fields
    ["#al-dep", "#al-dest", "#al-fn", "#al-aircraft", "#al-code"].forEach(function (sel) {
      $(sel)?.addEventListener("input", function (e) {
        const t = e.target;
        const start = t.selectionStart;
        t.value = t.value.toUpperCase();
        try {
          t.setSelectionRange(start, start);
        } catch (_) {}
      });
    });
  }

  function startPoll() {
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(function () {
      refreshOverview();
    }, 2000);
  }

  // Boot — delay network so first launch doesn't thrash WebView with parallel API storms
  try {
    bind();
    try {
      if (localStorage.getItem("navapron_airline_collapsed") === "1") {
        setAirlineCollapsed(true, { persist: false, quiet: true });
      }
    } catch (_) {}
    setTimeout(function () {
      refreshOverview()
        .then(refreshLogbook)
        .catch(function () {});
      startPoll();
    }, 1500);
  } catch (bootErr) {
    console.error("airline boot failed", bootErr);
  }
})();
