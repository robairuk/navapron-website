/**
 * NavApron — MSFS surface / SID · STAR companion
 *
 * Version:   edit frontend/js/version.js
 * Changelog: edit frontend/js/changelog.js (What's New page)
 *
 * Loaded as classic scripts (not ES modules) so a missing helper
 * file cannot blank the whole map/search UI.
 */

const $ = (sel) => document.querySelector(sel);

/** Tell the MSFS EFB / toolbar panel host that NavApron finished loading. */
(function notifyEfbHostReady() {
  try {
    if (window.parent && window.parent !== window) {
      const payload = {
        type: "navapron-panel-ready",
        phase: "hub-app",
        href: String(location.href || ""),
      };
      window.parent.postMessage(payload, "*");
      window.parent.postMessage({ type: "navapron-efb-ready" }, "*");
      // Repeat a few times — Coherent listeners may attach late
      let n = 0;
      const t = setInterval(function () {
        try {
          window.parent.postMessage(payload, "*");
          window.parent.postMessage({ type: "navapron-efb-ready" }, "*");
        } catch (_) {}
        if (++n >= 8) clearInterval(t);
      }, 500);
    }
  } catch (_) {
    /* not in iframe */
  }
})();

function appVersionLabel() {
  if (typeof window.NAVAPRON_VERSION_LABEL === "string" && window.NAVAPRON_VERSION_LABEL) {
    return window.NAVAPRON_VERSION_LABEL;
  }
  const ver = window.NAVAPRON_VERSION || "v0.2";
  const prefix = window.NAVAPRON_VERSION_PREFIX || "Beta Version";
  return prefix + ": " + ver;
}

function appVersion() {
  return window.NAVAPRON_VERSION || "v0.2";
}

function appChangelog() {
  return Array.isArray(window.NAVAPRON_CHANGELOG) ? window.NAVAPRON_CHANGELOG : [];
}

/** Load What's New from changelog.json (edited via Edit Changelog.bat). */
async function ensureChangelogLoaded() {
  try {
    const res = await fetch("/changelog.json?t=" + Date.now(), { cache: "no-store" });
    if (!res.ok) return;
    const data = await res.json();
    if (Array.isArray(data)) window.NAVAPRON_CHANGELOG = data;
  } catch (_) {
    /* keep whatever changelog.js set */
  }
}

// Show version in sidebar (single source of truth: version.js)
const _verEl = $("#app-version");
if (_verEl) _verEl.textContent = appVersionLabel();
const _hubVer = $("#hub-version");
if (_hubVer) _hubVer.textContent = appVersionLabel();
const _launcherVer = $("#launcher-version");
if (_launcherVer) _launcherVer.textContent = appVersionLabel();
document.title = "NavApron — " + appVersionLabel();

// ── What's New / changelog ───────────────────────────────────────
function escapeHtml(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function renderChangelog() {
  try {
    const body = $("#whats-new-body");
    const sub = $("#whats-new-sub");
    if (!body) return;
    if (sub) sub.textContent = appVersionLabel();

    const entries = appChangelog();
    if (!entries.length) {
      body.innerHTML =
        '<p class="changelog-empty">No release notes yet. Double-click <strong>Edit Changelog.bat</strong> in the project folder to add them (saves <code>frontend/changelog.json</code>).</p>';
      return;
    }

    const current = String(appVersion() || "").toLowerCase();
    body.innerHTML = entries
      .map(function (rel) {
        if (!rel || typeof rel !== "object") return "";
        const ver = escapeHtml(rel.version || "—");
        const isCurrent = String(rel.version || "").toLowerCase() === current;
        const date = rel.date
          ? '<span class="changelog-date">' + escapeHtml(rel.date) + "</span>"
          : "";
        const badge = isCurrent ? '<span class="changelog-badge">Current</span>' : "";
        const title = rel.title
          ? '<p class="changelog-title">' + escapeHtml(rel.title) + "</p>"
          : "";
        const changes = Array.isArray(rel.changes)
          ? rel.changes
          : typeof rel.changes === "string"
            ? [rel.changes]
            : [];
        const items = changes
          .map(function (c) {
            return "<li>" + escapeHtml(c) + "</li>";
          })
          .join("");
        return (
          '<article class="changelog-release' +
          (isCurrent ? " is-current" : "") +
          '">' +
          '<div class="changelog-meta">' +
          '<span class="changelog-ver">' +
          ver +
          "</span>" +
          badge +
          date +
          "</div>" +
          title +
          '<ul class="changelog-list">' +
          items +
          "</ul>" +
          "</article>"
        );
      })
      .join("");
  } catch (err) {
    console.error("renderChangelog", err);
    const body = $("#whats-new-body");
    if (body) {
      body.innerHTML =
        '<p class="changelog-empty">Could not render release notes. Check <code>frontend/changelog.json</code>.</p>';
    }
  }
}

function isWhatsNewOpen() {
  const modal = $("#whats-new-modal");
  return !!(modal && modal.classList.contains("is-open"));
}

function openWhatsNew() {
  try {
    const modal = $("#whats-new-modal");
    if (!modal) {
      console.warn("whats-new-modal missing from DOM");
      return;
    }
    // Open shell first (no focus / no blur CSS) so the click never freezes the host.
    // Avoid focus() — can crash some Edge WebView / app-mode hosts.
    modal.classList.add("is-open");
    modal.setAttribute("aria-hidden", "false");
    modal.removeAttribute("hidden");
    // Defer DOM paint work off the click stack (safer for WebView2).
    var paint = function () {
      try {
        renderChangelog();
      } catch (err) {
        console.error("renderChangelog deferred", err);
      }
      ensureChangelogLoaded()
        .then(function () {
          if (isWhatsNewOpen()) renderChangelog();
        })
        .catch(function (err) {
          console.warn("changelog load", err);
        });
    };
    if (typeof requestAnimationFrame === "function") {
      requestAnimationFrame(function () {
        setTimeout(paint, 0);
      });
    } else {
      setTimeout(paint, 0);
    }
  } catch (err) {
    console.error("openWhatsNew", err);
  }
}

function closeWhatsNew() {
  try {
    const modal = $("#whats-new-modal");
    if (!modal) return;
    modal.classList.remove("is-open");
    modal.setAttribute("aria-hidden", "true");
    modal.setAttribute("hidden", "");
  } catch (err) {
    console.error("closeWhatsNew", err);
  }
}

const _btnWhatsNew = $("#btn-whats-new");
if (_btnWhatsNew) {
  _btnWhatsNew.addEventListener("click", function (e) {
    try {
      if (e && e.preventDefault) e.preventDefault();
      openWhatsNew();
    } catch (err) {
      console.error(err);
    }
  });
}

const _whatsNewModal = $("#whats-new-modal");
if (_whatsNewModal) {
  // Ensure closed on boot (never block map/sidebar)
  closeWhatsNew();
  _whatsNewModal.addEventListener("click", function (e) {
    try {
      const t = e.target;
      if (t && t.getAttribute && t.getAttribute("data-close-whats-new") != null) {
        closeWhatsNew();
      }
    } catch (err) {
      console.error(err);
    }
  });
}

document.addEventListener("keydown", function (e) {
  try {
    if (e.key === "Escape" && isWhatsNewOpen()) {
      closeWhatsNew();
    }
  } catch (_) {
    /* ignore */
  }
});

if (_verEl) {
  _verEl.style.cursor = "pointer";
  _verEl.title = "Open What's New";
  _verEl.addEventListener("click", function (e) {
    try {
      if (e && e.preventDefault) e.preventDefault();
      openWhatsNew();
    } catch (err) {
      console.error(err);
    }
  });
}

const state = {
  airport: null,
  layout: null,
  runwayEnds: [],
  clearance: [],
  /** Inbound taxiway clearance tokens (arrival taxi-in) */
  arrClearance: [],
  start: null, // { lat, lon, label } — active (dep taxi-out) start
  end: null, // runway end currently shown as red marker
  runwayEndMeta: null, // active runway meta (dep or arr depending on step)
  arrivalStand: null, // { lat, lon, label }
  /**
   * Remember gate/stand + runway per journey phase so taxi-out ↔ taxi-in
   * (and back) restores dropdowns and markers instead of wiping them.
   */
  depPick: {
    start: null, // { lat, lon, label }
    runway: null, // { name, lat, lon, approach_hdg, runway }
  },
  arrPick: {
    stand: null, // { lat, lon, label }
    runway: null,
  },
  clickStartMode: false,
  /** Toolbar pen: freehand stroke snapped to taxi graph */
  drawTaxiMode: false,
  /** Hand-drawn paths — skip live auto re-route until Clear / Show / Best */
  manualTaxiPath: { route: false, taxiIn: false },
  depSuggestions: [],
  arrSuggestions: [],
  activeTab: "taxi",
  /** hub | journey | taxi | departure | arrival | flightplan */
  mode: "hub",
  journeyStep: "taxi-out",
  layerVisibility: {
    route: true,
    flightPlan: true,
    taxiIn: true,
    departure: true,
    arrival: true,
    aircraft: true,
    activeLeg: true,
    /** Precipitation radar tiles (RainViewer); off by default */
    weather: false,
    /** Live VATSIM pilots in map view; off by default */
    vatsim: false,
    /** Live VATSIM ATC radar ranges; off by default */
    vatsimAtc: false,
    /** Live IVAO pilots in map view; off by default */
    ivao: false,
    /** MSFS AI / injected traffic via SimConnect; off by default */
    simTraffic: false,
  },
  flightPlan: null, // last built plan object
  /** Latest METAR for the active airport (from /api/weather) */
  metar: null,
  /** Wind-preferred runway end hint (never auto-applied) */
  runwaySuggestion: null,
  /** Last drawn procedure paths (for linking enroute plan) */
  activeDeparture: null, // full API payload from Show SID
  activeArrival: null, // full API payload from Show STAR
  /** Dual airport charts for gate-to-gate */
  depChart: null, // { airport, layout, runwayEnds }
  destChart: null,
  /** Stored path polylines for active-leg snap (key → track or null) */
  pathTracks: {
    route: null,
    taxiIn: null,
    departure: null,
    arrival: null,
    flightPlan: null,
  },
  /**
   * Last drawn path payloads so mode/tab switches can re-paint the map.
   * Cleared only by explicit Clear buttons or a full airport reload.
   */
  pathSnapshots: {
    route: null, // { data, start, end }
    taxiIn: null, // { data, startInfo }
    departure: null, // { data }
    arrival: null, // { data }
  },
  /** Follow plan: auto-pan/zoom to aircraft + upcoming path (vs Follow = centre on A/C) */
  followPlan: false,
  /**
   * When false, hide gate/stand markers on the airport chart (map clutter).
   * Controlled by the Gates toolbar button — not tied to Follow plan.
   */
  showAirportClutter: true,
  /** When false, hide the map colour key / legend (bottom-left). */
  showMapLegend: true,
  /** Pink live tracking path (Airline / Career); toolbar can hide without stopping tracking */
  showLiveTrace: true,
  activeLegInfo: null,
  /** Sticky path lock so next-WP / to-dest don't flicker between SID and enroute */
  _legLock: null, // { key, segIdx }
  _legMisses: 0,
  _followPlanTick: 0,
  /** Map orientation: false = north-up, true = aircraft heading-up */
  mapHeadingUp: false,
  /** Auto re-route taxi when MSFS aircraft leaves the planned path */
  _taxiRerouteBusy: false,
  _lastTaxiRerouteAt: 0,
  _lastTaxiReroutePos: null,
  /**
   * After live landing at destination: auto-pick gate + taxi-in.
   * User can override stand anytime (_arrStandSource = "user").
   */
  autoArriveTaxiIn: true,
  /** Planned arrival gate/stand from SimBrief / OFP (string ref) */
  plannedArrGate: null,
  /** 'user' | 'auto' | null — whether current arrival stand was manual */
  _arrStandSource: null,
  _simWasAirborne: false,
  _autoArriveBusy: false,
  /** One-shot key per landing (cleared when airborne again) */
  _autoArriveDoneKey: null,
  /**
   * User manually picked a journey tab — don't yank back to taxi-in until
   * airborne again (career / live tracking used to fight the tabs).
   */
  _journeyStepUserLock: false,
  /** Lined up on dep runway → already switched to flight-plan step */
  _depRunwayFpDone: false,
  /** Last SimBrief OFP summary for map bubble (cruise, fuel, weights, …) */
  simbriefOfpSummary: null,
  sim: {
    enabled: false,
    connected: false,
    follow: false,
    /** GS / P.ALT / HDG bubble above the aircraft marker */
    showDataBubble: true,
    pollTimer: null,
    lat: null,
    lon: null,
    heading: null,
    altitudeFt: null,
    gsKt: null,
  },
  layers: {
    taxiways: null,
    runways: null,
    aprons: null,
    parking: null,
    route: null,
    startMarker: null,
    endMarker: null,
    labels: null,
  },
  twyLayerByName: new Map(),
  searchTimer: null,
};

// ── Map (DEFERRED init) ─────────────────────────────────────────
// Creating Leaflet at script-parse time (while the hub overlay is up) has
// crashed Edge WebView2 on first launch. We only build the real map the first
// time the user leaves Home for a planning mode.
/** Gate/stand numbers only when zoomed in this far (avoids clutter at airport overview). */
const GATE_LABEL_MIN_ZOOM = 16;

let map = null;
let baseLayers = null;
let _mapInitError = null;
let _mapReady = false;
let _mapCreating = false;
/** Set true after leaflet-rotate.js is lazy-loaded (never at hub boot). */
let _leafletRotateLoaded = false;
let _leafletRotateLoading = null;
/** Freehand Draw-taxi stroke (bound once real Leaflet map exists). */
let _penStroke = null; // [[lat,lon],...]
let _penPolyline = null;
let _penDrawing = false;
let _penMapBound = false;

// ── Weather radar (RainViewer) ───────────────────────────────────
const WEATHER_MAPS_URL = "https://api.rainviewer.com/public/weather-maps.json";
const WEATHER_REFRESH_MS = 6 * 60 * 1000; // ~6 min (radar frames ~10 min)
const WEATHER_OPACITY = 0.65;
// Free RainViewer API max zoom is 7 — higher z returns tiny "not supported" PNGs.
const WEATHER_MAX_NATIVE_ZOOM = 7;
const WEATHER_IMAGE_SIZE = 256;
// Universal Blue (2) — only scheme still supported on the free API.
const WEATHER_COLOR = 2;
const WEATHER_OPTIONS = "1_1"; // {smooth}_{snow}
const WEATHER_LAYER_REV = "v7-stable";
let _weatherTileLayer = null;
let _weatherZoomHooked = false;
/** Active raster basemap group (one or more tile layers) */
let _basemapLayer = null;
/** Individual basemap tile layers currently on the map (for hard detach). */
let _basemapTileLayers = [];
/** Bumps on every attach so late VFR/OFM callbacks cannot re-mix styles. */
let _basemapAttachGen = 0;
/** Cached free CARTO basemap API key from user prefs (optional) */
let _cartoApiKey = "";
/** User basemap style: dark | satellite | terrain | vfr */
let _mapStyle = "dark";
/** OpenFlightMaps AIRAC path fragment, e.g. "2610/base/latest" */
let _ofmCyclePath = "";
let _ofmCyclePromise = null;
let _weatherFramePath = null;
let _weatherRefreshTimer = null;
let _weatherLoadPromise = null;
let _weatherMapsCache = null; // { at, data }
let _weatherMapsCacheAt = 0;
let _weatherUrlTemplate = null; // host+path template for custom getTileUrl

function _makeLayerStub() {
  const _noop = function () {
    return this;
  };
  return {
    addTo: _noop,
    clearLayers: _noop,
    eachLayer: _noop,
    getLayers: function () {
      return [];
    },
    on: _noop,
    off: _noop,
    addLayer: _noop,
    removeLayer: _noop,
  };
}

function _makeMapStub() {
  const _noop = function () {
    return this;
  };
  return {
    on: _noop,
    off: _noop,
    getZoom: function () {
      return 13;
    },
    getContainer: function () {
      return document.getElementById("map") || document.body;
    },
    setView: _noop,
    fitBounds: _noop,
    panTo: _noop,
    invalidateSize: _noop,
    hasLayer: function () {
      return false;
    },
    addLayer: _noop,
    removeLayer: _noop,
    remove: _noop,
  };
}

function _installMapStubs() {
  map = _makeMapStub();
  baseLayers = {
    taxiways: _makeLayerStub(),
    runways: _makeLayerStub(),
    aprons: _makeLayerStub(),
    buildings: _makeLayerStub(),
    parking: _makeLayerStub(),
    holds: _makeLayerStub(),
    labels: _makeLayerStub(),
    route: _makeLayerStub(),
    taxiIn: _makeLayerStub(),
    departure: _makeLayerStub(),
    arrival: _makeLayerStub(),
    flightPlan: _makeLayerStub(),
    activeLeg: _makeLayerStub(),
    aircraft: _makeLayerStub(),
    markers: _makeLayerStub(),
    penPreview: _makeLayerStub(),
    weather: _makeLayerStub(),
    vatsim: _makeLayerStub(),
    vatsimAtc: _makeLayerStub(),
    ivao: _makeLayerStub(),
    simTraffic: _makeLayerStub(),
    flightTrace: _makeLayerStub(),
  };
}

// Safe defaults until ensureMapReady() runs (hub-only boot must not crash)
_installMapStubs();

/**
 * CARTO raster basemaps now require a free API key (watermark without it).
 * With a key → dark CARTO; without → OSM (no CSS filters — they freeze WebView2).
 */
function getCartoApiKey() {
  return String(_cartoApiKey || "").trim();
}

const MAP_STYLES = ["dark", "satellite", "terrain", "vfr"];

function loadMapStylePref() {
  try {
    const v = String(localStorage.getItem("navapron_map_style") || "dark")
      .trim()
      .toLowerCase();
    _mapStyle = MAP_STYLES.indexOf(v) >= 0 ? v : "dark";
  } catch (_) {
    _mapStyle = "dark";
  }
  try {
    const c = String(localStorage.getItem("navapron_ofm_cycle") || "").trim();
    if (/^\d{4}\/base\/latest$/.test(c)) _ofmCyclePath = c;
  } catch (_) {}
  return _mapStyle;
}

function saveMapStylePref(style) {
  try {
    localStorage.setItem("navapron_map_style", style);
  } catch (_) {}
}

function syncMapStyleChips() {
  document.querySelectorAll(".map-style-chip").forEach(function (btn) {
    const id = btn.getAttribute("data-map-style");
    btn.classList.toggle("active", id === _mapStyle);
    btn.setAttribute("aria-pressed", id === _mapStyle ? "true" : "false");
  });
}

function _ensureBasemapPane(mapInst) {
  if (!mapInst || typeof mapInst.createPane !== "function") return "tilePane";
  try {
    let pane = mapInst.getPane("basemapPane");
    if (!pane) {
      pane = mapInst.createPane("basemapPane");
    }
    // Below default tilePane (200) so nothing in tilePane can sandwich us;
    // we also keep tilePane clear of basemap hosts.
    pane.style.zIndex = 150;
    pane.style.pointerEvents = "none";
    return "basemapPane";
  } catch (_) {
    return "tilePane";
  }
}

function _tileOpts(extra) {
  return Object.assign(
    {
      pane: "basemapPane",
      updateWhenZooming: false,
      updateWhenIdle: true,
      keepBuffer: 0,
      crossOrigin: true,
      className: "navapron-basemap",
      navapronBasemap: true,
      navapronBasemapStyle: _mapStyle || "dark",
    },
    extra || {}
  );
}

/**
 * Strict host allowlist for the ACTIVE style only.
 * Dark+CARTO must NOT allow openstreetmap.org — old VFR underlay tiles were
 * surviving scrub and painting light streets + OFM over the dark basemap.
 * VFR allows OSM + OFM: street underlay stays visible past OFM native zoom
 * (airport view is often z>15; OFM-only looked blank there).
 */
function _basemapAllowedHostRe() {
  if (_mapStyle === "satellite") return /arcgisonline\.com|arcgis\.com/i;
  if (_mapStyle === "terrain") return /opentopomap\.org/i;
  if (_mapStyle === "vfr") {
    return _ofmCyclePath
      ? /newaydata\.com|openstreetmap\.org/i
      : /openstreetmap\.org/i;
  }
  if (getCartoApiKey()) return /cartocdn\.com/i;
  return /openstreetmap\.org/i;
}

function _layerUrl(lyr) {
  try {
    return String((lyr && (lyr._url || lyr._originalUrl)) || "");
  } catch (_) {
    return "";
  }
}

function _isWeatherLayer(lyr) {
  if (!lyr) return false;
  if (_weatherTileLayer && lyr === _weatherTileLayer) return true;
  try {
    if (lyr.options && lyr.options.className === "weather-radar-tiles") return true;
  } catch (_) {}
  return /rainviewer/i.test(_layerUrl(lyr));
}

function _killLayer(mapInst, lyr) {
  if (!lyr) return;
  try {
    if (typeof lyr._removeAllTiles === "function") lyr._removeAllTiles();
  } catch (_) {}
  try {
    if (typeof lyr.clearLayers === "function") lyr.clearLayers();
  } catch (_) {}
  if (mapInst) {
    try {
      mapInst.removeLayer(lyr);
    } catch (_) {}
  }
  try {
    if (lyr._map && lyr._map !== mapInst) lyr._map.removeLayer(lyr);
  } catch (_) {}
}

const _BASEMAP_HOST_RE =
  /cartocdn\.com|openstreetmap\.org|opentopomap\.org|arcgisonline\.com|arcgis\.com|newaydata\.com/i;

/** Wipe every basemap-like TileLayer via map._layers (catches LayerGroup kids). */
function nukeAllBasemapTileLayers(mapInst) {
  const m = mapInst || map;
  _basemapLayer = null;
  _basemapTileLayers = [];
  if (!m) return;
  const doomed = [];
  const seen = new Set();
  // Direct registry — more reliable than eachLayer for orphans
  try {
    const reg = m._layers || {};
    Object.keys(reg).forEach(function (id) {
      const lyr = reg[id];
      if (!lyr || seen.has(lyr) || _isWeatherLayer(lyr)) return;
      seen.add(lyr);
      const url = _layerUrl(lyr);
      const opts = lyr.options || {};
      if (opts.navapronBasemap || _BASEMAP_HOST_RE.test(url)) {
        doomed.push(lyr);
        return;
      }
      if (typeof lyr.getLayers === "function") {
        let kids = [];
        try {
          kids = lyr.getLayers() || [];
        } catch (_) {
          kids = [];
        }
        for (let i = 0; i < kids.length; i++) {
          const ku = _layerUrl(kids[i]);
          if (
            _BASEMAP_HOST_RE.test(ku) ||
            (kids[i].options && kids[i].options.navapronBasemap)
          ) {
            doomed.push(lyr);
            break;
          }
        }
      }
    });
  } catch (_) {}
  doomed.forEach(function (lyr) {
    _killLayer(m, lyr);
  });
}

function _clearBasemapPanes(mapInst) {
  const m = mapInst || map;
  if (!m || typeof m.getPane !== "function") return;
  ["basemapPane", "tilePane"].forEach(function (name) {
    try {
      const pane = m.getPane(name);
      if (!pane) return;
      pane
        .querySelectorAll(
          "img.leaflet-tile, canvas.leaflet-tile, .leaflet-tile-container"
        )
        .forEach(function (node) {
          try {
            if (node.classList && node.classList.contains("weather-radar-tiles")) {
              return;
            }
            const src = node.currentSrc || node.src || "";
            if (src && /rainviewer/i.test(src)) return;
            // On tilePane only remove known basemap hosts (leave other uses)
            if (name === "tilePane" && src && !_BASEMAP_HOST_RE.test(src)) return;
            node.remove();
          } catch (_) {}
        });
    } catch (_) {}
  });
}

function scrubForeignBasemapTiles(mapInst) {
  const m = mapInst || map;
  if (!m) return 0;
  const re = _basemapAllowedHostRe();
  let removed = 0;
  const root = typeof m.getContainer === "function" ? m.getContainer() : null;
  const scopes = [];
  if (typeof m.getPane === "function") {
    ["basemapPane", "tilePane"].forEach(function (name) {
      try {
        const pane = m.getPane(name);
        if (pane) scopes.push(pane);
      } catch (_) {}
    });
  }
  if (root) scopes.push(root);
  scopes.forEach(function (scope) {
    scope.querySelectorAll("img.leaflet-tile").forEach(function (img) {
      try {
        if (img.classList && img.classList.contains("weather-radar-tiles")) return;
        const src = img.currentSrc || img.src || "";
        if (!src || !_BASEMAP_HOST_RE.test(src)) return;
        if (!re.test(src)) {
          img.remove();
          removed += 1;
        }
      } catch (_) {}
    });
  });
  return removed;
}

function _basemapHasForeignDomTiles(mapInst) {
  const m = mapInst || map;
  if (!m || typeof m.getPane !== "function") return false;
  const re = _basemapAllowedHostRe();
  const panes = ["basemapPane", "tilePane"];
  for (let p = 0; p < panes.length; p++) {
    let pane;
    try {
      pane = m.getPane(panes[p]);
    } catch (_) {
      pane = null;
    }
    if (!pane) continue;
    const imgs = pane.querySelectorAll("img.leaflet-tile");
    for (let i = 0; i < imgs.length; i++) {
      const src = imgs[i].currentSrc || imgs[i].src || "";
      if (src && _BASEMAP_HOST_RE.test(src) && !re.test(src)) return true;
    }
  }
  return false;
}

function detachBasemap(mapInst) {
  nukeAllBasemapTileLayers(mapInst);
  _clearBasemapPanes(mapInst);
  scrubForeignBasemapTiles(mapInst);
}

function ofmCycleCandidates() {
  const out = [];
  const now = new Date();
  for (let i = 0; i < 10; i++) {
    const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1));
    const yy = String(d.getUTCFullYear() % 100).padStart(2, "0");
    const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
    out.push(yy + mm + "/base/latest");
  }
  return out;
}

function ofmTileUrl(cyclePath) {
  const path = String(cyclePath || "").replace(/[^0-9a-zA-Z/_-]/g, "");
  return (
    "https://nwy-tiles-api.prod.newaydata.com/tiles/{z}/{x}/{y}.jpg?path=" + path
  );
}

/** Resolve a working OpenFlightMaps AIRAC path (Europe coverage; gaps elsewhere). */
function ensureOfmCycle() {
  if (_ofmCyclePath) return Promise.resolve(_ofmCyclePath);
  if (_ofmCyclePromise) return _ofmCyclePromise;
  _ofmCyclePromise = (async function () {
    const probeZ = 8;
    const probeX = 134;
    const probeY = 86;
    const cands = ofmCycleCandidates();
    for (let i = 0; i < cands.length; i++) {
      const cycle = cands[i];
      const url =
        "https://nwy-tiles-api.prod.newaydata.com/tiles/" +
        probeZ +
        "/" +
        probeX +
        "/" +
        probeY +
        ".jpg?path=" +
        cycle;
      try {
        const res = await fetch(url, {
          method: "GET",
          cache: "no-store",
          mode: "cors",
        });
        if (!res.ok) continue;
        const buf = await res.arrayBuffer();
        if (buf && buf.byteLength > 2500) {
          _ofmCyclePath = cycle;
          try {
            localStorage.setItem("navapron_ofm_cycle", cycle);
          } catch (_) {}
          return cycle;
        }
      } catch (_) {}
    }
    return "";
  })().finally(function () {
    _ofmCyclePromise = null;
  });
  return _ofmCyclePromise;
}

/**
 * One or more TileLayer specs for the active style.
 * VFR uses OSM underlay + OFM chart (two separate layers, both tracked — never
 * a LayerGroup). Airport zoom is often past OFM maxNativeZoom; underlay keeps
 * the map from going blank.
 */
function basemapSpecsForStyle(style) {
  const id = MAP_STYLES.indexOf(style) >= 0 ? style : "dark";
  if (id === "satellite") {
    return [
      {
        url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        options: _tileOpts({
          attribution:
            "Tiles &copy; Esri — Source: Esri, Maxar, Earthstar Geographics, and the GIS User Community",
          maxZoom: 19,
          maxNativeZoom: 18,
        }),
      },
    ];
  }
  if (id === "terrain") {
    return [
      {
        url: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
        options: _tileOpts({
          attribution:
            'Map data: &copy; <a href="https://www.openstreetmap.org/copyright">OSM</a>, <a href="https://viewfinderpanoramas.org">SRTM</a> | Map style: &copy; <a href="https://opentopomap.org">OpenTopoMap</a> (CC-BY-SA)',
          subdomains: "abc",
          maxZoom: 17,
          maxNativeZoom: 15,
        }),
      },
    ];
  }
  if (id === "vfr") {
    const specs = [
      {
        url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
        options: _tileOpts({
          attribution:
            '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
          subdomains: "abc",
          maxZoom: 19,
          opacity: _ofmCyclePath ? 0.72 : 1,
          // OSM sends CORS; keep underlay reliable in WebView2
          crossOrigin: true,
        }),
      },
    ];
    if (_ofmCyclePath) {
      specs.push({
        url: ofmTileUrl(_ofmCyclePath),
        options: _tileOpts({
          attribution:
            '<a href="https://www.openflightmaps.org/" target="_blank" rel="noopener">OpenFlightMaps</a> (VFR)',
          // Allow zoom-in at airports; native tiles stop ~z11 and upscale after
          maxZoom: 19,
          maxNativeZoom: 11,
          opacity: 0.92,
          // OFM CDN often lacks CORS — crossOrigin:true made tiles blank in WebView2
          crossOrigin: false,
        }),
      });
    }
    return specs;
  }
  const key = getCartoApiKey();
  if (key) {
    return [
      {
        url:
          "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png?key=" +
          encodeURIComponent(key),
        options: _tileOpts({
          attribution:
            '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a> &copy; <a href="https://carto.com/">CARTO</a>',
          subdomains: "abcd",
          maxZoom: 20,
          maxNativeZoom: 18,
        }),
      },
    ];
  }
  return [
    {
      url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
      options: _tileOpts({
        attribution:
          '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        subdomains: "abc",
        maxZoom: 19,
      }),
    },
  ];
}

let _basemapZoomHooked = false;
let _basemapZoomScrubTimer = null;
let _basemapScrubRepairing = false;
let _basemapTileObserver = null;

function _stripForeignBasemapImg(img) {
  if (!img || !img.getAttribute) return false;
  try {
    if (img.classList && img.classList.contains("weather-radar-tiles")) return false;
    const src = img.currentSrc || img.src || img.getAttribute("src") || "";
    if (!src || !_BASEMAP_HOST_RE.test(src)) return false;
    if (_basemapAllowedHostRe().test(src)) return false;
    img.remove();
    return true;
  } catch (_) {
    return false;
  }
}

/** Instantly remove light OSM / VFR tiles that orphan layers re-insert on zoom. */
function _bindBasemapTileObserver(mapInst) {
  const m = mapInst || map;
  if (!m || m._navapronStub) return;
  if (typeof MutationObserver === "undefined") return;
  if (_basemapTileObserver) return;
  const root = typeof m.getContainer === "function" ? m.getContainer() : null;
  if (!root) return;
  _basemapTileObserver = new MutationObserver(function (mutations) {
    let stripped = 0;
    for (let i = 0; i < mutations.length; i++) {
      const nodes = mutations[i].addedNodes;
      if (!nodes) continue;
      for (let j = 0; j < nodes.length; j++) {
        const node = nodes[j];
        if (!node || node.nodeType !== 1) continue;
        if (
          node.matches &&
          node.matches("img.leaflet-tile") &&
          _stripForeignBasemapImg(node)
        ) {
          stripped += 1;
          continue;
        }
        if (!node.querySelectorAll) continue;
        const imgs = node.querySelectorAll("img.leaflet-tile");
        for (let k = 0; k < imgs.length; k++) {
          if (_stripForeignBasemapImg(imgs[k])) stripped += 1;
        }
      }
    }
    if (stripped > 0 && _mapStyle !== "vfr") {
      try {
        _purgeForeignBasemapLayers(m);
      } catch (_) {}
    }
  });
  try {
    _basemapTileObserver.observe(root, { childList: true, subtree: true });
  } catch (_) {
    _basemapTileObserver = null;
  }
}

function _purgeForeignBasemapLayers(mapInst) {
  const m = mapInst || map;
  if (!m) return;
  const keep = new Set(_basemapTileLayers);
  if (_basemapLayer) keep.add(_basemapLayer);
  const reg = m._layers || {};
  Object.keys(reg).forEach(function (id) {
    const lyr = reg[id];
    if (!lyr || keep.has(lyr) || _isWeatherLayer(lyr)) return;
    const url = _layerUrl(lyr);
    const opts = lyr.options || {};
    if (opts.navapronBasemap || _BASEMAP_HOST_RE.test(url)) {
      _killLayer(m, lyr);
    }
  });
}

function _runBasemapZoomScrub(mapInst) {
  const m = mapInst || map;
  if (!m || m._navapronStub || _basemapScrubRepairing) return;
  try {
    _purgeForeignBasemapLayers(m);
    scrubForeignBasemapTiles(m);
    // Dark must never keep OSM/OFM — rebuild if any foreign tile still painted
    if (_basemapHasForeignDomTiles(m) && _mapStyle === "dark") {
      _basemapScrubRepairing = true;
      try {
        attachBasemap(m);
      } finally {
        _basemapScrubRepairing = false;
      }
    }
  } catch (_) {
    _basemapScrubRepairing = false;
  }
}

function _bindBasemapZoomHook(mapInst) {
  const m = mapInst || map;
  if (!m || m._navapronStub || _basemapZoomHooked) return;
  _basemapZoomHooked = true;
  _bindBasemapTileObserver(m);
  const schedule = function () {
    if (_basemapZoomScrubTimer) clearTimeout(_basemapZoomScrubTimer);
    _basemapZoomScrubTimer = setTimeout(function () {
      _basemapZoomScrubTimer = null;
      _runBasemapZoomScrub(m);
    }, 0);
  };
  m.on("zoom", schedule);
  m.on("zoomend", schedule);
  m.on("moveend", schedule);
}

function attachBasemap(mapInst) {
  if (!mapInst || !L || typeof L.tileLayer !== "function") return null;
  const attachGen = ++_basemapAttachGen;
  _ensureBasemapPane(mapInst);
  _bindBasemapZoomHook(mapInst);
  detachBasemap(mapInst);
  try {
    const el =
      mapInst && typeof mapInst.getContainer === "function"
        ? mapInst.getContainer()
        : null;
    if (el && el.classList) {
      el.classList.remove("basemap-osm-dark");
      el.classList.remove("basemap-dark");
      el.classList.remove("basemap-satellite");
      el.classList.remove("basemap-terrain");
      el.classList.remove("basemap-vfr");
      el.classList.add("basemap-" + (_mapStyle || "dark"));
    }
  } catch (_) {}
  const specs = basemapSpecsForStyle(_mapStyle);
  const layers = [];
  for (let i = 0; i < specs.length; i++) {
    try {
      const lyr = L.tileLayer(specs[i].url, specs[i].options);
      lyr.addTo(mapInst);
      layers.push(lyr);
    } catch (err) {
      console.warn("basemap addTo", err);
    }
  }
  // Underlay first in list → bring underlay to back, chart stays above it
  for (let i = 0; i < layers.length; i++) {
    try {
      if (typeof layers[i].bringToBack === "function") layers[i].bringToBack();
    } catch (_) {}
  }
  _basemapTileLayers = layers;
  _basemapLayer = layers.length ? layers[layers.length - 1] : null;
  try {
    scrubForeignBasemapTiles(mapInst);
  } catch (_) {}
  // Always resolve OFM when on VFR (even if a stale cycle string is cached)
  if (_mapStyle === "vfr") {
    const hadCycle = !!_ofmCyclePath;
    ensureOfmCycle().then(function (cycle) {
      if (attachGen !== _basemapAttachGen) return;
      if (_mapStyle !== "vfr") return;
      if (!cycle) {
        setStatus(
          "VFR chart tiles unavailable — showing street underlay (OpenFlightMaps coverage is regional)",
          "err"
        );
        return;
      }
      // Re-attach once when cycle first becomes known so OFM layer appears
      if (!hadCycle) {
        try {
          attachBasemap(mapInst);
          setStatus("VFR map · OpenFlightMaps", "ok");
        } catch (err) {
          console.warn("VFR basemap attach", err);
        }
      }
    });
  }
  syncMapStyleChips();
  return _basemapLayer;
}

function setMapStyle(style, opts) {
  const quiet = !!(opts && opts.quiet);
  const next = String(style || "dark").trim().toLowerCase();
  const id = MAP_STYLES.indexOf(next) >= 0 ? next : "dark";
  _mapStyle = id;
  saveMapStylePref(id);
  syncMapStyleChips();
  if (!_mapReady || !map || map._navapronStub) return id;
  try {
    attachBasemap(map);
  } catch (err) {
    console.warn("setMapStyle", err);
  }
  if (!quiet) {
    const labels = {
      dark: "Dark map",
      satellite: "Satellite map",
      terrain: "Terrain map",
      vfr: "VFR chart map",
    };
    setStatus(labels[id] || "Map style updated", "ok");
  }
  return id;
}

window.setMapStyle = setMapStyle;

/** Prefetch bundled CARTO key before first map paint (avoids OSM+filter path). */
let _cartoKeyPromise = null;
function ensureCartoKeyLoaded() {
  if (getCartoApiKey()) return Promise.resolve(_cartoApiKey);
  if (_cartoKeyPromise) return _cartoKeyPromise;
  _cartoKeyPromise = loadBundledCartoKey()
    .catch(function () {})
    .then(function () {
      return _cartoApiKey;
    });
  return _cartoKeyPromise;
}

/** Swap basemap after the user saves/clears a CARTO key (map already open). */
function refreshBasemap() {
  if (!_mapReady || !map || map._navapronStub) return;
  try {
    attachBasemap(map);
  } catch (err) {
    console.warn("refreshBasemap", err);
  }
}

/**
 * Build the real Leaflet map + layers. Safe to call multiple times.
 * @returns {boolean} true if map is usable
 */
/** Promise that resolves when global L (Leaflet) is usable. */
function ensureLeafletLoaded() {
  return new Promise(function (resolve, reject) {
    if (typeof L !== "undefined" && L && typeof L.map === "function") {
      resolve();
      return;
    }
    if (typeof window.__navapronEnsureLeaflet === "function") {
      window.__navapronEnsureLeaflet(function (err) {
        if (err) reject(err);
        else if (typeof L !== "undefined" && L && typeof L.map === "function") resolve();
        else reject(new Error("Leaflet map library failed to load"));
      });
      return;
    }
    reject(
      new Error("Leaflet map library failed to load (expected /lib/leaflet/leaflet.js)")
    );
  });
}

function ensureMapReady() {
  if (_mapReady && map && !map._navapronStub) return true;
  if (_mapCreating) return false;
  if (typeof L === "undefined" || !L || typeof L.map !== "function") {
    // Kick off async load; caller should await ensureLeafletLoaded() for imports
    if (typeof window.__navapronEnsureLeaflet === "function") {
      window.__navapronEnsureLeaflet(function (err) {
        if (err) {
          console.error(err);
          try {
            setStatus("Map library failed to load", "err");
          } catch (_) {}
          return;
        }
        try {
          ensureMapReady();
        } catch (e) {
          console.error(e);
        }
      });
      return false;
    }
    throw new Error(
      "Leaflet map library failed to load (expected /lib/leaflet/leaflet.js)"
    );
  }
  _mapCreating = true;
  try {
    if (typeof L === "undefined" || !L || typeof L.map !== "function") {
      throw new Error(
        "Leaflet map library failed to load (expected /lib/leaflet/leaflet.js)"
      );
    }
    const el = document.getElementById("map");
    if (!el) throw new Error("Map container #map missing from page");

    // Destroy previous Leaflet instance if any (re-entry after soft fail)
    try {
      if (map && typeof map.remove === "function" && !map._navapronStub) {
        map.remove();
      }
    } catch (_) {}
    _penMapBound = false;
    _penDrawing = false;
    _penStroke = null;
    _penPolyline = null;
    // Reset weather / VATSIM handles so a new map gets a fresh layer
    stopWeatherRefresh();
    _weatherTileLayer = null;
    _weatherZoomHooked = false;
    _basemapLayer = null;
    _basemapTileLayers = [];
    _basemapAttachGen += 1;
    _basemapZoomHooked = false;
    try {
      if (_basemapTileObserver) _basemapTileObserver.disconnect();
    } catch (_) {}
    _basemapTileObserver = null;
    _flightTraceRenderer = null;
    _flightTraceOwner = null;
    _liveTracePolyline = null;
    _liveTraceStartMarker = null;
    _liveTraceEndMarker = null;
    _flightTraceIsLive = false;
    _weatherFramePath = null;
    _weatherLoadPromise = null;
    stopVatsimTraffic();
    _vatsimLoadPromise = null;
    _vatsimMapHooks = false;
    stopVatsimAtc();
    _vatsimAtcLoadPromise = null;
    _vatsimAtcMapHooks = false;
    stopIvaoTraffic();
    _ivaoLoadPromise = null;
    _ivaoMapHooks = false;
    stopSimTraffic();
    _simTrafficLoadPromise = null;
    _simTrafficMapHooks = false;

    // preferCanvas: fewer GPU compositing issues in some WebView2 hosts
    // rotate: only after leaflet-rotate is lazy-loaded (hub freezes if loaded at boot)
    const mapOpts = {
      zoomControl: true,
      attributionControl: true,
      preferCanvas: true,
      // Fade/zoom tile animations leave scaled ghost tiles from prior basemaps
      // in WebView2 (Dark selected, VFR chart reappears mid-zoom).
      fadeAnimation: false,
      zoomAnimation: false,
      markerZoomAnimation: false,
    };
    if (
      _leafletRotateLoaded &&
      typeof L.Map.prototype.setBearing === "function"
    ) {
      mapOpts.rotate = true;
      mapOpts.bearing = 0;
      mapOpts.rotateControl = false;
      mapOpts.touchRotate = false;
      mapOpts.shiftKeyRotate = false;
      mapOpts.compassBearing = false;
      mapOpts.trackContainerMutation = false;
    }

    // Phase 1 — empty map shell only (no tiles yet). Sync tile attach on the
    // same turn as L.map() freezes WebView2 on some hosts when leaving hub.
    const realMap = L.map(el, mapOpts).setView([51.47, -0.46], 13);
    _ensureBasemapPane(realMap);
    realMap.on("zoomend", updateGateLabelVisibility);
    realMap.on("zoom", updateGateLabelVisibility);
    try {
      realMap.on("rotate", function () {
        updateCompassUi();
      });
    } catch (_) {}

    map = realMap;
    baseLayers = {
      taxiways: L.layerGroup().addTo(map),
      runways: L.layerGroup().addTo(map),
      aprons: L.layerGroup().addTo(map),
      // Above aprons so terminal/hangar footprints read clearly on dark tiles
      buildings: L.layerGroup().addTo(map),
      parking: L.layerGroup().addTo(map),
      holds: L.layerGroup().addTo(map),
      labels: L.layerGroup().addTo(map),
      weather: L.layerGroup(),
      vatsim: L.layerGroup(),
      vatsimAtc: L.layerGroup(),
      ivao: L.layerGroup(),
      simTraffic: L.layerGroup(),
      route: L.layerGroup().addTo(map),
      taxiIn: L.layerGroup().addTo(map),
      departure: L.layerGroup().addTo(map),
      arrival: L.layerGroup().addTo(map),
      flightPlan: L.layerGroup().addTo(map),
      flightTrace: L.layerGroup().addTo(map),
      activeLeg: L.layerGroup().addTo(map),
      aircraft: L.layerGroup().addTo(map),
      markers: L.layerGroup().addTo(map),
      penPreview: L.layerGroup().addTo(map),
    };
    // Expose for career.js (waitForMapReady was checking window.map and always failing)
    try {
      window.map = map;
      window.baseLayers = baseLayers;
      window._navapronMapReady = true;
    } catch (_) {}
    _mapReady = true;
    _mapInitError = null;
    try {
      _bindMapInteractionTools();
    } catch (bindErr) {
      console.warn("map interaction tools", bindErr);
    }

    // Phase 2 — basemap tiles on a later turn (after hub reflow + key prefetch)
    setTimeout(function () {
      try {
        if (map && !map._navapronStub) attachBasemap(map);
      } catch (tileErr) {
        console.warn("Basemap tiles failed (offline?) — map still usable", tileErr);
      }
      try {
        if (map && !map._navapronStub) map.invalidateSize(true);
      } catch (_) {}
    }, 60);
    setTimeout(function () {
      try {
        if (map && !map._navapronStub) map.invalidateSize(true);
      } catch (_) {}
    }, 320);
    return true;
  } catch (err) {
    _mapInitError = err;
    console.error("Map init failed", err);
    _installMapStubs();
    map._navapronStub = true;
    try {
      setStatus(
        "Map failed to start: " +
          (err && err.message ? err.message : String(err)),
        "err"
      );
    } catch (_) {}
    return false;
  } finally {
    _mapCreating = false;
  }
}

// Mark stubs so ensureMapReady can tell them apart
if (map) map._navapronStub = true;

function updateGateLabelVisibility() {
  try {
    if (!map || map._navapronStub) return;
    const show = map.getZoom() >= GATE_LABEL_MIN_ZOOM;
    map.getContainer().classList.toggle("show-gate-labels", show);
    updateProcedureLabelVisibility();
  } catch (_) {}
}

/** Apply gate/stand visibility from state.showAirportClutter (Gates toolbar button). */
function updateAirportClutterVisibility() {
  try {
    if (!map || map._navapronStub) return;
    const hide = state.showAirportClutter === false;
    map.getContainer().classList.toggle("hide-airport-clutter", hide);
    const btn = $("#btn-map-clutter");
    if (btn) {
      const shown = !hide;
      btn.classList.toggle("active", shown);
      btn.setAttribute("aria-pressed", shown ? "true" : "false");
      btn.title = shown
        ? "Hide gate/stand markers (reduce chart clutter)"
        : "Show gate/stand markers";
      btn.textContent = shown ? "Hide Gates" : "Show Gates";
    }
  } catch (_) {}
}

function setShowAirportClutter(on, { quiet } = {}) {
  state.showAirportClutter = !!on;
  try {
    localStorage.setItem(
      "navapron_airport_clutter",
      state.showAirportClutter ? "1" : "0"
    );
  } catch (_) {}
  updateAirportClutterVisibility();
  if (!quiet) {
    setStatus(
      state.showAirportClutter
        ? "Gate/stand markers shown"
        : "Gate/stand markers hidden",
      "ok"
    );
  }
}

function loadAirportClutterPref() {
  try {
    const v = localStorage.getItem("navapron_airport_clutter");
    if (v === "0") state.showAirportClutter = false;
    else if (v === "1") state.showAirportClutter = true;
  } catch (_) {}
  // Apply later once map exists
  try {
    updateAirportClutterVisibility();
  } catch (_) {}
}

function updateMapLegendVisibility() {
  try {
    const show = state.showMapLegend !== false;
    const legend = $("#map-legend");
    const showTab = $("#btn-map-legend-show");
    const btn = $("#btn-map-legend");
    if (legend) {
      legend.classList.toggle("hidden", !show);
      if (!show) legend.setAttribute("hidden", "");
      else legend.removeAttribute("hidden");
    }
    if (showTab) {
      showTab.classList.toggle("hidden", show);
      if (show) showTab.setAttribute("hidden", "");
      else showTab.removeAttribute("hidden");
    }
    if (btn) {
      btn.classList.toggle("active", show);
      btn.setAttribute("aria-pressed", show ? "true" : "false");
      btn.title = show
        ? "Hide the map colour key / legend"
        : "Show the map colour key / legend";
      btn.textContent = show ? "Hide legend" : "Show legend";
    }
  } catch (_) {}
}

function setShowMapLegend(on, { quiet } = {}) {
  state.showMapLegend = !!on;
  try {
    localStorage.setItem(
      "navapron_map_legend",
      state.showMapLegend ? "1" : "0"
    );
  } catch (_) {}
  updateMapLegendVisibility();
  if (!quiet) {
    setStatus(
      state.showMapLegend ? "Map legend shown" : "Map legend hidden",
      "ok"
    );
  }
}

function updateLiveTraceButton() {
  try {
    const show = state.showLiveTrace !== false;
    const btn = $("#btn-live-trace");
    if (!btn) return;
    btn.classList.toggle("active", show);
    btn.setAttribute("aria-pressed", show ? "true" : "false");
    btn.title = show
      ? "Hide the pink live tracking path (tracking keeps running)"
      : "Show the pink live tracking path";
    btn.textContent = show ? "Hide trace" : "Show trace";
  } catch (_) {}
}

function setShowLiveTrace(on, { quiet } = {}) {
  state.showLiveTrace = !!on;
  try {
    localStorage.setItem(
      "navapron_live_trace",
      state.showLiveTrace ? "1" : "0"
    );
  } catch (_) {}
  updateLiveTraceButton();
  if (!state.showLiveTrace) {
    try {
      clearLiveTrackingTrace();
    } catch (_) {}
  }
  if (!quiet) {
    setStatus(
      state.showLiveTrace
        ? "Live tracking path shown"
        : "Live tracking path hidden",
      "ok"
    );
  }
}

function loadLiveTracePref() {
  try {
    const v = localStorage.getItem("navapron_live_trace");
    if (v === "0") state.showLiveTrace = false;
    else if (v === "1") state.showLiveTrace = true;
  } catch (_) {}
  updateLiveTraceButton();
}

function loadMapLegendPref() {
  try {
    const v = localStorage.getItem("navapron_map_legend");
    if (v === "0") state.showMapLegend = false;
    else if (v === "1") state.showMapLegend = true;
  } catch (_) {}
  try {
    updateMapLegendVisibility();
  } catch (_) {}
}

const MODE_LABELS = {
  launcher: "Home",
  hub: "NavApron",
  simbrief: "SimBrief plan",
  journey: "Full journey",
  taxi: "Taxi only",
  departure: "Departure",
  arrival: "Arrival",
  flightplan: "Flight plan",
};

// ── Hub / modes ──────────────────────────────────────────────────
// Hub is a full-screen overlay (z-index). Keep #app always laid out (not
// display:none) so Leaflet never inits on a zero-size map container.
function _setOverlayVisible(el, visible, zIndex) {
  if (!el) return;
  try {
    if (visible) {
      el.hidden = false;
      el.removeAttribute("aria-hidden");
      el.style.removeProperty("display");
      el.style.setProperty("display", "block", "important");
      el.style.setProperty("visibility", "visible", "important");
      el.style.setProperty("pointer-events", "auto", "important");
      if (zIndex != null) el.style.setProperty("z-index", String(zIndex), "important");
    } else {
      el.hidden = true;
      el.setAttribute("aria-hidden", "true");
      // Must clear/override any prior display:block !important from showHub
      el.style.setProperty("display", "none", "important");
      el.style.setProperty("pointer-events", "none", "important");
    }
  } catch (_) {
    try {
      el.hidden = !visible;
    } catch (_) {}
  }
}

function hideHubOverlay() {
  _setOverlayVisible($("#hub"), false);
}

function hideLauncherOverlay() {
  _setOverlayVisible($("#launcher"), false);
}

function hideSimBriefSetup() {
  _setOverlayVisible($("#sb-setup"), false);
}

function showSimBriefSetup() {
  state.mode = "simbrief";
  try {
    // SimBrief setup is not the home hub; don't let launch rescue re-show home.
    window.__navapronLeftHub = true;
  } catch (_) {}
  hideLauncherOverlay();
  hideHubOverlay();
  _setOverlayVisible($("#sb-setup"), true, 5001);
  document.body.classList.add("hub-open");
  try {
    localStorage.setItem("navapron_mode", "simbrief");
  } catch (_) {}
  // Prefill SimBrief ID from durable prefs / fields already restored at boot
  try {
    const u =
      localStorage.getItem(SB_USER_LS_KEY) ||
      ($("#fp-sb-user")?.value || "").trim();
    if (u && $("#sb-user")) $("#sb-user").value = u;
  } catch (_) {}
  loadRememberedSimBriefUser();
  // Prefer remembered / plan aircraft type over hard-coded B738 default
  const ac =
    ($("#fp-ac")?.value || "").trim() ||
    getRememberedAircraftType() ||
    "B738";
  applyAircraftTypeToFields(ac);
  if ($("#fp-dep")?.value) setSbAirportPick("dep", { icao: $("#fp-dep").value });
  if ($("#fp-dest")?.value) setSbAirportPick("dest", { icao: $("#fp-dest").value });
  _setSbSetupStatus("");
  // Never .focus() here — native focus crashes some Edge WebView2 hosts on open.
}

function showHubHome() {
  const home = $("#hub-view-home");
  const settings = $("#hub-view-settings");
  if (home) home.hidden = false;
  if (settings) settings.hidden = true;
}

function showHubSettings() {
  const home = $("#hub-view-home");
  const settings = $("#hub-view-settings");
  if (home) home.hidden = true;
  if (settings) settings.hidden = false;
  try {
    refreshHubLanStatus();
    refreshHubCommunityPrefs().catch(function () {});
  } catch (_) {}
}

/**
 * Legacy product chooser — retired. Always open the unified home hub so
 * callers (career back button, old localStorage) still land correctly.
 */
function showLauncher() {
  showHub();
}

function showHub() {
  state.mode = "hub";
  _enterModeBusy = false;
  try {
    window.__navapronLeftHub = false;
  } catch (_) {}
  hideSimBriefSetup();
  hideLauncherOverlay();
  try {
    if (typeof window.hideCareerHub === "function") window.hideCareerHub();
  } catch (_) {}
  _setOverlayVisible($("#hub"), true, 5000);
  document.body.classList.add("hub-open");
  if (window.NAVAPRON_PANEL_EMBED) {
    document.body.classList.add("navapron-panel-embed");
    document.documentElement.classList.add("navapron-panel-embed");
  }
  showHubHome();
  try {
    setLoading(false);
  } catch (_) {}
  // Drop stray taxi/runway/SID art under the hub overlay (ghost runway reports)
  try {
    abortAirportLoads();
    clearSurfaceLayers();
    for (const key of [
      "route",
      "taxiIn",
      "departure",
      "arrival",
      "flightPlan",
      "markers",
      "activeLeg",
    ]) {
      baseLayers?.[key]?.clearLayers?.();
    }
  } catch (_) {}
  try {
    localStorage.setItem("navapron_mode", "hub");
  } catch (_) {}
  // Re-sync hub boxes off the paint stack (immediate fetch on boot froze some hosts)
  setTimeout(function () {
    try {
      refreshHubCommunityPrefs().catch(function () {});
    } catch (_) {}
    try {
      refreshHubLanStatus();
      refreshObsOverlayHub();
      scheduleOverlayPublish();
    } catch (_) {}
    try {
      if (typeof window.paintHubCareerStrip === "function") {
        window.paintHubCareerStrip();
      }
    } catch (_) {}
  }, 0);
}

/**
 * Wipe in-session planning (imported OFP, taxi paths, SID/STAR, loaded charts).
 * Keeps user data: logbook, saved plans on disk, SimBrief ID, aircraft type,
 * window prefs, recent airports, MSFS connection.
 *
 * Defensive: never uses window.confirm/alert (crashes some WebView2 hosts),
 * and avoids cascading clear* helpers that re-enter map/active-leg logic mid-wipe.
 */
function clearSessionPlanning({ quiet } = {}) {
  const safe = (fn) => {
    try {
      fn();
    } catch (err) {
      console.warn("clearSessionPlanning step", err);
    }
  };

  try {
    abortAirportLoads();
    // 1) Drop path state first so clearPathTrack / active-leg don't re-snap
    state.pathTracks = {
      route: null,
      taxiIn: null,
      departure: null,
      arrival: null,
      flightPlan: null,
    };
    state.pathSnapshots = {
      route: null,
      taxiIn: null,
      departure: null,
      arrival: null,
    };
    state.manualTaxiPath = { route: false, taxiIn: false };
    state.drawTaxiMode = false;
    state.clickStartMode = false;
    state.clearance = [];
    state.arrClearance = [];
    state.start = null;
    state.end = null;
    state.runwayEndMeta = null;
    state.arrivalStand = null;
    state.depPick = { start: null, runway: null };
    state.arrPick = { stand: null, runway: null };
    state.depSuggestions = [];
    state.arrSuggestions = [];
    state.activeDeparture = null;
    state.activeArrival = null;
    state.flightPlan = null;
    state.metar = null;
    state.runwaySuggestion = null;
    state.simbriefOfpSummary = null;
    state.plannedArrGate = null;
    state._arrStandSource = null;
    state._simWasAirborne = false;
    state._autoArriveBusy = false;
    state._autoArriveDoneKey = null;
    state._journeyStepUserLock = false;
    state._depRunwayFpDone = false;
    state.simbriefProcedures = null;
    state.simbriefMeta = null;
    state.activeLegInfo = null;
    state._legLock = null;
    state._legMisses = 0;
    state.followPlan = false;
    state.clickStartMode = false;
    state.airport = null;
    state.layout = null;
    state.runwayEnds = [];
    state.depChart = null;
    state.destChart = null;
    // Allow Dep/Dest auto-rebuild after a fresh import (not blocked by old pair)
    try {
      _fpAutoBuildKey = "";
    } catch (_) {}
    try {
      if (_fpAutoBuildTimer) {
        clearTimeout(_fpAutoBuildTimer);
        _fpAutoBuildTimer = null;
      }
    } catch (_) {}

    // 2) Map layers (keep live aircraft marker)
    safe(() => {
      if (typeof baseLayers !== "object" || !baseLayers) return;
      for (const key of Object.keys(baseLayers)) {
        if (key === "aircraft") continue;
        try {
          baseLayers[key]?.clearLayers?.();
        } catch (_) {}
      }
      if (state.twyLayerByName && typeof state.twyLayerByName.clear === "function") {
        state.twyLayerByName.clear();
      }
    });

    // 3) Hide panels
    safe(() => {
      for (const id of [
        "#airport-card",
        "#route-summary",
        "#dep-summary",
        "#arr-summary",
        "#arr-taxi-summary",
        "#fp-summary",
      ]) {
        $(id)?.classList?.remove("visible");
      }
      const roleHint = $("#ap-role-hint");
      if (roleHint) {
        roleHint.style.display = "none";
        roleHint.textContent = "";
      }
    });

    // 4) Form fields (keep SimBrief user + aircraft type)
    safe(() => {
      for (const id of [
        "#airport-search",
        "#clearance-text",
        "#arr-taxi-clearance",
        "#fp-dep",
        "#fp-dest",
        "#fp-route",
        "#fp-name",
        "#fp-saved",
        "#dep-atc",
        "#arr-atc",
        "#sb-dep-search",
        "#sb-dest-search",
        "#sb-route",
        "#fp-warnings",
        "#fp-sb-status",
        "#sb-setup-status",
      ]) {
        const el = $(id);
        if (el && "value" in el) el.value = "";
        else if (el) el.textContent = "";
      }
    });

    // 5) Selects / buttons
    safe(() => {
      const startSel = $("#start-select");
      if (startSel) {
        startSel.innerHTML = `<option value="">— Load an airport —</option>`;
        startSel.disabled = true;
      }
      for (const id of [
        "#runway-select",
        "#dep-runway-select",
        "#arr-runway-select",
        "#arr-stand-select",
        "#dep-select",
        "#arr-select",
      ]) {
        const el = $(id);
        if (!el) continue;
        el.innerHTML = `<option value="">— —</option>`;
        el.disabled = true;
      }
      for (const id of [
        "#btn-route",
        "#btn-auto-route",
        "#btn-dep-suggest",
        "#btn-dep-show",
        "#btn-arr-suggest",
        "#btn-arr-show",
        "#btn-arr-taxi-show",
        "#btn-arr-taxi-best",
      ]) {
        const el = $(id);
        if (el) el.disabled = true;
      }
    });

    // 6) Clearance pills / taxiway grid
    safe(() => {
      const row = $("#clearance-row");
      if (row) row.innerHTML = "";
      const arow = $("#arr-clearance-row");
      if (arow) arow.innerHTML = "";
      const grid = $("#twy-grid");
      if (grid) grid.innerHTML = "";
      const agrid = $("#arr-twy-grid");
      if (agrid) agrid.innerHTML = "";
    });

    // 7) OFP bubble (inline — avoid helpers that touch missing nodes)
    safe(() => {
      const bubble = $("#sb-ofp-bubble");
      if (bubble) {
        bubble.classList.add("hidden");
        bubble.setAttribute("hidden", "");
      }
      const tab = $("#btn-sb-ofp-show");
      if (tab) {
        tab.classList.add("hidden");
        tab.setAttribute("hidden", "");
      }
    });

    // 8) HUD / toolbar
    safe(() => {
      const hud = $("#active-leg-hud");
      if (hud) {
        hud.classList.remove("visible");
        hud.textContent = "";
      }
      $("#btn-follow-plan")?.classList?.remove("active");
      $("#btn-click-start")?.classList?.remove("active");
      try {
        if (typeof map !== "undefined" && map && map.getContainer) {
          map.getContainer().style.cursor = "";
        }
      } catch (_) {}
    });

    // 9) SimBrief setup picks (optional chaining — function may exist later)
    safe(() => {
      if (typeof setSbAirportPick === "function") {
        setSbAirportPick("dep", null);
        setSbAirportPick("dest", null);
      }
    });

    safe(() => {
      const hint = $("#map-hint");
      if (hint) {
        hint.innerHTML = "";
        hint.classList.remove("visible");
      }
    });

    if (!quiet) {
      safe(() =>
        setStatus(
          "Session cleared — plans & paths removed (logbook, saved plans & settings kept)",
          "ok"
        )
      );
    }
  } catch (err) {
    console.error("clearSessionPlanning", err);
    try {
      if (!quiet) {
        setStatus("Could not clear session: " + (err && err.message ? err.message : err), "err");
      }
    } catch (_) {}
  }
}

let _enterModeBusy = false;

function enterMode(mode) {
  try {
    if (!mode || mode === "hub") {
      showHub();
      return;
    }
    if (mode === "launcher") {
      showLauncher();
      return;
    }
    if (mode === "career") {
      if (typeof window.showCareerHub === "function") window.showCareerHub();
      return;
    }
    if (mode === "simbrief") {
      showSimBriefSetup();
      return;
    }
    // Prevent double-clicks stacking Leaflet inits (WebView freeze source)
    if (_enterModeBusy) return;
    _enterModeBusy = true;

    state.mode = mode;
    try {
      // Tell desktop hub-rescue not to force Home open after first-click leave
      window.__navapronLeftHub = true;
    } catch (_) {}
    hideSimBriefSetup();
    hideLauncherOverlay();
    hideHubOverlay();
    try {
      if (typeof window.hideCareerHub === "function") window.hideCareerHub();
    } catch (_) {}
    document.body.classList.remove("hub-open");
    try {
      localStorage.setItem("navapron_mode", mode);
    } catch (_) {}

    // Desktop: open planning menu. Phone: map-first (panels as bottom sheets).
    try {
      const mobile =
        typeof window !== "undefined" &&
        window.matchMedia &&
        window.matchMedia("(max-width: 900px)").matches;
      if (mobile) {
        setSidebarCollapsed(true, { persist: false, quiet: true });
        try {
          if (typeof setAirlineCollapsed === "function") {
            setAirlineCollapsed(true, { persist: false, quiet: true });
          } else {
            $("#app")?.classList.add("airline-collapsed");
          }
        } catch (_) {
          $("#app")?.classList.add("airline-collapsed");
        }
      } else {
        setSidebarCollapsed(false, { persist: true, quiet: true });
      }
    } catch (_) {}

    const badge = $("#mode-badge");
    if (badge) badge.textContent = MODE_LABELS[mode] || mode;

    const journeySteps = $("#journey-steps");
    const modeTabs = $("#mode-tabs");
    // Defer tab/journey UI until after first map paint when possible — but
    // set structure now so sidebar isn't empty.
    if (mode === "journey") {
      if (journeySteps) journeySteps.hidden = false;
      if (modeTabs) modeTabs.hidden = true;
    } else {
      if (journeySteps) journeySteps.hidden = true;
      if (modeTabs) modeTabs.hidden = false;
    }

    try {
      setLoading(true, "Starting map…");
      setStatus("Starting map…", "busy");
    } catch (_) {}

    const finishUi = function () {
      try {
        if (mode === "journey") {
          setJourneyStep(state.journeyStep || "taxi-out");
        } else {
          const tabMap = {
            taxi: "taxi",
            departure: "departure",
            arrival: "arrival",
            flightplan: "flightplan",
          };
          switchTab(tabMap[mode] || "taxi");
        }
        if (mode === "flightplan") {
          try {
            refreshSavedPlansList();
          } catch (err) {
            console.warn("refreshSavedPlansList", err);
          }
        }
      } catch (err) {
        console.warn("enterMode finishUi", err);
      }
    };

    // CRITICAL for WebView2: never build Leaflet on the same stack as the
    // hub click. Prefetch CARTO key, wait for hub hide reflow, create an
    // empty map shell, THEN attach tiles / journey UI on later turns.
    const startMap = function () {
      const afterKey = function () {
        try {
          ensureMapReady();
        } catch (err) {
          console.error("ensureMapReady in enterMode", err);
          try {
            setStatus(
              "Map failed to start: " +
                (err && err.message ? err.message : String(err)),
              "err"
            );
          } catch (_) {}
          _enterModeBusy = false;
          try {
            setLoading(false);
          } catch (_) {}
          return;
        }
        // Yield before journey/tab work — finishUi (setJourneyStep) is heavy
        setTimeout(function () {
          try {
            finishUi();
          } catch (err) {
            console.warn("enterMode finishUi", err);
          }
          try {
            setLoading(false);
          } catch (_) {}
          try {
            if (map && !map._navapronStub) map.invalidateSize(true);
          } catch (_) {}
          setTimeout(function () {
            try {
              if (map && !map._navapronStub) map.invalidateSize(true);
            } catch (_) {}
            try {
              setStatus("Mode: " + (MODE_LABELS[mode] || mode), "ok");
            } catch (_) {}
            _enterModeBusy = false;
            scheduleSessionPush();
          }, 280);
        }, 200);
      };
      // Don't block forever if prefs are slow — map still starts
      let keyDone = false;
      const go = function () {
        if (keyDone) return;
        keyDone = true;
        afterKey();
      };
      try {
        ensureCartoKeyLoaded().then(go, go);
      } catch (_) {
        go();
      }
      setTimeout(go, 900);
    };

    // Longer defer when leaving hub — first map paint is the freeze hotspot
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        setTimeout(startMap, 280);
      });
    });
  } catch (err) {
    _enterModeBusy = false;
    console.error("enterMode failed", mode, err);
    try {
      setLoading(false);
    } catch (_) {}
    try {
      setStatus("Could not open mode: " + (err && err.message ? err.message : err), "err");
    } catch (_) {}
  }
}

// ── SimBrief setup screen (airport pickers + generate) ───────────
const _sbPicks = { dep: null, dest: null };
let _sbSearchTimers = { dep: null, dest: null };

function _setSbSetupStatus(text) {
  const el = $("#sb-setup-status");
  if (el) el.textContent = text || "";
}

function setSbAirportPick(which, ap) {
  const icao = (ap?.icao || "").toUpperCase();
  _sbPicks[which] = icao
    ? {
        icao,
        name: ap.name || "",
        city: ap.city || "",
        iata: ap.iata || "",
        country: ap.country || "",
      }
    : null;
  const picked = $(which === "dep" ? "#sb-dep-picked" : "#sb-dest-picked");
  if (picked) {
    if (_sbPicks[which]) {
      const bits = [_sbPicks[which].icao];
      if (_sbPicks[which].iata) bits.push(_sbPicks[which].iata);
      if (_sbPicks[which].name) bits.push(_sbPicks[which].name);
      picked.textContent = bits.join(" · ");
      picked.classList.remove("is-empty");
      rememberRecentAirport(_sbPicks[which]);
    } else {
      picked.textContent =
        which === "dep" ? "No departure selected" : "No arrival selected";
      picked.classList.add("is-empty");
    }
  }
  const search = $(which === "dep" ? "#sb-dep-search" : "#sb-dest-search");
  if (search && icao) search.value = icao;
  // Sync main plan fields early
  if (icao && which === "dep" && $("#fp-dep")) $("#fp-dep").value = icao;
  if (icao && which === "dest" && $("#fp-dest")) $("#fp-dest").value = icao;
}

async function runSbAirportSearch(which, q) {
  const list = $(which === "dep" ? "#sb-dep-results" : "#sb-dest-results");
  if (!list) return;
  const query = (q || "").trim();
  try {
    list.innerHTML = "";
    let items = [];
    let recentCount = 0;
    if (!query) {
      const recent = getRecentAirports();
      recentCount = recent.length;
      const res = await fetch(`/api/airports/search?q=&limit=12`);
      const popular = await res.json().catch(function () {
        return [];
      });
      const seen = new Set(recent.map((a) => a.icao));
      const fill = (Array.isArray(popular) ? popular : []).filter(
        (a) => a && a.icao && !seen.has(String(a.icao).toUpperCase())
      );
      items = recent.length ? recent.concat(fill).slice(0, 12) : fill.slice(0, 12);
    } else {
      const res = await fetch(
        `/api/airports/search?q=${encodeURIComponent(query)}&limit=12`
      );
      items = await res.json();
    }
    if (!items.length) {
      list.classList.remove("open");
      return;
    }
    if (recentCount > 0) {
      const head = document.createElement("li");
      head.className = "results-heading";
      head.textContent = "Recent";
      list.appendChild(head);
    }
    items.forEach(function (ap, idx) {
      if (recentCount > 0 && idx === recentCount) {
        const head = document.createElement("li");
        head.className = "results-heading";
        head.textContent = "Popular";
        list.appendChild(head);
      }
      const li = document.createElement("li");
      const loc = [ap.city, ap.country].filter(Boolean).join(", ");
      li.innerHTML =
        `<span class="code">${escapeHtml(ap.icao)}</span>${escapeHtml(ap.name || "")}` +
        `<span class="meta">${ap.iata ? escapeHtml(ap.iata) + " · " : ""}${escapeHtml(
          loc || ap.type || ""
        )}</span>`;
      li.addEventListener("click", () => {
        setSbAirportPick(which, ap);
        list.classList.remove("open");
        list.innerHTML = "";
      });
      list.appendChild(li);
    });
    list.classList.add("open");
  } catch (err) {
    console.warn("sb airport search", err);
    // Offline: still show recents when empty
    if (!query) {
      const recent = getRecentAirports();
      if (recent.length) {
        list.innerHTML = "";
        const head = document.createElement("li");
        head.className = "results-heading";
        head.textContent = "Recent";
        list.appendChild(head);
        recent.forEach(function (ap) {
          const li = document.createElement("li");
          li.innerHTML =
            `<span class="code">${escapeHtml(ap.icao)}</span>${escapeHtml(ap.name || ap.icao)}`;
          li.addEventListener("click", () => {
            setSbAirportPick(which, ap);
            list.classList.remove("open");
            list.innerHTML = "";
          });
          list.appendChild(li);
        });
        list.classList.add("open");
        return;
      }
    }
    list.classList.remove("open");
  }
}

function wireSbAirportSearch(which) {
  const input = $(which === "dep" ? "#sb-dep-search" : "#sb-dest-search");
  const list = $(which === "dep" ? "#sb-dep-results" : "#sb-dest-results");
  if (!input || !list) return;
  input.addEventListener("input", () => {
    clearTimeout(_sbSearchTimers[which]);
    const q = input.value.trim();
    if (q.length < 1) {
      // Empty field → show recents (not a closed empty list)
      _sbSearchTimers[which] = setTimeout(() => runSbAirportSearch(which, ""), 120);
      return;
    }
    // Typing a 4-letter ICAO can select immediately when search returns
    _sbSearchTimers[which] = setTimeout(() => runSbAirportSearch(which, q), 200);
  });
  input.addEventListener("focus", () => {
    runSbAirportSearch(which, input.value.trim());
  });
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const icao = input.value.trim().toUpperCase();
      if (/^[A-Z0-9]{3,4}$/.test(icao)) {
        setSbAirportPick(which, { icao });
        list.classList.remove("open");
      }
    }
  });
}

document.addEventListener("click", (e) => {
  if (!e.target.closest(".sb-search-field")) {
    $("#sb-dep-results")?.classList.remove("open");
    $("#sb-dest-results")?.classList.remove("open");
  }
});

/**
 * @param {string} step
 * @param {{ skipFit?: boolean }} [opts] — skipFit: true when auto-switching
 *   during live flight (avoids whole-airport zoom jumps on landing / lineup).
 */
function setJourneyStep(step, opts) {
  const skipFit = !!(opts && opts.skipFit);
  const skipSync = !!(opts && opts.skipSync);
  // Bump so in-flight session applies can detect user navigation mid-await
  // (EFB OFP sync used to yank taxi-in back to flightplan while charts loaded).
  state._journeyStepGen = (state._journeyStepGen || 0) + 1;
  // New taxi-out cycle → allow runway→flight-plan auto switch again
  if (step === "taxi-out") state._depRunwayFpDone = false;
  state.journeyStep = step;
  document.querySelectorAll(".journey-step").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.journeyStep === step);
  });
  // Taxi out includes SID on the same panel (same runway — no extra step)
  const tab =
    step === "taxi-out"
      ? "taxi"
      : step === "flightplan"
        ? "flightplan"
        : step === "taxi-in"
          ? "arrival"
          : "taxi";
  switchTab(tab, { skipFit });
  const title = $("#airport-panel-title");
  const searchInputEl = $("#airport-search");
  if (title) {
    if (step === "taxi-in") {
      title.textContent = "Airport (arrival / destination)";
    } else if (step === "flightplan") {
      const depSet = !!(
        ($("#fp-dep")?.value || state.depChart?.airport?.icao || "").trim()
      );
      title.textContent = depSet
        ? "Search destination"
        : "Search departure or destination";
    } else {
      title.textContent = "Airport (departure — taxi & SID)";
    }
  }
  if (searchInputEl) {
    if (step === "flightplan") {
      const depSet = !!(
        ($("#fp-dep")?.value || state.depChart?.airport?.icao || "").trim()
      );
      searchInputEl.placeholder = depSet
        ? "Search destination ICAO, IATA, name…"
        : "Search ICAO, IATA, name, city…";
    } else if (step === "taxi-in") {
      searchInputEl.placeholder = "Search arrival ICAO, IATA, name…";
    } else {
      searchInputEl.placeholder = "Search ICAO, IATA, name, city…";
    }
  }
  // Flight plan: keep search, hide bulky airport card/METAR so FP form can scroll.
  const apPanel = document.querySelector(".panel-airport");
  if (apPanel) {
    apPanel.classList.toggle("is-compact", step === "flightplan");
  }
  try {
    $("#search-results")?.classList.remove("open");
  } catch (_) {}
  // Switch surface selects to the chart for this phase (paths stay on map)
  if (step === "taxi-in" && state.destChart) {
    applyChartAsActive(state.destChart, { fit: false, redrawAll: true });
    if (!skipFit) fitChartBounds(state.destChart);
  } else if (step === "taxi-out" && state.depChart) {
    applyChartAsActive(state.depChart, { fit: false, redrawAll: true });
    if (!skipFit) fitChartBounds(state.depChart);
  } else if (step === "flightplan") {
    redrawSurfaces({ fit: false });
    if (state.flightPlan) drawFlightPlan(state.flightPlan, { fit: false });
  } else if (step === "taxi-in" && state.layout && state.airport) {
    // Single-airport arrival (dest chart not dual-loaded yet)
    if (!skipFit) {
      fitChartBounds({ airport: state.airport, layout: state.layout });
    }
  }
  // Re-paint taxi / SID / STAR after chart swap (switchTab also restores)
  restoreAllPathLayers();
  // Flight plan step: zoom out to the whole journey (enroute + taxi paths)
  // like before path-restore used fit:false everywhere.
  if (step === "flightplan" && !skipFit) {
    setTimeout(function () {
      try {
        fitJourneyOverview();
      } catch (err) {
        console.warn("fitJourneyOverview", err);
      }
    }, 40);
  }
  if (!skipSync) scheduleSessionPush();
}

/** Keep the SID panel under Taxi (journey / taxi) or under Departure mode tab. */
function placeSidPanel(forTab) {
  const panel = $("#panel-sid");
  if (!panel) return;
  const mountTaxi = $("#sid-mount-taxi");
  const mountDep = $("#sid-mount-departure");
  if (forTab === "departure" && mountDep) {
    if (panel.parentElement !== mountDep) mountDep.appendChild(panel);
  } else if (mountTaxi) {
    if (panel.parentElement !== mountTaxi) mountTaxi.appendChild(panel);
  }
}

// ── Layer chips ──────────────────────────────────────────────────
function applyLayerVisibility() {
  const vis = state.layerVisibility;
  // Weather tiles load async; need a real map (not hub stub).
  // TileLayer is added directly to the map (not nested in a LayerGroup) —
  // nesting broke redraw when zooming out.
  if (vis.weather) {
    try {
      ensureMapReady();
    } catch (_) {}
    ensureWeatherOverlay({ quiet: true }).catch(function () {});
  } else {
    stopWeatherRefresh();
    try {
      if (_weatherTileLayer && map && map.hasLayer(_weatherTileLayer)) {
        map.removeLayer(_weatherTileLayer);
      }
    } catch (_) {}
  }
  if (vis.vatsim) {
    ensureVatsimTraffic({ quiet: true }).catch(function () {});
  } else {
    stopVatsimTraffic();
  }
  if (vis.vatsimAtc) {
    ensureVatsimAtc({ quiet: true }).catch(function () {});
  } else {
    stopVatsimAtc();
  }
  if (vis.ivao) {
    ensureIvaoTraffic({ quiet: true }).catch(function () {});
  } else {
    stopIvaoTraffic();
  }
  if (vis.simTraffic) {
    ensureSimTraffic({ quiet: true }).catch(function () {});
  } else {
    stopSimTraffic();
  }
  for (const [key, on] of Object.entries(vis)) {
    if (key === "weather") continue; // handled via _weatherTileLayer above
    const layer = baseLayers && baseLayers[key];
    if (!layer || !map || typeof map.hasLayer !== "function") continue;
    if (on) {
      if (!map.hasLayer(layer)) layer.addTo(map);
    } else if (map.hasLayer(layer)) {
      map.removeLayer(layer);
    }
  }
  document.querySelectorAll(".layer-chip").forEach((chip) => {
    const k = chip.dataset.layer;
    chip.classList.toggle("active", !!vis[k]);
  });
}

function stopWeatherRefresh() {
  if (_weatherRefreshTimer != null) {
    try {
      clearInterval(_weatherRefreshTimer);
    } catch (_) {}
    _weatherRefreshTimer = null;
  }
}

function _latestRainViewerFrame(data) {
  if (!data || !data.radar) return null;
  const host = String(data.host || "https://tilecache.rainviewer.com").replace(
    /\/$/,
    ""
  );
  const past = (data.radar.past || []).slice();
  const nowcast = (data.radar.nowcast || []).slice();
  // Prefer latest past frame; nowcast is forecast and often empty
  const frame = past.length
    ? past[past.length - 1]
    : nowcast.length
      ? nowcast[nowcast.length - 1]
      : null;
  if (!frame || !frame.path) return null;
  return { host: host, path: frame.path, time: frame.time };
}

function _weatherTileUrl(host, path) {
  // Free API: max {z} is 7 — do not request higher (error placeholder images).
  return (
    host +
    path +
    "/" +
    WEATHER_IMAGE_SIZE +
    "/{z}/{x}/{y}/" +
    WEATHER_COLOR +
    "/" +
    WEATHER_OPTIONS +
    ".png"
  );
}

function _weatherFrameKey(path) {
  return (
    String(path || "") +
    "|" +
    WEATHER_LAYER_REV +
    "|" +
    WEATHER_IMAGE_SIZE +
    "|" +
    WEATHER_COLOR +
    "|" +
    WEATHER_OPTIONS
  );
}

/**
 * Build a RainViewer tile layer that never requests z > 7 (hard clamp).
 * maxNativeZoom alone can fail under leaflet-rotate / WebView2; clamping the
 * URL + display max zoom keeps radar visible without blank error tiles.
 */
function _createWeatherTileLayer(urlTemplate) {
  _weatherUrlTemplate = urlTemplate;
  const Layer = L.TileLayer.extend({
    getTileUrl: function (coords) {
      let z = coords.z;
      let x = coords.x;
      let y = coords.y;
      // Belt-and-suspenders: never hit the API above z7
      if (z > WEATHER_MAX_NATIVE_ZOOM) {
        const dz = z - WEATHER_MAX_NATIVE_ZOOM;
        const div = Math.pow(2, dz);
        z = WEATHER_MAX_NATIVE_ZOOM;
        x = Math.floor(x / div);
        y = Math.floor(y / div);
      }
      return L.Util.template(
        this._url,
        L.extend({ s: this._getSubdomain(coords), z: z, x: x, y: y }, this.options)
      );
    },
  });
  return new Layer(urlTemplate, {
    // Default overlay pane — custom weather pane flashed then vanished in WebView2
    opacity: WEATHER_OPACITY,
    tileSize: 256,
    maxZoom: 20,
    maxNativeZoom: WEATHER_MAX_NATIVE_ZOOM,
    minZoom: 0,
    // Do NOT redraw on every zoomend — that cleared good tiles after the zoom flash
    updateWhenZooming: false,
    updateWhenIdle: true,
    keepBuffer: 2,
    className: "weather-radar-tiles",
    attribution:
      '<a href="https://www.rainviewer.com/" target="_blank" rel="noopener">Radar © RainViewer</a>',
  });
}

/** If weather is on but dropped off the map after a zoom, put it back (no redraw). */
function _bindWeatherZoomHook() {
  if (!map || map._navapronStub || _weatherZoomHooked) return;
  _weatherZoomHooked = true;
  map.on("zoomend", function () {
    try {
      if (!state.layerVisibility.weather || !_weatherTileLayer) return;
      if (!map.hasLayer(_weatherTileLayer)) {
        _weatherTileLayer.addTo(map);
      }
    } catch (_) {}
  });
}

async function fetchRainViewerMaps(force) {
  const now = Date.now();
  if (
    !force &&
    _weatherMapsCache &&
    now - _weatherMapsCacheAt < 90 * 1000
  ) {
    return _weatherMapsCache;
  }
  const res = await fetch(WEATHER_MAPS_URL, { cache: "no-store" });
  if (!res.ok) throw new Error("Weather maps HTTP " + res.status);
  const data = await res.json();
  _weatherMapsCache = data;
  _weatherMapsCacheAt = now;
  return data;
}

/**
 * Load or refresh RainViewer precipitation tiles into baseLayers.weather.
 * @param {{ quiet?: boolean, force?: boolean }} opts
 */
async function ensureWeatherOverlay(opts) {
  opts = opts || {};
  const quiet = !!opts.quiet;
  if (!map || map._navapronStub || typeof L === "undefined") {
    return false;
  }
  if (!baseLayers || !baseLayers.weather) return false;
  // Coalesce concurrent loads (toggle + refresh)
  if (_weatherLoadPromise) return _weatherLoadPromise;

  _weatherLoadPromise = (async function () {
    try {
      const data = await fetchRainViewerMaps(!!opts.force);
      const frame = _latestRainViewerFrame(data);
      if (!frame) throw new Error("No radar frame available");

      const url = _weatherTileUrl(frame.host, frame.path);
      const frameKey = _weatherFrameKey(frame.path);
      if (_weatherTileLayer && _weatherFramePath === frameKey) {
        // Same frame — keep existing tiles (do not redraw; that caused blank radar)
        if (!state.layerVisibility.weather) return true;
        if (!map.hasLayer(_weatherTileLayer)) {
          _weatherTileLayer.addTo(map);
        }
        _bindWeatherZoomHook();
        _startWeatherRefresh();
        return true;
      }

      // Swap tile layer without stacking old frames
      try {
        if (_weatherTileLayer && map.hasLayer(_weatherTileLayer)) {
          map.removeLayer(_weatherTileLayer);
        }
      } catch (_) {}
      try {
        if (_weatherTileLayer && _weatherTileLayer.remove) {
          _weatherTileLayer.remove();
        }
      } catch (_) {}

      _weatherTileLayer = _createWeatherTileLayer(url);
      _weatherFramePath = frameKey;

      if (state.layerVisibility.weather) {
        _weatherTileLayer.addTo(map);
      }
      _bindWeatherZoomHook();
      _startWeatherRefresh();
      if (!quiet) {
        try {
          setStatus("Weather radar on (RainViewer)", "ok");
        } catch (_) {}
      }
      return true;
    } catch (err) {
      console.warn("Weather radar failed", err);
      if (!quiet) {
        try {
          setStatus(
            "Weather radar unavailable (need internet)",
            "err"
          );
        } catch (_) {}
      }
      // Revert chip if we never got tiles
      if (!_weatherTileLayer) {
        state.layerVisibility.weather = false;
        document.querySelectorAll('.layer-chip[data-layer="weather"]').forEach(
          function (chip) {
            chip.classList.remove("active");
          }
        );
        stopWeatherRefresh();
      }
      return false;
    } finally {
      _weatherLoadPromise = null;
    }
  })();

  return _weatherLoadPromise;
}

function _startWeatherRefresh() {
  stopWeatherRefresh();
  if (!state.layerVisibility.weather) return;
  _weatherRefreshTimer = setInterval(function () {
    if (!state.layerVisibility.weather) {
      stopWeatherRefresh();
      return;
    }
    ensureWeatherOverlay({ quiet: true, force: true }).catch(function () {});
  }, WEATHER_REFRESH_MS);
}

// ── VATSIM live traffic ──────────────────────────────────────────
const VATSIM_POLL_MS = 20 * 1000; // feed updates ~15s; poll a bit slower
let _vatsimPollTimer = null;
let _vatsimMoveTimer = null;
let _vatsimLoadPromise = null;
let _vatsimMapHooks = false;

function stopVatsimTraffic() {
  if (_vatsimPollTimer != null) {
    try {
      clearInterval(_vatsimPollTimer);
    } catch (_) {}
    _vatsimPollTimer = null;
  }
  if (_vatsimMoveTimer != null) {
    try {
      clearTimeout(_vatsimMoveTimer);
    } catch (_) {}
    _vatsimMoveTimer = null;
  }
  try {
    if (baseLayers && baseLayers.vatsim && baseLayers.vatsim.clearLayers) {
      baseLayers.vatsim.clearLayers();
    }
  } catch (_) {}
  try {
    _trailByKey.vatsim.clear();
  } catch (_) {}
}

function _startVatsimPoll() {
  if (_vatsimPollTimer != null) return;
  if (!state.layerVisibility.vatsim) return;
  _vatsimPollTimer = setInterval(function () {
    if (!state.layerVisibility.vatsim) {
      stopVatsimTraffic();
      return;
    }
    ensureVatsimTraffic({ quiet: true }).catch(function () {});
  }, VATSIM_POLL_MS);
}

function _bindVatsimMapHooks() {
  if (_vatsimMapHooks || !map || map._navapronStub) return;
  _vatsimMapHooks = true;
  const onViewChange = function () {
    if (!state.layerVisibility.vatsim) return;
    if (_vatsimMoveTimer != null) clearTimeout(_vatsimMoveTimer);
    _vatsimMoveTimer = setTimeout(function () {
      ensureVatsimTraffic({ quiet: true }).catch(function () {});
    }, 350);
  };
  try {
    map.on("moveend", onViewChange);
    map.on("zoomend", onViewChange);
  } catch (_) {}
}

function vatsimPilotIcon(pilot, showLabel) {
  const h =
    pilot && pilot.heading != null && isFinite(Number(pilot.heading))
      ? Number(pilot.heading)
      : 0;
  const cs = String((pilot && pilot.callsign) || "").replace(/[<>&]/g, "");
  const label = showLabel
    ? '<div class="vatsim-callsign">' + cs + "</div>"
    : "";
  return L.divIcon({
    className: "vatsim-icon",
    html:
      '<div class="vatsim-wrap">' +
      label +
      '<div class="vatsim-arrow" style="transform:rotate(' +
      h +
      'deg)"></div>' +
      "</div>",
    iconSize: showLabel ? [72, 36] : [18, 18],
    iconAnchor: showLabel ? [36, 28] : [9, 9],
  });
}

function _escapeHtml(s) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/**
 * Fetch VATSIM pilots in the current map bbox and paint markers.
 * @param {{ quiet?: boolean }} opts
 */
async function ensureVatsimTraffic(opts) {
  opts = opts || {};
  const quiet = !!opts.quiet;
  if (!state.layerVisibility.vatsim) {
    stopVatsimTraffic();
    return false;
  }
  if (!map || map._navapronStub || typeof L === "undefined") return false;
  if (!baseLayers || !baseLayers.vatsim) return false;
  if (_vatsimLoadPromise) return _vatsimLoadPromise;

  _vatsimLoadPromise = (async function () {
    try {
      _bindVatsimMapHooks();
      const b = map.getBounds();
      if (!b || typeof b.getWest !== "function") {
        throw new Error("Map bounds unavailable");
      }
      const zoom = typeof map.getZoom === "function" ? map.getZoom() : 10;
      // Cap markers on wide views
      const limit = zoom <= 5 ? 250 : zoom <= 7 ? 450 : 800;
      const params = new URLSearchParams({
        west: String(b.getWest()),
        south: String(b.getSouth()),
        east: String(b.getEast()),
        north: String(b.getNorth()),
        limit: String(limit),
      });
      const res = await fetch("/api/vatsim/pilots?" + params.toString(), {
        cache: "no-store",
      });
      const data = await res.json().catch(function () {
        return null;
      });
      if (!res.ok || !data) {
        throw new Error(
          (data && (data.detail || data.error)) ||
            "VATSIM HTTP " + res.status
        );
      }
      if (data.error && !(data.pilots && data.pilots.length) && !data.total_cached) {
        throw new Error(data.error);
      }

      const pilots = data.pilots || [];
      const showLabel = zoom >= 8;
      baseLayers.vatsim.clearLayers();
      const alive = new Set();
      pilots.forEach(function (p) {
        if (!p || p.lat == null || p.lon == null) return;
        const key = String(p.callsign || "").toUpperCase() || null;
        if (key) alive.add(key);
        const airborne = _isAirborneForTrail({
          gsKt: p.groundspeed_kt,
          altFt: p.altitude_ft,
        });
        const hist = key
          ? _rememberTrafficTrail("vatsim", key, p.lat, p.lon, airborne)
          : [];
        if (airborne) {
          _drawAircraftTrail(
            baseLayers.vatsim,
            p.lat,
            p.lon,
            p.heading,
            "#38bdf8"
          );
        }
        const m = L.marker([p.lat, p.lon], {
          icon: vatsimPilotIcon(p, showLabel),
          zIndexOffset: 600,
          keyboard: false,
        });
        const route =
          (p.departure || "—") + " → " + (p.arrival || "—");
        const alt =
          p.altitude_ft != null ? Math.round(p.altitude_ft) + " ft" : "—";
        const gs =
          p.groundspeed_kt != null
            ? Math.round(p.groundspeed_kt) + " kt"
            : "—";
        const ac = p.aircraft || "—";
        m.bindPopup(
          '<div class="vatsim-popup">' +
            "<strong>" +
            _escapeHtml(p.callsign) +
            "</strong>" +
            '<div class="vatsim-popup-row">' +
            _escapeHtml(route) +
            "</div>" +
            '<div class="vatsim-popup-row">' +
            _escapeHtml(ac) +
            " · " +
            _escapeHtml(alt) +
            " · " +
            _escapeHtml(gs) +
            "</div>" +
            "</div>",
          { closeButton: true, maxWidth: 220 }
        );
        m.addTo(baseLayers.vatsim);
      });
      _pruneTrafficTrails("vatsim", alive);

      if (!map.hasLayer(baseLayers.vatsim)) {
        baseLayers.vatsim.addTo(map);
      }
      _startVatsimPoll();
      if (!quiet) {
        setStatus(
          "VATSIM on — " +
            pilots.length +
            " aircraft in view" +
            (data.total_cached
              ? " (" + data.total_cached + " online)"
              : ""),
          "ok"
        );
      }
      return true;
    } catch (err) {
      console.warn("VATSIM traffic failed", err);
      if (!quiet) {
        setStatus(
          "VATSIM unavailable (need internet): " +
            (err && err.message ? err.message : String(err)),
          "err"
        );
      }
      if (!baseLayers.vatsim.getLayers || !baseLayers.vatsim.getLayers().length) {
        state.layerVisibility.vatsim = false;
        try {
          if (map.hasLayer(baseLayers.vatsim)) {
            map.removeLayer(baseLayers.vatsim);
          }
        } catch (_) {}
        document
          .querySelectorAll('.layer-chip[data-layer="vatsim"]')
          .forEach(function (chip) {
            chip.classList.remove("active");
          });
        stopVatsimTraffic();
      }
      return false;
    } finally {
      _vatsimLoadPromise = null;
    }
  })();

  return _vatsimLoadPromise;
}

// ── VATSIM ATC radar ranges ──────────────────────────────────────
const VATSIM_ATC_POLL_MS = 20 * 1000;
let _vatsimAtcPollTimer = null;
let _vatsimAtcMoveTimer = null;
let _vatsimAtcLoadPromise = null;
let _vatsimAtcMapHooks = false;

const VATSIM_ATC_COLORS = {
  FSS: "#22d3ee",
  DEL: "#a78bfa",
  GND: "#60a5fa",
  TWR: "#4ade80",
  APP: "#fb923c",
  CTR: "#f87171",
};

function stopVatsimAtc() {
  if (_vatsimAtcPollTimer != null) {
    try {
      clearInterval(_vatsimAtcPollTimer);
    } catch (_) {}
    _vatsimAtcPollTimer = null;
  }
  if (_vatsimAtcMoveTimer != null) {
    try {
      clearTimeout(_vatsimAtcMoveTimer);
    } catch (_) {}
    _vatsimAtcMoveTimer = null;
  }
  try {
    if (baseLayers && baseLayers.vatsimAtc && baseLayers.vatsimAtc.clearLayers) {
      baseLayers.vatsimAtc.clearLayers();
    }
  } catch (_) {}
}

function _startVatsimAtcPoll() {
  if (_vatsimAtcPollTimer != null) return;
  if (!state.layerVisibility.vatsimAtc) return;
  _vatsimAtcPollTimer = setInterval(function () {
    if (!state.layerVisibility.vatsimAtc) {
      stopVatsimAtc();
      return;
    }
    ensureVatsimAtc({ quiet: true }).catch(function () {});
  }, VATSIM_ATC_POLL_MS);
}

function _bindVatsimAtcMapHooks() {
  if (_vatsimAtcMapHooks || !map || map._navapronStub) return;
  _vatsimAtcMapHooks = true;
  const onViewChange = function () {
    if (!state.layerVisibility.vatsimAtc) return;
    if (_vatsimAtcMoveTimer != null) clearTimeout(_vatsimAtcMoveTimer);
    _vatsimAtcMoveTimer = setTimeout(function () {
      ensureVatsimAtc({ quiet: true }).catch(function () {});
    }, 350);
  };
  try {
    map.on("moveend", onViewChange);
    map.on("zoomend", onViewChange);
  } catch (_) {}
}

function vatsimAtcIcon(ctrl, showLabel) {
  const short = String((ctrl && ctrl.facility_short) || "ATC").toUpperCase();
  const color = VATSIM_ATC_COLORS[short] || "#94a3b8";
  const cs = String((ctrl && ctrl.callsign) || "").replace(/[<>&]/g, "");
  const label = showLabel
    ? '<div class="vatsimatc-callsign" style="border-color:' +
      color +
      '">' +
      cs +
      "</div>"
    : "";
  return L.divIcon({
    className: "vatsimatc-icon",
    html:
      '<div class="vatsimatc-wrap">' +
      label +
      '<div class="vatsimatc-dot" style="background:' +
      color +
      ";box-shadow:0 0 6px " +
      color +
      '"></div>' +
      '<div class="vatsimatc-badge" style="background:' +
      color +
      '">' +
      short +
      "</div>" +
      "</div>",
    iconSize: showLabel ? [88, 44] : [28, 28],
    iconAnchor: showLabel ? [44, 36] : [14, 14],
  });
}

/**
 * Fetch online VATSIM ATC and paint radar-range circles + callsign markers.
 * @param {{ quiet?: boolean }} opts
 */
async function ensureVatsimAtc(opts) {
  opts = opts || {};
  const quiet = !!opts.quiet;
  if (!state.layerVisibility.vatsimAtc) {
    stopVatsimAtc();
    return false;
  }
  if (!map || map._navapronStub || typeof L === "undefined") return false;
  if (!baseLayers || !baseLayers.vatsimAtc) return false;
  if (_vatsimAtcLoadPromise) return _vatsimAtcLoadPromise;

  _vatsimAtcLoadPromise = (async function () {
    try {
      _bindVatsimAtcMapHooks();
      const b = map.getBounds();
      if (!b || typeof b.getWest !== "function") {
        throw new Error("Map bounds unavailable");
      }
      const zoom = typeof map.getZoom === "function" ? map.getZoom() : 10;
      const limit = zoom <= 5 ? 80 : zoom <= 8 ? 140 : 220;
      const params = new URLSearchParams({
        west: String(b.getWest()),
        south: String(b.getSouth()),
        east: String(b.getEast()),
        north: String(b.getNorth()),
        limit: String(limit),
      });
      const res = await fetch("/api/vatsim/controllers?" + params.toString(), {
        cache: "no-store",
      });
      const data = await res.json().catch(function () {
        return null;
      });
      if (!res.ok || !data) {
        throw new Error(
          (data && data.error) ||
            "VATSIM ATC request failed (" + res.status + ")"
        );
      }
      if (data.error && !(data.controllers && data.controllers.length)) {
        throw new Error(data.error);
      }

      const controllers = Array.isArray(data.controllers)
        ? data.controllers
        : [];
      baseLayers.vatsimAtc.clearLayers();
      const showLabel = zoom >= 7;
      const showRange = zoom >= 5;
      controllers.forEach(function (ctrl) {
        if (!ctrl || ctrl.lat == null || ctrl.lon == null) return;
        const short = String(ctrl.facility_short || "ATC").toUpperCase();
        const color = VATSIM_ATC_COLORS[short] || "#94a3b8";
        const rangeNm =
          ctrl.visual_range_nm != null && isFinite(Number(ctrl.visual_range_nm))
            ? Math.max(1, Number(ctrl.visual_range_nm))
            : 40;
        if (showRange) {
          try {
            L.circle([ctrl.lat, ctrl.lon], {
              radius: rangeNm * 1852,
              color: color,
              weight: 1.5,
              opacity: 0.7,
              fillColor: color,
              fillOpacity: 0.1,
              interactive: false,
              className: "vatsimatc-range",
            }).addTo(baseLayers.vatsimAtc);
          } catch (_) {}
        }
        const m = L.marker([ctrl.lat, ctrl.lon], {
          icon: vatsimAtcIcon(ctrl, showLabel),
          interactive: true,
          keyboard: false,
          zIndexOffset: 200,
        });
        const freq = ctrl.frequency
          ? _escapeHtml(ctrl.frequency) + " MHz"
          : "—";
        const info = ctrl.text_atis
          ? '<div class="vatsimatc-popup-row vatsimatc-popup-info">' +
            _escapeHtml(ctrl.text_atis) +
            "</div>"
          : "";
        m.bindPopup(
          '<div class="vatsimatc-popup"><strong>' +
            _escapeHtml(ctrl.callsign || "ATC") +
            "</strong>" +
            '<div class="vatsimatc-popup-row">' +
            _escapeHtml(ctrl.facility_long || short) +
            " · " +
            freq +
            " · " +
            Math.round(rangeNm) +
            " NM</div>" +
            (ctrl.name
              ? '<div class="vatsimatc-popup-row">' +
                _escapeHtml(ctrl.name) +
                "</div>"
              : "") +
            info +
            "</div>",
          { maxWidth: 280 }
        );
        m.addTo(baseLayers.vatsimAtc);
      });

      if (!map.hasLayer(baseLayers.vatsimAtc)) {
        baseLayers.vatsimAtc.addTo(map);
      }
      _startVatsimAtcPoll();
      if (!quiet) {
        setStatus(
          "VATSIM ATC on — " +
            controllers.length +
            " controller" +
            (controllers.length === 1 ? "" : "s") +
            " in view" +
            (data.truncated ? " (capped)" : ""),
          "ok"
        );
      }
      return true;
    } catch (err) {
      console.warn("VATSIM ATC failed", err);
      if (!quiet) {
        setStatus(
          "VATSIM ATC unavailable: " +
            (err && err.message ? err.message : String(err)),
          "err"
        );
      }
      return false;
    } finally {
      _vatsimAtcLoadPromise = null;
    }
  })();

  return _vatsimAtcLoadPromise;
}

// ── IVAO live traffic ────────────────────────────────────────────
const IVAO_POLL_MS = 20 * 1000;
let _ivaoPollTimer = null;
let _ivaoMoveTimer = null;
let _ivaoLoadPromise = null;
let _ivaoMapHooks = false;

function stopIvaoTraffic() {
  if (_ivaoPollTimer != null) {
    try {
      clearInterval(_ivaoPollTimer);
    } catch (_) {}
    _ivaoPollTimer = null;
  }
  if (_ivaoMoveTimer != null) {
    try {
      clearTimeout(_ivaoMoveTimer);
    } catch (_) {}
    _ivaoMoveTimer = null;
  }
  try {
    if (baseLayers && baseLayers.ivao && baseLayers.ivao.clearLayers) {
      baseLayers.ivao.clearLayers();
    }
  } catch (_) {}
  try {
    _trailByKey.ivao.clear();
  } catch (_) {}
}

function _startIvaoPoll() {
  if (_ivaoPollTimer != null) return;
  if (!state.layerVisibility.ivao) return;
  _ivaoPollTimer = setInterval(function () {
    if (!state.layerVisibility.ivao) {
      stopIvaoTraffic();
      return;
    }
    ensureIvaoTraffic({ quiet: true }).catch(function () {});
  }, IVAO_POLL_MS);
}

function _bindIvaoMapHooks() {
  if (_ivaoMapHooks || !map || map._navapronStub) return;
  _ivaoMapHooks = true;
  const onViewChange = function () {
    if (!state.layerVisibility.ivao) return;
    if (_ivaoMoveTimer != null) clearTimeout(_ivaoMoveTimer);
    _ivaoMoveTimer = setTimeout(function () {
      ensureIvaoTraffic({ quiet: true }).catch(function () {});
    }, 350);
  };
  try {
    map.on("moveend", onViewChange);
    map.on("zoomend", onViewChange);
  } catch (_) {}
}

function ivaoPilotIcon(pilot, showLabel) {
  const h =
    pilot && pilot.heading != null && isFinite(Number(pilot.heading))
      ? Number(pilot.heading)
      : 0;
  const cs = String((pilot && pilot.callsign) || "").replace(/[<>&]/g, "");
  const label = showLabel
    ? '<div class="ivao-callsign">' + cs + "</div>"
    : "";
  return L.divIcon({
    className: "ivao-icon",
    html:
      '<div class="ivao-wrap">' +
      label +
      '<div class="ivao-arrow" style="transform:rotate(' +
      h +
      'deg)"></div>' +
      "</div>",
    iconSize: showLabel ? [72, 36] : [18, 18],
    iconAnchor: showLabel ? [36, 28] : [9, 9],
  });
}

/**
 * Fetch IVAO pilots in the current map bbox and paint markers.
 * @param {{ quiet?: boolean }} opts
 */
async function ensureIvaoTraffic(opts) {
  opts = opts || {};
  const quiet = !!opts.quiet;
  if (!state.layerVisibility.ivao) {
    stopIvaoTraffic();
    return false;
  }
  if (!map || map._navapronStub || typeof L === "undefined") return false;
  if (!baseLayers || !baseLayers.ivao) return false;
  if (_ivaoLoadPromise) return _ivaoLoadPromise;

  _ivaoLoadPromise = (async function () {
    try {
      _bindIvaoMapHooks();
      const b = map.getBounds();
      if (!b || typeof b.getWest !== "function") {
        throw new Error("Map bounds unavailable");
      }
      const zoom = typeof map.getZoom === "function" ? map.getZoom() : 10;
      const limit = zoom <= 5 ? 250 : zoom <= 7 ? 450 : 800;
      const params = new URLSearchParams({
        west: String(b.getWest()),
        south: String(b.getSouth()),
        east: String(b.getEast()),
        north: String(b.getNorth()),
        limit: String(limit),
      });
      const res = await fetch("/api/ivao/pilots?" + params.toString(), {
        cache: "no-store",
      });
      const data = await res.json().catch(function () {
        return null;
      });
      if (!res.ok || !data) {
        throw new Error(
          (data && (data.detail || data.error)) || "IVAO HTTP " + res.status
        );
      }
      if (data.error && !(data.pilots && data.pilots.length) && !data.total_cached) {
        throw new Error(data.error);
      }

      const pilots = data.pilots || [];
      const showLabel = zoom >= 8;
      baseLayers.ivao.clearLayers();
      const alive = new Set();
      pilots.forEach(function (p) {
        if (!p || p.lat == null || p.lon == null) return;
        const key = String(p.callsign || "").toUpperCase() || null;
        if (key) alive.add(key);
        const airborne = _isAirborneForTrail({
          gsKt: p.groundspeed_kt,
          altFt: p.altitude_ft,
        });
        const hist = key
          ? _rememberTrafficTrail("ivao", key, p.lat, p.lon, airborne)
          : [];
        if (airborne) {
          _drawAircraftTrail(
            baseLayers.ivao,
            p.lat,
            p.lon,
            p.heading,
            "#4ade80"
          );
        }
        const m = L.marker([p.lat, p.lon], {
          icon: ivaoPilotIcon(p, showLabel),
          zIndexOffset: 590,
          keyboard: false,
        });
        const route = (p.departure || "—") + " → " + (p.arrival || "—");
        const alt =
          p.altitude_ft != null ? Math.round(p.altitude_ft) + " ft" : "—";
        const gs =
          p.groundspeed_kt != null
            ? Math.round(p.groundspeed_kt) + " kt"
            : "—";
        const ac = p.aircraft || "—";
        m.bindPopup(
          '<div class="ivao-popup">' +
            "<strong>" +
            _escapeHtml(p.callsign) +
            "</strong>" +
            '<div class="ivao-popup-row">IVAO · ' +
            _escapeHtml(route) +
            "</div>" +
            '<div class="ivao-popup-row">' +
            _escapeHtml(ac) +
            " · " +
            _escapeHtml(alt) +
            " · " +
            _escapeHtml(gs) +
            "</div>" +
            "</div>",
          { closeButton: true, maxWidth: 220 }
        );
        m.addTo(baseLayers.ivao);
      });
      _pruneTrafficTrails("ivao", alive);

      if (!map.hasLayer(baseLayers.ivao)) {
        baseLayers.ivao.addTo(map);
      }
      _startIvaoPoll();
      if (!quiet) {
        setStatus(
          "IVAO on — " +
            pilots.length +
            " aircraft in view" +
            (data.total_cached ? " (" + data.total_cached + " online)" : ""),
          "ok"
        );
      }
      return true;
    } catch (err) {
      console.warn("IVAO traffic failed", err);
      if (!quiet) {
        setStatus(
          "IVAO unavailable (need internet): " +
            (err && err.message ? err.message : String(err)),
          "err"
        );
      }
      if (!baseLayers.ivao.getLayers || !baseLayers.ivao.getLayers().length) {
        state.layerVisibility.ivao = false;
        try {
          if (map.hasLayer(baseLayers.ivao)) {
            map.removeLayer(baseLayers.ivao);
          }
        } catch (_) {}
        document
          .querySelectorAll('.layer-chip[data-layer="ivao"]')
          .forEach(function (chip) {
            chip.classList.remove("active");
          });
        stopIvaoTraffic();
      }
      return false;
    } finally {
      _ivaoLoadPromise = null;
    }
  })();

  return _ivaoLoadPromise;
}

// ── MSFS SimConnect AI / injected traffic ─────────────────────────
const SIM_TRAFFIC_POLL_MS = 2500;
let _simTrafficPollTimer = null;
let _simTrafficMoveTimer = null;
let _simTrafficLoadPromise = null;
let _simTrafficMapHooks = false;

function stopSimTraffic() {
  if (_simTrafficPollTimer != null) {
    try {
      clearInterval(_simTrafficPollTimer);
    } catch (_) {}
    _simTrafficPollTimer = null;
  }
  if (_simTrafficMoveTimer != null) {
    try {
      clearTimeout(_simTrafficMoveTimer);
    } catch (_) {}
    _simTrafficMoveTimer = null;
  }
  try {
    if (baseLayers && baseLayers.simTraffic && baseLayers.simTraffic.clearLayers) {
      baseLayers.simTraffic.clearLayers();
    }
  } catch (_) {}
  try {
    _trailByKey.sim.clear();
  } catch (_) {}
}

function _startSimTrafficPoll() {
  if (_simTrafficPollTimer != null) return;
  if (!state.layerVisibility.simTraffic) return;
  _simTrafficPollTimer = setInterval(function () {
    if (!state.layerVisibility.simTraffic) {
      stopSimTraffic();
      return;
    }
    ensureSimTraffic({ quiet: true }).catch(function () {});
  }, SIM_TRAFFIC_POLL_MS);
}

function _bindSimTrafficMapHooks() {
  if (_simTrafficMapHooks || !map || map._navapronStub) return;
  _simTrafficMapHooks = true;
  const onViewChange = function () {
    if (!state.layerVisibility.simTraffic) return;
    if (_simTrafficMoveTimer != null) clearTimeout(_simTrafficMoveTimer);
    _simTrafficMoveTimer = setTimeout(function () {
      ensureSimTraffic({ quiet: true }).catch(function () {});
    }, 350);
  };
  try {
    map.on("moveend", onViewChange);
    map.on("zoomend", onViewChange);
  } catch (_) {}
}

function simTrafficIcon(ac, showLabel) {
  const h =
    ac && ac.heading != null && isFinite(Number(ac.heading))
      ? Number(ac.heading)
      : 0;
  const cs = String((ac && ac.callsign) || "AI").replace(/[<>&]/g, "");
  const label = showLabel
    ? '<div class="simtraffic-callsign">' + cs + "</div>"
    : "";
  return L.divIcon({
    className: "simtraffic-icon",
    html:
      '<div class="simtraffic-wrap">' +
      label +
      '<div class="simtraffic-arrow" style="transform:rotate(' +
      h +
      'deg)"></div>' +
      "</div>",
    iconSize: showLabel ? [72, 36] : [18, 18],
    iconAnchor: showLabel ? [36, 28] : [9, 9],
  });
}

/**
 * Fetch MSFS AI / injected traffic near the player and paint markers.
 * Requires SimConnect connected.
 */
async function ensureSimTraffic(opts) {
  opts = opts || {};
  const quiet = !!opts.quiet;
  if (!state.layerVisibility.simTraffic) {
    stopSimTraffic();
    return false;
  }
  if (!map || map._navapronStub || typeof L === "undefined") return false;
  if (!baseLayers || !baseLayers.simTraffic) return false;
  if (_simTrafficLoadPromise) return _simTrafficLoadPromise;

  _simTrafficLoadPromise = (async function () {
    try {
      _bindSimTrafficMapHooks();
      if (!state.sim.connected) {
        // Try status — user may have connected via pill
        try {
          const st = await fetch("/api/sim/status", { cache: "no-store" }).then(
            function (r) {
              return r.json();
            }
          );
          state.sim.connected = !!st.connected;
          state.sim.enabled = !!st.enabled;
        } catch (_) {}
      }
      if (!state.sim.connected) {
        if (!quiet) {
          setStatus(
            "Sim traffic needs MSFS — click Connect on the toolbar first",
            "err"
          );
        }
        return false;
      }

      const b = map.getBounds();
      if (!b || typeof b.getWest !== "function") {
        throw new Error("Map bounds unavailable");
      }
      const zoom = typeof map.getZoom === "function" ? map.getZoom() : 10;
      const limit = zoom <= 6 ? 80 : zoom <= 9 ? 150 : 250;
      const params = new URLSearchParams({
        west: String(b.getWest()),
        south: String(b.getSouth()),
        east: String(b.getEast()),
        north: String(b.getNorth()),
        limit: String(limit),
      });
      const res = await fetch("/api/sim/traffic?" + params.toString(), {
        cache: "no-store",
      });
      const data = await res.json().catch(function () {
        return null;
      });
      if (!res.ok || !data) {
        throw new Error(
          (data && data.error) || "Sim traffic request failed (" + res.status + ")"
        );
      }
      if (!data.connected) {
        if (!quiet) {
          setStatus("Sim traffic: MSFS not connected", "err");
        }
        return false;
      }

      const aircraft = Array.isArray(data.aircraft) ? data.aircraft : [];
      baseLayers.simTraffic.clearLayers();
      const showLabel = zoom >= 9;
      const alive = new Set();
      aircraft.forEach(function (ac) {
        if (!ac || ac.lat == null || ac.lon == null) return;
        const key =
          ac.id != null
            ? "id:" + String(ac.id)
            : String(ac.callsign || "").toUpperCase() || null;
        if (key) alive.add(key);
        const airborne = _isAirborneForTrail({
          onGround: ac.on_ground,
          gsKt: ac.gs_kt,
          altFt: ac.alt_ft,
        });
        const hist = key
          ? _rememberTrafficTrail("sim", key, ac.lat, ac.lon, airborne)
          : [];
        if (airborne) {
          _drawAircraftTrail(
            baseLayers.simTraffic,
            ac.lat,
            ac.lon,
            ac.heading,
            "#fbbf24"
          );
        }
        const m = L.marker([ac.lat, ac.lon], {
          icon: simTrafficIcon(ac, showLabel),
          interactive: true,
          keyboard: false,
        });
        const alt =
          ac.alt_ft != null && isFinite(Number(ac.alt_ft))
            ? Math.round(Number(ac.alt_ft)) + " ft"
            : "—";
        const gs =
          ac.gs_kt != null && isFinite(Number(ac.gs_kt))
            ? Math.round(Number(ac.gs_kt)) + " kt"
            : "—";
        const gnd = ac.on_ground ? "On ground" : "Airborne";
        const acType =
          ac.type && String(ac.type).trim()
            ? _escapeHtml(String(ac.type).trim())
            : "";
        m.bindPopup(
          '<div class="simtraffic-popup"><strong>' +
            _escapeHtml(ac.callsign || "AI") +
            "</strong>" +
            (acType
              ? '<div class="simtraffic-popup-row">' + acType + "</div>"
              : "") +
            '<div class="simtraffic-popup-row">' +
            gnd +
            " · " +
            alt +
            " · " +
            gs +
            "</div>" +
            '<div class="simtraffic-popup-row">MSFS traffic #' +
            _escapeHtml(ac.id) +
            "</div></div>",
          { maxWidth: 220 }
        );
        m.addTo(baseLayers.simTraffic);
      });
      _pruneTrafficTrails("sim", alive);

      if (!map.hasLayer(baseLayers.simTraffic)) {
        baseLayers.simTraffic.addTo(map);
      }
      _startSimTrafficPoll();
      if (!quiet) {
        setStatus(
          "Sim traffic on — " +
            aircraft.length +
            " AI aircraft nearby" +
            (data.error ? " (" + data.error + ")" : ""),
          "ok"
        );
      }
      return true;
    } catch (err) {
      console.warn("Sim traffic failed", err);
      if (!quiet) {
        setStatus(
          "Sim traffic unavailable: " +
            (err && err.message ? err.message : String(err)),
          "err"
        );
      }
      return false;
    } finally {
      _simTrafficLoadPromise = null;
    }
  })();

  return _simTrafficLoadPromise;
}

function fitAllRoutes() {
  try {
    if (fitJourneyOverview({ quiet: false })) return;
    if (state.layout) drawLayout(state.layout);
    else setStatus("Nothing to fit yet — draw a route first", "err");
  } catch (err) {
    console.warn("fitAllRoutes", err);
    setStatus("Could not fit bounds", "err");
  }
}

/**
 * Zoom to show the full journey: flight plan + taxi/SID/STAR paths, or
 * both airport charts when paths are not drawn yet.
 * @returns {boolean} true if the map was fitted
 */
function fitJourneyOverview(opts) {
  opts = opts || {};
  const quiet = !!opts.quiet;
  try {
    if (!map || typeof map.fitBounds !== "function") return false;
    const layers = [];
    const vis = state.layerVisibility || {};
    const collect = (key) => {
      const g = baseLayers && baseLayers[key];
      if (!g || vis[key] === false) return;
      try {
        const list =
          typeof g.getLayers === "function" ? g.getLayers() : [];
        list.forEach((ly) => layers.push(ly));
      } catch (_) {}
    };
    collect("route");
    collect("flightPlan");
    collect("taxiIn");
    collect("departure");
    collect("arrival");
    collect("activeLeg");
    if (layers.length) {
      const fg = L.featureGroup(layers);
      const b = fg.getBounds();
      if (b && b.isValid && b.isValid()) {
        map.fitBounds(b.pad(0.12));
        return true;
      }
    }
    // Fallback: plan coordinates and/or both airports (unwrap for date line)
    const pts = [];
    const fp = state.flightPlan;
    const coords = fp && (fp.coords || fp._raw?.coords);
    if (Array.isArray(coords)) {
      for (const c of coords) {
        if (Array.isArray(c) && c.length >= 2) pts.push([Number(c[0]), Number(c[1])]);
        else if (c && c.lat != null) pts.push([Number(c.lat), Number(c.lon)]);
      }
    }
    for (const chart of [state.depChart, state.destChart]) {
      const ap = chart && chart.airport;
      if (ap && ap.lat != null && ap.lon != null) {
        pts.push([Number(ap.lat), Number(ap.lon)]);
      }
    }
    const unwrappedPts = unwrapLatLngs(pts);
    if (unwrappedPts.length >= 2) {
      const b = L.latLngBounds(unwrappedPts);
      if (b.isValid()) {
        map.fitBounds(b.pad(0.15), { maxZoom: 10 });
        return true;
      }
    }
    if (pts.length === 1) {
      map.setView(pts[0], 10);
      return true;
    }
    if (!quiet) setStatus("Nothing to fit yet — draw a route first", "err");
    return false;
  } catch (err) {
    console.warn("fitJourneyOverview", err);
    if (!quiet) setStatus("Could not fit bounds", "err");
    return false;
  }
}

// ── Active leg / follow plan ─────────────────────────────────────
/** Metres between two WGS84 points. */
function haversineM(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const toR = Math.PI / 180;
  const dLat = (lat2 - lat1) * toR;
  const dLon = (lon2 - lon1) * toR;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * toR) * Math.cos(lat2 * toR) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
}

/** Distance from point to segment; local equirectangular projection. */
function distPointToSegmentM(lat, lon, lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const toR = Math.PI / 180;
  const midLat = ((lat1 + lat2) / 2) * toR;
  const x = (lon - lon1) * toR * Math.cos(midLat) * R;
  const y = (lat - lat1) * toR * R;
  const dx = (lon2 - lon1) * toR * Math.cos(midLat) * R;
  const dy = (lat2 - lat1) * toR * R;
  const len2 = dx * dx + dy * dy;
  let t = len2 < 1e-6 ? 0 : (x * dx + y * dy) / len2;
  t = Math.max(0, Math.min(1, t));
  const px = t * dx;
  const py = t * dy;
  const dist = Math.hypot(x - px, y - py);
  return {
    dist,
    t,
    alongLat: lat1 + t * (lat2 - lat1),
    alongLon: lon1 + t * (lon2 - lon1),
  };
}

/**
 * Register a drawn path for active-leg snapping.
 * @param {string} key pathTracks key
 * @param {Array} coords [[lat,lon],...] or [{lat,lon}]
 * @param {{ name?: string, labels?: string[], maxSnapM?: number }} opts
 */
function setPathTrack(key, coords, opts = {}) {
  if (!state.pathTracks) state.pathTracks = {};
  if (!coords || coords.length < 2) {
    state.pathTracks[key] = null;
    return;
  }
  const pts = coords.map((c) => {
    if (Array.isArray(c)) return [Number(c[0]), Number(c[1])];
    return [Number(c.lat), Number(c.lon)];
  }).filter((p) => Number.isFinite(p[0]) && Number.isFinite(p[1]));
  if (pts.length < 2) {
    state.pathTracks[key] = null;
    return;
  }
  state.pathTracks[key] = {
    coords: pts,
    labels: opts.labels || null,
    name: opts.name || key,
    maxSnapM: opts.maxSnapM != null ? opts.maxSnapM : defaultSnapM(key),
  };
}

function defaultSnapM(key) {
  if (key === "route" || key === "taxiIn") return 400;
  if (key === "departure" || key === "arrival") return 8000;
  if (key === "flightPlan") return 25000;
  return 2000;
}

function clearPathTrack(key) {
  if (state.pathTracks) state.pathTracks[key] = null;
  // Drop sticky lock if it was on this track
  if (state._legLock && state._legLock.key === key) {
    state._legLock = null;
    state._legMisses = 0;
  }
  if (state.sim.lat != null) updateActiveLeg(state.sim.lat, state.sim.lon);
  else {
    baseLayers.activeLeg?.clearLayers();
    state.activeLegInfo = null;
    updateActiveLegHud(null);
  }
}

/**
 * Along-track distance (m) from a projected point on segment segIdx
 * to path vertex `toIdx` (inclusive of that vertex).
 */
function alongTrackDistM(coords, segIdx, alongLat, alongLon, toIdx) {
  if (!coords || coords.length < 2) return 0;
  if (toIdx <= segIdx) return 0;
  const last = coords.length - 1;
  const endIdx = Math.min(Math.max(0, toIdx), last);
  if (endIdx <= segIdx) return 0;
  // Guard: along point might equal next vertex
  let d = haversineM(
    alongLat,
    alongLon,
    coords[segIdx + 1][0],
    coords[segIdx + 1][1]
  );
  if (!Number.isFinite(d)) d = 0;
  for (let j = segIdx + 1; j < endIdx; j++) {
    const step = haversineM(
      coords[j][0],
      coords[j][1],
      coords[j + 1][0],
      coords[j + 1][1]
    );
    if (Number.isFinite(step)) d += step;
  }
  return d;
}

/**
 * Project (lat,lon) onto a track; return nearest segment info or null.
 * minSeg: don't snap more than a few segments behind progress (avoids reverse jumps).
 */
function projectOntoTrack(tr, lat, lon, key, minSeg) {
  if (!tr?.coords || tr.coords.length < 2) return null;
  let maxSnap = tr.maxSnapM || defaultSnapM(key);
  const onGround = state.sim.onGround !== false;
  if (!onGround && key === "flightPlan") maxSnap = Math.max(maxSnap, 80000);
  // Climb / SID→enroute handoff: 8 km was too tight — past ~FL200 the A/C often
  // sits outside that corridor and the bottom HUD lost "next WP" until cruise.
  if (!onGround && key === "departure") maxSnap = Math.max(maxSnap, 35000);
  if (!onGround && key === "arrival") maxSnap = Math.max(maxSnap, 35000);
  if (!onGround && (key === "route" || key === "taxiIn")) {
    maxSnap = Math.min(maxSnap, 8000);
  }

  let best = null;
  const startI = 0;
  for (let i = startI; i < tr.coords.length - 1; i++) {
    // Soft progress lock: penalise going far backwards on same track
    if (minSeg != null && i < minSeg - 2) continue;
    const a = tr.coords[i];
    const b = tr.coords[i + 1];
    const { dist, alongLat, alongLon, t } = distPointToSegmentM(
      lat,
      lon,
      a[0],
      a[1],
      b[0],
      b[1]
    );
    if (!Number.isFinite(dist) || dist > maxSnap) continue;
    let score = dist;
    if (minSeg != null && i < minSeg) score += (minSeg - i) * 40;
    if (best && score >= best.score) continue;

    const lastIdx = tr.coords.length - 1;
    const remaining = alongTrackDistM(tr.coords, i, alongLat, alongLon, lastIdx);

    let nextIdx = i + 1;
    let nextLabel = null;
    if (tr.labels && tr.labels.length) {
      // Skip labels that are empty or pure placeholders behind progress
      for (let j = i + 1; j < tr.labels.length; j++) {
        const lab = String(tr.labels[j] || "").trim();
        if (!lab) continue;
        // Skip duplicate of previous label when still on same fix
        const prev = String(tr.labels[i] || "").trim();
        if (j === i + 1 && t < 0.15 && prev && lab === prev) continue;
        nextLabel = lab;
        nextIdx = j;
        break;
      }
    }
    if (!nextLabel) nextLabel = "WP" + (i + 2);
    const toNext = alongTrackDistM(
      tr.coords,
      i,
      alongLat,
      alongLon,
      Math.min(nextIdx, lastIdx)
    );

    best = {
      key,
      segIdx: i,
      nextIdx,
      dist,
      remaining,
      toNext,
      nextLabel,
      alongLat,
      alongLon,
      coords: tr.coords,
      name: tr.name,
      score,
      t,
    };
  }
  return best;
}

/**
 * Destination airport for "NM to dest" (great-circle fallback).
 */
function resolveDestinationPoint() {
  const fp = state.flightPlan;
  if (fp?.dest?.lat != null && fp?.dest?.lon != null) {
    return { lat: Number(fp.dest.lat), lon: Number(fp.dest.lon), icao: fp.dest.icao };
  }
  if (state.destChart?.airport?.lat != null) {
    const a = state.destChart.airport;
    return { lat: Number(a.lat), lon: Number(a.lon), icao: a.icao };
  }
  const destIcao = ($("#fp-dest")?.value || "").trim().toUpperCase();
  // No coords without a chart/plan
  if (destIcao && state.airport?.icao === destIcao && state.airport.lat != null) {
    return {
      lat: Number(state.airport.lat),
      lon: Number(state.airport.lon),
      icao: destIcao,
    };
  }
  return null;
}

/** Departure airport coords (FP / dep chart / form). */
function resolveDeparturePoint() {
  const fp = state.flightPlan;
  if (fp?.dep?.lat != null && fp?.dep?.lon != null) {
    return { lat: Number(fp.dep.lat), lon: Number(fp.dep.lon), icao: fp.dep.icao };
  }
  if (state.depChart?.airport?.lat != null) {
    const a = state.depChart.airport;
    return { lat: Number(a.lat), lon: Number(a.lon), icao: a.icao };
  }
  const depIcao = ($("#fp-dep")?.value || "").trim().toUpperCase();
  if (depIcao && state.airport?.icao === depIcao && state.airport.lat != null) {
    return {
      lat: Number(state.airport.lat),
      lon: Number(state.airport.lon),
      icao: depIcao,
    };
  }
  return null;
}

/** Full length of a path track in metres. */
function trackLengthM(tr) {
  const coords = tr?.coords;
  if (!coords || coords.length < 2) return 0;
  let d = 0;
  for (let i = 0; i < coords.length - 1; i++) {
    const step = haversineM(
      coords[i][0],
      coords[i][1],
      coords[i + 1][0],
      coords[i + 1][1]
    );
    if (Number.isFinite(step)) d += step;
  }
  return d;
}

/**
 * Project onto a track; return remaining metres or null.
 * looseSnap: use a very large snap radius (airborne enroute).
 */
function remainingOnTrackM(tr, lat, lon, key, { looseSnap, minSeg } = {}) {
  if (!tr?.coords || tr.coords.length < 2 || lat == null || lon == null) {
    return null;
  }
  const track = looseSnap ? { ...tr, maxSnapM: 200000 } : tr;
  const proj = projectOntoTrack(track, lat, lon, key, minSeg);
  if (proj && Number.isFinite(proj.remaining)) return proj.remaining;
  return null;
}

/**
 * Distance remaining to destination (metres).
 *
 * Airborne journey (when drawn):
 *   SID remaining + flight-plan remaining + STAR remaining
 * so "NM to dest" includes departure and arrival procedures, not only the
 * purple enroute plan.
 */
function remainingToDestinationM(lat, lon, hit) {
  const tracks = state.pathTracks || {};
  const onGround = state.sim.onGround !== false;

  // Taxi phases: remaining along the active taxi path is correct "to rwy/gate"
  if (onGround && hit && (hit.key === "route" || hit.key === "taxiIn")) {
    if (hit.remaining != null && Number.isFinite(hit.remaining)) return hit.remaining;
  }

  const dep = tracks.departure;
  const fp = tracks.flightPlan;
  const arr = tracks.arrival;
  const depLen = trackLengthM(dep);
  const fpLen = trackLengthM(fp);
  const arrLen = trackLengthM(arr);

  const fpMinSeg =
    state._legLock && state._legLock.key === "flightPlan"
      ? state._legLock.segIdx
      : null;
  const depMinSeg =
    state._legLock && state._legLock.key === "departure"
      ? state._legLock.segIdx
      : null;
  const arrMinSeg =
    state._legLock && state._legLock.key === "arrival"
      ? state._legLock.segIdx
      : null;

  // Journey phase from active leg (SID / enroute / STAR)
  let phase =
    hit &&
    (hit.key === "departure" ||
      hit.key === "flightPlan" ||
      hit.key === "arrival")
      ? hit.key
      : null;

  if (!onGround && !phase) {
    // Detect phase when HUD hit is missing/held on a taxi path
    if (
      remainingOnTrackM(arr, lat, lon, "arrival", { minSeg: arrMinSeg }) != null
    ) {
      phase = "arrival";
    } else if (
      remainingOnTrackM(fp, lat, lon, "flightPlan", {
        looseSnap: true,
        minSeg: fpMinSeg,
      }) != null
    ) {
      phase = "flightPlan";
    } else if (
      remainingOnTrackM(dep, lat, lon, "departure", { minSeg: depMinSeg }) !=
      null
    ) {
      phase = "departure";
    }
  }

  // Remaining = current procedure left + all later drawn procedures
  if (
    !onGround ||
    phase === "departure" ||
    phase === "flightPlan" ||
    phase === "arrival"
  ) {
    if (phase === "departure") {
      let total = 0;
      const remDep =
        hit && hit.key === "departure" && Number.isFinite(hit.remaining)
          ? hit.remaining
          : remainingOnTrackM(dep, lat, lon, "departure", {
              minSeg: depMinSeg,
            });
      total += remDep != null ? remDep : depLen;
      total += fpLen;
      total += arrLen;
      if (total > 0) return total;
    }

    if (phase === "flightPlan" || (!phase && fpLen > 0 && !onGround)) {
      let total = 0;
      const remFp =
        hit && hit.key === "flightPlan" && Number.isFinite(hit.remaining)
          ? hit.remaining
          : remainingOnTrackM(fp, lat, lon, "flightPlan", {
              looseSnap: true,
              minSeg: fpMinSeg,
            });
      if (remFp != null) total += remFp;
      else if (!phase && fpLen > 0) total += fpLen;
      total += arrLen;
      if (total > 0) return total;
    }

    if (phase === "arrival") {
      const remArr =
        hit && hit.key === "arrival" && Number.isFinite(hit.remaining)
          ? hit.remaining
          : remainingOnTrackM(arr, lat, lon, "arrival", {
              minSeg: arrMinSeg,
            });
      if (remArr != null) return remArr;
      if (arrLen > 0) return arrLen;
    }

    // Airborne with procedures drawn but phase unknown: full SID + FP + STAR
    if (!onGround && (depLen > 0 || fpLen > 0 || arrLen > 0)) {
      return depLen + fpLen + arrLen;
    }
  }

  // Fallback: great-circle to destination airport
  const dest = resolveDestinationPoint();
  if (dest && lat != null && lon != null) {
    const d = haversineM(lat, lon, dest.lat, dest.lon);
    if (Number.isFinite(d)) return d;
  }

  // Last resort: remaining on whatever path we snapped to
  if (hit && hit.remaining != null && Number.isFinite(hit.remaining)) {
    return hit.remaining;
  }
  return null;
}

function findNearestOnTracks(lat, lon) {
  const tracks = state.pathTracks || {};
  const onGround = state.sim.onGround !== false;
  // Prefer surface when on ground; enroute when airborne
  const priority = onGround
    ? ["route", "taxiIn", "departure", "arrival", "flightPlan"]
    : ["flightPlan", "arrival", "departure", "route", "taxiIn"];

  const lock = state._legLock;
  let best = null;

  // 1) Sticky: re-project onto locked track first (stable next-WP + no flicker)
  if (lock?.key && tracks[lock.key]) {
    const sticky = projectOntoTrack(
      tracks[lock.key],
      lat,
      lon,
      lock.key,
      lock.segIdx
    );
    const stickyMax =
      (tracks[lock.key].maxSnapM || defaultSnapM(lock.key)) *
      (!onGround && lock.key === "departure" ? 1.6 : 1.25);
    // Airborne: drop SID sticky near the end so enroute can take over (FL200 gap)
    const sidHandoff =
      !onGround &&
      lock.key === "departure" &&
      sticky &&
      Number.isFinite(sticky.remaining) &&
      sticky.remaining < 12000;
    if (sticky && sticky.dist < stickyMax && !sidHandoff) {
      sticky.score = sticky.dist; // prefer sticky unless another track is much closer
      best = sticky;
    } else if (sidHandoff) {
      // Clear lock so we don't keep rejecting flight-plan snaps
      state._legLock = null;
    }
  }

  priority.forEach((key, prioIdx) => {
    const tr = tracks[key];
    if (!tr?.coords || tr.coords.length < 2) return;
    const minSeg =
      state._legLock && state._legLock.key === key
        ? state._legLock.segIdx
        : null;
    const cand = projectOntoTrack(tr, lat, lon, key, minSeg);
    if (!cand) return;
    // Strong bias toward flight plan when airborne
    const prioBias = onGround
      ? prioIdx * 25
      : key === "flightPlan"
        ? 0
        : 150 + prioIdx * 100;
    cand.score = cand.dist + prioBias;
    // Only steal sticky lock if much closer or sticky missing
    if (best && state._legLock && best.key === state._legLock.key && key !== best.key) {
      // Airborne enroute may be farther from the purple line than the old SID
      // sticky — still allow the handoff once we're in the climb/cruise band.
      if (!onGround && key === "flightPlan" && cand.dist < 90000) {
        /* allow steal */
      } else if (cand.dist > best.dist * 0.55 && cand.dist > 2500) {
        return;
      }
    }
    if (!best || cand.score < best.score) best = cand;
  });
  return best;
}

function updateActiveLeg(lat, lon) {
  const layer = baseLayers.activeLeg;
  if (!layer) return;
  layer.clearLayers();
  if (lat == null || lon == null) {
    state.activeLegInfo = null;
    updateActiveLegHud(null);
    return;
  }
  let hit = findNearestOnTracks(lat, lon);

  // Hold last good sample when we lose the path (rebuild / SID→enroute gap)
  if (!hit) {
    state._legMisses = (state._legMisses || 0) + 1;
    const airborne = state.sim.onGround === false;
    // Airborne: try a very loose enroute snap before blanking the HUD
    if (airborne && state.pathTracks?.flightPlan) {
      const loose = projectOntoTrack(
        { ...state.pathTracks.flightPlan, maxSnapM: 200000 },
        lat,
        lon,
        "flightPlan",
        null
      );
      if (loose) {
        hit = loose;
        state._legMisses = 0;
      }
    }
  }
  if (!hit) {
    const airborne = state.sim.onGround === false;
    const missLimit = airborne ? 40 : 6;
    if (state.activeLegInfo && state._legMisses < missLimit) {
      // Keep showing previous HUD with refreshed to-dest only
      const prev = { ...state.activeLegInfo, dist: null, held: true };
      prev.toDest = remainingToDestinationM(lat, lon, prev);
      updateActiveLegHud(prev);
      return;
    }
    state.activeLegInfo = null;
    state._legLock = null;
    updateActiveLegHud(null);
    return;
  }
  state._legMisses = 0;

  // Refresh lock (progress only moves forward on same track)
  if (!state._legLock || state._legLock.key !== hit.key) {
    state._legLock = { key: hit.key, segIdx: hit.segIdx };
  } else {
    state._legLock.segIdx = Math.max(state._legLock.segIdx || 0, hit.segIdx);
  }

  // Always attach independent "to dest" (flight-plan based when possible)
  hit.toDest = remainingToDestinationM(lat, lon, hit);
  state.activeLegInfo = hit;

  if (state.layerVisibility.activeLeg !== false) {
    // Current segment + a few ahead (amber highlight)
    const endIdx = Math.min(hit.coords.length - 1, hit.segIdx + 4);
    const highlight = unwrapLatLngs(hit.coords.slice(hit.segIdx, endIdx + 1));
    if (highlight.length >= 2) {
      L.polyline(highlight, {
        color: "#f59e0b",
        weight: 12,
        opacity: 0.4,
        lineCap: "round",
        lineJoin: "round",
        interactive: false,
      }).addTo(layer);
      L.polyline(highlight, {
        color: "#fde68a",
        weight: 6,
        opacity: 1,
        lineCap: "round",
        lineJoin: "round",
        interactive: false,
      }).addTo(layer);
    }
    // Tip of current segment (next vertex)
    const tip = hit.coords[Math.min(hit.segIdx + 1, hit.coords.length - 1)];
    if (tip) {
      L.circleMarker(tip, {
        radius: 7,
        color: "#fef3c7",
        fillColor: "#f59e0b",
        fillOpacity: 1,
        weight: 2,
        interactive: false,
      }).addTo(layer);
    }
  }

  updateActiveLegHud(hit);
  if (state.followPlan && !hit.held) applyFollowPlan(lat, lon, hit);
}

function fmtNm(meters) {
  const nm = Math.max(0, Number(meters) || 0) / 1852;
  if (nm >= 100) return nm.toFixed(0);
  if (nm >= 10) return nm.toFixed(1);
  if (nm >= 1) return nm.toFixed(1);
  return nm.toFixed(2);
}

function updateActiveLegHud(hit) {
  const el = $("#active-leg-hud");
  if (!el) return;
  if (!hit) {
    el.classList.remove("visible");
    el.textContent = "";
    return;
  }
  const phaseNames = {
    route: "Taxi out",
    taxiIn: "Taxi in",
    departure: "SID",
    arrival: "STAR",
    flightPlan: "Enroute",
  };
  const phase = phaseNames[hit.key] || hit.name || "Path";
  // Distance to NEXT waypoint (TOC/TOD/fix)
  const toNextM =
    hit.toNext != null && Number.isFinite(hit.toNext)
      ? hit.toNext
      : hit.remaining;
  const nextNm =
    toNextM != null && Number.isFinite(toNextM) ? fmtNm(toNextM) : null;
  const nextName = hit.nextLabel || "next";

  // Distance to destination — independent of which path we snapped for "next"
  let toDestM =
    hit.toDest != null && Number.isFinite(hit.toDest) ? hit.toDest : null;
  if (toDestM == null && hit.remaining != null && Number.isFinite(hit.remaining)) {
    // Only use path remaining as dest when we're on the flight plan itself
    if (hit.key === "flightPlan") toDestM = hit.remaining;
  }

  let text = phase;
  if (!hit.held && nextNm != null) {
    text += ` · next ${nextName} ${nextNm} NM`;
  } else if (hit.held) {
    text += " · reacquiring…";
  }
  // Always show dest distance when we have a sensible value (enroute / airborne)
  const onGround = state.sim.onGround !== false;
  const showDest =
    toDestM != null &&
    Number.isFinite(toDestM) &&
    toDestM > 500 &&
    (hit.key === "flightPlan" ||
      hit.key === "departure" ||
      hit.key === "arrival" ||
      !onGround ||
      hit.held);
  if (showDest) {
    text += ` · ${fmtNm(toDestM)} NM to dest`;
  } else if (
    toDestM != null &&
    Number.isFinite(toDestM) &&
    (hit.key === "route" || hit.key === "taxiIn") &&
    toDestM > 80
  ) {
    // Taxi: "to dest" means runway / gate along the taxi path
    const label = hit.key === "taxiIn" ? "to stand" : "to rwy";
    text += ` · ${fmtNm(toDestM)} NM ${label}`;
  }
  el.textContent = text;
  el.classList.add("visible");
}

/** Keep aircraft + upcoming path in view; phase-aware max zoom. */
function applyFollowPlan(lat, lon, hit) {
  try {
    state._followPlanTick = (state._followPlanTick || 0) + 1;
    // ~every 1.5s at 750ms poll — smoother, less fight with user pan
    if (state._followPlanTick % 2 !== 0) return;
    if (!map || map._navapronStub || !hit || !hit.coords) return;

    const onGround = state.sim.onGround !== false;
    const panOnly = function () {
      map.panTo([lat, lon], { animate: true, duration: 0.4 });
    };

    // On/near the runway: pan only. fitBounds zooms in/out as remaining
    // runway length in the ahead window changes every tick.
    if (onGround && (hit.key === "taxiIn" || hit.key === "route")) {
      const onRwy = minDistToRunwayCentrelineM(
        lat,
        lon,
        hit.key === "taxiIn"
      );
      if (Number.isFinite(onRwy) && onRwy < 110) {
        panOnly();
        return;
      }
    }

    // Taxi-in: if we left the drawn path (later exit / wrong vacate), pan only.
    // fitBounds against a stale long remainder causes zoom-out then zoom-in
    // when re-route finally catches up (LEMG E8 plan → exit E9).
    if (hit.key === "taxiIn" && onGround) {
      const dPath = minDistToPathTrack("taxiIn", lat, lon);
      const pathStart = state.pathTracks?.taxiIn?.coords?.[0];
      let dStart = Infinity;
      if (pathStart && pathStart.length >= 2) {
        dStart = haversineApproxM(
          lat,
          lon,
          Number(pathStart[0]),
          Number(pathStart[1])
        );
      }
      const stalePath =
        (Number.isFinite(dPath) && dPath > TAXI_IN_OFF_PATH_SOFT_M) ||
        (Number.isFinite(dStart) && dStart > TAXI_IN_PAST_EXIT_M);
      if (stalePath) {
        panOnly();
        return;
      }
    }

    const pts = [[lat, lon]];
    // Taxi-in: fewer segments ahead so remaining runway length doesn't dominate
    const aheadN = hit.key === "taxiIn" ? 2 : 6;
    const ahead = Math.min(hit.coords.length - 1, hit.segIdx + aheadN);
    for (let i = hit.segIdx; i <= ahead; i++) pts.push(hit.coords[i]);
    const b = L.latLngBounds(pts);
    if (!b.isValid()) return;

    const maxZoom =
      hit.key === "route" || hit.key === "taxiIn"
        ? 16
        : hit.key === "flightPlan"
          ? 9
          : 12;
    // Tighter pad on surface so a long runway→gate remainder doesn't zoom out
    const pad = hit.key === "taxiIn" || hit.key === "route" ? 0.22 : 0.4;
    let targetZoom = maxZoom;
    try {
      if (typeof map.getBoundsZoom === "function") {
        targetZoom = Math.min(maxZoom, map.getBoundsZoom(b.pad(pad)));
      }
    } catch (_) {}
    const curZoom = map.getZoom();
    // Hysteresis — skip tiny zoom flips that look like zoom in/out pumping
    if (
      state._followPlanLastZoom != null &&
      Math.abs(targetZoom - state._followPlanLastZoom) < 0.45 &&
      Math.abs(targetZoom - curZoom) < 0.6
    ) {
      panOnly();
      return;
    }
    state._followPlanLastZoom = targetZoom;
    map.fitBounds(b.pad(pad), {
      animate: true,
      duration: 0.55,
      maxZoom,
    });
  } catch (err) {
    console.warn("applyFollowPlan", err);
  }
}

function setFollowPlan(on) {
  state.followPlan = !!on;
  const btn = $("#btn-follow-plan");
  if (btn) btn.classList.toggle("active", state.followPlan);
  if (state.followPlan) {
    // Avoid fighting pure aircraft-follow pan
    if (state.sim.follow) {
      state.sim.follow = false;
      $("#btn-sim-follow")?.classList.remove("active");
    }
    if (state.sim.lat != null && state.activeLegInfo) {
      applyFollowPlan(state.sim.lat, state.sim.lon, state.activeLegInfo);
    } else if (state.sim.lat != null) {
      updateActiveLeg(state.sim.lat, state.sim.lon);
    }
    setStatus("Follow plan on — map tracks the active path with phase zoom", "ok");
  } else {
    setStatus("Follow plan off", "ok");
  }
}

// ── Sidebar tabs ─────────────────────────────────────────────────
document.querySelectorAll(".tab").forEach((btn) => {
  btn.addEventListener("click", () => switchTab(btn.dataset.tab));
});

/**
 * @param {string} name
 * @param {{ skipFit?: boolean }} [opts] — skipFit when auto-switching during
 *   live flight (Flight plan → Taxi-in must not zoom out to the whole airport).
 */
function switchTab(name, opts) {
  const skipFit = !!(opts && opts.skipFit);
  state.activeTab = name;
  document.querySelectorAll(".tab").forEach((t) => {
    const on = t.dataset.tab === name;
    t.classList.toggle("active", on);
    t.setAttribute("aria-selected", on ? "true" : "false");
  });
  document.querySelectorAll(".tab-panel").forEach((p) => {
    const on = p.id === `tab-${name}`;
    p.classList.toggle("active", on);
    if (on) p.removeAttribute("hidden");
    else p.setAttribute("hidden", "");
  });
  // SID panel: under Taxi for journey/taxi; under Departure when that tab is open
  placeSidPanel(name === "departure" ? "departure" : "taxi");
  // Swap which airport is "active" for selects + which chart's taxiways are clickable
  if (state.depChart || state.destChart) {
    try {
      let chart = null;
      if (name === "arrival" && state.destChart) chart = state.destChart;
      else if ((name === "taxi" || name === "departure") && state.depChart)
        chart = state.depChart;
      if (chart) {
        state.airport = chart.airport;
        state.layout = chart.layout;
        state.runwayEnds = chart.runwayEnds || [];
        renderAirportCard({ airport: chart.airport, layout: chart.layout });
        populateSelects({
          airport: chart.airport,
          layout: chart.layout,
          runway_ends: chart.runwayEnds,
        });
        renderTaxiwayButtons(chart.layout.taxiway_names || []);
        restoreSurfacePicks(name === "arrival" ? "arr" : "dep");
      }
      redrawSurfaces({ fit: false });
      if (name === "arrival") {
        renderArrClearance();
        if (!skipFit) {
          // Manual Arrival tab — zoom to destination chart
          if (state.destChart) fitChartBounds(state.destChart);
          else if (chart) fitChartBounds(chart);
        } else if (state.sim.lat != null && state.sim.lon != null && map) {
          // Live landing transition — stay with the aircraft at taxi zoom
          try {
            state._followPlanLastZoom = null;
            const z = map.getZoom();
            if (z < 14.5) {
              map.setView([state.sim.lat, state.sim.lon], 15.5, {
                animate: true,
              });
            } else {
              map.panTo([state.sim.lat, state.sim.lon], {
                animate: true,
                duration: 0.35,
              });
            }
          } catch (_) {
            /* ignore */
          }
        }
      }
    } catch (err) {
      console.warn("switchTab chart swap", err);
    }
  } else if (name === "arrival" && state.layout && state.airport && !skipFit) {
    fitChartBounds({ airport: state.airport, layout: state.layout });
  }
  // Keep previously drawn taxi / SID / STAR / plan on the map across tabs
  restoreAllPathLayers();
  if (name === "flightplan") refreshSavedPlansList();
}

// Hub cards + home
document.querySelectorAll(".hub-card[data-mode]").forEach((card) => {
  card.addEventListener("click", function () {
    try {
      enterMode(card.dataset.mode);
    } catch (err) {
      console.error("hub card enterMode", err);
      try {
        setStatus(
          "Could not open that mode: " +
            (err && err.message ? err.message : String(err)),
          "err"
        );
      } catch (_) {}
    }
  });
});
$("#btn-home")?.addEventListener("click", () => showHub());
$("#btn-launch-navapron")?.addEventListener("click", function (e) {
  try {
    if (e && e.preventDefault) e.preventDefault();
    showHub();
  } catch (err) {
    console.error("launch-navapron", err);
  }
});
$("#btn-hub-back-launcher")?.addEventListener("click", function (e) {
  try {
    if (e && e.preventDefault) e.preventDefault();
    showHub();
  } catch (err) {
    console.error("hub-back-launcher", err);
  }
});
$("#btn-hub-settings")?.addEventListener("click", function (e) {
  try {
    if (e && e.preventDefault) e.preventDefault();
    showHubSettings();
  } catch (err) {
    console.error("hub-settings", err);
  }
});
$("#btn-hub-lan-hint-settings")?.addEventListener("click", function (e) {
  try {
    if (e && e.preventDefault) e.preventDefault();
    showHubSettings();
  } catch (err) {
    console.error("hub-lan-hint-settings", err);
  }
});
$("#btn-hub-settings-back")?.addEventListener("click", function (e) {
  try {
    if (e && e.preventDefault) e.preventDefault();
    showHubHome();
  } catch (err) {
    console.error("hub-settings-back", err);
  }
});
$("#btn-whats-new-hub")?.addEventListener("click", function (e) {
  try {
    if (e && e.preventDefault) e.preventDefault();
    openWhatsNew();
  } catch (err) {
    console.error("whats-new-hub", err);
  }
});
// Two-step confirm in-page (never window.confirm — crashes some WebView2 hosts)
let _clearSessionArmUntil = 0;
$("#btn-clear-session-hub")?.addEventListener("click", function (e) {
  try {
    if (e && e.preventDefault) e.preventDefault();
    if (e && e.stopPropagation) e.stopPropagation();
    const btn = $("#btn-clear-session-hub");
    const now = Date.now();
    if (now > _clearSessionArmUntil) {
      // First click: arm
      _clearSessionArmUntil = now + 4000;
      if (btn) {
        btn.dataset.prevLabel = btn.textContent || "Clear session";
        btn.textContent = "Click again to confirm";
        btn.classList.add("btn-clear-session-armed");
      }
      try {
        setStatus(
          "Click Clear session again to wipe plans/paths (settings & logbook kept)",
          "busy"
        );
      } catch (_) {}
      setTimeout(function () {
        if (Date.now() >= _clearSessionArmUntil - 50) {
          if (btn) {
            btn.textContent = btn.dataset.prevLabel || "Clear session";
            btn.classList.remove("btn-clear-session-armed");
          }
        }
      }, 4100);
      return;
    }
    // Second click within arm window
    _clearSessionArmUntil = 0;
    if (btn) {
      btn.textContent = btn.dataset.prevLabel || "Clear session";
      btn.classList.remove("btn-clear-session-armed");
    }
    // Defer off the click stack — safer for WebView2
    setTimeout(function () {
      try {
        clearSessionPlanning();
      } catch (err) {
        console.error("clearSessionPlanning", err);
        try {
          setStatus("Clear session failed — try again", "err");
        } catch (_) {}
      }
    }, 0);
  } catch (err) {
    console.error("clear-session-hub", err);
  }
});

// ── Hub: LAN / phone access ──────────────────────────────────────
function normalizeLanHttpUrl(u) {
  // Always force plain http — phones often default to https and fail SSL
  let s = String(u || "").trim();
  if (!s) return "";
  s = s.replace(/^https:\/\//i, "http://");
  if (!/^https?:\/\//i.test(s)) s = "http://" + s.replace(/^\/+/, "");
  return s;
}

function copyLanUrl(url, btn) {
  const text = normalizeLanHttpUrl(url);
  if (!text) return;
  const done = function () {
    if (btn) {
      const prev = btn.textContent;
      btn.textContent = "Copied";
      btn.classList.add("is-done");
      setTimeout(function () {
        btn.textContent = prev || "Copy";
        btn.classList.remove("is-done");
      }, 1600);
    }
    try {
      setStatus(
        "Copied " +
          text +
          " — paste in the phone browser. Must start with http:// (not https://)",
        "ok"
      );
    } catch (_) {}
  };
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done).catch(function () {
        // Fallback
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.setAttribute("readonly", "");
        ta.style.position = "fixed";
        ta.style.left = "-9999px";
        document.body.appendChild(ta);
        ta.select();
        try {
          document.execCommand("copy");
        } catch (_) {}
        document.body.removeChild(ta);
        done();
      });
      return;
    }
  } catch (_) {}
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    document.body.removeChild(ta);
  } catch (_) {}
  done();
}

function paintHubLanStatus(st) {
  try {
    const cb = $("#hub-lan-enabled");
    const urlsBox = $("#hub-lan-urls");
    const list = $("#hub-lan-url-list");
    const statusEl = $("#hub-lan-status");
    if (cb) cb.checked = !!(st && st.enabled);
    if (list) list.innerHTML = "";
    const urls = ((st && st.urls) || [])
      .map(normalizeLanHttpUrl)
      .filter(Boolean);
    const showUrls = !!(st && st.listening_on_lan && urls.length);
    if (urlsBox) urlsBox.classList.toggle("hidden", !showUrls);
    if (list && showUrls) {
      urls.forEach(function (u) {
        const li = document.createElement("li");
        const span = document.createElement("span");
        span.className = "hub-lan-url-text";
        span.textContent = u;
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "hub-lan-copy";
        btn.textContent = "Copy";
        btn.title = "Copy http:// address for your phone";
        btn.addEventListener("click", function (ev) {
          if (ev && ev.preventDefault) ev.preventDefault();
          copyLanUrl(u, btn);
        });
        li.appendChild(span);
        li.appendChild(btn);
        list.appendChild(li);
      });
    }
    if (statusEl) {
      statusEl.classList.remove("is-warn", "is-ok");
      if (!st) {
        statusEl.textContent = "";
        return;
      }
      if (st.restart_required) {
        statusEl.classList.add("is-warn");
        statusEl.textContent =
          st.message ||
          "Restart NavApron fully for this network setting to take effect.";
      } else if (st.enabled && st.listening_on_lan) {
        statusEl.classList.add("is-ok");
        statusEl.textContent =
          st.message ||
          "LAN active — copy an http:// link below (not https). Private Wi‑Fi only.";
      } else if (!st.enabled) {
        statusEl.textContent =
          st.message || "LAN off — only this PC can open NavApron.";
      } else {
        statusEl.classList.add("is-warn");
        statusEl.textContent =
          st.message || "Restart NavApron to finish applying LAN access.";
      }
    }
  } catch (err) {
    console.warn("paintHubLanStatus", err);
  }
}
function obsOverlayUrl() {
  try {
    const port = window.location.port || "8765";
    const host = window.location.hostname || "127.0.0.1";
    const proto = window.location.protocol || "http:";
    return proto + "//" + host + (port ? ":" + port : "") + "/overlay";
  } catch (_) {
    return "http://127.0.0.1:8765/overlay";
  }
}

function refreshObsOverlayHub() {
  try {
    const url = obsOverlayUrl();
    const el = $("#hub-obs-url");
    if (el) el.textContent = url;
    const open = $("#btn-obs-open");
    if (open) open.href = url;
  } catch (_) {}
}

$("#btn-obs-copy")?.addEventListener("click", function (e) {
  try {
    if (e && e.preventDefault) e.preventDefault();
    const btn = $("#btn-obs-copy");
    copyLanUrl(obsOverlayUrl(), btn);
    const st = $("#hub-obs-status");
    if (st) {
      st.textContent = "Copied — paste as OBS Browser Source URL (1920×200 suggested)";
    }
  } catch (_) {}
});

async function refreshHubLanStatus() {
  try {
    const res = await fetch("/api/lan", { cache: "no-store" });
    const st = await res.json().catch(function () {
      return null;
    });
    if (st && st.ok !== false) paintHubLanStatus(st);
  } catch (err) {
    console.warn("refreshHubLanStatus", err);
  }
}

async function setHubLanEnabled(on) {
  try {
    const res = await fetch("/api/lan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ enabled: !!on }),
    });
    const st = await res.json().catch(function () {
      return null;
    });
    if (!res.ok || !st) {
      throw new Error((st && st.detail) || "Could not save LAN setting");
    }
    paintHubLanStatus(st);
    if (st.restart_required) {
      setStatus(
        on
          ? "LAN access saved — fully quit and restart NavApron, then open the phone URL on home Wi‑Fi"
          : "LAN off saved — fully quit and restart NavApron to stop network access",
        "busy"
      );
    } else {
      setStatus(
        on
          ? "LAN / phone access on — private network only"
          : "LAN / phone access off",
        "ok"
      );
    }
  } catch (err) {
    console.error("setHubLanEnabled", err);
    setStatus(err.message || "LAN setting failed", "err");
    // Re-sync checkbox from server
    refreshHubLanStatus();
  }
}

$("#hub-lan-enabled")?.addEventListener("change", function (e) {
  const on = !!(e && e.target && e.target.checked);
  // If enabling, checkbox stays on; server may still require restart
  setHubLanEnabled(on);
});
// Load current LAN state shortly after hub paints
setTimeout(function () {
  refreshHubLanStatus();
}, 400);

// ── Hub: anonymous community stats opt-in (hidden while server flag off) ──
let _communityPrefsBusy = false;

function _communityDetailMessage(st, fallback) {
  try {
    if (!st) return fallback;
    const d = st.detail;
    if (typeof d === "string" && d) return d;
    if (Array.isArray(d) && d.length) {
      const first = d[0];
      if (typeof first === "string") return first;
      if (first && first.msg) return String(first.msg);
    }
    if (st.error) return String(st.error);
  } catch (_) {}
  return fallback;
}

async function refreshHubCommunityPrefs() {
  // Optimistic: show the hub box unless the server explicitly disables it.
  // (A failed/early fetch used to leave the panel stuck hidden.)
  let featureOn = true;
  try {
    const statusRes = await fetch("/api/community/status", { cache: "no-store" });
    const status = await statusRes.json().catch(function () {
      return null;
    });
    if (status && status.enabled === false) featureOn = false;
    const hubPanel = $("#hub-community-panel");
    const alWrap = $("#al-community-wrap");
    if (hubPanel) {
      hubPanel.classList.toggle("hidden", !featureOn);
      if (featureOn) hubPanel.removeAttribute("hidden");
      else hubPanel.setAttribute("hidden", "");
    }
    if (alWrap) {
      alWrap.classList.toggle("hidden", !featureOn);
      if (featureOn) alWrap.removeAttribute("hidden");
      else alWrap.setAttribute("hidden", "");
    }
    if (!featureOn) return;

    const res = await fetch("/api/user/prefs", { cache: "no-store" });
    const st = await res.json().catch(function () {
      return null;
    });
    const cb = $("#hub-community-stats");
    const alCb = $("#al-community-stats");
    const on = !!(st && st.share_community_stats);
    // Avoid firing change handlers while syncing UI from server
    if (cb) {
      cb.checked = on;
    }
    if (alCb) {
      alCb.checked = on;
    }
    const statusEl = $("#hub-community-status");
    if (statusEl) {
      statusEl.textContent = on
        ? "Sharing on — completed flights add to anonymous community totals."
        : "Sharing off — flights stay on this PC only.";
    }
  } catch (err) {
    console.warn("refreshHubCommunityPrefs", err);
    // Keep the hub panel visible even if prefs sync failed
    try {
      const hubPanel = $("#hub-community-panel");
      if (hubPanel) {
        hubPanel.classList.remove("hidden");
        hubPanel.removeAttribute("hidden");
      }
    } catch (_) {}
  }
}

async function setShareCommunityStats(on) {
  if (_communityPrefsBusy) return;
  _communityPrefsBusy = true;
  const cb = $("#hub-community-stats");
  const alCb = $("#al-community-stats");
  try {
    if (cb) cb.disabled = true;
    if (alCb) alCb.disabled = true;
    const res = await fetch("/api/user/prefs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ share_community_stats: !!on }),
    });
    const st = await res.json().catch(function () {
      return null;
    });
    if (!res.ok) {
      throw new Error(_communityDetailMessage(st, "Could not save"));
    }
    const enabled = !!(st && st.share_community_stats);
    if (cb) cb.checked = enabled;
    if (alCb) alCb.checked = enabled;
    const statusEl = $("#hub-community-status");
    if (statusEl) {
      statusEl.textContent = enabled
        ? "Sharing on — completed flights add to anonymous community totals."
        : "Sharing off — flights stay on this PC only.";
    }
    try {
      setStatus(
        enabled
          ? "Anonymous community stats sharing enabled"
          : "Community stats sharing disabled",
        "ok"
      );
    } catch (_) {}
  } catch (err) {
    console.error("setShareCommunityStats", err);
    try {
      setStatus(
        (err && err.message) || "Could not save sharing preference",
        "err"
      );
    } catch (_) {}
    try {
      await refreshHubCommunityPrefs();
    } catch (_) {}
  } finally {
    if (cb) cb.disabled = false;
    if (alCb) alCb.disabled = false;
    _communityPrefsBusy = false;
  }
}

$("#hub-community-stats")?.addEventListener("change", function (e) {
  try {
    setShareCommunityStats(!!(e && e.target && e.target.checked));
  } catch (err) {
    console.error("hub-community-stats change", err);
  }
});
$("#al-community-stats")?.addEventListener("change", function (e) {
  try {
    setShareCommunityStats(!!(e && e.target && e.target.checked));
  } catch (err) {
    console.error("al-community-stats change", err);
  }
});
function _efbCommunityPathFromUi() {
  const el = $("#efb-community-path");
  return el ? String(el.value || "").trim() : "";
}

function _syncEfbCommunityPathInput(st) {
  const el = $("#efb-community-path");
  if (!el) return;
  // Don't clobber while the user is typing
  if (document.activeElement === el) return;
  const custom = (st && st.custom_community_path) || "";
  if (custom) {
    el.value = custom;
    return;
  }
  const dirs = (st && st.community_dirs) || [];
  const first = dirs[0] && dirs[0].path ? dirs[0].path : "";
  // Show detected path as a hint in the field only when empty
  if (!el.value && first) el.placeholder = first;
}

function _syncEfbOrientationSelect(prefs) {
  const sel = $("#efb-orientation");
  if (!sel) return;
  if (document.activeElement === sel) return;
  const v =
    prefs && prefs.efb_orientation
      ? String(prefs.efb_orientation).toLowerCase()
      : "auto";
  sel.value = v === "portrait" || v === "landscape" ? v : "auto";
}

function _syncCareerCurrencySelect(prefs) {
  const sel = $("#career-currency");
  if (!sel) return;
  if (document.activeElement === sel) return;
  const v =
    prefs && prefs.career_currency
      ? String(prefs.career_currency).toUpperCase()
      : "USD";
  const allowed = ["USD", "EUR", "GBP", "CAD", "AUD"];
  sel.value = allowed.indexOf(v) >= 0 ? v : "USD";
  try {
    window.__navapronCareerCurrency = {
      code: sel.value,
      symbol: (prefs && prefs.career_currency_symbol) || "$",
      rate: Number((prefs && prefs.career_currency_rate) || 1) || 1,
    };
  } catch (_) {}
}

async function setHubCareerCurrency(code) {
  const cleaned = String(code || "USD").toUpperCase();
  try {
    const res = await fetch("/api/user/prefs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ career_currency: cleaned }),
    });
    const st = await res.json().catch(function () {
      return null;
    });
    if (!res.ok) throw new Error("Could not save currency");
    _syncCareerCurrencySelect(st);
    const status = $("#hub-career-currency-status");
    if (status) {
      status.textContent =
        "Career currency: " +
        ((st && st.career_currency) || cleaned) +
        " — display only; progress stays saved on this PC.";
    }
    setStatus("Career currency updated", "ok");
  } catch (err) {
    console.error("setHubCareerCurrency", err);
    setStatus(err && err.message ? err.message : String(err), "err");
  }
}

async function setHubEfbOrientation(mode) {
  const cleaned =
    mode === "portrait" || mode === "landscape" || mode === "auto"
      ? mode
      : "auto";
  try {
    const res = await fetch("/api/user/prefs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ efb_orientation: cleaned }),
    });
    const st = await res.json().catch(function () {
      return null;
    });
    if (!res.ok) throw new Error("Could not save EFB layout");
    _syncEfbOrientationSelect(st);
    setStatus(
      "EFB layout: " +
        (cleaned === "auto"
          ? "Auto"
          : cleaned === "landscape"
            ? "Landscape"
            : "Portrait") +
        " (reopen the EFB app in MSFS to apply)",
      "ok"
    );
  } catch (err) {
    console.error("setHubEfbOrientation", err);
    setStatus(err && err.message ? err.message : String(err), "err");
  }
}

async function refreshHubEfbStatus() {
  const statusEl = $("#hub-efb-status");
  const btnInstall = $("#btn-efb-install");
  const btnRemove = $("#btn-efb-uninstall");
  try {
    const res = await fetch("/api/efb", { cache: "no-store" });
    const st = await res.json().catch(function () {
      return null;
    });
    if (!st || !res.ok) {
      if (statusEl) statusEl.textContent = "Could not check EFB plugin status.";
      return;
    }
    _syncEfbCommunityPathInput(st);
    try {
      const prefRes = await fetch("/api/user/prefs", { cache: "no-store" });
      const prefs = await prefRes.json().catch(function () {
        return null;
      });
      if (prefs) {
        _syncEfbOrientationSelect(prefs);
        _syncCareerCurrencySelect(prefs);
      }
    } catch (_) {}
    const dirs = st.community_dirs || [];
    const paths = dirs.map(function (d) {
      return (d.kind || "Community") + ": " + d.path;
    });
    if (statusEl) {
      if (!st.source_available) {
        statusEl.textContent =
          "In-sim packages (msfs-community) are missing from this NavApron build. " +
          "Use a newer portable/Store build, or run from the project folder with msfs-community present.";
        statusEl.classList.add("is-warn");
        statusEl.classList.remove("is-ok");
      } else if (st.installed) {
        const efbOn = !!(st.efb && st.efb.installed);
        const panelOn = !!(st.panel && st.panel.installed);
        const bits = [];
        if (efbOn) bits.push("EFB");
        if (panelOn) bits.push("panel");
        statusEl.textContent =
          (bits.length ? bits.join(" + ") : "Packages") +
          " installed. Restart NavApron + MSFS → EFB Apps → NavApron. " +
          (paths[0] || "");
        statusEl.classList.add("is-ok");
        statusEl.classList.remove("is-warn");
      } else if (dirs.length) {
        statusEl.textContent =
          "Ready to install EFB + panel into: " + (paths[0] || "Community folder");
        statusEl.classList.remove("is-ok", "is-warn");
      } else {
        statusEl.textContent =
          "No MSFS 2024 Community folder found. Use Browse… / paste the path below (usually …\\Packages\\Community), then Save and Install.";
        statusEl.classList.add("is-warn");
        statusEl.classList.remove("is-ok");
      }
    }
    if (btnInstall) btnInstall.disabled = !st.source_available;
    if (btnRemove) btnRemove.disabled = !st.installed;
  } catch (err) {
    console.warn("refreshHubEfbStatus", err);
    if (statusEl) statusEl.textContent = "Could not check EFB plugin status.";
  }
}

async function saveHubEfbCommunityPath(pathOverride) {
  const statusEl = $("#hub-efb-status");
  const path =
    pathOverride != null ? String(pathOverride).trim() : _efbCommunityPathFromUi();
  try {
    if (statusEl) {
      statusEl.textContent = path
        ? "Saving Community folder…"
        : "Clearing manual Community folder…";
      statusEl.classList.remove("is-ok", "is-warn");
    }
    const res = await fetch("/api/efb/community-path", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ path: path || "" }),
    });
    const st = await res.json().catch(function () {
      return null;
    });
    if (!res.ok || !st || st.ok === false) {
      throw new Error((st && st.error) || "Could not save Community folder");
    }
    const el = $("#efb-community-path");
    if (el) el.value = st.custom_community_path || path || "";
    if (statusEl) {
      statusEl.textContent = st.message || "Community folder saved.";
      if (st.warning) {
        statusEl.classList.add("is-warn");
        statusEl.classList.remove("is-ok");
      } else {
        statusEl.classList.add("is-ok");
        statusEl.classList.remove("is-warn");
      }
    }
    try {
      setStatus(st.message || "Community folder saved", st.warning ? "err" : "ok");
    } catch (_) {}
    await refreshHubEfbStatus();
    return st;
  } catch (err) {
    console.error("saveHubEfbCommunityPath", err);
    if (statusEl) {
      statusEl.textContent = (err && err.message) || "Save failed";
      statusEl.classList.add("is-warn");
    }
    try {
      setStatus((err && err.message) || "Community path save failed", "err");
    } catch (_) {}
    return null;
  }
}

async function browseHubEfbCommunityPath() {
  const statusEl = $("#hub-efb-status");
  const btn = $("#btn-efb-community-browse");
  try {
    if (btn) btn.disabled = true;
    if (statusEl) {
      statusEl.textContent = "Opening folder picker…";
      statusEl.classList.remove("is-ok", "is-warn");
    }
    const res = await fetch("/api/efb/community-path/browse", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: "{}",
    });
    const st = await res.json().catch(function () {
      return null;
    });
    if (st && st.cancelled) {
      if (statusEl) statusEl.textContent = "Folder picker cancelled.";
      await refreshHubEfbStatus();
      return;
    }
    if (!res.ok || !st || st.ok === false) {
      throw new Error((st && st.error) || "Browse failed");
    }
    const el = $("#efb-community-path");
    if (el && st.path) el.value = st.path;
    await saveHubEfbCommunityPath(st.path || "");
  } catch (err) {
    console.error("browseHubEfbCommunityPath", err);
    if (statusEl) {
      statusEl.textContent =
        ((err && err.message) || "Browse failed") +
        " — you can paste the path and click Save instead.";
      statusEl.classList.add("is-warn");
    }
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function installHubEfbPlugin() {
  const statusEl = $("#hub-efb-status");
  const btnInstall = $("#btn-efb-install");
  try {
    if (btnInstall) btnInstall.disabled = true;
    // If the user typed a path that isn't saved yet, save it first
    const typed = _efbCommunityPathFromUi();
    if (typed) {
      const saved = await saveHubEfbCommunityPath(typed);
      if (!saved) {
        return;
      }
    }
    if (statusEl) {
      statusEl.textContent =
        "Installing EFB + panel, and applying Store loopback exemption…";
      statusEl.classList.remove("is-ok", "is-warn");
    }
    const body = {};
    if (typed) body.target_path = typed;
    const res = await fetch("/api/efb/install", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const st = await res.json().catch(function () {
      return null;
    });
    if (!res.ok || !st || st.ok === false) {
      throw new Error((st && st.error) || "Install failed");
    }
    const loop = st.loopback || null;
    let msg = st.message || "EFB plugin installed";
    if (statusEl) {
      statusEl.textContent = msg;
      if (loop && loop.ok === false) {
        statusEl.classList.add("is-warn");
        statusEl.classList.remove("is-ok");
      } else {
        statusEl.classList.add("is-ok");
        statusEl.classList.remove("is-warn");
      }
    }
    try {
      setStatus(msg, loop && loop.ok === false ? "err" : "ok");
    } catch (_) {}
    await refreshHubEfbStatus();
  } catch (err) {
    console.error("installHubEfbPlugin", err);
    if (statusEl) {
      statusEl.textContent = (err && err.message) || "Install failed";
      statusEl.classList.add("is-warn");
    }
    try {
      setStatus((err && err.message) || "EFB install failed", "err");
    } catch (_) {}
    await refreshHubEfbStatus();
  } finally {
    if (btnInstall) btnInstall.disabled = false;
  }
}

async function uninstallHubEfbPlugin() {
  const statusEl = $("#hub-efb-status");
  const btnRemove = $("#btn-efb-uninstall");
  try {
    if (btnRemove) btnRemove.disabled = true;
    if (statusEl) statusEl.textContent = "Removing EFB plugin…";
    const res = await fetch("/api/efb/uninstall", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: "{}",
    });
    const st = await res.json().catch(function () {
      return null;
    });
    if (!res.ok || !st || st.ok === false) {
      throw new Error((st && st.error) || "Remove failed");
    }
    try {
      setStatus(st.message || "EFB plugin removed", "ok");
    } catch (_) {}
    await refreshHubEfbStatus();
  } catch (err) {
    console.error("uninstallHubEfbPlugin", err);
    if (statusEl) {
      statusEl.textContent = (err && err.message) || "Remove failed";
      statusEl.classList.add("is-warn");
    }
    try {
      setStatus((err && err.message) || "EFB remove failed", "err");
    } catch (_) {}
    await refreshHubEfbStatus();
  } finally {
    if (btnRemove) btnRemove.disabled = false;
  }
}

$("#btn-efb-install")?.addEventListener("click", function (e) {
  try {
    if (e && e.preventDefault) e.preventDefault();
    installHubEfbPlugin();
  } catch (err) {
    console.error("btn-efb-install", err);
  }
});
$("#btn-efb-uninstall")?.addEventListener("click", function (e) {
  try {
    if (e && e.preventDefault) e.preventDefault();
    uninstallHubEfbPlugin();
  } catch (err) {
    console.error("btn-efb-uninstall", err);
  }
});
$("#btn-efb-loopback")?.addEventListener("click", async function (e) {
  try {
    if (e && e.preventDefault) e.preventDefault();
    const statusEl = $("#hub-efb-status");
    if (statusEl) statusEl.textContent = "Applying Store loopback exemption…";
    const res = await fetch("/api/efb/loopback", { method: "POST" });
    const st = await res.json().catch(function () {
      return null;
    });
    if (!res.ok || !st || st.ok === false) {
      throw new Error((st && st.error) || "Loopback fix failed");
    }
    if (statusEl) {
      statusEl.textContent = st.message || "Loopback OK — restart MSFS";
      statusEl.classList.add("is-ok");
    }
    try {
      setStatus(st.message || "Loopback exemption OK", "ok");
    } catch (_) {}
  } catch (err) {
    console.error("btn-efb-loopback", err);
    const statusEl = $("#hub-efb-status");
    if (statusEl) {
      statusEl.textContent = (err && err.message) || "Loopback fix failed";
      statusEl.classList.add("is-warn");
    }
    try {
      setStatus((err && err.message) || "Loopback fix failed", "err");
    } catch (_) {}
  }
});
$("#btn-efb-community-browse")?.addEventListener("click", function (e) {
  try {
    if (e && e.preventDefault) e.preventDefault();
    browseHubEfbCommunityPath();
  } catch (err) {
    console.error("btn-efb-community-browse", err);
  }
});
$("#btn-efb-community-save")?.addEventListener("click", function (e) {
  try {
    if (e && e.preventDefault) e.preventDefault();
    saveHubEfbCommunityPath();
  } catch (err) {
    console.error("btn-efb-community-save", err);
  }
});
$("#btn-efb-community-clear")?.addEventListener("click", function (e) {
  try {
    if (e && e.preventDefault) e.preventDefault();
    const el = $("#efb-community-path");
    if (el) el.value = "";
    saveHubEfbCommunityPath("");
  } catch (err) {
    console.error("btn-efb-community-clear", err);
  }
});
$("#efb-community-path")?.addEventListener("keydown", function (e) {
  if (e.key === "Enter") {
    e.preventDefault();
    saveHubEfbCommunityPath();
  }
});
$("#efb-orientation")?.addEventListener("change", function (e) {
  try {
    const v = e && e.target ? e.target.value : "auto";
    setHubEfbOrientation(v);
  } catch (err) {
    console.error("efb-orientation", err);
  }
});
$("#career-currency")?.addEventListener("change", function (e) {
  try {
    const v = e && e.target ? e.target.value : "USD";
    setHubCareerCurrency(v);
  } catch (err) {
    console.error("career-currency", err);
  }
});

// Sync community box after first paint (avoid stacking fetches at t=0)
setTimeout(function () {
  refreshHubCommunityPrefs().catch(function () {});
  refreshHubEfbStatus().catch(function () {});
  loadBundledCartoKey().catch(function () {});
}, 800);
setTimeout(function () {
  refreshHubCommunityPrefs().catch(function () {});
  refreshHubEfbStatus().catch(function () {});
}, 2500);

/** Silent: load developer-bundled CARTO key (no hub UI — users never see this). */
async function loadBundledCartoKey() {
  try {
    const res = await fetch("/api/user/prefs", { cache: "no-store" });
    const st = await res.json().catch(function () {
      return null;
    });
    const next =
      st && st.carto_api_key ? String(st.carto_api_key).trim() : "";
    const changed = next !== _cartoApiKey;
    _cartoApiKey = next;
    if (changed) refreshBasemap();
  } catch (err) {
    console.warn("loadBundledCartoKey", err);
  }
}

document.querySelectorAll(".journey-step").forEach((btn) => {
  btn.addEventListener("click", () => {
    // Manual tab pick — stop live auto taxi-in from snapping the step back
    state._journeyStepUserLock = true;
    setJourneyStep(btn.dataset.journeyStep);
  });
});
document.querySelectorAll(".layer-chip").forEach((chip) => {
  chip.addEventListener("click", () => {
    const k = chip.dataset.layer;
    if (!k || !(k in state.layerVisibility)) return;
    const next = !state.layerVisibility[k];
    state.layerVisibility[k] = next;
    applyLayerVisibility();
    // Weather: explicit load with user-facing status (apply only kicks quiet load)
    if (k === "weather") {
      if (next) {
        ensureMapReady();
        ensureWeatherOverlay({ quiet: false, force: true }).catch(function () {});
      } else {
        stopWeatherRefresh();
        try {
          setStatus("Weather radar off", "ok");
        } catch (_) {}
      }
    }
    if (k === "vatsim") {
      if (next) {
        ensureMapReady();
        ensureVatsimTraffic({ quiet: false }).catch(function () {});
      } else {
        stopVatsimTraffic();
        try {
          setStatus("VATSIM traffic off", "ok");
        } catch (_) {}
      }
    }
    if (k === "vatsimAtc") {
      if (next) {
        ensureMapReady();
        ensureVatsimAtc({ quiet: false }).catch(function () {});
      } else {
        stopVatsimAtc();
        try {
          setStatus("VATSIM ATC off", "ok");
        } catch (_) {}
      }
    }
    if (k === "ivao") {
      if (next) {
        ensureMapReady();
        ensureIvaoTraffic({ quiet: false }).catch(function () {});
      } else {
        stopIvaoTraffic();
        try {
          setStatus("IVAO traffic off", "ok");
        } catch (_) {}
      }
    }
    if (k === "simTraffic") {
      if (next) {
        ensureMapReady();
        ensureSimTraffic({ quiet: false }).catch(function () {});
      } else {
        stopSimTraffic();
        try {
          setStatus("Sim traffic off", "ok");
        } catch (_) {}
      }
    }
  });
});
$("#btn-fit-journey")?.addEventListener("click", () => fitAllRoutes());
$("#ap-metar-refresh")?.addEventListener("click", function () {
  const icao = state.airport && state.airport.icao;
  if (!icao) {
    setStatus("Load an airport first", "err");
    return;
  }
  ensureMetar(icao, { force: true, quiet: false }).catch(function () {});
});
document.querySelectorAll(".rwy-suggest-use").forEach(function (btn) {
  btn.addEventListener("click", function () {
    applySuggestedRunway();
  });
});
applyLayerVisibility();

// ── Status / loading ─────────────────────────────────────────────
function setStatus(text, mode = "ok") {
  const st = $("#status-text");
  if (st) st.textContent = text;
  const dot = $("#status-dot");
  if (!dot) return;
  dot.classList.remove("busy", "err");
  if (mode === "busy") dot.classList.add("busy");
  if (mode === "err") dot.classList.add("err");
}
// Expose for airline.js (classic script, no modules)
try {
  window.setStatus = setStatus;
} catch (_) {}

/** Generation counter so a finished load cannot leave a later overlay stuck,
 *  and a late soft-fail cannot clear a newer load's spinner. */
let _loadingGen = 0;

function setLoading(on, text = "Loading…") {
  const el = $("#loading");
  const lt = $("#loading-text");
  if (on) {
    _loadingGen += 1;
    if (lt) lt.textContent = text;
    if (el) el.classList.add("visible");
    return _loadingGen;
  }
  if (lt && text && text !== "Loading…") lt.textContent = text;
  if (el) el.classList.remove("visible");
  return _loadingGen;
}

function clearLoadingIf(gen) {
  if (gen == null || gen === _loadingGen) {
    setLoading(false);
  }
}

function setHint(text, visible = true) {
  const el = $("#map-hint");
  if (!el) return;
  el.innerHTML = text;
  el.classList.toggle("visible", visible && !!text);
}

// ── Airport search (+ recent selections) ─────────────────────────
const RECENT_AIRPORTS_KEY = "navapron_recent_airports";
const RECENT_AIRPORTS_MAX = 10;
/** In-memory cache of recent airport picks (newest first). */
let _recentAirports = [];

function normalizeRecentAirport(ap) {
  if (!ap) return null;
  const icao = String(ap.icao || "").trim().toUpperCase();
  if (!icao || icao.length < 3) return null;
  const out = { icao };
  if (ap.name) out.name = String(ap.name).trim();
  if (ap.city) out.city = String(ap.city).trim();
  if (ap.country) out.country = String(ap.country).trim();
  if (ap.iata) out.iata = String(ap.iata).trim().toUpperCase();
  if (ap.type) out.type = String(ap.type).trim();
  return out;
}

function loadRecentAirportsLocal() {
  try {
    const raw = localStorage.getItem(RECENT_AIRPORTS_KEY);
    if (!raw) return [];
    const data = JSON.parse(raw);
    if (!Array.isArray(data)) return [];
    return data.map(normalizeRecentAirport).filter(Boolean).slice(0, RECENT_AIRPORTS_MAX);
  } catch (_) {
    return [];
  }
}

function saveRecentAirportsLocal(list) {
  try {
    localStorage.setItem(RECENT_AIRPORTS_KEY, JSON.stringify(list || []));
  } catch (_) {
    /* ignore quota */
  }
}

function getRecentAirports() {
  if (_recentAirports && _recentAirports.length) return _recentAirports.slice();
  _recentAirports = loadRecentAirportsLocal();
  return _recentAirports.slice();
}

/** Remember an airport pick (search, SimBrief, OFP import, etc.). */
function rememberRecentAirport(ap) {
  const item = normalizeRecentAirport(ap);
  if (!item) return;
  const rest = getRecentAirports().filter(
    (x) => String(x.icao || "").toUpperCase() !== item.icao
  );
  _recentAirports = [item, ...rest].slice(0, RECENT_AIRPORTS_MAX);
  saveRecentAirportsLocal(_recentAirports);
  // Durable server copy under data/user_prefs.json
  try {
    fetch("/api/user/prefs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ recent_airport: item }),
      keepalive: true,
    }).catch(function () {});
  } catch (_) {}
}

async function hydrateRecentAirportsFromServer() {
  _recentAirports = loadRecentAirportsLocal();
  try {
    const res = await fetch("/api/user/prefs", { cache: "no-store" });
    if (!res.ok) return;
    const data = await res.json();
    const server = Array.isArray(data.recent_airports)
      ? data.recent_airports.map(normalizeRecentAirport).filter(Boolean)
      : [];
    if (!server.length) {
      // Migrate local-only history to server once
      if (_recentAirports.length) {
        fetch("/api/user/prefs", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ recent_airports: _recentAirports }),
        }).catch(function () {});
      }
      return;
    }
    // Prefer server order; merge any newer local-only codes at front
    const seen = new Set(server.map((a) => a.icao));
    const merged = server.slice();
    for (const a of _recentAirports) {
      if (!seen.has(a.icao)) {
        merged.push(a);
        seen.add(a.icao);
      }
    }
    _recentAirports = merged.slice(0, RECENT_AIRPORTS_MAX);
    saveRecentAirportsLocal(_recentAirports);
  } catch (_) {
    /* offline */
  }
}

const searchInput = $("#airport-search");
const resultsList = $("#search-results");

if (searchInput) {
  searchInput.addEventListener("input", () => {
    clearTimeout(state.searchTimer);
    state.searchTimer = setTimeout(() => runSearch(searchInput.value), 220);
  });

  searchInput.addEventListener("focus", () => {
    if (!searchInput.value.trim()) runSearch("");
  });
}

document.addEventListener("click", (e) => {
  if (resultsList && !e.target.closest(".search-wrap")) {
    resultsList.classList.remove("open");
  }
});

async function runSearch(q) {
  const query = (q || "").trim();
  try {
    // Empty box → recent picks first (then popular hubs as fill)
    if (!query) {
      const recent = getRecentAirports();
      const res = await fetch(`/api/airports/search?q=&limit=20`);
      const popular = await res.json().catch(function () {
        return [];
      });
      const recentIcaos = new Set(recent.map((a) => a.icao));
      const fill = (Array.isArray(popular) ? popular : []).filter(
        (a) => a && a.icao && !recentIcaos.has(String(a.icao).toUpperCase())
      );
      const items = recent.length
        ? recent.concat(fill).slice(0, 16)
        : fill.slice(0, 16);
      renderResults(items, {
        recentCount: recent.length,
        emptyLabel: recent.length ? null : "Popular airports",
      });
      return;
    }
    const res = await fetch(
      `/api/airports/search?q=${encodeURIComponent(query)}&limit=20`
    );
    const data = await res.json();
    renderResults(data);
  } catch (err) {
    console.error(err);
    // Offline / server down: still show recents when empty
    if (!query) {
      const recent = getRecentAirports();
      if (recent.length) {
        renderResults(recent, { recentCount: recent.length });
        return;
      }
    }
    setStatus("Search failed", "err");
  }
}

/**
 * @param {Array} items
 * @param {{ recentCount?: number, emptyLabel?: string|null, onPick?: function }} opts
 */
function renderResults(items, opts) {
  opts = opts || {};
  if (!resultsList) return;
  resultsList.innerHTML = "";
  if (!items || !items.length) {
    resultsList.classList.remove("open");
    return;
  }
  const recentCount = Math.max(0, Number(opts.recentCount) || 0);
  const onPick =
    typeof opts.onPick === "function"
      ? opts.onPick
      : function (ap) {
          resultsList.classList.remove("open");
          if (searchInput) searchInput.value = ap.icao;
          rememberRecentAirport(ap);
          // Load as dest when planning arrival / taxi-in so dep chart is not overwritten
          const asDest = shouldLoadAirportAsDest();
          loadAirport(ap.icao, {
            role: asDest ? "dest" : "dep",
            keepPaths:
              state.mode === "journey" ||
              !!state.flightPlan ||
              !!(state.depChart && state.destChart) ||
              asDest ||
              !!state.depChart ||
              !!state.destChart,
            fit: !state.flightPlan,
          });
        };

  if (recentCount > 0) {
    const head = document.createElement("li");
    head.className = "results-heading";
    head.textContent = "Recent";
    resultsList.appendChild(head);
  } else if (opts.emptyLabel) {
    const head = document.createElement("li");
    head.className = "results-heading";
    head.textContent = opts.emptyLabel;
    resultsList.appendChild(head);
  }

  items.forEach(function (ap, idx) {
    if (recentCount > 0 && idx === recentCount) {
      const head = document.createElement("li");
      head.className = "results-heading";
      head.textContent = "Popular";
      resultsList.appendChild(head);
    }
    const li = document.createElement("li");
    const loc = [ap.city, ap.country].filter(Boolean).join(", ");
    li.innerHTML =
      `<span class="code">${escapeHtml(ap.icao)}</span>${escapeHtml(ap.name || ap.icao)}` +
      `<span class="meta">${ap.iata ? escapeHtml(ap.iata) + " · " : ""}${escapeHtml(
        loc || ap.type || ""
      )}</span>`;
    li.addEventListener("click", function () {
      onPick(ap);
    });
    resultsList.appendChild(li);
  });
  resultsList.classList.add("open");
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

// ── Load airport layout ──────────────────────────────────────────
/** True when search/refresh should store the chart as destination, not departure. */
function shouldLoadAirportAsDest() {
  if (state.mode === "arrival") return true;
  if (state.mode === "journey" && state.journeyStep === "taxi-in") return true;
  if (state.activeTab === "arrival") return true;
  // Flight plan: once departure is set, the shared search fills destination
  // (plain ICAO boxes stay available too).
  const onFlightPlan =
    state.mode === "flightplan" ||
    state.activeTab === "flightplan" ||
    (state.mode === "journey" && state.journeyStep === "flightplan");
  if (onFlightPlan) {
    const dep = ($("#fp-dep")?.value || state.depChart?.airport?.icao || "")
      .trim()
      .toUpperCase();
    if (dep) return true;
  }
  return false;
}

/**
 * @param {string} icao
 * @param {boolean|{refresh?:boolean, role?:"dep"|"dest"|"active", keepPaths?:boolean, fit?:boolean, quietLoading?:boolean}} options
 *   quietLoading: parent owns the loading overlay (e.g. loadBothAirports)
 */
/** In-flight airport layout fetches — aborted on Home / clear session. */
const _airportLoadControllers = new Set();

function abortAirportLoads() {
  for (const c of Array.from(_airportLoadControllers)) {
    try {
      c.abort();
    } catch (_) {}
  }
  _airportLoadControllers.clear();
}

async function loadAirport(icao, options = false) {
  const opts =
    typeof options === "boolean"
      ? {
          refresh: options,
          role: "active",
          keepPaths: false,
          fit: true,
          quietLoading: false,
          skipSessionPush: false,
        }
      : {
          refresh: !!options.refresh,
          role: options.role || "active",
          keepPaths: !!options.keepPaths,
          fit: options.fit !== false,
          quietLoading: !!options.quietLoading,
          skipSessionPush: !!options.skipSessionPush,
        };

  let loadGen = null;
  if (!opts.quietLoading) {
    loadGen = setLoading(true, `Loading taxi chart for ${icao}…`);
  }
  setStatus(`Fetching chart for ${icao} from OpenStreetMap…`, "busy");

  if (!opts.keepPaths) {
    // Drop previous airport surface immediately so a failed/slow load cannot
    // leave a ghost runway on an empty map.
    try {
      clearSurfaceLayers();
    } catch (_) {}
    clearRoute();
    clearDeparture();
    clearArrival();
    clearTaxiIn();
    clearAllPathSnapshots();
    state.clearance = [];
    state.arrClearance = [];
    state.runwayEndMeta = null;
    state.arrivalStand = null;
    state.depPick = { start: null, runway: null };
    state.arrPick = { stand: null, runway: null };
    state.start = null;
    state.end = null;
    state.depSuggestions = [];
    state.arrSuggestions = [];
    resetDepSelect();
    resetArrSelect();
    updateArrTaxiButtons();
    renderClearance();
    renderArrClearance();
  }

  // Progress messages so a slow OSM response doesn't feel frozen
  const started = Date.now();
  const tips = [
    `Contacting map servers for ${icao}…`,
    "OpenStreetMap can take 10–30s on first load…",
    "Still waiting on chart servers — almost there…",
    "Large airports take longer the first time (then cached)…",
  ];
  let tipIdx = 0;
  const progressTimer = setInterval(() => {
    const sec = Math.round((Date.now() - started) / 1000);
    tipIdx = Math.min(tipIdx + 1, tips.length - 1);
    // Never force the full-screen overlay when a parent owns loading
    // (session sync / dual OFP load) — that left "Loading arrival…" stuck.
    if (!opts.quietLoading) {
      loadGen = setLoading(true, `${tips[tipIdx]} (${sec}s)`);
    }
    setStatus(`Loading ${icao}… ${sec}s`, "busy");
  }, 4000);

  const controller = new AbortController();
  _airportLoadControllers.add(controller);
  // Career / dual loads: fail faster so small fields don't freeze the UI for 90s
  const abortMs = opts.quietLoading || opts.keepPaths ? 45000 : 90000;
  const killTimer = setTimeout(() => controller.abort(), abortMs);

  try {
    const url = `/api/airports/${encodeURIComponent(icao)}/layout${
      opts.refresh ? "?refresh=true" : ""
    }`;
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      const detail = err.detail;
      // Soft-fail for background dual loads (career hops) — plan already on map
      if (opts.keepPaths || opts.quietLoading) {
        console.warn("Chart load soft-fail for", icao, detail || res.statusText);
        setStatus(
          `Chart for ${icao} unavailable (sparse OSM) — enroute plan still shown`,
          "ok"
        );
        return null;
      }
      throw new Error(
        typeof detail === "string" ? detail : detail?.[0]?.msg || res.statusText
      );
    }
    const data = await res.json();
    const chart = {
      airport: data.airport,
      layout: data.layout,
      runwayEnds: data.runway_ends || [],
      source: data.source,
    };

    // Store dual-airport charts — never clobber the other role's airport
    const icaoUp = (data.airport?.icao || icao || "").toUpperCase();
    let role = opts.role || "active";
    if (role === "active") {
      role = shouldLoadAirportAsDest() ? "dest" : "dep";
    }
    if (role === "dep") {
      state.depChart = chart;
      if ($("#fp-dep") && icaoUp) {
        // Only auto-fill dep ICAO; leave dest alone
        $("#fp-dep").value = icaoUp;
      }
    } else if (role === "dest") {
      state.destChart = chart;
      if ($("#fp-dest") && icaoUp) {
        $("#fp-dest").value = icaoUp;
      }
    }
    // Dep+Dest known (search or load) → auto pink DCT path.
    // Skip when keepPaths (SimBrief/dual load already has an OFP track) so we
    // do not schedule a navaids rebuild that strips RNAV midpoints.
    if (!opts.keepPaths) {
      try {
        scheduleAutoShowFlightPlan(250);
      } catch (_) {}
    }

    // Active chart for selects / taxi buttons (both surfaces if dual)
    applyChartAsActive(chart, { fit: opts.fit, redrawAll: true });
    // Keep taxi / procedure paths if this was a dual-chart / soft reload
    if (opts.keepPaths) {
      try {
        restoreAllPathLayers();
      } catch (_) {}
    }
    // Track for “Recent” airport search suggestions
    rememberRecentAirport(data.airport || { icao: icaoUp });
    // Don't echo a push while applying a remote session (PC↔iPad fight)
    if (!opts.skipSessionPush) scheduleSessionPush();

    // Keep Charts panel in sync when it is already open
    try {
      if (
        window.NavApronPlates &&
        typeof window.NavApronPlates.onAirportLoaded === "function"
      ) {
        window.NavApronPlates.onAirportLoaded(icaoUp, { role });
      }
    } catch (_) {}

    const st = (data.layout && data.layout.stats) || {};
    const thin =
      !!st.minimal ||
      ((st.taxiway_segments || 0) === 0 && (st.named_taxiways || 0) === 0);
    const apType = String(data.airport?.type || "");
    const hubStub =
      thin &&
      (apType === "large_airport" || apType === "medium_airport" || !!st.minimal);
    // One automatic retry: hub 18/36 stubs mean Overpass/cache failed — force refresh
    if (hubStub && !opts.refresh && !opts._retriedStub) {
      console.warn("Stub chart for hub", icao, "— retrying with refresh");
      setStatus(`Retrying full chart for ${icao}…`, "busy");
      return loadAirport(icao, Object.assign({}, opts, { refresh: true, _retriedStub: true }));
    }
    const src = data.source ? ` · ${data.source}` : "";
    const sec = Math.round((Date.now() - started) / 1000);
    const both =
      state.depChart &&
      state.destChart &&
      state.depChart.airport.icao !== state.destChart.airport.icao;
    if (thin) {
      setStatus(
        `${data.airport.icao} opened with a stub chart (no taxiways yet) — click Refresh${src}`,
        "err"
      );
      setHint(
        `<strong>${escapeHtml(data.airport.icao)}</strong> has little OSM surface data right now. ` +
          `Click <strong>Refresh</strong> to retry map servers.`,
        true
      );
      // Dual OFP load must not treat ghost 18/36 as success
      if (hubStub && (opts.quietLoading || opts.keepPaths)) {
        return null;
      }
    } else {
      setStatus(
        both
          ? `${state.depChart.airport.icao} + ${state.destChart.airport.icao} charts · gate-to-gate ready (${sec}s)`
          : `${data.airport.icao} · ${st.taxiway_segments || 0} segments · ${st.named_taxiways || 0} taxiways${src} (${sec}s)`,
        "ok"
      );
      setHint(
        both
          ? `Both airports loaded — taxi out at <strong>${state.depChart.airport.icao}</strong>, taxi in at <strong>${state.destChart.airport.icao}</strong>`
          : `Chart loaded for <strong>${data.airport.icao}</strong> — pick start, runway, and taxiways`,
        true
      );
      setTimeout(() => setHint("", false), 6000);
    }
    return chart;
  } catch (err) {
    const soft =
      opts.keepPaths ||
      opts.quietLoading ||
      (err && err.name === "AbortError" && state.mode === "hub");
    if (soft && err && err.name === "AbortError") {
      // Home/clear aborted us, or background timeout — don't alarm
      if (opts.keepPaths || opts.quietLoading) {
        setStatus(
          `Chart for ${icao} timed out — enroute plan still shown. Try Refresh.`,
          "ok"
        );
        return null;
      }
      return null;
    }
    if (soft && opts.keepPaths) {
      console.warn("Chart load soft-fail for", icao, err);
      setStatus(
        `Chart for ${icao} unavailable — enroute plan still shown. Try Refresh.`,
        "ok"
      );
      return null;
    }
    console.error(err);
    const msg =
      err.name === "AbortError"
        ? "Timed out waiting for map servers. Click Refresh or try again."
        : err.message;
    setStatus(`Failed: ${msg}`, "err");
    setHint(`Could not load chart: ${escapeHtml(msg)}`, true);
    return null;
  } finally {
    clearInterval(progressTimer);
    clearTimeout(killTimer);
    _airportLoadControllers.delete(controller);
    if (!opts.quietLoading) clearLoadingIf(loadGen);
  }
}

function applyChartAsActive(chart, { fit = true, redrawAll = true } = {}) {
  if (!chart) return;
  state.airport = chart.airport;
  state.layout = chart.layout;
  state.runwayEnds = chart.runwayEnds || [];
  renderAirportCard({ airport: chart.airport, layout: chart.layout });
  if (redrawAll) redrawSurfaces({ fit });
  else {
    drawLayout(chart.layout, { fit, clearSurface: true });
  }
  populateSelects({
    airport: chart.airport,
    layout: chart.layout,
    runway_ends: chart.runwayEnds,
  });
  renderTaxiwayButtons(chart.layout.taxiway_names || []);
  // Only restore picks for the phase the user is currently editing.
  // (Avoid applying dest/arr runway onto taxi-out while dual-loading charts.)
  const role = surfacePickRoleForChart(chart);
  if (role === surfacePickRoleActive()) {
    restoreSurfacePicks(role);
  }
}

/** Which remembered pick set belongs to this chart / UI phase. */
function surfacePickRoleForChart(chart) {
  if (!chart) return isArrivalTaxiMode() ? "arr" : "dep";
  // Prefer explicit journey/tab phase over chart identity
  if (isArrivalTaxiMode()) return "arr";
  if (state.destChart && chart === state.destChart && chart !== state.depChart) {
    return "arr";
  }
  return "dep";
}

function surfacePickRoleActive() {
  return isArrivalTaxiMode() ? "arr" : "dep";
}

/** Match a select option by parking label/latlon or runway name. */
function selectOptionMatching(sel, matcher) {
  if (!sel || !matcher) return false;
  for (const opt of sel.options) {
    if (!opt.value) continue;
    try {
      if (matcher(JSON.parse(opt.value), opt)) {
        sel.value = opt.value;
        return true;
      }
    } catch (_) {
      /* ignore */
    }
  }
  return false;
}

function sameParkingPick(a, b) {
  if (!a || !b) return false;
  if (a.label && b.label && String(a.label) === String(b.label)) return true;
  return (
    Math.abs(Number(a.lat) - Number(b.lat)) < 1e-5 &&
    Math.abs(Number(a.lon) - Number(b.lon)) < 1e-5
  );
}

/** Normalize runway designator for compare: "07" / "7" / "RWY 25" → "7" / "25". */
function normalizeRwyName(name) {
  let s = String(name || "")
    .toUpperCase()
    .replace(/^RWY\s*/i, "")
    .replace(/^RW\s*/i, "")
    .trim();
  // Strip leading zeros on numeric part (07 → 7, 25L stays 25L)
  const m = s.match(/^0*(\d+)([A-Z]?)$/);
  if (m) return m[1] + (m[2] || "");
  return s;
}

function sameRunwayPick(a, b) {
  if (!a || !b) return false;
  const na = normalizeRwyName(a.name || a.label);
  const nb = normalizeRwyName(b.name || b.label);
  if (na && nb && na === nb) return true;
  if (a.lat == null || b.lat == null) return false;
  return (
    Math.abs(Number(a.lat) - Number(b.lat)) < 1e-5 &&
    Math.abs(Number(a.lon) - Number(b.lon)) < 1e-5
  );
}

/** Sync only the dropdowns that belong to dep or arr (never cross-contaminate). */
function syncRunwayDropdowns(meta, { forArrival, syncFrom } = {}) {
  if (!meta) return;
  const ids = forArrival
    ? ["arr-runway-select"]
    : ["runway-select", "dep-runway-select"];
  for (const id of ids) {
    const el = $(`#${id}`);
    if (!el || el.id === syncFrom) continue;
    selectOptionMatching(el, (v) => sameRunwayPick(v, meta));
  }
}

/** Read runway meta from a select if set. */
function runwayMetaFromSelect(id) {
  const el = $(`#${id}`);
  if (!el || !el.value) return null;
  try {
    const v = JSON.parse(el.value);
    if (v.lat == null || v.lon == null) return null;
    return {
      name: v.name,
      lat: v.lat,
      lon: v.lon,
      approach_hdg: v.approach_hdg,
      runway: v.runway,
    };
  } catch (_) {
    return null;
  }
}

/** Active taxi-out end must come from depPick (not a stale landing runway). */
function ensureDepRunwayActive() {
  let r = state.depPick?.runway;
  // Prefer explicit taxi / dep dropdown if user just changed it
  if (!r) {
    r =
      runwayMetaFromSelect("runway-select") ||
      runwayMetaFromSelect("dep-runway-select");
    if (r) {
      if (!state.depPick) state.depPick = { start: null, runway: null };
      state.depPick.runway = { ...r };
    }
  }
  if (!r || r.lat == null || r.lon == null) return false;
  state.runwayEndMeta = {
    name: r.name,
    lat: r.lat,
    lon: r.lon,
    approach_hdg: r.approach_hdg,
    runway: r.runway,
  };
  state.end = {
    lat: r.lat,
    lon: r.lon,
    label: r.name ? `RWY ${r.name}` : "Runway",
  };
  return true;
}

/** Active taxi-in landing runway from arrPick when present. */
function ensureArrRunwayActive() {
  let r = state.arrPick?.runway;
  if (!r) {
    r = runwayMetaFromSelect("arr-runway-select");
    if (r) {
      if (!state.arrPick) state.arrPick = { stand: null, runway: null };
      state.arrPick.runway = { ...r };
    }
  }
  if (!r || r.lat == null || r.lon == null) return false;
  state.runwayEndMeta = {
    name: r.name,
    lat: r.lat,
    lon: r.lon,
    approach_hdg: r.approach_hdg,
    runway: r.runway,
  };
  return true;
}

function placeArrStandMarker(stand) {
  if (!stand || stand.lat == null || stand.lon == null) return;
  baseLayers.markers.eachLayer((layer) => {
    if (layer._isArrStand) baseLayers.markers.removeLayer(layer);
  });
  const m = L.circleMarker([stand.lat, stand.lon], {
    radius: 8,
    color: "#38bdf8",
    fillColor: "#0284c7",
    fillOpacity: 1,
    weight: 2,
  }).bindPopup(`Taxi-in: <strong>${stand.label || "Stand"}</strong>`);
  m._isArrStand = true;
  m.addTo(baseLayers.markers);
}

/**
 * After populateSelects rebuilds dropdowns, restore gate/stand + runway
 * for the active phase so taxi-out ↔ taxi-in keeps choices.
 */
function restoreSurfacePicks(role) {
  role = role || surfacePickRoleActive();
  try {
    if (role === "arr") {
      const pick = state.arrPick || {};
      if (pick.stand) {
        state.arrivalStand = { ...pick.stand };
        // Restored picks count as intentional — don't let auto-arrive replace them
        if (!state._arrStandSource) state._arrStandSource = "user";
        const arrStand = $("#arr-stand-select");
        if (arrStand) {
          const matched = selectOptionMatching(arrStand, (v) =>
            sameParkingPick(v, pick.stand)
          );
          if (!matched) {
            const opt = document.createElement("option");
            opt.value = JSON.stringify({
              lat: pick.stand.lat,
              lon: pick.stand.lon,
              label: pick.stand.label,
            });
            opt.textContent = pick.stand.label || "Stand";
            arrStand.appendChild(opt);
            arrStand.value = opt.value;
          }
        }
        placeArrStandMarker(pick.stand);
      }
      if (pick.runway) {
        ensureArrRunwayActive();
        // Arrival only — do NOT rewrite taxi-out / dep runway dropdowns
        syncRunwayDropdowns(pick.runway, { forArrival: true });
        onRunwayChangedForArrival({ quiet: true });
      }
      updateArrTaxiButtons();
    } else {
      const pick = state.depPick || {};
      if (pick.start) {
        // setStart also re-saves depPick — fine
        setStart(pick.start.lat, pick.start.lon, pick.start.label, {
          remember: false,
        });
        const startSel = $("#start-select");
        if (startSel) {
          const matched = selectOptionMatching(startSel, (v) =>
            sameParkingPick(v, pick.start)
          );
          if (!matched) {
            const opt = document.createElement("option");
            opt.value = JSON.stringify({
              lat: pick.start.lat,
              lon: pick.start.lon,
              label: pick.start.label,
            });
            opt.textContent = pick.start.label || "Start";
            startSel.appendChild(opt);
            startSel.value = opt.value;
          }
        }
      }
      if (pick.runway) {
        ensureDepRunwayActive();
        setEnd(
          pick.runway.lat,
          pick.runway.lon,
          pick.runway.name ? `RWY ${pick.runway.name}` : "Runway"
        );
        // Dep / taxi only — do NOT overwrite landing runway selection
        syncRunwayDropdowns(pick.runway, { forArrival: false });
        onRunwayChangedForDeparture({ quiet: true });
      }
      updateRouteButton();
    }
  } catch (err) {
    console.warn("restoreSurfacePicks", role, err);
  }
}

/**
 * Zoom the map to a single airport chart (like first load), not both dep+dest.
 */
function fitChartBounds(chart, { maxZoom = 16, pad = 0.08 } = {}) {
  if (!chart) return;
  try {
    const bounds = [];
    const layout = chart.layout;
    if (layout) {
      for (const tw of layout.taxiways || []) {
        for (const c of tw.coords || []) {
          if (c != null && c[0] != null) bounds.push([c[0], c[1]]);
        }
      }
      for (const rw of layout.runways || []) {
        for (const c of rw.coords || []) {
          if (c != null && c[0] != null) bounds.push([c[0], c[1]]);
        }
      }
      for (const ap of layout.aprons || []) {
        for (const c of ap.coords || []) {
          if (c != null && c[0] != null) bounds.push([c[0], c[1]]);
        }
      }
      for (const p of layout.parking || []) {
        if (p.lat != null && p.lon != null) bounds.push([p.lat, p.lon]);
      }
    }
    if (bounds.length >= 2) {
      const b = L.latLngBounds(bounds);
      if (b.isValid()) {
        map.fitBounds(b.pad(pad), { maxZoom, animate: true });
        return;
      }
    }
    if (chart.airport?.lat != null && chart.airport?.lon != null) {
      map.setView([chart.airport.lat, chart.airport.lon], Math.min(14, maxZoom), {
        animate: true,
      });
    }
  } catch (err) {
    console.warn("fitChartBounds", err);
  }
}

function clearSurfaceLayers() {
  for (const key of [
    "taxiways",
    "runways",
    "aprons",
    "buildings",
    "parking",
    "holds",
    "labels",
  ]) {
    baseLayers[key]?.clearLayers();
  }
  state.twyLayerByName.clear();
}

/** Arrival / taxi-in phase — inbound clearance UI and dest chart interaction. */
function isArrivalTaxiMode() {
  if (state.mode === "arrival") return true;
  if (state.mode === "journey" && state.journeyStep === "taxi-in") return true;
  if (state.activeTab === "arrival") return true;
  return false;
}

/** Draw dep + dest surface charts together (paths preserved). */
function redrawSurfaces({ fit = false } = {}) {
  clearSurfaceLayers();
  const bounds = [];
  const paint = (chart, opts) => {
    if (!chart?.layout) return;
    paintLayoutOntoMap(chart.layout, {
      ...opts,
      collectBounds: bounds,
    });
  };
  const dep = state.depChart;
  const dest = state.destChart;
  const arrMode = isArrivalTaxiMode();
  // In arrival/taxi-in: dest chart is interactive (clickable taxiways for inbound clearance)
  // Otherwise: dep chart interactive, dest dimmed if both loaded
  if (dep && dest && dep.airport?.icao !== dest.airport?.icao) {
    if (arrMode) {
      paint(dep, { taxiInteractive: false, dim: true });
      paint(dest, { taxiInteractive: true, dim: false });
    } else {
      paint(dep, { taxiInteractive: true, dim: false });
      paint(dest, { taxiInteractive: false, dim: true });
    }
  } else if (dep) {
    paint(dep, { taxiInteractive: true });
  } else if (dest) {
    paint(dest, { taxiInteractive: true });
  } else if (state.layout) {
    // Legacy single layout
    paintLayoutOntoMap(state.layout, {
      taxiInteractive: true,
      collectBounds: bounds,
    });
  }
  if (fit && bounds.length) {
    try {
      map.fitBounds(L.latLngBounds(bounds).pad(0.08));
    } catch (_) {}
  }
}

function renderAirportCard(data) {
  const ap = data.airport;
  const st = data.layout.stats;
  $("#airport-card").classList.add("visible");
  $("#ap-icao").textContent = ap.icao + (ap.iata ? ` / ${ap.iata}` : "");
  $("#ap-name").textContent = [ap.name, ap.city, ap.country].filter(Boolean).join(" · ");
  const roleHint = $("#ap-role-hint");
  if (roleHint) {
    const depI = state.depChart?.airport?.icao;
    const destI = state.destChart?.airport?.icao;
    if (depI && destI && depI !== destI) {
      roleHint.style.display = "block";
      roleHint.innerHTML =
        `Dep <strong>${escapeHtml(depI)}</strong> · Dest <strong>${escapeHtml(destI)}</strong>` +
        ` · editing <strong>${escapeHtml(ap.icao)}</strong>` +
        (isArrivalTaxiMode()
          ? " (arrival / taxi-in)"
          : " (departure / taxi-out)");
    } else {
      roleHint.style.display = "none";
      roleHint.textContent = "";
    }
  }
  const holdN = st.holds != null ? st.holds : 0;
  $("#ap-stats").innerHTML = `
    <span class="chip ok">${st.named_taxiways} taxiways</span>
    <span class="chip">${st.runways} runways</span>
    <span class="chip">${st.parking} stands/gates</span>
    <span class="chip">${holdN} holds</span>
    <span class="chip">${st.taxiway_segments} segments</span>
  `;
  // METAR is async — kick off after the card paints (don’t block chart load)
  if (ap && ap.icao) {
    const box = $("#ap-metar");
    const sum = $("#ap-metar-summary");
    if (
      box &&
      sum &&
      (!state.metar || state.metar.icao !== ap.icao)
    ) {
      box.hidden = false;
      sum.textContent = "Loading METAR…";
      const raw = $("#ap-metar-raw");
      if (raw) raw.textContent = "";
      const cat = $("#ap-metar-cat");
      if (cat) {
        cat.hidden = true;
        cat.textContent = "";
      }
    }
    ensureMetar(ap.icao, { quiet: true }).catch(function () {});
  } else {
    clearMetarCard();
  }
}

const METAR_MIN_WIND_KT = 3;

function clearMetarCard() {
  state.metar = null;
  state.runwaySuggestion = null;
  const box = $("#ap-metar");
  if (box) box.hidden = true;
  document.querySelectorAll(".rwy-suggest").forEach(function (el) {
    el.hidden = true;
  });
}

function renderMetarCard(metar) {
  const box = $("#ap-metar");
  const sum = $("#ap-metar-summary");
  const raw = $("#ap-metar-raw");
  const cat = $("#ap-metar-cat");
  if (!box || !sum) return;
  if (!metar || !metar.ok) {
    box.hidden = false;
    sum.textContent = metar && metar.error ? "METAR unavailable" : "No METAR";
    if (raw) raw.textContent = (metar && metar.error) || "";
    if (cat) {
      cat.hidden = true;
      cat.textContent = "";
      cat.className = "ap-metar-cat";
    }
    return;
  }
  box.hidden = false;
  const bits = [];
  if (metar.wind_dir_variable) {
    bits.push("VRB" + (metar.wind_speed_kt != null ? String(metar.wind_speed_kt).padStart(2, "0") : "") + " kt");
  } else if (metar.wind_speed_kt === 0) {
    bits.push("Calm");
  } else if (metar.wind_dir_deg != null && metar.wind_speed_kt != null) {
    let w =
      String(Math.round(metar.wind_dir_deg)).padStart(3, "0") +
      "°/" +
      String(metar.wind_speed_kt).padStart(2, "0") +
      " kt";
    if (metar.wind_gust_kt != null) w += " G" + metar.wind_gust_kt;
    bits.push(w);
  }
  if (metar.altimeter_hpa != null) bits.push("Q" + metar.altimeter_hpa);
  if (metar.temp_c != null) {
    bits.push(
      Math.round(metar.temp_c) +
        "°C" +
        (metar.dewpoint_c != null ? "/" + Math.round(metar.dewpoint_c) : "")
    );
  }
  if (metar.stale) bits.push("stale");
  sum.textContent = bits.length ? bits.join(" · ") : "METAR";
  if (raw) raw.textContent = metar.raw || "";
  if (cat) {
    const fc = (metar.flight_category || "").toUpperCase();
    if (fc) {
      cat.hidden = false;
      cat.textContent = fc;
      cat.className = "ap-metar-cat cat-" + fc.toLowerCase();
    } else {
      cat.hidden = true;
      cat.textContent = "";
      cat.className = "ap-metar-cat";
    }
  }
}

/**
 * Score runway ends for best headwind. Hint only — never auto-applies.
 * @returns {object|null}
 */
function scorePreferredRunway(ends, metar) {
  if (!metar || !metar.ok || metar.wind_dir_variable) return null;
  if (metar.wind_dir_deg == null || metar.wind_speed_kt == null) return null;
  const spd = Number(metar.wind_speed_kt);
  if (!Number.isFinite(spd) || spd < METAR_MIN_WIND_KT) return null;
  const wdir = ((Number(metar.wind_dir_deg) % 360) + 360) % 360;
  let best = null;
  let bestHw = -1e9;
  for (const e of ends || []) {
    if (!e || e.approach_hdg == null || !e.name) continue;
    const approach = ((Number(e.approach_hdg) % 360) + 360) % 360;
    if (!Number.isFinite(approach)) continue;
    let delta = Math.abs(approach - wdir) % 360;
    delta = Math.min(delta, 360 - delta);
    const rad = (delta * Math.PI) / 180;
    const headwind = spd * Math.cos(rad);
    const crosswind = Math.abs(spd * Math.sin(rad));
    const length = Number(e.length_m) || 0;
    const osm = e.osm_named ? 1 : 0;
    if (
      best == null ||
      headwind > bestHw + 0.05 ||
      (Math.abs(headwind - bestHw) <= 0.05 &&
        (length > (best.length_m || 0) ||
          (length === (best.length_m || 0) && osm > (best.osm_named ? 1 : 0))))
    ) {
      bestHw = headwind;
      best = {
        name: String(e.name),
        runway: e.runway || null,
        lat: e.lat,
        lon: e.lon,
        approach_hdg: approach,
        length_m: length,
        osm_named: !!e.osm_named,
        headwind_kt: Math.round(headwind * 10) / 10,
        crosswind_kt: Math.round(crosswind * 10) / 10,
        wind_dir_deg: Math.round(wdir),
        wind_speed_kt: Math.round(spd),
        label: e.name ? "RWY " + e.name : "Runway",
      };
    }
  }
  return best;
}

function updateRunwaySuggestion() {
  const sug = scorePreferredRunway(state.runwayEnds || [], state.metar);
  state.runwaySuggestion = sug;
  const boxes = document.querySelectorAll(".rwy-suggest");
  if (!boxes.length) return;
  if (!sug) {
    boxes.forEach(function (el) {
      el.hidden = true;
    });
    return;
  }
  const hw = sug.headwind_kt;
  const xw = sug.crosswind_kt;
  const wdir =
    sug.wind_dir_deg != null
      ? sug.wind_dir_deg
      : state.metar && state.metar.wind_dir_deg;
  const wspd =
    sug.wind_speed_kt != null
      ? sug.wind_speed_kt
      : state.metar && state.metar.wind_speed_kt;
  const parts = ["Suggested: " + sug.name];
  if (wdir != null && wspd != null) {
    parts.push(
      "METAR wind " +
        String(Math.round(wdir)).padStart(3, "0") +
        "°/" +
        Math.round(wspd) +
        " kt"
    );
  }
  if (hw >= 0.5) {
    parts.push("on this runway ≈ " + Math.round(hw) + " kt headwind");
    if (xw >= 3) parts.push(Math.round(xw) + " kt crosswind");
  } else {
    parts.push(
      "on this runway ≈ " + Math.round(Math.abs(hw)) + " kt tailwind (least bad)"
    );
  }
  const text = parts.join(" · ");
  boxes.forEach(function (el) {
    const span = el.querySelector(".rwy-suggest-text");
    if (span) span.textContent = text;
    el.hidden = false;
    el.title =
      "METAR wind is the full wind (direction FROM). Headwind/crosswind are components of that wind on this runway heading — they add up in magnitude from the same METAR, not a different forecast. Click Use to apply.";
  });
}

/**
 * Fetch METAR for ICAO and refresh card + runway hint.
 * @param {string} icao
 * @param {{ force?: boolean, quiet?: boolean }} opts
 */
async function ensureMetar(icao, opts) {
  opts = opts || {};
  const key = String(icao || "")
    .trim()
    .toUpperCase();
  if (!key) {
    clearMetarCard();
    return null;
  }
  // Skip network if we already have fresh METAR for this ICAO (unless force)
  const fetchedAt = state.metar && state.metar._fetchedAt;
  const clientAge =
    fetchedAt != null ? (Date.now() - fetchedAt) / 1000 : 1e9;
  if (
    !opts.force &&
    state.metar &&
    state.metar.ok &&
    state.metar.icao === key &&
    !state.metar.stale &&
    clientAge < 480
  ) {
    renderMetarCard(state.metar);
    updateRunwaySuggestion();
    return state.metar;
  }
  try {
    const q = opts.force ? "?force=1" : "";
    const res = await fetch("/api/weather/" + encodeURIComponent(key) + q, {
      cache: "no-store",
    });
    const data = await res.json().catch(function () {
      return null;
    });
    if (!data) throw new Error("HTTP " + res.status);
    // Keep showing data even when ok:false (error message on card)
    if (data.icao && data.icao !== key && state.airport && state.airport.icao !== data.icao) {
      // Stale response for a previous airport — ignore
      return state.metar;
    }
    if (state.airport && state.airport.icao && state.airport.icao !== key) {
      // User switched airports while request was in flight
      return state.metar;
    }
    data._fetchedAt = Date.now();
    state.metar = data;
    renderMetarCard(data);
    updateRunwaySuggestion();
    if (!opts.quiet && data.ok) {
      setStatus("METAR updated for " + key, "ok");
    }
    return data;
  } catch (err) {
    console.warn("METAR fetch failed", err);
    if (!state.metar || state.metar.icao !== key) {
      state.metar = {
        ok: false,
        icao: key,
        error: err && err.message ? err.message : String(err),
      };
      renderMetarCard(state.metar);
      updateRunwaySuggestion();
    }
    if (!opts.quiet) {
      setStatus(
        "METAR unavailable: " + (err && err.message ? err.message : String(err)),
        "err"
      );
    }
    return state.metar;
  }
}

function applySuggestedRunway() {
  const sug = state.runwaySuggestion;
  if (!sug || sug.lat == null || sug.lon == null) return;
  const forArrival =
    typeof isArrivalTaxiMode === "function" && isArrivalTaxiMode();
  applyRunwaySelection(
    {
      name: sug.name,
      lat: sug.lat,
      lon: sug.lon,
      approach_hdg: sug.approach_hdg,
      runway: sug.runway,
      label: sug.label || "RWY " + sug.name,
    },
    { forArrival: forArrival }
  );
  setStatus(
    "Using METAR-suggested runway " + sug.name,
    "ok"
  );
}

// ── Draw chart ───────────────────────────────────────────────────
function clearLayers() {
  for (const key of Object.keys(baseLayers)) {
    baseLayers[key].clearLayers();
  }
  state.twyLayerByName.clear();
  $("#dep-summary")?.classList?.remove("visible");
  $("#arr-summary")?.classList?.remove("visible");
}

/**
 * Draw surface geometry without wiping taxi/enroute path layers.
 * @param {object} layout
 * @param {{fit?: boolean, clearSurface?: boolean}} [opts]
 */
function drawLayout(layout, opts = {}) {
  const fit = opts.fit !== false;
  if (opts.clearSurface !== false) clearSurfaceLayers();
  const bounds = [];
  paintLayoutOntoMap(layout, {
    taxiInteractive: true,
    collectBounds: bounds,
  });
  if (fit && bounds.length) {
    try {
      map.fitBounds(L.latLngBounds(bounds).pad(0.08));
    } catch (_) {}
  }
}

function paintLayoutOntoMap(layout, {
  taxiInteractive = true,
  dim = false,
  collectBounds = null,
} = {}) {
  const bounds = collectBounds || [];
  const opMul = dim ? 0.55 : 1;

  for (const apron of layout.aprons || []) {
    if ((apron.coords || []).length < 3) continue;
    const latlngs = apron.coords.map((c) => [c[0], c[1]]);
    L.polygon(latlngs, {
      color: "#334155",
      weight: 1,
      fillColor: "#1e293b",
      fillOpacity: 0.45 * opMul,
    })
      .bindPopup(`Apron: ${apron.name}`)
      .addTo(baseLayers.aprons);
    latlngs.forEach((ll) => bounds.push(ll));
  }

  // Terminal / hangar footprints — lighter fill so buildings stand out on dark charts
  for (const bld of layout.buildings || []) {
    if ((bld.coords || []).length < 3) continue;
    const latlngs = bld.coords.map((c) => [c[0], c[1]]);
    const isHangar = String(bld.kind || "") === "hangar";
    L.polygon(latlngs, {
      color: isHangar ? "#94a3b8" : "#cbd5e1",
      weight: 1.5,
      fillColor: isHangar ? "#64748b" : "#78859a",
      fillOpacity: (isHangar ? 0.78 : 0.82) * opMul,
      opacity: 0.95 * opMul,
    })
      .bindPopup(
        `${isHangar ? "Hangar" : "Terminal"}: ${bld.name || (isHangar ? "Hangar" : "Terminal")}`
      )
      .addTo(baseLayers.buildings);
    latlngs.forEach((ll) => bounds.push(ll));
  }

  for (const tw of layout.taxiways || []) {
    // Graph-only stand lead-ins (draw:false) — used for routing, not painted
    if (tw.draw === false) continue;
    const latlngs = tw.coords.map((c) => [c[0], c[1]]);
    const isUnnamed = !tw.name || tw.name === "UNNAMED";
    // Unnamed connectors/curves: warm yellow (not grey) so bends match named taxiways
    const line = L.polyline(latlngs, {
      color: isUnnamed ? (dim ? "#92720a" : "#c9a227") : dim ? "#ca8a04" : "#f0c040",
      weight: isUnnamed ? 3 : 3.5,
      opacity: (isUnnamed ? 0.75 : 0.9) * opMul,
      lineCap: "round",
      lineJoin: "round",
    }).bindPopup(
      isUnnamed
        ? "Taxiway (unnamed connector)"
        : `Taxiway <strong>${tw.name}</strong>`
    );
    line.addTo(baseLayers.taxiways);
    if (!isUnnamed && taxiInteractive) {
      if (!state.twyLayerByName.has(tw.name)) {
        state.twyLayerByName.set(tw.name, []);
      }
      state.twyLayerByName.get(tw.name).push(line);
      // Click taxiway on map → clearance (out or in, same as pill buttons)
      line.on("click", (e) => {
        try {
          if (e?.originalEvent) L.DomEvent.stopPropagation(e.originalEvent);
        } catch (_) {}
        if (state.drawTaxiMode) return;
        if (isArrivalTaxiMode()) addToArrClearance(tw.name);
        else addToClearance(tw.name);
      });
      line.on("mouseover", function () {
        this.setStyle({ weight: 5.5, opacity: 1 });
      });
      line.on("mouseout", function () {
        // re-apply clearance highlight state
        if (isArrivalTaxiMode()) highlightArrClearanceTaxiways();
        else highlightClearanceTaxiways();
      });
    }
    latlngs.forEach((ll) => bounds.push(ll));
  }

  for (const rw of layout.runways || []) {
    const latlngs = rw.coords.map((c) => [c[0], c[1]]);
    L.polyline(latlngs, {
      color: "#9ca3af",
      weight: 16,
      opacity: 0.85 * opMul,
      lineCap: "butt",
    })
      .bindPopup(`Runway <strong>${rw.name}</strong>`)
      .addTo(baseLayers.runways);
    // centerline dashes
    L.polyline(latlngs, {
      color: "#e5e7eb",
      weight: 2,
      opacity: 0.7 * opMul,
      dashArray: "8 10",
    }).addTo(baseLayers.runways);
    latlngs.forEach((ll) => bounds.push(ll));
  }

  // Parking / gates — thin stand guides then numbered markers
  const parking = layout.parking || [];
  // Guides first (under markers) — open parking_position = thin centerline;
  // closed stand boxes = stroke-only outline (no fill — must not look like buildings)
  for (const p of parking) {
    const pad = p.pad;
    if (!Array.isArray(pad) || pad.length < 2) continue;
    const ring = [];
    for (const c of pad) {
      if (!c || c[0] == null || c[1] == null) continue;
      ring.push([c[0], c[1]]);
    }
    if (ring.length < 2) continue;
    const asLine = !!p.pad_line || ring.length < 3;
    if (asLine) {
      L.polyline(ring, {
        color: "#94a3b8",
        weight: 1.15,
        opacity: 0.72 * opMul,
        interactive: false,
        className: "stand-pad",
        lineCap: "round",
        lineJoin: "round",
      }).addTo(baseLayers.parking);
    } else {
      L.polygon(ring, {
        color: "#94a3b8",
        weight: 1.15,
        fill: false,
        fillOpacity: 0,
        opacity: 0.72 * opMul,
        interactive: false,
        className: "stand-pad",
      }).addTo(baseLayers.parking);
    }
  }
  const maxMarkers = dim ? 150 : 600;
  const step = parking.length > maxMarkers ? Math.ceil(parking.length / maxMarkers) : 1;
  for (let i = 0; i < parking.length; i += step) {
    const p = parking[i];
    const name = String(p.name || "").trim();
    if (!name) continue;
    // Skip raw OSM node IDs (long pure numbers) — not useful as gate labels
    if (/^\d{6,}$/.test(name)) continue;

    const isGate = p.type === "gate";
    const kind = isGate ? "Gate" : "Stand";
    const label = `${kind} ${name}`;
    const val = JSON.stringify({ lat: p.lat, lon: p.lon, label });

    // iconAnchor 0,0 + CSS centering — keep the stand lat/lon under the dot
    // (previous [0,8] + translate offset shifted labels at LEMG and other hubs)
    const icon = L.divIcon({
      className: "gate-marker",
      html:
        `<div class="gate-label ${isGate ? "is-gate" : "is-stand"}" style="opacity:${opMul}">` +
        `<span class="gate-dot"></span>` +
        `<span class="gate-name">${escapeHtml(name)}</span>` +
        `</div>`,
      iconSize: [0, 0],
      iconAnchor: [0, 0],
    });
    const m = L.marker([p.lat, p.lon], {
      icon,
      interactive: true,
      keyboard: false,
      zIndexOffset: 200,
    }).bindPopup(`${kind} <strong>${escapeHtml(name)}</strong>`);

    m.on("click", () => {
      // Taxi-in phase: gate click sets arrival stand (override auto-assign)
      if (
        (state.mode === "journey" && state.journeyStep === "taxi-in") ||
        state.activeTab === "arrival" ||
        state.mode === "arrival"
      ) {
        const stand = { lat: p.lat, lon: p.lon, label };
        setArrivalStandChoice(stand, {
          source: "user",
          reroute:
            !!state.sim.connected &&
            state.sim.onGround !== false &&
            !!state.runwayEndMeta,
        });
      } else {
        setStart(p.lat, p.lon, label);
        const startSel = $("#start-select");
        if (startSel) {
          let found = false;
          for (const opt of startSel.options) {
            if (opt.value === val) {
              found = true;
              break;
            }
          }
          if (!found) {
            const opt = document.createElement("option");
            opt.value = val;
            opt.textContent = label;
            startSel.appendChild(opt);
          }
          startSel.value = val;
        }
      }
    });
    m.addTo(baseLayers.parking);
  }

  // Holding / hold-short positions (horizontal bar — simpler to read)
  const holds = layout.holds || [];
  for (const h of holds) {
    if (h.lat == null || h.lon == null) continue;
    const hName = String(h.name || "Hold").trim() || "Hold";
    const icon = L.divIcon({
      className: "hold-marker",
      html:
        `<div class="hold-label" style="opacity:${opMul}">` +
        `<span class="hold-bar"></span>` +
        `<span class="hold-name">${escapeHtml(hName)}</span>` +
        `</div>`,
      iconSize: [0, 0],
      iconAnchor: [0, 0],
    });
    L.marker([h.lat, h.lon], {
      icon,
      interactive: true,
      keyboard: false,
      zIndexOffset: 180,
    })
      .bindPopup(`Holding point <strong>${escapeHtml(hName)}</strong>`)
      .addTo(baseLayers.holds);
  }

  // Taxiway name labels + runway numbers at thresholds
  addTaxiwayLabels(layout);
  // Runway labels only for active/interactive chart to avoid clutter
  if (taxiInteractive) {
    addRunwayLabels(layout, state.runwayEnds || []);
  }

  highlightClearanceTaxiways();
}

function addTaxiwayLabels(layout) {
  const best = new Map(); // name -> {len, mid}
  for (const tw of layout.taxiways || []) {
    if (!tw.name || tw.name === "UNNAMED" || tw.coords.length < 2) continue;
    let len = 0;
    for (let i = 1; i < tw.coords.length; i++) {
      const a = tw.coords[i - 1];
      const b = tw.coords[i];
      const dlat = a[0] - b[0];
      const dlon = a[1] - b[1];
      len += Math.sqrt(dlat * dlat + dlon * dlon);
    }
    const mid = tw.coords[Math.floor(tw.coords.length / 2)];
    const prev = best.get(tw.name);
    if (!prev || len > prev.len) {
      best.set(tw.name, { len, mid });
    }
  }
  for (const [name, info] of best) {
    const icon = L.divIcon({
      className: "",
      html: `<div class="marker-label">${name}</div>`,
      iconSize: null,
      iconAnchor: [12, 10],
    });
    L.marker(info.mid, { icon, interactive: false }).addTo(baseLayers.labels);
  }
}

function parseRwyHeading(desig) {
  const m = String(desig).trim().match(/^(\d{1,2})/);
  if (!m) return null;
  let n = parseInt(m[1], 10);
  if (n === 0) n = 36;
  return (n % 36) * 10;
}

function bearingDeg(a, b) {
  const toRad = Math.PI / 180;
  const lat1 = a[0] * toRad;
  const lat2 = b[0] * toRad;
  const dlon = (b[1] - a[1]) * toRad;
  const y = Math.sin(dlon) * Math.cos(lat2);
  const x =
    Math.cos(lat1) * Math.sin(lat2) -
    Math.sin(lat1) * Math.cos(lat2) * Math.cos(dlon);
  return ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360;
}

function headingDelta(a, b) {
  const d = Math.abs(a - b) % 360;
  return Math.min(d, 360 - d);
}

/**
 * Nudge a label away from already-placed labels that share nearly the same tip
 * (crossing runways, e.g. EIDW 28L / 34). Offset is perpendicular to approach
 * heading so the designator stays near its threshold.
 */
function resolveRunwayLabelPosition(lat, lon, approachHdg, placed, minSepM = 55) {
  let outLat = lat;
  let outLon = lon;
  const hdg =
    approachHdg != null && Number.isFinite(Number(approachHdg))
      ? Number(approachHdg)
      : 0;
  // Perpendicular to leave heading (right-hand side of approach)
  const perp = (hdg + 90) % 360;
  const toRad = Math.PI / 180;
  const mPerDegLat = 111320;
  const mPerDegLon = 111320 * Math.max(0.2, Math.cos(lat * toRad));

  for (let attempt = 0; attempt < 4; attempt++) {
    let clash = false;
    for (const p of placed) {
      if (haversineM(outLat, outLon, p.lat, p.lon) < minSepM) {
        clash = true;
        break;
      }
    }
    if (!clash) break;
    const step = minSepM * (attempt + 1) * 0.55;
    const rad = perp * toRad;
    // alternate sides each attempt
    const sign = attempt % 2 === 0 ? 1 : -1;
    outLat = lat + (sign * step * Math.cos(rad)) / mPerDegLat;
    outLon = lon + (sign * step * Math.sin(rad)) / mPerDegLon;
  }
  return { lat: outLat, lon: outLon };
}

/** Place large runway designator labels at each threshold. */
function addRunwayLabels(layout, runwayEnds) {
  const placed = [];

  // Prefer API-computed ends (deduped, real numbers like 07 / 25)
  if (runwayEnds && runwayEnds.length) {
    for (const re of runwayEnds) {
      const n = String(re.name || "");
      if (!n || /\(A\)|\(B\)/i.test(n) || n.toUpperCase() === "RWY") continue;
      const pos = resolveRunwayLabelPosition(
        re.lat,
        re.lon,
        re.approach_hdg,
        placed
      );
      placeRunwayLabel(pos.lat, pos.lon, n);
      placed.push(pos);
    }
    return;
  }

  // Fallback: per-runway ends from layout, then geometry
  for (const rw of layout.runways || []) {
    if (rw.ends && rw.ends.length >= 2) {
      for (const e of rw.ends) {
        const pos = resolveRunwayLabelPosition(
          e.lat,
          e.lon,
          e.approach_hdg,
          placed
        );
        placeRunwayLabel(pos.lat, pos.lon, e.name);
        placed.push(pos);
      }
      continue;
    }
    const coords = rw.coords || [];
    if (coords.length < 2) continue;
    const name = rw.name || "";
    const parts = name.replace(/\s+/g, "").split("/").filter(Boolean);
    const endA = coords[0];
    const endB = coords[coords.length - 1];
    if (parts.length >= 2 && /^\d/.test(parts[0])) {
      // Designator at a threshold = landing course FROM that end TO the far end
      const h0 = parseRwyHeading(parts[0]);
      const leaveA = bearingDeg(endA, endB);
      const leaveB = bearingDeg(endB, endA);
      let nameA = parts[0];
      let nameB = parts[1];
      if (h0 != null) {
        if (headingDelta(leaveA, h0) > headingDelta(leaveB, h0)) {
          nameA = parts[1];
          nameB = parts[0];
        }
      }
      let posA = resolveRunwayLabelPosition(endA[0], endA[1], leaveA, placed);
      placeRunwayLabel(posA.lat, posA.lon, nameA);
      placed.push(posA);
      let posB = resolveRunwayLabelPosition(endB[0], endB[1], leaveB, placed);
      placeRunwayLabel(posB.lat, posB.lon, nameB);
      placed.push(posB);
    }
  }
}

function placeRunwayLabel(lat, lon, text) {
  const icon = L.divIcon({
    className: "",
    html: `<div class="runway-label">${escapeHtml(String(text))}</div>`,
    iconSize: null,
    iconAnchor: [18, 12],
  });
  L.marker([lat, lon], { icon, interactive: false, zIndexOffset: 500 }).addTo(
    baseLayers.labels
  );
}

function highlightClearanceTaxiways() {
  // reset all named taxiways (unnamed connectors stay warm yellow via redraw)
  for (const [, lines] of state.twyLayerByName) {
    for (const line of lines) {
      line.setStyle({ color: "#f0c040", weight: 3.5, opacity: 0.9 });
    }
  }
  const names = isArrivalTaxiMode()
    ? state.arrClearance || []
    : state.clearance || [];
  // Orange for BOTH — never cyan (cyan is reserved for the single taxi path;
  // inbound cyan highlights looked like multiple blue route lines).
  const color = "#f97316";
  for (const name of names) {
    const lines = state.twyLayerByName.get(name) || [];
    for (const line of lines) {
      line.setStyle({ color, weight: 5, opacity: 1 });
    }
  }
}

function highlightArrClearanceTaxiways() {
  highlightClearanceTaxiways();
}

// ── Selects ──────────────────────────────────────────────────────
function runwayOptionValue(re) {
  return JSON.stringify({
    lat: re.lat,
    lon: re.lon,
    label: `RWY ${re.name}`,
    name: re.name,
    approach_hdg: re.approach_hdg ?? null,
    runway: re.runway || null,
  });
}

function fillRunwaySelect(sel, ends, placeholder) {
  sel.disabled = false;
  sel.innerHTML = `<option value="">${placeholder}</option>`;
  for (const re of ends || []) {
    const opt = document.createElement("option");
    opt.value = runwayOptionValue(re);
    opt.textContent = `Runway ${re.name}${
      re.runway && re.runway !== re.name ? ` (${re.runway})` : ""
    }`;
    sel.appendChild(opt);
  }
}

function populateSelects(data) {
  const startSel = $("#start-select");
  const rwySel = $("#runway-select");
  const depRwy = $("#dep-runway-select");
  const arrRwy = $("#arr-runway-select");
  const arrStand = $("#arr-stand-select");

  startSel.disabled = false;
  startSel.innerHTML = `<option value="">— Click map or pick stand (${(data.layout.parking || []).length}) —</option>`;
  const parking = [...(data.layout.parking || [])];
  // Backend already sorts; keep stable natural-ish order
  for (const p of parking) {
    const opt = document.createElement("option");
    const label = `${p.type === "gate" ? "Gate" : "Stand"} ${p.name}`;
    opt.value = JSON.stringify({ lat: p.lat, lon: p.lon, label });
    opt.textContent = label;
    startSel.appendChild(opt);
  }

  // Arrival stand list
  if (arrStand) {
    arrStand.disabled = false;
    arrStand.innerHTML = `<option value="">— Select stand for taxi-in (${parking.length}) —</option>`;
    for (const p of parking) {
      const opt = document.createElement("option");
      const label = `${p.type === "gate" ? "Gate" : "Stand"} ${p.name}`;
      opt.value = JSON.stringify({ lat: p.lat, lon: p.lon, label });
      opt.textContent = label;
      arrStand.appendChild(opt);
    }
    arrStand.onchange = () => {
      if (!arrStand.value) {
        state.arrivalStand = null;
        if (!state.arrPick) state.arrPick = { stand: null, runway: null };
        state.arrPick.stand = null;
        state._arrStandSource = null;
        baseLayers.markers.eachLayer((layer) => {
          if (layer._isArrStand) baseLayers.markers.removeLayer(layer);
        });
        updateArrTaxiButtons();
        return;
      }
      const v = JSON.parse(arrStand.value);
      const stand = { lat: v.lat, lon: v.lon, label: v.label };
      // User override — rebuild taxi-in from live aircraft when connected
      setArrivalStandChoice(stand, {
        source: "user",
        reroute:
          !!state.sim.connected &&
          state.sim.onGround !== false &&
          !!state.runwayEndMeta,
      });
    };
  }

  const ends = data.runway_ends || [];
  fillRunwaySelect(rwySel, ends, "— Select runway —");
  fillRunwaySelect(depRwy, ends, "— Select departure runway —");
  fillRunwaySelect(arrRwy, ends, "— Select landing runway —");

  startSel.onchange = () => {
    if (!startSel.value) return;
    const v = JSON.parse(startSel.value);
    setStart(v.lat, v.lon, v.label);
  };

  const onRwyChange = (sel, alsoArrival) => {
    if (!sel.value) return;
    const v = JSON.parse(sel.value);
    applyRunwaySelection(v, { syncFrom: sel.id, forArrival: alsoArrival });
  };

  rwySel.onchange = () => onRwyChange(rwySel, false);
  depRwy.onchange = () => onRwyChange(depRwy, false);
  arrRwy.onchange = () => onRwyChange(arrRwy, true);

  $("#btn-route").disabled = false;
  $("#btn-dep-suggest").disabled = false;
  $("#btn-arr-suggest").disabled = false;

  // Runway ends just (re)loaded — refresh METAR wind hint if we have weather
  updateRunwaySuggestion();
}

function applyRunwaySelection(v, { syncFrom, forArrival } = {}) {
  const meta = {
    name: v.name,
    lat: v.lat,
    lon: v.lon,
    approach_hdg: v.approach_hdg,
    runway: v.runway,
  };
  // Explicit only: never infer from isArrivalTaxiMode() alone — that made
  // landing runway overwrite taxi-out destination (e.g. 07 instead of 25).
  const asArrival =
    !!forArrival || syncFrom === "arr-runway-select";
  if (asArrival) {
    if (!state.arrPick) state.arrPick = { stand: null, runway: null };
    state.arrPick.runway = { ...meta };
    // Keep runwayEndMeta for STAR/taxi-in panels, but do NOT move taxi-out end marker
    state.runwayEndMeta = meta;
  } else {
    if (!state.depPick) state.depPick = { start: null, runway: null };
    state.depPick.runway = { ...meta };
    state.runwayEndMeta = meta;
    setEnd(v.lat, v.lon, v.label || (v.name ? `RWY ${v.name}` : "Runway"));
  }
  syncRunwayDropdowns(meta, { forArrival: asArrival, syncFrom });
  if (asArrival) {
    onRunwayChangedForArrival();
  } else {
    onRunwayChangedForDeparture();
  }
  updateArrTaxiButtons();
  updateRouteButton();
  scheduleSessionPush();
}

function updateArrTaxiButtons() {
  const ready = !!(state.airport && state.runwayEndMeta && state.arrivalStand);
  const a = $("#btn-arr-taxi-show");
  const b = $("#btn-arr-taxi-best");
  if (a) a.disabled = !ready;
  if (b) b.disabled = !ready;
}

function setStart(lat, lon, label, opts = {}) {
  const pick = { lat, lon, label };
  state.start = pick;
  // Remember for taxi-out (don't clobber when restore re-applies)
  if (opts.remember !== false && !isArrivalTaxiMode()) {
    if (!state.depPick) state.depPick = { start: null, runway: null };
    state.depPick.start = { ...pick };
  }
  baseLayers.markers.eachLayer((layer) => {
    if (layer._isStart) baseLayers.markers.removeLayer(layer);
  });
  const m = L.circleMarker([lat, lon], {
    radius: 9,
    color: "#22c55e",
    fillColor: "#16a34a",
    fillOpacity: 1,
    weight: 3,
  }).bindPopup(`Start: <strong>${label || "Position"}</strong>`);
  m._isStart = true;
  m.addTo(baseLayers.markers);
  updateRouteButton();
  scheduleSessionPush();
}

function setEnd(lat, lon, label) {
  state.end = { lat, lon, label };
  baseLayers.markers.eachLayer((layer) => {
    if (layer._isEnd) baseLayers.markers.removeLayer(layer);
  });
  const m = L.circleMarker([lat, lon], {
    radius: 9,
    color: "#ef4444",
    fillColor: "#b91c1c",
    fillOpacity: 1,
    weight: 3,
  }).bindPopup(`Runway: <strong>${label || "End"}</strong>`);
  m._isEnd = true;
  m.addTo(baseLayers.markers);
  updateRouteButton();
  scheduleSessionPush();
}

function updateRouteButton() {
  $("#btn-route").disabled = !(state.airport && state.start && state.end);
}

// ── Clearance UI ─────────────────────────────────────────────────
function renderTaxiwayButtons(names) {
  // Outbound grid
  fillTwyGrid($("#twy-grid"), names, (name) => addToClearance(name), state.clearance);
  // Inbound grid (same names from active arrival chart)
  fillTwyGrid(
    $("#arr-twy-grid"),
    names,
    (name) => addToArrClearance(name),
    state.arrClearance || []
  );
}

function fillTwyGrid(grid, names, onClick, selectedList) {
  if (!grid) return;
  grid.innerHTML = "";
  if (!names.length) {
    grid.innerHTML =
      '<span style="font-size:0.8rem;color:var(--text-muted)">No named taxiways in OSM for this airport.</span>';
    return;
  }
  for (const name of names) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "twy-btn";
    btn.textContent = name;
    btn.dataset.name = name;
    if ((selectedList || []).includes(name)) btn.classList.add("selected");
    btn.addEventListener("click", () => onClick(name));
    grid.appendChild(btn);
  }
}

/** Add taxiway to clearance, or remove it if already selected (no duplicates). */
function toggleClearanceToken(list, name) {
  if (!list || !name) return;
  const idx = list.lastIndexOf(name);
  if (idx >= 0) list.splice(idx, 1);
  else list.push(name);
}

function addToClearance(name) {
  if (!name) return;
  toggleClearanceToken(state.clearance, name);
  renderClearance();
  highlightClearanceTaxiways();
  // Re-route so orange selection actually moves the cyan path
  maybeRerouteAfterClearanceChange();
  scheduleSessionPush();
}

function removeClearanceAt(index) {
  state.clearance.splice(index, 1);
  renderClearance();
  highlightClearanceTaxiways();
  maybeRerouteAfterClearanceChange();
  scheduleSessionPush();
}

/** After clearance pills change, refresh taxi-out path if start/runway are set. */
function maybeRerouteAfterClearanceChange() {
  if (!state.airport || !state.start || !state.end) return;
  // Debounce rapid multi-clicks on taxiway pills
  clearTimeout(state._clearanceRerouteTimer);
  state._clearanceRerouteTimer = setTimeout(() => {
    computeRoute(true, { quiet: true, skipFit: true }).then((data) => {
      if (data) {
        setStatus(
          data.message ||
            (state.clearance.length
              ? "Path updated for clearance " + state.clearance.join(" → ")
              : "Path updated"),
          "ok"
        );
      }
    });
  }, 280);
}

function renderClearance() {
  const row = $("#clearance-row");
  if (!row) return;
  row.innerHTML = "";
  state.clearance.forEach((name, i) => {
    const pill = document.createElement("span");
    pill.className = "twy-pill";
    pill.innerHTML = `${escapeHtml(name)} <span class="x">✕</span>`;
    pill.title = "Remove";
    pill.addEventListener("click", () => removeClearanceAt(i));
    row.appendChild(pill);
  });
  // mark selected buttons (outbound grid only)
  document.querySelectorAll("#twy-grid .twy-btn").forEach((btn) => {
    btn.classList.toggle("selected", state.clearance.includes(btn.dataset.name));
  });
  const textEl = $("#clearance-text");
  if (textEl && document.activeElement !== textEl) {
    textEl.value = state.clearance.join(" ");
  }
}

function addToArrClearance(name) {
  if (!name) return;
  if (!state.arrClearance) state.arrClearance = [];
  toggleClearanceToken(state.arrClearance, name);
  renderArrClearance();
  highlightArrClearanceTaxiways();
  maybeRerouteTaxiInAfterClearanceChange();
  scheduleSessionPush();
}

function maybeRerouteTaxiInAfterClearanceChange() {
  if (!state.airport || !state.arrivalStand || !state.runwayEndMeta) return;
  clearTimeout(state._arrClearanceRerouteTimer);
  state._arrClearanceRerouteTimer = setTimeout(() => {
    if (typeof computeTaxiIn === "function") {
      computeTaxiIn(true, { quiet: true, skipFit: true });
    }
  }, 280);
}

function removeArrClearanceAt(index) {
  if (!state.arrClearance) return;
  state.arrClearance.splice(index, 1);
  renderArrClearance();
  highlightArrClearanceTaxiways();
  maybeRerouteTaxiInAfterClearanceChange();
  scheduleSessionPush();
}

function renderArrClearance() {
  const row = $("#arr-clearance-row");
  if (row) {
    row.innerHTML = "";
    (state.arrClearance || []).forEach((name, i) => {
      const pill = document.createElement("span");
      pill.className = "twy-pill";
      pill.innerHTML = `${escapeHtml(name)} <span class="x">✕</span>`;
      pill.title = "Remove";
      pill.addEventListener("click", () => removeArrClearanceAt(i));
      row.appendChild(pill);
    });
  }
  document.querySelectorAll("#arr-twy-grid .twy-btn").forEach((btn) => {
    btn.classList.toggle(
      "selected",
      (state.arrClearance || []).includes(btn.dataset.name)
    );
  });
  const textEl = $("#arr-taxi-clearance");
  if (textEl && document.activeElement !== textEl) {
    textEl.value = (state.arrClearance || []).join(" ");
  }
}

function syncArrClearanceFromText() {
  const parsed = parseClearanceText($("#arr-taxi-clearance")?.value || "");
  state.arrClearance = parsed;
  renderArrClearance();
  highlightArrClearanceTaxiways();
}

function clearTaxiPage() {
  // Clearance
  state.clearance = [];
  const textEl = $("#clearance-text");
  if (textEl) textEl.value = "";
  renderClearance();
  highlightClearanceTaxiways();
  // Drawn taxi-out path + summary
  clearRoute();
  setStatus("Taxi path and clearance cleared", "ok");
}

const btnClearTaxi = $("#btn-clear-clearance");
if (btnClearTaxi) {
  btnClearTaxi.addEventListener("click", (e) => {
    e.preventDefault();
    clearTaxiPage();
  });
}

const PHONETIC = {
  ALPHA: "A",
  BRAVO: "B",
  CHARLIE: "C",
  DELTA: "D",
  ECHO: "E",
  FOXTROT: "F",
  GOLF: "G",
  HOTEL: "H",
  INDIA: "I",
  JULIET: "J",
  JULIETT: "J",
  KILO: "K",
  LIMA: "L",
  MIKE: "M",
  NOVEMBER: "N",
  OSCAR: "O",
  PAPA: "P",
  QUEBEC: "Q",
  ROMEO: "R",
  SIERRA: "S",
  TANGO: "T",
  UNIFORM: "U",
  VICTOR: "V",
  WHISKEY: "W",
  XRAY: "X",
  "X-RAY": "X",
  YANKEE: "Y",
  ZULU: "Z",
};

// Dual-lane colour words (EDDM E3 blue / orange, etc.)
const TAXI_COLOURS = new Set([
  "BLUE",
  "ORANGE",
  "YELLOW",
  "GREEN",
  "RED",
  "WHITE",
  "BLACK",
  "BROWN",
  "GREY",
  "GRAY",
  "PURPLE",
  "PINK",
]);

function parseClearanceText(text) {
  const raw = text.toUpperCase().replace(/,/g, " ").replace(/\s+/g, " ").trim();
  if (!raw) return [];
  // Remember if ATC said CROSS … RUNWAY so bare 18L becomes RWY18L
  const mentionsCrossRwy = /\bCROSS\b/.test(raw) || /\bRUNWAY\b/.test(raw) || /\bRWY\b/.test(raw);
  // Drop common ATC filler words (keep runway designators like 18L)
  const skip = new Set([
    "TAXI",
    "VIA",
    "TO",
    "HOLD",
    "SHORT",
    "RUNWAY",
    "RWY",
    "CROSS",
    "AND",
    "THE",
    "AT",
    "ON",
    "FOR",
    "DEPARTURE",
  ]);
  const tokens = raw.split(" ").filter((t) => t && !skip.has(t));
  const names = state.layout?.taxiway_names || [];
  const rwyNames = new Set(
    (state.runwayEnds || [])
      .map((e) => String(e.name || "").toUpperCase())
      .filter(Boolean)
  );
  const out = [];
  for (let i = 0; i < tokens.length; i++) {
    let t = tokens[i];
    if (PHONETIC[t]) t = PHONETIC[t];

    // Join "E3 BLUE" / "D3 ORANGE" into one token when next word is a colour
    let joined = t;
    if (i + 1 < tokens.length && TAXI_COLOURS.has(tokens[i + 1])) {
      joined = t + " " + tokens[i + 1];
      i += 1;
    }

    // Runway cross / lineup: "18L" → "RWY18L" so backend allows runway surface
    if (/^\d{1,2}[LCR]?$/.test(t)) {
      if (mentionsCrossRwy || rwyNames.has(t)) {
        out.push("RWY" + t);
        continue;
      }
    }

    // Exact match (case-insensitive) against chart names
    let exact = names.find((n) => n.toUpperCase() === joined);
    if (!exact) exact = names.find((n) => n.toUpperCase() === t);
    // Bare designator: prefer unique match, else keep bare so routing can
    // accept any colour of that taxiway (backend colour-aware match).
    if (!exact && t === joined) {
      const hits = names.filter(
        (n) =>
          n.toUpperCase() === t ||
          n.toUpperCase().replace(/\s+/g, "") === t ||
          n.toUpperCase().startsWith(t + " ")
      );
      if (hits.length === 1) exact = hits[0];
    }
    if (exact) {
      out.push(exact);
      continue;
    }
    // keep token as typed (e.g. A1 or "E3 Blue")
    if (
      /^[A-Z]{1,3}\d*[A-Z]?$/.test(t) ||
      /^[A-Z]\d+[A-Z]?$/.test(t) ||
      /^[A-Z]{1,3}\d+\s+[A-Z]+$/.test(joined)
    ) {
      out.push(joined.includes(" ") ? joined : t);
    }
  }
  return out;
}

$("#clearance-text")?.addEventListener("change", () => {
  const parsed = parseClearanceText($("#clearance-text").value);
  state.clearance = parsed;
  renderClearance();
  highlightClearanceTaxiways();
  maybeRerouteAfterClearanceChange();
});

$("#clearance-text")?.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    const parsed = parseClearanceText($("#clearance-text").value);
    state.clearance = parsed;
    renderClearance();
    highlightClearanceTaxiways();
    maybeRerouteAfterClearanceChange();
  }
});

// ── Routing ──────────────────────────────────────────────────────
/**
 * @param {boolean} useClearance
 * @param {{ quiet?: boolean, fromAircraft?: boolean, skipFit?: boolean, ignoreHeading?: boolean }} opts
 */
async function computeRoute(useClearance = true, opts = {}) {
  const quiet = !!opts.quiet;
  const fromAircraft = !!opts.fromAircraft;
  // Always route to the *departure* runway pick, not a leftover landing rwy
  ensureDepRunwayActive();
  if (!state.airport || !state.end) {
    if (!quiet) setStatus("Select start position and runway first", "err");
    return null;
  }
  let startLat = state.start?.lat;
  let startLon = state.start?.lon;
  if (fromAircraft && state.sim.lat != null && state.sim.lon != null) {
    startLat = state.sim.lat;
    startLon = state.sim.lon;
    state.start = {
      lat: startLat,
      lon: startLon,
      label: quiet ? "Aircraft (auto re-route)" : "Aircraft (live)",
    };
  }
  if (startLat == null || startLon == null) {
    if (!quiet) setStatus("Select start position and runway first", "err");
    return null;
  }
  if (!quiet) {
    setLoading(true, "Computing taxi path…");
    setStatus(
      "Routing to " +
        (state.runwayEndMeta?.name
          ? "RWY " + state.runwayEndMeta.name
          : state.end?.label || "runway") +
        "…",
      "busy"
    );
  }
  try {
    // Opposite end of the *dep* runway pair (for threshold snap bias)
    const far = getOppositeRunwayEnd();
    const routeBody = {
      icao: state.airport.icao,
      start_lat: startLat,
      start_lon: startLon,
      end_lat: state.end.lat,
      end_lon: state.end.lon,
      clearance: useClearance ? state.clearance : [],
      // Always target the runway *threshold end*, not a mid-runway join
      end_is_runway_threshold: true,
      far_lat: far?.lat ?? null,
      far_lon: far?.lon ?? null,
    };
    // Live re-route: pass heading so the pathfinder won't U-turn the aircraft
    // (can be skipped when heading blocks snaps on the runway / heading-up)
    if (
      fromAircraft &&
      !opts.ignoreHeading &&
      state.sim.heading != null &&
      Number.isFinite(Number(state.sim.heading))
    ) {
      routeBody.start_heading_deg = Number(state.sim.heading);
    }
    const res = await fetch("/api/route", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(routeBody),
    });
    const data = await res.json();
    if (!data.ok) {
      throw new Error(data.error || "Routing failed");
    }
    drawRoute(data, { skipFit: quiet || !!opts.skipFit });
    showRouteSummary(data);
    try {
      if (!state.manualTaxiPath) state.manualTaxiPath = { route: false, taxiIn: false };
      // Auto / Show / Best replaces a hand-drawn path
      if (!opts.fromManual) state.manualTaxiPath.route = false;
    } catch (_) {}
    setStatus(
      quiet
        ? "Taxi path updated from aircraft position"
        : data.message || "Route ready",
      "ok"
    );
    return data;
  } catch (err) {
    console.error(err);
    if (!quiet) {
      setStatus(err.message, "err");
      $("#route-summary").classList.remove("visible");
    }
    return null;
  } finally {
    if (!quiet) setLoading(false);
  }
}

function drawRoute(data, opts = {}) {
  baseLayers.route.clearLayers();
  if (!data.coords || data.coords.length < 2) {
    clearPathTrack("route");
    if (!opts.fromSnapshot) clearPathSnapshot("route");
    return;
  }
  // One continuous path (dedupe consecutive duplicate points from via stitching)
  const latlngs = [];
  for (const c of data.coords) {
    const ll = [c[0], c[1]];
    const prev = latlngs[latlngs.length - 1];
    if (
      prev &&
      Math.abs(prev[0] - ll[0]) < 1e-9 &&
      Math.abs(prev[1] - ll[1]) < 1e-9
    ) {
      continue;
    }
    latlngs.push(ll);
  }
  if (latlngs.length < 2) return;
  ensurePathLayerVisible("route");
  // Soft under-glow + single cyan stroke (not two competing “routes”)
  L.polyline(latlngs, {
    color: "#0891b2",
    weight: 10,
    opacity: 0.22,
    lineCap: "round",
    lineJoin: "round",
    // Keep intersection fillets accurate (Leaflet simplify was squaring curves)
    smoothFactor: 0,
    interactive: false,
  }).addTo(baseLayers.route);
  L.polyline(latlngs, {
    color: "#22d3ee",
    weight: 5,
    opacity: 1,
    lineCap: "round",
    lineJoin: "round",
    smoothFactor: 0,
  })
    .bindPopup(data.message || "Taxi path")
    .addTo(baseLayers.route);
  setPathTrack("route", latlngs, { name: "Taxi out" });
  if (!opts.fromSnapshot) {
    savePathSnapshot("route", {
      data: { ...data, coords: latlngs },
      start: state.start ? { ...state.start } : null,
      end: state.end ? { ...state.end } : null,
    });
  }
  if (state.sim.lat != null && !opts.fromSnapshot) {
    updateActiveLeg(state.sim.lat, state.sim.lon);
  }
  if (!opts.skipFit) {
    map.fitBounds(latlngs, { padding: [50, 50], maxZoom: 17 });
  }
}

function clearRoute() {
  baseLayers.route.clearLayers();
  clearPathTrack("route");
  clearPathSnapshot("route");
  $("#route-summary")?.classList?.remove("visible");
  try {
    if (state.manualTaxiPath) state.manualTaxiPath.route = false;
  } catch (_) {}
  // keep departure until explicitly cleared
}

function showRouteSummary(data) {
  const el = $("#route-summary");
  el.classList.add("visible");
  $("#route-dist").textContent = `${data.distance_nm} NM · ${data.distance_m} m`;
  $("#route-msg").textContent = data.message || "";
  const via = (data.taxiways_used || []).join(" → ");
  $("#route-via").textContent = via ? `VIA ${via}` : "";
}

$("#btn-route")?.addEventListener("click", () => computeRoute(true));
$("#btn-auto-route")?.addEventListener("click", () => computeRoute(false));

// ── Departures / SIDs ────────────────────────────────────────────
async function onRunwayChangedForDeparture() {
  if (!state.airport || !state.runwayEndMeta) {
    resetDepSelect();
    return;
  }
  const sugBtn = $("#btn-dep-suggest");
  const showBtn = $("#btn-dep-show");
  if (sugBtn) sugBtn.disabled = false;
  if (showBtn) showBtn.disabled = false;
  // Load published SIDs for this runway into the dropdown
  try {
    const rwy = encodeURIComponent(state.runwayEndMeta.name || "");
    const res = await fetch(
      `/api/airports/${encodeURIComponent(state.airport.icao)}/departures?runway=${rwy}`
    );
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(formatApiError(data, "Could not load SIDs"));
    const catalog = (data.sids || []).map((s) => ({
      ...s,
      kind: "sid",
    }));
    if (catalog.length) {
      state.depSuggestions = catalog;
      populateDepSelect(
        catalog,
        `SIDs for RWY ${state.runwayEndMeta.name} (catalog + SimBrief)`
      );
      const sb = catalog.filter((s) => s.source === "simbrief").length;
      setStatus(
        `${catalog.length} SID(s) for RWY ${state.runwayEndMeta.name}` +
          (sb ? ` · ${sb} from SimBrief` : ""),
        "ok"
      );
      return;
    }
    setStatus("No published SIDs — loading suggested departures…", "busy");
    await loadSuggestions({ quiet: true });
  } catch (err) {
    console.error(err);
    setStatus(err.message || "Could not load SIDs", "err");
    try {
      await loadSuggestions({ quiet: true });
    } catch (_) {
      resetDepSelect();
    }
  }
}

function resetDepSelect() {
  const sel = $("#dep-select");
  if (sel) {
    sel.disabled = true;
    sel.innerHTML = `<option value="">Select runway first</option>`;
  }
  const show = $("#btn-dep-show");
  if (show) show.disabled = true;
  const sug = $("#btn-dep-suggest");
  if (sug) sug.disabled = !state.runwayEndMeta;
}

function formatApiError(data, fallback) {
  if (!data) return fallback;
  const d = data.detail;
  if (typeof d === "string") return d;
  if (Array.isArray(d)) {
    return d
      .map((x) => (typeof x === "string" ? x : x.msg || JSON.stringify(x)))
      .join("; ");
  }
  if (data.error) return String(data.error);
  if (data.message) return String(data.message);
  return fallback;
}

function ensurePathLayerVisible(key) {
  state.layerVisibility[key] = true;
  const layer = baseLayers[key];
  if (layer && !map.hasLayer(layer)) layer.addTo(map);
  document.querySelectorAll(`.layer-chip[data-layer="${key}"]`).forEach((chip) => {
    chip.classList.add("active");
  });
}

function savePathSnapshot(key, payload) {
  if (!state.pathSnapshots) {
    state.pathSnapshots = {
      route: null,
      taxiIn: null,
      departure: null,
      arrival: null,
    };
  }
  state.pathSnapshots[key] = payload || null;
  scheduleSessionPush();
}

function clearPathSnapshot(key) {
  if (state.pathSnapshots) state.pathSnapshots[key] = null;
}

function clearAllPathSnapshots() {
  state.pathSnapshots = {
    route: null,
    taxiIn: null,
    departure: null,
    arrival: null,
  };
}

/**
 * Re-paint saved taxi / SID / STAR / enroute paths after switching modes or
 * journey steps. Snapshots survive tab changes; only Clear / full reload wipes them.
 */
function restoreAllPathLayers() {
  const snaps = state.pathSnapshots || {};
  const prevRelink = state._skipPathRelink;
  state._skipPathRelink = true;
  try {
    if (snaps.route?.data) {
      drawRoute(snaps.route.data, { skipFit: true, fromSnapshot: true });
      try {
        showRouteSummary(snaps.route.data);
      } catch (_) {}
      if (snaps.route.start) {
        setStart(
          snaps.route.start.lat,
          snaps.route.start.lon,
          snaps.route.start.label,
          { remember: false }
        );
      }
      if (snaps.route.end) {
        setEnd(
          snaps.route.end.lat,
          snaps.route.end.lon,
          snaps.route.end.label
        );
      }
    }
    if (snaps.taxiIn?.data) {
      drawTaxiIn(snaps.taxiIn.data, snaps.taxiIn.startInfo || null, {
        skipFit: true,
        fromSnapshot: true,
      });
    }
    if (snaps.departure?.data) {
      drawDeparture(snaps.departure.data, {
        skipFit: true,
        fromSnapshot: true,
      });
    }
    if (snaps.arrival?.data) {
      drawArrival(snaps.arrival.data, { skipFit: true, fromSnapshot: true });
    }
    if (state.flightPlan) {
      drawFlightPlan(state.flightPlan, { fit: false, skipStitch: true });
    }
    applyLayerVisibility();
    bringPathLayersToFront();
  } catch (err) {
    console.warn("restoreAllPathLayers", err);
  } finally {
    state._skipPathRelink = prevRelink;
    try {
      // Full-track (SimBrief) plans only refresh link flags — never strip mid-fixes
      if (!state._skipPathRelink) relinkFlightPlanToProcedures();
    } catch (_) {}
    if (state.sim.lat != null) {
      try {
        updateActiveLeg(state.sim.lat, state.sim.lon);
      } catch (_) {}
    }
  }
}

function populateDepSelect(items, placeholder) {
  const sel = $("#dep-select");
  if (!sel) return;
  sel.disabled = false;
  sel.innerHTML = "";
  const ph = document.createElement("option");
  ph.value = "";
  ph.textContent = placeholder || "— Select departure —";
  sel.appendChild(ph);
  for (const s of items) {
    const opt = document.createElement("option");
    opt.value = s.id;
    let tag = s.kind === "sid" ? "SID" : s.type || "SUG";
    if (s.source === "simbrief") tag = "SimBrief";
    opt.textContent = `[${tag}] ${s.name}`;
    opt.title = s.description || "";
    sel.appendChild(opt);
  }
  const showBtn = $("#btn-dep-show");
  if (showBtn) showBtn.disabled = false;
}

async function loadSuggestions(opts = {}) {
  const quiet = !!opts.quiet;
  if (!state.airport || !state.runwayEndMeta) {
    if (!quiet) setStatus("Select a departure runway first", "err");
    return;
  }
  if (!quiet) {
    setLoading(true, "Finding departure options…");
    setStatus("Suggesting departures…", "busy");
  }
  try {
    const res = await fetch("/api/departures/suggest", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        icao: state.airport.icao,
        runway: {
          name: String(state.runwayEndMeta.name || ""),
          lat: Number(state.runwayEndMeta.lat),
          lon: Number(state.runwayEndMeta.lon),
          approach_hdg:
            state.runwayEndMeta.approach_hdg != null
              ? Number(state.runwayEndMeta.approach_hdg)
              : null,
          runway: state.runwayEndMeta.runway || null,
        },
        limit: 8,
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(formatApiError(data, "Suggest failed"));
    state.depSuggestions = data.suggestions || [];
    populateDepSelect(
      state.depSuggestions,
      quiet
        ? `Suggested for RWY ${state.runwayEndMeta.name} (no published SIDs)`
        : `Suggestions for RWY ${state.runwayEndMeta.name}`
    );
    setStatus(
      `${state.depSuggestions.length} departure option(s) for RWY ${state.runwayEndMeta.name}`,
      "ok"
    );
    if (!quiet) {
      setHint("Pick a SID or suggested route, then <strong>Show SID</strong>", true);
      setTimeout(() => setHint("", false), 4000);
    }
  } catch (err) {
    console.error(err);
    setStatus(err.message || "Suggest failed", "err");
  } finally {
    if (!quiet) setLoading(false);
  }
}

async function showDeparture() {
  if (!state.airport || !state.runwayEndMeta) {
    setStatus("Select a departure runway first", "err");
    return;
  }
  // Prefer departure runway pick (don't use a leftover landing rwy)
  if (typeof ensureDepRunwayActive === "function") ensureDepRunwayActive();
  const sel = $("#dep-select");
  let sidId = sel ? sel.value : "";
  const atcEl = $("#dep-atc");
  const atcText = (atcEl && atcEl.value ? atcEl.value : "").trim();

  if (!sidId && !atcText) {
    setStatus(
      "Pick a SID, or type ATC clearance (e.g. HELDO2A or HELDO2A: HELDO BOMBI)",
      "err"
    );
    return;
  }

  let meta = (state.depSuggestions || []).find((s) => s.id === sidId) || null;
  // ATC text wins when filled — VATSIM SID often isn't in the dropdown
  if (atcText) {
    sidId = "AUTO";
    meta = null;
  }

  setLoading(true, "Building departure route…");
  setStatus("Building SID / departure path…", "busy");
  try {
    const res = await fetch("/api/departures/route", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        icao: state.airport.icao,
        runway: {
          name: String(state.runwayEndMeta.name || ""),
          lat: Number(state.runwayEndMeta.lat),
          lon: Number(state.runwayEndMeta.lon),
          approach_hdg:
            state.runwayEndMeta.approach_hdg != null
              ? Number(state.runwayEndMeta.approach_hdg)
              : null,
          runway: state.runwayEndMeta.runway || null,
        },
        sid_id: sidId || "AUTO",
        meta: meta,
        atc_text: atcText || null,
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.ok === false) {
      throw new Error(formatApiError(data, "Could not build departure"));
    }
    drawDeparture(data);
    showDepSummary(data);
    setStatus(data.message || "Departure ready", "ok");
    try {
      const icao = state.airport?.icao || $("#fp-dep")?.value || "";
      if (
        icao &&
        window.NavApronPlates &&
        typeof window.NavApronPlates.openForProcedure === "function"
      ) {
        window.NavApronPlates.openForProcedure(
          "sid",
          icao,
          data.sid_name || data.sid_id || ""
        );
      }
    } catch (_) {}
  } catch (err) {
    console.error(err);
    setStatus(typeof err.message === "string" ? err.message : "Departure failed", "err");
    $("#dep-summary")?.classList?.remove("visible");
  } finally {
    setLoading(false);
  }
}

/**
 * Altitude / speed chips for a SID/STAR fix bubble.
 * Catalog: alt_ft, alt_min_ft, alt_max_ft, speed_kt, speed_min_kt, speed_max_kt.
 * @returns {{ alt: string|null, speed: string|null }}
 */
function procedureConstraintChips(p) {
  const out = { alt: null, speed: null };
  if (!p) return out;
  const minA = p.alt_min_ft != null ? Number(p.alt_min_ft) : null;
  const maxA = p.alt_max_ft != null ? Number(p.alt_max_ft) : null;
  const atA = p.alt_ft != null ? Number(p.alt_ft) : null;
  const fmtAlt = (ft) => {
    if (!Number.isFinite(ft)) return "";
    if (ft >= 1000 && ft % 100 === 0) {
      return "FL" + String(Math.round(ft / 100)).padStart(2, "0");
    }
    return Math.round(ft) + " ft";
  };
  if (
    minA != null &&
    maxA != null &&
    Number.isFinite(minA) &&
    Number.isFinite(maxA)
  ) {
    out.alt = minA === maxA ? fmtAlt(minA) : fmtAlt(minA) + " – " + fmtAlt(maxA);
  } else if (minA != null && Number.isFinite(minA)) {
    out.alt = "↑ " + fmtAlt(minA);
  } else if (maxA != null && Number.isFinite(maxA)) {
    out.alt = "↓ " + fmtAlt(maxA);
  } else if (atA != null && Number.isFinite(atA)) {
    out.alt = "A " + fmtAlt(atA);
  }

  const minS = p.speed_min_kt != null ? Number(p.speed_min_kt) : null;
  const maxS = p.speed_max_kt != null ? Number(p.speed_max_kt) : null;
  const atS = p.speed_kt != null ? Number(p.speed_kt) : null;
  if (
    minS != null &&
    maxS != null &&
    Number.isFinite(minS) &&
    Number.isFinite(maxS)
  ) {
    out.speed = Math.round(minS) + "–" + Math.round(maxS) + " kt";
  } else if (maxS != null && Number.isFinite(maxS)) {
    out.speed = "max " + Math.round(maxS) + " kt";
  } else if (minS != null && Number.isFinite(minS)) {
    out.speed = "min " + Math.round(minS) + " kt";
  } else if (atS != null && Number.isFinite(atS)) {
    out.speed = Math.round(atS) + " kt";
  }
  return out;
}

/** Zoom at/above which SID/STAR bubbles (not just pins) are shown. */
const PROC_LABEL_BUBBLE_MIN_ZOOM = 9;

/**
 * Bubble marker HTML: pin on the fix, card offset to one side with ident + chips.
 * Bubbles hide when zoomed out (map gets .proc-labels-compact).
 * @param {object} p
 * @param {"dep"|"arr"} kind
 * @param {{ side?: "left"|"right", pinOnly?: boolean }} opts
 */
function procedureFixLabelHtml(p, kind, opts) {
  opts = opts || {};
  const tone = kind === "arr" ? "arr" : "dep";
  const side = opts.side === "left" ? "left" : "right";
  const ident = escapeHtml(p && p.ident ? p.ident : "");
  const chips = procedureConstraintChips(p);
  const chipHtml = [];
  if (chips.alt) {
    chipHtml.push(
      `<span class="proc-chip proc-chip-alt">${escapeHtml(chips.alt)}</span>`
    );
  }
  if (chips.speed) {
    chipHtml.push(
      `<span class="proc-chip proc-chip-spd">${escapeHtml(chips.speed)}</span>`
    );
  }
  const chipsRow = chipHtml.length
    ? `<div class="proc-bubble-chips">${chipHtml.join("")}</div>`
    : "";
  // Climb/DER stubs: pin only — never a bubble on the line
  const pinOnly =
    opts.pinOnly ||
    (p && (p.kind === "climb" || p.kind === "final" || p.kind === "runway"));
  const bubble = pinOnly
    ? ""
    : `<div class="proc-bubble">` +
      `<div class="proc-bubble-ident">${ident}</div>` +
      chipsRow +
      `</div>`;
  const title = pinOnly
    ? ""
    : ` title="${ident}${chips.alt ? " · " + escapeHtml(chips.alt) : ""}${
        chips.speed ? " · " + escapeHtml(chips.speed) : ""
      }"`;
  return (
    `<div class="proc-fix-marker proc-fix-${tone} proc-side-${side}${
      pinOnly ? " proc-pin-only" : ""
    }"${title}>` +
    `<span class="proc-fix-pin" aria-hidden="true"></span>` +
    bubble +
    `</div>`
  );
}

function updateProcedureLabelVisibility() {
  try {
    if (!map || map._navapronStub) return;
    const z = typeof map.getZoom === "function" ? map.getZoom() : 0;
    const full = z >= PROC_LABEL_BUBBLE_MIN_ZOOM;
    const el = map.getContainer();
    el.classList.toggle("proc-labels-compact", !full);
    el.classList.toggle("proc-labels-full", full);
  } catch (_) {}
}

/**
 * Place SID/STAR fix markers: pins on the track, bubbles offset off-line.
 * @param {object[]} points
 * @param {"dep"|"arr"} kind
 * @param {L.LayerGroup} layer
 */
function addProcedureFixMarkers(points, kind, layer) {
  if (!layer || !points || !points.length) return;
  let labelIdx = 0;
  for (let i = 0; i < points.length; i++) {
    const p = points[i];
    if (!p || p.lat == null || p.lon == null) continue;
    if (p.kind === "runway") continue;
    const pinOnly =
      p.kind === "climb" || p.kind === "final" || p.kind === "vector";
    // Alternate sides so consecutive bubbles don't stack on the line
    const side = labelIdx % 2 === 0 ? "right" : "left";
    if (!pinOnly) labelIdx += 1;
    const icon = L.divIcon({
      className: "proc-fix-icon",
      html: procedureFixLabelHtml(p, kind, { side, pinOnly }),
      iconSize: [8, 8],
      iconAnchor: [5, 5],
    });
    L.marker([p.lat, p.lon], {
      icon,
      interactive: false,
      zIndexOffset: 380,
    }).addTo(layer);
  }
  updateProcedureLabelVisibility();
}

function drawDeparture(data, opts = {}) {
  baseLayers.departure.clearLayers();
  const coords = data.coords || (data.points || []).map((p) => [p.lat, p.lon]);
  if (!coords || coords.length < 2) {
    clearPathTrack("departure");
    if (!opts.fromSnapshot) clearPathSnapshot("departure");
    state.activeDeparture = null;
    if (!opts.fromSnapshot) setStatus("Departure path has no coordinates", "err");
    return;
  }
  if (!data.airport_icao) {
    data.airport_icao = (
      state.airport?.icao ||
      $("#fp-dep")?.value ||
      ""
    )
      .toString()
      .trim()
      .toUpperCase();
  }
  state.activeDeparture = data;
  const latlngs = unwrapLatLngs(coords.map((c) => [c[0], c[1]]));
  if (latlngs.length < 2) {
    clearPathTrack("departure");
    return;
  }

  ensurePathLayerVisible("departure");

  L.polyline(latlngs, {
    color: "#6b21a8",
    weight: 12,
    opacity: 0.3,
    lineCap: "round",
    lineJoin: "round",
  }).addTo(baseLayers.departure);

  L.polyline(latlngs, {
    color: "#c084fc",
    weight: 4,
    opacity: 1,
    dashArray: "10 8",
    lineCap: "round",
    lineJoin: "round",
  })
    .bindPopup(
      `<strong>${escapeHtml(data.sid_name || "Departure")}</strong><br>${escapeHtml(
        data.message || ""
      )}`
    )
    .addTo(baseLayers.departure);

  addProcedureFixMarkers(data.points || [], "dep", baseLayers.departure);

  const labels = (data.points || []).map((p) => p.ident || "");
  setPathTrack("departure", latlngs, {
    name: data.sid_name || "Departure",
    labels: labels.length === latlngs.length ? labels : null,
  });
  if (!opts.fromSnapshot) {
    savePathSnapshot("departure", { data });
  }
  if (state.sim.lat != null && !opts.fromSnapshot) {
    updateActiveLeg(state.sim.lat, state.sim.lon);
  }
  // Re-link enroute plan to this SID exit if a plan is on the map
  if (!opts.fromSnapshot && !state._skipPathRelink) {
    relinkFlightPlanToProcedures();
  }

  if (!opts.skipFit) {
    try {
      const b = L.latLngBounds(latlngs);
      if (b.isValid()) map.fitBounds(b.pad(0.2), { maxZoom: 12 });
    } catch (err) {
      console.warn("fitBounds departure", err);
    }
  }
  try {
    if (
      window.NavApronPlates &&
      typeof window.NavApronPlates.refreshNavapron === "function"
    ) {
      window.NavApronPlates.refreshNavapron();
    }
  } catch (_) {}
}

function clearDeparture() {
  baseLayers.departure.clearLayers();
  clearPathTrack("departure");
  clearPathSnapshot("departure");
  state.activeDeparture = null;
  $("#dep-summary")?.classList?.remove("visible");
  const atc = $("#dep-atc");
  if (atc) atc.value = "";
  relinkFlightPlanToProcedures();
  try {
    if (
      window.NavApronPlates &&
      typeof window.NavApronPlates.refreshNavapron === "function"
    ) {
      window.NavApronPlates.refreshNavapron();
    }
  } catch (_) {}
}

function showDepSummary(data) {
  const el = $("#dep-summary");
  if (!el) return;
  el.classList.add("visible");
  const dist = $("#dep-dist");
  const msg = $("#dep-msg");
  const via = $("#dep-via");
  if (dist)
    dist.textContent = `${data.distance_nm ?? "—"} NM · HDG ${data.departure_hdg ?? "—"}°`;
  if (msg) msg.textContent = data.message || data.description || "";
  if (via) {
    const path = (data.points || []).map((p) => p.ident).filter(Boolean).join(" → ");
    via.textContent = path || "";
  }
}

$("#btn-dep-suggest")?.addEventListener("click", () => loadSuggestions());
$("#btn-dep-show")?.addEventListener("click", () => showDeparture());
$("#btn-dep-clear")?.addEventListener("click", () => clearDeparture());
$("#dep-atc")?.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    showDeparture();
  }
});

// ── Arrivals / STARs ─────────────────────────────────────────────
async function onRunwayChangedForArrival() {
  if (!state.airport || !state.runwayEndMeta) {
    resetArrSelect();
    return;
  }
  const sugBtn = $("#btn-arr-suggest");
  const showBtn = $("#btn-arr-show");
  if (sugBtn) sugBtn.disabled = false;
  if (showBtn) showBtn.disabled = false;
  try {
    const rwy = encodeURIComponent(state.runwayEndMeta.name || "");
    const res = await fetch(
      `/api/airports/${encodeURIComponent(state.airport.icao)}/arrivals?runway=${rwy}`
    );
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(formatApiError(data, "Could not load STARs"));
    const catalog = (data.stars || []).map((s) => ({ ...s, kind: "star" }));
    if (catalog.length) {
      state.arrSuggestions = catalog;
      populateArrSelect(
        catalog,
        `STARs for RWY ${state.runwayEndMeta.name} (catalog + SimBrief)`
      );
      const sb = catalog.filter((s) => s.source === "simbrief").length;
      setStatus(
        `${catalog.length} STAR(s) for RWY ${state.runwayEndMeta.name}` +
          (sb ? ` · ${sb} from SimBrief` : ""),
        "ok"
      );
      return;
    }
    // No catalog entries — auto-load vector suggestions (no extra click)
    setStatus("No published STARs — loading suggested arrivals…", "busy");
    await loadArrivalSuggestions({ quiet: true });
  } catch (err) {
    console.error(err);
    setStatus(err.message || "Could not load STARs", "err");
    // Still try suggestions so dropdown is usable
    try {
      await loadArrivalSuggestions({ quiet: true });
    } catch (_) {
      resetArrSelect();
    }
  }
}

function resetArrSelect() {
  const sel = $("#arr-select");
  if (sel) {
    sel.disabled = true;
    sel.innerHTML = `<option value="">Select runway first</option>`;
  }
  const show = $("#btn-arr-show");
  if (show) show.disabled = true;
  const sug = $("#btn-arr-suggest");
  if (sug) sug.disabled = !state.runwayEndMeta;
}

function populateArrSelect(items, placeholder) {
  const sel = $("#arr-select");
  if (!sel) return;
  sel.disabled = false;
  sel.innerHTML = "";
  const ph = document.createElement("option");
  ph.value = "";
  ph.textContent = placeholder || "— Select arrival —";
  sel.appendChild(ph);
  for (const s of items) {
    const opt = document.createElement("option");
    opt.value = s.id;
    let tag = s.kind === "star" ? "STAR" : s.type || "SUG";
    if (s.source === "simbrief") tag = "SimBrief";
    opt.textContent = `[${tag}] ${s.name}`;
    opt.title = s.description || "";
    sel.appendChild(opt);
  }
  const showBtn = $("#btn-arr-show");
  if (showBtn) showBtn.disabled = false;
}

async function loadArrivalSuggestions(opts = {}) {
  const quiet = !!opts.quiet;
  if (!state.airport || !state.runwayEndMeta) {
    if (!quiet) setStatus("Select a landing runway first", "err");
    return;
  }
  if (!quiet) {
    setLoading(true, "Finding arrival options…");
    setStatus("Suggesting arrivals…", "busy");
  }
  try {
    const res = await fetch("/api/arrivals/suggest", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        icao: state.airport.icao,
        runway: {
          name: String(state.runwayEndMeta.name || ""),
          lat: Number(state.runwayEndMeta.lat),
          lon: Number(state.runwayEndMeta.lon),
          approach_hdg:
            state.runwayEndMeta.approach_hdg != null
              ? Number(state.runwayEndMeta.approach_hdg)
              : null,
          runway: state.runwayEndMeta.runway || null,
        },
        limit: 8,
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(formatApiError(data, "Suggest failed"));
    state.arrSuggestions = data.suggestions || [];
    populateArrSelect(
      state.arrSuggestions,
      quiet
        ? `Suggested for RWY ${state.runwayEndMeta.name} (no published STARs)`
        : `Suggestions for RWY ${state.runwayEndMeta.name}`
    );
    setStatus(
      `${state.arrSuggestions.length} arrival option(s) for RWY ${state.runwayEndMeta.name}`,
      "ok"
    );
    if (!quiet) {
      setHint("Pick a STAR or suggested arrival, then <strong>Show STAR</strong>", true);
      setTimeout(() => setHint("", false), 4000);
    }
  } catch (err) {
    console.error(err);
    setStatus(err.message || "Suggest failed", "err");
  } finally {
    if (!quiet) setLoading(false);
  }
}

async function showArrival() {
  if (!state.airport || !state.runwayEndMeta) {
    setStatus("Select a landing runway first", "err");
    return;
  }
  const sel = $("#arr-select");
  let starId = sel ? sel.value : "";
  const atcEl = $("#arr-atc");
  const atcText = (atcEl && atcEl.value ? atcEl.value : "").trim();
  if (!starId && !atcText) {
    setStatus(
      "Pick a STAR, or type ATC clearance (e.g. LOGAN1A or LOGAN1A: LOGAN BIG)",
      "err"
    );
    return;
  }
  let meta = (state.arrSuggestions || []).find((s) => s.id === starId) || null;
  if (atcText) {
    starId = "AUTO";
    meta = null;
  }

  setLoading(true, "Building arrival route…");
  setStatus("Building STAR / arrival path…", "busy");
  try {
    const res = await fetch("/api/arrivals/route", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        icao: state.airport.icao,
        runway: {
          name: String(state.runwayEndMeta.name || ""),
          lat: Number(state.runwayEndMeta.lat),
          lon: Number(state.runwayEndMeta.lon),
          approach_hdg:
            state.runwayEndMeta.approach_hdg != null
              ? Number(state.runwayEndMeta.approach_hdg)
              : null,
          runway: state.runwayEndMeta.runway || null,
        },
        star_id: starId || "AUTO",
        meta: meta,
        atc_text: atcText || null,
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.ok === false) {
      throw new Error(formatApiError(data, "Could not build arrival"));
    }
    drawArrival(data);
    showArrSummary(data);
    setStatus(data.message || "Arrival ready", "ok");
    try {
      const icao =
        state.destAirport?.icao ||
        state.airport?.icao ||
        $("#fp-dest")?.value ||
        "";
      if (
        icao &&
        window.NavApronPlates &&
        typeof window.NavApronPlates.openForProcedure === "function"
      ) {
        window.NavApronPlates.openForProcedure(
          "star",
          icao,
          data.star_name || data.star_id || ""
        );
      }
    } catch (_) {}
  } catch (err) {
    console.error(err);
    setStatus(typeof err.message === "string" ? err.message : "Arrival failed", "err");
    $("#arr-summary")?.classList?.remove("visible");
  } finally {
    setLoading(false);
  }
}

function drawArrival(data, opts = {}) {
  baseLayers.arrival.clearLayers();
  const coords = data.coords || (data.points || []).map((p) => [p.lat, p.lon]);
  if (!coords || coords.length < 2) {
    clearPathTrack("arrival");
    if (!opts.fromSnapshot) clearPathSnapshot("arrival");
    state.activeArrival = null;
    if (!opts.fromSnapshot) setStatus("Arrival path has no coordinates", "err");
    return;
  }
  if (!data.airport_icao) {
    data.airport_icao = (
      state.destAirport?.icao ||
      state.airport?.icao ||
      $("#fp-dest")?.value ||
      ""
    )
      .toString()
      .trim()
      .toUpperCase();
  }
  state.activeArrival = data;
  const latlngs = unwrapLatLngs(coords.map((c) => [c[0], c[1]]));
  if (latlngs.length < 2) {
    clearPathTrack("arrival");
    return;
  }
  ensurePathLayerVisible("arrival");

  // Draw STAR feeder (to FAF) thinner, final approach thicker solid green
  const points = data.points || [];
  const finalIdx = points.findIndex((p) => p.kind === "final");
  if (finalIdx > 0) {
    const feeder = latlngs.slice(0, finalIdx + 1);
    const finalSeg = latlngs.slice(finalIdx);
    if (feeder.length >= 2) {
      L.polyline(feeder, {
        color: "#4ade80",
        weight: 3,
        opacity: 0.75,
        dashArray: "8 8",
        lineCap: "round",
      }).addTo(baseLayers.arrival);
    }
    if (finalSeg.length >= 2) {
      L.polyline(finalSeg, {
        color: "#166534",
        weight: 10,
        opacity: 0.3,
        lineCap: "round",
      }).addTo(baseLayers.arrival);
      L.polyline(finalSeg, {
        color: "#4ade80",
        weight: 5,
        opacity: 1,
        lineCap: "round",
        lineJoin: "round",
      })
        .bindPopup(
          `<strong>${escapeHtml(data.star_name || "Arrival")}</strong><br>` +
            `Landing <strong>RWY ${escapeHtml(String(data.runway || ""))}</strong> ` +
            `HDG ${data.approach_hdg ?? "—"}°<br>${escapeHtml(data.message || "")}`
        )
        .addTo(baseLayers.arrival);
    }
  } else {
    L.polyline(latlngs, {
      color: "#4ade80",
      weight: 4,
      opacity: 1,
      dashArray: "12 7",
    })
      .bindPopup(escapeHtml(data.message || "Arrival"))
      .addTo(baseLayers.arrival);
  }

  for (const p of points) {
    if (p.kind === "runway") {
      // Landing threshold marker
      L.circleMarker([p.lat, p.lon], {
        radius: 10,
        color: "#4ade80",
        fillColor: "#16a34a",
        fillOpacity: 1,
        weight: 3,
      })
        .bindPopup(`Landing: <strong>${escapeHtml(p.ident)}</strong>`)
        .addTo(baseLayers.arrival);
    }
  }
  addProcedureFixMarkers(points, "arr", baseLayers.arrival);

  const arrLabels = (data.points || []).map((p) => p.ident || "");
  setPathTrack("arrival", latlngs, {
    name: data.star_name || "Arrival",
    labels: arrLabels.length === latlngs.length ? arrLabels : null,
  });
  if (!opts.fromSnapshot) {
    savePathSnapshot("arrival", { data });
  }
  if (state.sim.lat != null && !opts.fromSnapshot) {
    updateActiveLeg(state.sim.lat, state.sim.lon);
  }
  // Re-join enroute plan end → STAR entry (after tracks are stored)
  if (!opts.fromSnapshot && !state._skipPathRelink) {
    try {
      relinkFlightPlanToProcedures();
    } catch (err) {
      console.warn("relink after STAR", err);
    }
  }

  if (!opts.skipFit) {
    try {
      const b = L.latLngBounds(latlngs);
      if (b.isValid()) map.fitBounds(b.pad(0.2), { maxZoom: 12 });
    } catch (err) {
      console.warn("fitBounds arrival", err);
    }
  }
  try {
    if (
      window.NavApronPlates &&
      typeof window.NavApronPlates.refreshNavapron === "function"
    ) {
      window.NavApronPlates.refreshNavapron();
    }
  } catch (_) {}
}

function clearArrival() {
  baseLayers.arrival.clearLayers();
  clearPathTrack("arrival");
  clearPathSnapshot("arrival");
  state.activeArrival = null;
  $("#arr-summary")?.classList?.remove("visible");
  const atc = $("#arr-atc");
  if (atc) atc.value = "";
  relinkFlightPlanToProcedures();
  try {
    if (
      window.NavApronPlates &&
      typeof window.NavApronPlates.refreshNavapron === "function"
    ) {
      window.NavApronPlates.refreshNavapron();
    }
  } catch (_) {}
}

/**
 * Active SID/STAR payload for the plate panel (NavApron-owned procedure strip).
 * @param {string} [icao]
 * @param {"sid"|"star"|"DP"|"STAR"} [kind]
 */
function getActiveProcedure(icao, kind) {
  const icaoU = String(icao || "")
    .trim()
    .toUpperCase();
  const k = String(kind || "")
    .toUpperCase();
  const wantStar = k === "STAR" || k === "ARR" || k === "ARRIVAL";
  const data = wantStar ? state.activeArrival : state.activeDeparture;
  if (!data || !(data.points || []).length) return null;
  const dataIcao = String(data.airport_icao || "").toUpperCase();
  if (icaoU && dataIcao && dataIcao !== icaoU) return null;
  return data;
}

function fitActiveProcedure(kind) {
  const wantStar =
    String(kind || "")
      .toUpperCase()
      .indexOf("STAR") >= 0 ||
    String(kind || "")
      .toUpperCase()
      .indexOf("ARR") >= 0;
  const data = wantStar ? state.activeArrival : state.activeDeparture;
  const coords =
    (data && data.coords) ||
    (data && data.points
      ? data.points.map((p) => [p.lat, p.lon])
      : null);
  if (!coords || coords.length < 2 || !window.map) return false;
  try {
    const latlngs = unwrapLatLngs(coords.map((c) => [c[0], c[1]]));
    const b = L.latLngBounds(latlngs);
    if (b.isValid()) {
      map.fitBounds(b.pad(0.2), { maxZoom: 12 });
      return true;
    }
  } catch (err) {
    console.warn("fitActiveProcedure", err);
  }
  return false;
}

function focusProcedureFix(lat, lon, opts) {
  opts = opts || {};
  if (lat == null || lon == null || !window.map) return false;
  try {
    const z = opts.zoom != null ? opts.zoom : Math.max(map.getZoom(), 11);
    map.setView([Number(lat), Number(lon)], z, { animate: true });
    return true;
  } catch (err) {
    console.warn("focusProcedureFix", err);
    return false;
  }
}

function showArrSummary(data) {
  const el = $("#arr-summary");
  if (!el) return;
  el.classList.add("visible");
  const dist = $("#arr-dist");
  const msg = $("#arr-msg");
  const viaEl = $("#arr-via");
  if (dist)
    dist.textContent = `${data.distance_nm ?? "—"} NM · HDG ${data.approach_hdg ?? "—"}°`;
  if (msg) msg.textContent = data.message || data.description || "";
  if (viaEl) {
    const via = (data.points || []).map((p) => p.ident).filter(Boolean).join(" → ");
    viaEl.textContent = via || "";
  }
}

$("#btn-arr-suggest")?.addEventListener("click", () => loadArrivalSuggestions());
$("#btn-arr-show")?.addEventListener("click", () => showArrival());
$("#btn-arr-clear")?.addEventListener("click", () => clearArrival());
$("#arr-atc")?.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    showArrival();
  }
});

// ── Arrival taxi-in (runway → gate) ───────────────────────────────
function parseClearanceTokens(text) {
  return parseClearanceText(text || "");
}

function haversineApproxM(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const toR = Math.PI / 180;
  const dLat = (lat2 - lat1) * toR;
  const dLon = (lon2 - lon1) * toR;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * toR) * Math.cos(lat2 * toR) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

/**
 * Unwrap longitudes so consecutive points never jump more than 180°.
 * Needed for Pacific routes (e.g. RJAA→PANC): Leaflet otherwise draws the
 * pink enroute line the long way around the world across the Atlantic.
 * Returned lons may be outside [-180, 180]; that is intentional for drawing.
 * @param {Array<[number,number]|{lat:number,lon:number}>} latlngs
 * @returns {Array<[number,number]>}
 */
function unwrapLatLngs(latlngs) {
  if (!latlngs || !latlngs.length) return [];
  const out = [];
  let prevLon = null;
  for (let i = 0; i < latlngs.length; i++) {
    const pt = latlngs[i];
    if (pt == null) continue;
    let lat;
    let lon;
    if (Array.isArray(pt)) {
      lat = Number(pt[0]);
      lon = Number(pt[1]);
    } else {
      lat = Number(pt.lat);
      lon = Number(pt.lon);
    }
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) continue;
    if (prevLon != null && Number.isFinite(prevLon)) {
      while (lon - prevLon > 180) lon -= 360;
      while (prevLon - lon > 180) lon += 360;
    }
    out.push([lat, lon]);
    prevLon = lon;
  }
  return out;
}

/** Opposite threshold of the currently selected runway (same pair). */
function getOppositeRunwayEnd() {
  // Prefer the active dep runway when taxiing out
  const land =
    state.depPick?.runway || state.runwayEndMeta || state.end;
  if (!land) return null;
  const ends = state.runwayEnds || [];
  const landName = normalizeRwyName(land.name || land.label);
  const pair = land.runway || null;
  if (pair) {
    const others = ends.filter(
      (e) =>
        e.runway === pair &&
        normalizeRwyName(e.name) !== landName
    );
    if (others.length === 1) return others[0];
  }
  // Match by lat/lon to a known end, then find pair opposite
  let best = null;
  let bestD = Infinity;
  for (const e of ends) {
    const d =
      (e.lat - (land.lat || 0)) ** 2 + (e.lon - (land.lon || 0)) ** 2;
    if (d < bestD) {
      bestD = d;
      best = e;
    }
  }
  if (best?.runway) {
    const others = ends.filter(
      (e) =>
        e.runway === best.runway &&
        normalizeRwyName(e.name) !== normalizeRwyName(best.name)
    );
    if (others.length === 1) return others[0];
  }
  return null;
}

/**
 * After landing runway NN you roll out toward the far end — taxi-in starts
 * there, not at the approach threshold. Prefer the opposite end of the same
 * runway pair (e.g. land 07 → vacate near 25).
 */
function getTaxiInStartPoint() {
  const land = state.runwayEndMeta;
  if (!land) return null;

  const ends = state.runwayEnds || [];
  const landName = String(land.name || "").toUpperCase();
  const pair = land.runway || null;

  // 1) Same pair string (e.g. "07/25") — other designator
  if (pair && ends.length) {
    const others = ends.filter(
      (e) =>
        e.runway === pair &&
        String(e.name || "").toUpperCase() !== landName
    );
    if (others.length === 1) {
      return {
        lat: others[0].lat,
        lon: others[0].lon,
        label: `Vacate / RWY ${others[0].name} end (after landing ${land.name})`,
        name: others[0].name,
      };
    }
  }

  // 2) Reciprocal number (07↔25, 09L↔27R)
  const m = landName.match(/^(\d{1,2})([LCR]?)$/);
  if (m && ends.length) {
    let n = parseInt(m[1], 10);
    if (n === 0) n = 36;
    const recip = ((n + 17) % 36) + 1; // +18 mod 36, 1–36
    const recipStr = String(recip).padStart(2, "0");
    // Prefer opposite side letter: L↔R, C stays C
    const side = m[2] || "";
    const oppSide = side === "L" ? "R" : side === "R" ? "L" : side;
    const candidates = [
      recipStr + oppSide,
      recipStr + side,
      recipStr,
    ];
    for (const c of candidates) {
      const hit = ends.find(
        (e) => String(e.name || "").toUpperCase() === c.toUpperCase()
      );
      if (hit) {
        return {
          lat: hit.lat,
          lon: hit.lon,
          label: `Vacate / RWY ${hit.name} end (after landing ${land.name})`,
          name: hit.name,
        };
      }
    }
  }

  // 3) Fallback: project ~1.2 NM along landing heading from threshold
  //    (approx. down-runway toward far end if we lack pair data)
  const hdg = land.approach_hdg;
  if (hdg != null && Number.isFinite(Number(hdg))) {
    const distM = 1200;
    const R = 6371000;
    const br = (Number(hdg) * Math.PI) / 180;
    const lat1 = (land.lat * Math.PI) / 180;
    const lon1 = (land.lon * Math.PI) / 180;
    const lat2 = Math.asin(
      Math.sin(lat1) * Math.cos(distM / R) +
        Math.cos(lat1) * Math.sin(distM / R) * Math.cos(br)
    );
    const lon2 =
      lon1 +
      Math.atan2(
        Math.sin(br) * Math.sin(distM / R) * Math.cos(lat1),
        Math.cos(distM / R) - Math.sin(lat1) * Math.sin(lat2)
      );
    return {
      lat: (lat2 * 180) / Math.PI,
      lon: (lon2 * 180) / Math.PI,
      label: `Rollout (along RWY ${land.name})`,
      name: land.name,
    };
  }

  // Last resort: landing threshold (incorrect but better than nothing)
  return {
    lat: land.lat,
    lon: land.lon,
    label: `RWY ${land.name} threshold`,
    name: land.name,
  };
}

/**
 * Make sure taxi-in uses the *destination* airport + landing runway/stand.
 * iPad/LAN sessions often still have the departure chart active after landing,
 * which produced HTTP 400 "Unknown landing runway" masked as a generic failure.
 */
function ensureTaxiInContext() {
  // Dual-airport journey: always route on the destination chart
  try {
    if (state.destChart?.airport) {
      const destIcao = state.destChart.airport.icao;
      if (!state.airport || state.airport.icao !== destIcao) {
        state.airport = state.destChart.airport;
        state.layout = state.destChart.layout;
        state.runwayEnds = state.destChart.runwayEnds || [];
      }
    } else {
      ensureAirportForTaxiFocus("taxiIn");
    }
  } catch (_) {
    ensureAirportForTaxiFocus("taxiIn");
  }

  // Restore stand from remembered arrival pick if the select was rebuilt
  if (
    (!state.arrivalStand || state.arrivalStand.lat == null) &&
    state.arrPick?.stand
  ) {
    state.arrivalStand = { ...state.arrPick.stand };
  }

  // Landing runway only — never leave a leftover taxi-out runwayEndMeta in place
  if (!ensureArrRunwayActive()) {
    return {
      ok: false,
      reason: "Select the landing runway (Arrival tab) first",
    };
  }

  if (!state.airport) {
    return { ok: false, reason: "Load the destination airport first" };
  }
  if (!state.runwayEndMeta || !state.runwayEndMeta.name) {
    return {
      ok: false,
      reason: "Select the landing runway (Arrival tab) first",
    };
  }
  if (
    !state.arrivalStand ||
    state.arrivalStand.lat == null ||
    state.arrivalStand.lon == null ||
    !Number.isFinite(Number(state.arrivalStand.lat)) ||
    !Number.isFinite(Number(state.arrivalStand.lon))
  ) {
    return {
      ok: false,
      reason: "Select gate/stand for taxi-in first",
    };
  }
  return { ok: true };
}

/**
 * @param {boolean} useClearance
 * @param {{ quiet?: boolean, fromAircraft?: boolean, skipFit?: boolean, ignoreHeading?: boolean }} opts
 */
async function computeTaxiIn(useClearance, opts = {}) {
  const quiet = !!opts.quiet;
  const ctx = ensureTaxiInContext();
  if (!ctx.ok) {
    if (!quiet) setStatus(ctx.reason || "Select landing runway and gate/stand first", "err");
    return null;
  }
  // Prefer pill/map selection; fall back to text field
  if (useClearance) {
    syncArrClearanceFromText();
  }
  const clearance = useClearance ? state.arrClearance || [] : [];
  if (!quiet) {
    setLoading(true, "Evaluating runway exits…");
    setStatus("Trying early exits + full length for taxi-in…", "busy");
  }
  try {
    const body = {
      icao: state.airport.icao,
      land_runway: String(state.runwayEndMeta.name || "").trim(),
      stand_lat: Number(state.arrivalStand.lat),
      stand_lon: Number(state.arrivalStand.lon),
      clearance,
    };
    // Live aircraft: always preferred when connected (missed exit re-route)
    if (
      (opts.fromAircraft || state.sim.connected) &&
      state.sim.lat != null &&
      state.sim.lon != null &&
      Number.isFinite(Number(state.sim.lat)) &&
      Number.isFinite(Number(state.sim.lon))
    ) {
      body.aircraft_lat = Number(state.sim.lat);
      body.aircraft_lon = Number(state.sim.lon);
      if (
        !opts.ignoreHeading &&
        state.sim.heading != null &&
        Number.isFinite(Number(state.sim.heading))
      ) {
        body.aircraft_heading_deg = Number(state.sim.heading);
      }
    }
    const res = await fetch("/api/route/taxi-in", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    let data = null;
    try {
      data = await res.json();
    } catch (_) {
      data = null;
    }
    if (!res.ok) {
      throw new Error(
        formatApiError(
          data,
          "Taxi-in failed (HTTP " +
            res.status +
            "). On iPad: check landing runway + stand on Arrival, and that destination airport is loaded."
        )
      );
    }
    if (!data || data.ok === false) {
      throw new Error(
        formatApiError(
          data,
          (data && data.error) || "Taxi-in routing failed"
        )
      );
    }
    const startNote = data.exit_label || "runway exit";
    drawTaxiIn(
      data,
      {
        startLat: data.exit_lat,
        startLon: data.exit_lon,
        startNote,
      },
      { skipFit: quiet || !!opts.skipFit }
    );
    showArrTaxiSummary(data, startNote);
    try {
      if (!state.manualTaxiPath) state.manualTaxiPath = { route: false, taxiIn: false };
      if (!opts.fromManual) state.manualTaxiPath.taxiIn = false;
    } catch (_) {}
    let note = quiet
      ? `Taxi-in updated from aircraft (${startNote})`
      : `Taxi-in via ${startNote} → ${state.arrivalStand.label}`;
    if (clearance.length && data.clearance_honoured === false) {
      note += " (clearance not fully matched — try Show taxi-in again)";
    } else if (clearance.length && data.clearance_honoured) {
      note += " · clearance used";
    }
    setStatus(note, "ok");
    return data;
  } catch (err) {
    console.error(err);
    if (!quiet) {
      let msg = err && err.message ? err.message : String(err);
      // Safari / LAN often surfaces opaque network failures mid-route
      if (
        /failed to fetch|load failed|networkerror|network connection was lost|the internet connection appears to be offline/i.test(
          msg
        )
      ) {
        msg =
          "Taxi-in request lost (Wi‑Fi / Safari). Keep iPad on the same network, retry Best taxi-in — or run it on the PC.";
      }
      setStatus(msg, "err");
      $("#arr-taxi-summary")?.classList.remove("visible");
    }
    return null;
  } finally {
    if (!quiet) setLoading(false);
  }
}

function drawTaxiIn(data, startInfo, opts = {}) {
  baseLayers.taxiIn.clearLayers();
  if (!data.coords || data.coords.length < 2) {
    clearPathTrack("taxiIn");
    if (!opts.fromSnapshot) clearPathSnapshot("taxiIn");
    return;
  }
  const latlngs = data.coords.map((c) => [c[0], c[1]]);
  ensurePathLayerVisible("taxiIn");
  L.polyline(latlngs, {
    color: "#0369a1",
    weight: 10,
    opacity: 0.22,
    lineCap: "round",
    lineJoin: "round",
    smoothFactor: 0,
    interactive: false,
  }).addTo(baseLayers.taxiIn);
  L.polyline(latlngs, {
    color: "#38bdf8",
    weight: 5,
    opacity: 1,
    lineCap: "round",
    lineJoin: "round",
    smoothFactor: 0,
  })
    .bindPopup(data.message || "Taxi-in path")
    .addTo(baseLayers.taxiIn);

  // Mark vacate / rollout start (far end after landing)
  if (startInfo && startInfo.startLat != null) {
    L.circleMarker([startInfo.startLat, startInfo.startLon], {
      radius: 8,
      color: "#38bdf8",
      fillColor: "#0ea5e9",
      fillOpacity: 1,
      weight: 2,
    })
      .bindPopup(
        `Taxi-in start:<br><strong>${escapeHtml(startInfo.startNote || "Vacate")}</strong>`
      )
      .addTo(baseLayers.taxiIn);
  }

  setPathTrack("taxiIn", latlngs, { name: "Taxi in" });
  if (!opts.fromSnapshot) {
    savePathSnapshot("taxiIn", {
      data: { ...data, coords: latlngs },
      startInfo: startInfo
        ? {
            startLat: startInfo.startLat,
            startLon: startInfo.startLon,
            startNote: startInfo.startNote,
          }
        : null,
    });
  }
  if (state.sim.lat != null && !opts.fromSnapshot) {
    updateActiveLeg(state.sim.lat, state.sim.lon);
  }

  if (!opts.skipFit) {
    try {
      map.fitBounds(latlngs, { padding: [50, 50], maxZoom: 16 });
    } catch {
      /* ignore */
    }
  }
}

function clearTaxiIn() {
  baseLayers.taxiIn.clearLayers();
  clearPathTrack("taxiIn");
  clearPathSnapshot("taxiIn");
  $("#arr-taxi-summary")?.classList.remove("visible");
  state.arrClearance = [];
  if ($("#arr-taxi-clearance")) $("#arr-taxi-clearance").value = "";
  try {
    if (state.manualTaxiPath) state.manualTaxiPath.taxiIn = false;
  } catch (_) {}
  renderArrClearance();
  highlightArrClearanceTaxiways();
}

/** Distance (m) from planned taxi centerline before we re-route. Taxiway ~20–40 m. */
const TAXI_OFF_PATH_M = 42;
/** Soft threshold: after this for a few samples, re-route even if not fully off. */
const TAXI_OFF_PATH_SOFT_M = 28;
/** Taxi-in: treat “different runway exit” sooner (still on the field). */
const TAXI_IN_OFF_PATH_M = 28;
const TAXI_IN_OFF_PATH_SOFT_M = 16;
/** On the strip, rebuild if planned exit is this far behind the aircraft. */
const TAXI_IN_PAST_EXIT_M = 70;
/** Along-runway gap (aircraft past planned vacate) that forces a taxi-in rebuild. */
const TAXI_IN_ALONG_PAST_EXIT_M = 80;
/** Don't re-route more often than this (ms). */
const TAXI_REROUTE_COOLDOWN_MS = 2800;
/** Near destination — stop re-routing. */
const TAXI_NEAR_GOAL_M = 45;
/** Min GS (kt) when GS is available. Missing GS falls back to movement. */
const TAXI_REROUTE_MIN_GS_KT = 1.2;
/** Samples off-path (soft) before re-route. */
const TAXI_OFF_PATH_SOFT_HITS = 2;

/** Flip UI to Arrival / journey Taxi-in after landing (no chart zoom jump). */
function switchToTaxiInModeAfterLanding() {
  try {
    // User picked another journey tab — don't fight them until airborne again
    if (state._journeyStepUserLock && state.journeyStep !== "taxi-in") {
      return;
    }
    if (state.mode === "journey") {
      if (state.journeyStep !== "taxi-in") {
        setJourneyStep("taxi-in", { skipFit: true });
      }
      return;
    }
    if (state.mode === "arrival") {
      try {
        switchTab("arrival");
      } catch (_) {}
      return;
    }
    // Full journey preferred when both charts exist; else Arrival mode
    if (state.depChart && state.destChart && typeof enterMode === "function") {
      enterMode("journey");
      setTimeout(function () {
        try {
          setJourneyStep("taxi-in", { skipFit: true });
        } catch (_) {}
      }, 50);
    } else if (typeof enterMode === "function") {
      enterMode("arrival");
    }
  } catch (err) {
    console.warn("switchToTaxiInModeAfterLanding", err);
  }
}

function minDistToPathTrack(key, lat, lon) {
  const tr = state.pathTracks?.[key];
  if (!tr?.coords || tr.coords.length < 2) return Infinity;
  let best = Infinity;
  for (let i = 0; i < tr.coords.length - 1; i++) {
    const a = tr.coords[i];
    const b = tr.coords[i + 1];
    const { dist } = distPointToSegmentM(lat, lon, a[0], a[1], b[0], b[1]);
    if (dist < best) best = dist;
  }
  return best;
}

/** Ensure state.airport matches the chart for this taxi phase. */
function ensureAirportForTaxiFocus(focus) {
  try {
    if (focus === "route" && state.depChart?.airport) {
      if (
        !state.airport ||
        state.airport.icao !== state.depChart.airport.icao
      ) {
        state.airport = state.depChart.airport;
        state.layout = state.depChart.layout;
        state.runwayEnds = state.depChart.runwayEnds || [];
      }
    } else if (focus === "taxiIn" && state.destChart?.airport) {
      if (
        !state.airport ||
        state.airport.icao !== state.destChart.airport.icao
      ) {
        state.airport = state.destChart.airport;
        state.layout = state.destChart.layout;
        state.runwayEnds = state.destChart.runwayEnds || [];
      }
    }
  } catch (_) {
    /* ignore */
  }
}

/**
 * Auto re-route from aircraft: prefer existing clearance pills when set
 * (EHAM etc.). Fall back to a free path only if the clearance route fails.
 */
async function autoRerouteTaxiOutFromAircraft(distM) {
  try {
    if (state.manualTaxiPath && state.manualTaxiPath.route) return null;
  } catch (_) {}
  const hasClr = Array.isArray(state.clearance) && state.clearance.length > 0;
  const tryOnce = async function (useClr, ignoreHeading) {
    return computeRoute(useClr, {
      quiet: true,
      fromAircraft: true,
      skipFit: true,
      ignoreHeading: !!ignoreHeading,
    });
  };
  let data = null;
  if (hasClr) {
    data = await tryOnce(true, false);
    if (!data || data.ok === false) data = await tryOnce(true, true);
  }
  if (!data || data.ok === false) {
    data = await tryOnce(false, false);
    if (!data || data.ok === false) data = await tryOnce(false, true);
    if (data && data.ok !== false) {
      setStatus(
        "Taxi path re-routed from your position (" +
          Math.round(distM) +
          " m off plan)" +
          (hasClr ? " — clearance path unavailable, used best route" : ""),
        "ok"
      );
      return data;
    }
    return null;
  }
  setStatus(
    "Taxi path re-routed with clearance " +
      state.clearance.join(" → ") +
      " (" +
      Math.round(distM) +
      " m off plan)",
    "ok"
  );
  return data;
}

async function autoRerouteTaxiInFromAircraft(statusNote) {
  try {
    if (state.manualTaxiPath && state.manualTaxiPath.taxiIn) return null;
  } catch (_) {}
  const hasClr =
    Array.isArray(state.arrClearance) && state.arrClearance.length > 0;
  const tryOnce = async function (useClr, ignoreHeading) {
    return computeTaxiIn(useClr, {
      quiet: true,
      fromAircraft: true,
      skipFit: true,
      ignoreHeading: !!ignoreHeading,
    });
  };
  let data = null;
  if (hasClr) {
    data = await tryOnce(true, false);
    // Heading U-turn penalty can block re-route on the runway — retry plain
    if (!data) data = await tryOnce(true, true);
  }
  if (!data) {
    data = await tryOnce(false, false);
    if (!data) data = await tryOnce(false, true);
    if (data) {
      setStatus(
        (statusNote || "Taxi-in re-routed from aircraft") +
          (hasClr ? " — clearance path unavailable, used best route" : ""),
        "ok"
      );
      return data;
    }
    return null;
  }
  setStatus(
    (statusNote || "Taxi-in re-routed from aircraft") +
      " with clearance " +
      state.arrClearance.join(" → "),
    "ok"
  );
  return data;
}

/**
 * While MSFS is connected and taxiing, if the aircraft leaves the drawn taxi
 * path (wrong turn / missed exit), recompute from live position to the goal.
 * Honours clearance pills when set; free path is only a fallback.
 */
async function maybeAutoRerouteTaxi(lat, lon) {
  if (!state.autoRerouteTaxi) return;
  if (!state.sim.connected) return;
  // Airborne — no surface re-route. null on_ground: still allow (some aircraft).
  if (state.sim.onGround === false) return;
  if (state._taxiRerouteBusy) return;
  if (lat == null || lon == null) return;

  const now = Date.now();
  const dOut = minDistToPathTrack("route", lat, lon);
  const dIn = minDistToPathTrack("taxiIn", lat, lon);
  const hasOut = Number.isFinite(dOut) && dOut < 1e8;
  const hasIn = Number.isFinite(dIn) && dIn < 1e8;

  // Taxi-in later-exit check FIRST (before cooldown + slow-taxi GS gates).
  // High-speed rollout past an early exit must rebuild even at 30–50 kt
  // (LEMG E8→E9) — cooldown after the first auto taxi-in used to block this.
  const taxiInMode =
    (typeof isArrivalTaxiMode === "function" && isArrivalTaxiMode()) ||
    state.mode === "arrival" ||
    state.journeyStep === "taxi-in" ||
    // Just landed — mode flip may be a tick behind; still watch exits
    (state._simWasAirborne &&
      typeof isNearArrivalField === "function" &&
      isNearArrivalField(lat, lon));
  if (
    taxiInMode &&
    state.arrivalStand &&
    state.runwayEndMeta &&
    state.sim.onGround !== false
  ) {
    const onLandRwy = minDistToRunwayCentrelineM(lat, lon, true);
    const pathStart = state.pathTracks?.taxiIn?.coords?.[0];
    let dStart = Infinity;
    if (pathStart && pathStart.length >= 2) {
      dStart = haversineApproxM(
        lat,
        lon,
        Number(pathStart[0]),
        Number(pathStart[1])
      );
    }
    const nearStrip = Number.isFinite(onLandRwy) && onLandRwy < 110;
    // Off the strip but still on the field (took an exit) — LEMG E9 etc.
    const vacated =
      Number.isFinite(onLandRwy) && onLandRwy >= 40 && onLandRwy < 420;
    const startFar =
      (nearStrip || vacated) && dStart > TAXI_IN_PAST_EXIT_M;
    // Rolled past the planned vacate along the strip (E8 drawn, took E9).
    // Keep this after vacating — nearStrip alone missed the rebuild once off
    // the centreline, so Follow plan zoomed to the stale path instead.
    let alongPastExit = false;
    if (
      (nearStrip || vacated) &&
      hasIn &&
      pathStart &&
      pathStart.length >= 2
    ) {
      const alongAc = alongLandingRunwayM(lat, lon);
      const alongStart = alongLandingRunwayM(
        Number(pathStart[0]),
        Number(pathStart[1])
      );
      if (
        Number.isFinite(alongAc) &&
        Number.isFinite(alongStart) &&
        alongAc > alongStart + TAXI_IN_ALONG_PAST_EXIT_M
      ) {
        alongPastExit = true;
      }
    }
    const vacatedWrongExit =
      hasIn &&
      Number.isFinite(dIn) &&
      dIn > 24 &&
      (dStart > TAXI_IN_PAST_EXIT_M || dIn > TAXI_IN_OFF_PATH_M);
    const rolledPastExit =
      (nearStrip || vacated) &&
      hasIn &&
      Number.isFinite(dStart) &&
      dStart > TAXI_IN_PAST_EXIT_M &&
      Number.isFinite(dIn) &&
      dIn > 14;
    // Vacated and far from the drawn path start — always rebuild from aircraft
    const vacatedPastPlannedExit =
      vacated &&
      hasIn &&
      Number.isFinite(dStart) &&
      dStart > TAXI_IN_PAST_EXIT_M;
    if (
      !hasIn ||
      startFar ||
      vacatedWrongExit ||
      rolledPastExit ||
      alongPastExit ||
      vacatedPastPlannedExit
    ) {
      state._taxiRerouteBusy = true;
      state._lastTaxiRerouteAt = now;
      try {
        switchToTaxiInModeAfterLanding();
        ensureAirportForTaxiFocus("taxiIn");
        const rebuilt = await autoRerouteTaxiInFromAircraft(
          startFar ||
            vacatedWrongExit ||
            rolledPastExit ||
            alongPastExit ||
            vacatedPastPlannedExit
            ? "Taxi-in re-routed from your runway exit"
            : "Taxi-in built from aircraft"
        );
        // Allow Follow plan to re-fit the new shorter path cleanly
        if (rebuilt) state._followPlanLastZoom = null;
      } catch (err) {
        console.warn("bootstrap/re-exit taxi-in", err);
      } finally {
        state._taxiRerouteBusy = false;
      }
      return;
    }
  }

  // Normal off-path re-routes (wrong turn on apron) keep a short cooldown
  if (
    state._lastTaxiRerouteAt &&
    now - state._lastTaxiRerouteAt < TAXI_REROUTE_COOLDOWN_MS
  ) {
    return;
  }

  const gs =
    state.sim.gsKt != null && Number.isFinite(Number(state.sim.gsKt))
      ? Number(state.sim.gsKt)
      : null;
  // If SimConnect reports GS, require a crawl. If GS is missing, use movement.
  if (gs != null && gs < TAXI_REROUTE_MIN_GS_KT) return;

  // Movement gate (also used when GS is null)
  if (state._lastTaxiReroutePos) {
    const moved = haversineApproxM(
      lat,
      lon,
      state._lastTaxiReroutePos.lat,
      state._lastTaxiReroutePos.lon
    );
    // After a re-route, require some travel before another attempt
    if (moved < 12 && now - (state._lastTaxiRerouteAt || 0) < 20000) {
      /* still evaluate off-path below for first detection */
    }
  }
  if (gs == null) {
    // No GS: need prior sample far enough to prove we're rolling
    if (!state._taxiWatchPos) {
      state._taxiWatchPos = { lat, lon, t: now };
      return;
    }
    const movedWatch = haversineApproxM(
      lat,
      lon,
      state._taxiWatchPos.lat,
      state._taxiWatchPos.lon
    );
    const dt = Math.max(0.5, (now - (state._taxiWatchPos.t || now)) / 1000);
    // ~1 m/s ≈ 2 kt
    if (movedWatch / dt < 0.6 && movedWatch < 8) {
      // barely moving — refresh watch occasionally
      if (now - state._taxiWatchPos.t > 4000) {
        state._taxiWatchPos = { lat, lon, t: now };
      }
      return;
    }
    state._taxiWatchPos = { lat, lon, t: now };
  }

  if (!hasOut && !hasIn) {
    return;
  }

  // Prefer journey / arrival phase over “whichever path is closer”
  // so a leftover taxi-in line at another airport doesn't steal focus.
  let focus = null;
  if (typeof isArrivalTaxiMode === "function" && isArrivalTaxiMode()) {
    if (hasIn) focus = "taxiIn";
    else if (hasOut) focus = "route";
  } else if (state.mode === "arrival" || state.journeyStep === "taxi-in") {
    if (hasIn) focus = "taxiIn";
    else if (hasOut) focus = "route";
  } else if (hasOut && hasIn) {
    if (state.activeLegInfo?.key === "taxiIn") focus = "taxiIn";
    else if (state.activeLegInfo?.key === "route") focus = "route";
    else focus = dOut <= dIn + 30 ? "route" : "taxiIn";
  } else if (hasOut) focus = "route";
  else focus = "taxiIn";

  const dist = focus === "route" ? dOut : dIn;
  if (!Number.isFinite(dist)) return;

  // Taxi-in: snappier off-path so a different runway exit rebuilds the path
  const softM =
    focus === "taxiIn" ? TAXI_IN_OFF_PATH_SOFT_M : TAXI_OFF_PATH_SOFT_M;
  const hardM = focus === "taxiIn" ? TAXI_IN_OFF_PATH_M : TAXI_OFF_PATH_M;

  // Soft / hard off-path detection (consecutive soft hits)
  if (dist <= softM) {
    state._taxiOffPathHits = 0;
    return;
  }
  if (dist <= hardM) {
    state._taxiOffPathHits = (state._taxiOffPathHits || 0) + 1;
    if (state._taxiOffPathHits < TAXI_OFF_PATH_SOFT_HITS) return;
  } else {
    state._taxiOffPathHits = TAXI_OFF_PATH_SOFT_HITS; // hard off → go now
  }

  if (focus === "route") {
    // Need a runway end goal (dep pick or live end marker)
    const end =
      state.end ||
      (state.depPick?.runway
        ? {
            lat: state.depPick.runway.lat,
            lon: state.depPick.runway.lon,
            label: state.depPick.runway.name
              ? "RWY " + state.depPick.runway.name
              : "Runway",
          }
        : null);
    if (!end || end.lat == null) return;
    if (!state.end) state.end = end;
    if (!state.runwayEndMeta && state.depPick?.runway) {
      state.runwayEndMeta = { ...state.depPick.runway };
    }
    ensureAirportForTaxiFocus("route");
    if (!state.airport) return;

    const nearRwy =
      haversineApproxM(lat, lon, end.lat, end.lon) < TAXI_NEAR_GOAL_M;
    if (nearRwy) return;

    state._taxiRerouteBusy = true;
    state._lastTaxiRerouteAt = now;
    state._lastTaxiReroutePos = { lat, lon };
    state._taxiOffPathHits = 0;
    try {
      await autoRerouteTaxiOutFromAircraft(dist);
    } catch (err) {
      console.warn("auto re-route taxi-out", err);
    } finally {
      state._taxiRerouteBusy = false;
    }
    return;
  }

  if (focus === "taxiIn") {
    const stand =
      state.arrivalStand ||
      (state.arrPick?.stand ? { ...state.arrPick.stand } : null);
    if (!stand || stand.lat == null) return;
    if (!state.arrivalStand) state.arrivalStand = stand;
    if (!state.runwayEndMeta && state.arrPick?.runway) {
      state.runwayEndMeta = { ...state.arrPick.runway };
    }
    if (!state.runwayEndMeta) return;
    ensureAirportForTaxiFocus("taxiIn");
    if (!state.airport) return;

    const nearGate =
      haversineApproxM(lat, lon, stand.lat, stand.lon) < TAXI_NEAR_GOAL_M;
    if (nearGate) return;

    // Ensure Arrival / Taxi-in UI when rebuilding after a different exit
    try {
      switchToTaxiInModeAfterLanding();
    } catch (_) {}

    state._taxiRerouteBusy = true;
    state._lastTaxiRerouteAt = now;
    state._lastTaxiReroutePos = { lat, lon };
    state._taxiOffPathHits = 0;
    try {
      await autoRerouteTaxiInFromAircraft(
        "Taxi-in updated from your exit (" +
          Math.round(dist) +
          " m off previous path)"
      );
    } catch (err) {
      console.warn("auto re-route taxi-in", err);
    } finally {
      state._taxiRerouteBusy = false;
    }
  }
}

function showArrTaxiSummary(data, startNote) {
  const el = $("#arr-taxi-summary");
  if (!el) return;
  el.classList.add("visible");
  $("#arr-taxi-dist").textContent = `${data.distance_nm} NM · ${data.distance_m} m`;
  const from = startNote ? `From ${startNote}. ` : "";
  $("#arr-taxi-msg").textContent =
    from + (data.message || "Taxi-in route (after landing rollout)");
  const via = (data.taxiways_used || []).join(" → ");
  $("#arr-taxi-via").textContent = via ? `VIA ${via}` : "";
}

$("#btn-arr-taxi-show")?.addEventListener("click", () => computeTaxiIn(true));
$("#btn-arr-taxi-best")?.addEventListener("click", () => computeTaxiIn(false));
$("#btn-arr-taxi-clear")?.addEventListener("click", () => clearTaxiIn());
$("#arr-taxi-clearance")?.addEventListener("change", () => syncArrClearanceFromText());
$("#arr-taxi-clearance")?.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    syncArrClearanceFromText();
    computeTaxiIn(true);
  }
});

// ── SimConnect live aircraft ─────────────────────────────────────
function setUseAircraftVisible(show) {
  for (const id of ["#btn-use-aircraft", "#btn-use-aircraft-start"]) {
    const el = $(id);
    if (el) el.classList.toggle("hidden", !show);
  }
}

/** Last sim connection phase for status-bar updates */
let _simStatusPhase = ""; // off | searching | live | n/a

function setSimPill(st) {
  const pill = $("#sim-pill");
  const btn = $("#btn-sim-connect");
  const follow = $("#btn-sim-follow");
  const followPlan = $("#btn-follow-plan");
  const acBubble = $("#btn-aircraft-bubble");
  if (!pill) return;
  pill.classList.remove("on", "searching");
  if (!st.available && st.error && String(st.error).includes("not installed")) {
    pill.textContent = "MSFS: n/a";
    pill.title = st.error || "SimConnect not installed";
    if (btn) btn.classList.add("hidden");
    setUseAircraftVisible(false);
    if (follow) follow.classList.add("hidden");
    if (followPlan) followPlan.classList.add("hidden");
    if (acBubble) acBubble.classList.add("hidden");
    if (_simStatusPhase !== "n/a") {
      _simStatusPhase = "n/a";
    }
    return;
  }
  if (btn) btn.classList.remove("hidden");
  if (st.connected && st.lat != null) {
    pill.textContent = "MSFS: live";
    pill.classList.add("on");
    if (btn) {
      btn.textContent = "Disconnect";
      btn.classList.add("sim-on");
    }
    if (follow) follow.classList.remove("hidden");
    if (followPlan) followPlan.classList.remove("hidden");
    if (acBubble) acBubble.classList.remove("hidden");
    setUseAircraftVisible(true);
    if (_simStatusPhase !== "live") {
      _simStatusPhase = "live";
      setStatus(
        "MSFS connected — live aircraft on map" +
          (st.gs_kt != null ? ` · ${Math.round(st.gs_kt)} kt` : ""),
        "ok"
      );
    }
  } else if (st.enabled || st.connected) {
    // enabled but no lat yet, or connected without position
    pill.textContent = st.connected ? "MSFS: connected…" : "MSFS: searching…";
    pill.classList.add("searching");
    if (btn) {
      btn.textContent = "Disconnect";
      btn.classList.remove("sim-on");
    }
    if (follow) follow.classList.add("hidden");
    if (followPlan) followPlan.classList.add("hidden");
    if (acBubble) acBubble.classList.add("hidden");
    setUseAircraftVisible(!!st.connected);
    if (_simStatusPhase !== "searching") {
      _simStatusPhase = "searching";
      setStatus(
        st.connected
          ? "MSFS connected — waiting for aircraft position (load a flight)…"
          : "Looking for MSFS (start a flight if needed)…",
        "busy"
      );
    }
  } else {
    pill.textContent = "MSFS: off";
    if (btn) {
      btn.textContent = "Connect MSFS";
      btn.classList.remove("sim-on");
    }
    if (follow) follow.classList.add("hidden");
    if (followPlan) followPlan.classList.add("hidden");
    if (acBubble) acBubble.classList.add("hidden");
    setUseAircraftVisible(false);
    if (_simStatusPhase === "live" || _simStatusPhase === "searching") {
      _simStatusPhase = "off";
      setStatus("Disconnected from MSFS", "ok");
    } else {
      _simStatusPhase = "off";
    }
  }
}

function fmtSimSpeed(kt) {
  if (kt == null || Number.isNaN(Number(kt))) return "—";
  return Math.round(Number(kt)) + " kt";
}

function fmtSimAlt(ft) {
  if (ft == null || Number.isNaN(Number(ft))) return "—";
  const n = Math.round(Number(ft));
  // Compact FL for cruise; feet near ground
  if (n >= 10000) return "FL" + String(Math.round(n / 100)).padStart(3, "0");
  return n.toLocaleString() + " ft";
}

function fmtSimHdg(deg) {
  if (deg == null || Number.isNaN(Number(deg))) return "—";
  return String(Math.round(Number(deg)) % 360).padStart(3, "0") + "°";
}

// ── Aircraft motion trails (own + VATSIM / IVAO / Sim traffic) ───
// Airborne only. Heading-aligned dashed stub so it matches the arrow.
const _trailOwn = []; // kept for clear-on-ground / disconnect
const _trailByKey = {
  vatsim: new Map(),
  ivao: new Map(),
  sim: new Map(),
};

function _offsetLatLon(lat, lon, bearingDeg, distM) {
  const R = 6371000;
  const br = ((Number(bearingDeg) || 0) * Math.PI) / 180;
  const lat1 = (lat * Math.PI) / 180;
  const lon1 = (lon * Math.PI) / 180;
  const ang = distM / R;
  const lat2 = Math.asin(
    Math.sin(lat1) * Math.cos(ang) +
      Math.cos(lat1) * Math.sin(ang) * Math.cos(br)
  );
  const lon2 =
    lon1 +
    Math.atan2(
      Math.sin(br) * Math.sin(ang) * Math.cos(lat1),
      Math.cos(ang) - Math.sin(lat1) * Math.sin(lat2)
    );
  return [(lat2 * 180) / Math.PI, (((lon2 * 180) / Math.PI + 540) % 360) - 180];
}

/** True when the contact should show a motion trail (airborne only). */
function _isAirborneForTrail(opts) {
  opts = opts || {};
  if (opts.onGround === true) return false;
  if (opts.onGround === false) return true;
  const gs = opts.gsKt != null ? Number(opts.gsKt) : null;
  const alt = opts.altFt != null ? Number(opts.altFt) : null;
  if (gs != null && Number.isFinite(gs) && gs >= 45) return true;
  if (alt != null && Number.isFinite(alt) && alt >= 800) return true;
  if (gs != null && Number.isFinite(gs) && gs < 35) return false;
  if (alt != null && Number.isFinite(alt) && alt < 400) return false;
  return false;
}

/** Approx metres per CSS pixel at lat/zoom (Web Mercator). */
function _metersPerPixel(lat, zoom) {
  const cos = Math.cos((Number(lat) * Math.PI) / 180);
  const z = Number(zoom);
  if (!Number.isFinite(cos) || !Number.isFinite(z)) return 10;
  return (156543.03392 * Math.max(0.05, Math.abs(cos))) / Math.pow(2, z);
}

/**
 * Trail geometry + stroke sized in screen pixels so zoom in/out keeps a
 * consistent look (length, dash, weight all scale with metres-per-pixel).
 */
function _trailStyleForZoom(lat) {
  let z = 10;
  try {
    if (map && typeof map.getZoom === "function") z = map.getZoom();
  } catch (_) {}
  const mpp = _metersPerPixel(lat, z);
  // ~46px trail + ~6px gap behind the arrow tip
  const lenPx = 46;
  const gapPx = 6;
  const weightPx = z >= 12 ? 1.8 : z >= 9 ? 1.5 : 1.25;
  const dashOnPx = 4;
  const dashOffPx = 6;
  return {
    lengthM: Math.max(180, Math.min(28000, lenPx * mpp)),
    gapM: Math.max(25, Math.min(2500, gapPx * mpp)),
    weight: weightPx,
    // dashArray is in absolute pixels for SVG strokes — keep nearly constant
    dashArray: dashOnPx + " " + dashOffPx,
    opacity: z <= 6 ? 0.22 : 0.3,
  };
}

/**
 * Build a short stub directly behind the nose (matches arrow heading).
 * Nose end is pulled slightly back so the dash doesn't sit under the tip.
 */
function _headingTrailPoints(lat, lon, heading, style) {
  if (
    lat == null ||
    lon == null ||
    heading == null ||
    !isFinite(Number(heading))
  ) {
    return null;
  }
  const hdg = ((Number(heading) % 360) + 360) % 360;
  const back = (hdg + 180) % 360;
  const st = style || _trailStyleForZoom(lat);
  const len = st.lengthM;
  const noseGapM = Math.min(st.gapM, len * 0.25);
  const tail = _offsetLatLon(lat, lon, back, len);
  const nose = _offsetLatLon(lat, lon, back, noseGapM);
  return [tail, nose];
}

/** Single low-opacity dashed line along heading (zoom-scaled). */
function _drawAircraftTrail(layerGroup, lat, lon, heading, color) {
  if (!layerGroup || typeof L === "undefined") return;
  const style = _trailStyleForZoom(lat);
  const pts = _headingTrailPoints(lat, lon, heading, style);
  if (!pts || pts.length < 2) return;
  const col = color || "#38bdf8";
  try {
    L.polyline(pts, {
      color: col,
      weight: style.weight,
      opacity: style.opacity,
      dashArray: style.dashArray,
      lineCap: "round",
      lineJoin: "round",
      interactive: false,
      className: "aircraft-trail",
    }).addTo(layerGroup);
  } catch (_) {}
}

function _rememberTrafficTrail(bucket, key, lat, lon, airborne) {
  // History no longer drawn; still clear keys when on ground / pruned
  if (!key || !_trailByKey[bucket]) return [];
  if (!airborne) {
    _trailByKey[bucket].delete(key);
    return [];
  }
  if (!_trailByKey[bucket].has(key)) _trailByKey[bucket].set(key, []);
  return _trailByKey[bucket].get(key);
}

function _pruneTrafficTrails(bucket, aliveKeys) {
  const map = _trailByKey[bucket];
  if (!map) return;
  const keep = aliveKeys instanceof Set ? aliveKeys : new Set(aliveKeys || []);
  for (const k of Array.from(map.keys())) {
    if (!keep.has(k)) map.delete(k);
  }
}

function aircraftIcon(heading, { gsKt, altFt, showBubble } = {}) {
  const h = heading != null ? Number(heading) : 0;
  const withBubble = showBubble !== false && state.sim.showDataBubble !== false;
  const gs = fmtSimSpeed(gsKt);
  // Pressure altitude (std 1013) — FL matches sim flight levels
  const alt = fmtSimAlt(altFt);
  const hdg = fmtSimHdg(heading);
  // Arrow CSS is screen-relative (marker does not use rotateWithView).
  // Heading-up: nose stays screen-up. North-up: nose follows true heading.
  const arrowDeg = state.mapHeadingUp
    ? 0
    : ((Number.isFinite(h) ? h : 0) % 360 + 360) % 360;
  const bubbleHtml = withBubble
    ? '<div class="aircraft-bubble" aria-hidden="true">' +
      '<div class="ac-b-row"><span class="ac-b-k">GS</span><span class="ac-b-v">' +
      gs +
      "</span></div>" +
      '<div class="ac-b-row"><span class="ac-b-k">P.ALT</span><span class="ac-b-v">' +
      alt +
      "</span></div>" +
      '<div class="ac-b-row"><span class="ac-b-k">HDG</span><span class="ac-b-v">' +
      hdg +
      "</span></div>" +
      "</div>"
    : "";
  return L.divIcon({
    className: "aircraft-icon",
    html:
      '<div class="aircraft-wrap' +
      (withBubble ? "" : " no-bubble") +
      '">' +
      bubbleHtml +
      '<div class="aircraft-arrow" style="transform:rotate(' +
      arrowDeg +
      'deg)"></div>' +
      "</div>",
    // Compact when bubble is hidden so the chevron stays on the aircraft
    iconSize: withBubble ? [92, 78] : [28, 28],
    iconAnchor: withBubble ? [46, 70] : [14, 14],
  });
}

function setAircraftDataBubble(on, { persist = true, quiet = false } = {}) {
  state.sim.showDataBubble = !!on;
  const btn = $("#btn-aircraft-bubble");
  if (btn) {
    btn.classList.toggle("active", state.sim.showDataBubble);
    btn.setAttribute("aria-pressed", state.sim.showDataBubble ? "true" : "false");
    btn.title = state.sim.showDataBubble
      ? "Hide GS / altitude / heading bubble over the aircraft"
      : "Show GS / altitude / heading bubble over the aircraft";
  }
  if (persist) {
    try {
      localStorage.setItem(
        "navapron_aircraft_bubble",
        state.sim.showDataBubble ? "1" : "0"
      );
    } catch (_) {}
  }
  // Refresh marker immediately if live
  if (state.sim.lat != null && state.sim.lon != null) {
    updateAircraftMarker(state.sim.lat, state.sim.lon, state.sim.heading, {
      gsKt: state.sim.gsKt,
      altFt: state.sim.altitudeFt,
    });
  }
  if (!quiet) {
    setStatus(
      state.sim.showDataBubble
        ? "Aircraft data bubble shown"
        : "Aircraft data bubble hidden",
      "ok"
    );
  }
}

function loadAircraftBubblePref() {
  try {
    const v = localStorage.getItem("navapron_aircraft_bubble");
    if (v === "0") state.sim.showDataBubble = false;
    else if (v === "1") state.sim.showDataBubble = true;
  } catch (_) {}
  const btn = $("#btn-aircraft-bubble");
  if (btn) {
    btn.classList.toggle("active", state.sim.showDataBubble !== false);
    btn.setAttribute(
      "aria-pressed",
      state.sim.showDataBubble !== false ? "true" : "false"
    );
  }
}

function updateAircraftMarker(lat, lon, heading, extras) {
  baseLayers.aircraft.clearLayers();
  if (lat == null || lon == null) return;
  const gsKt = extras && extras.gsKt != null ? extras.gsKt : state.sim.gsKt;
  const altFt =
    extras && extras.altFt != null ? extras.altFt : state.sim.altitudeFt;
  // Airborne-only motion trail (cleared on the ground)
  try {
    const airborne = _isAirborneForTrail({
      onGround: state.sim.onGround,
      gsKt: gsKt,
      altFt: altFt,
    });
    if (airborne) {
      _drawAircraftTrail(baseLayers.aircraft, lat, lon, heading, "#7dd3fc");
    } else {
      _trailOwn.length = 0;
    }
  } catch (_) {}
  const m = L.marker([lat, lon], {
    icon: aircraftIcon(heading, { gsKt, altFt }),
    zIndexOffset: 1000,
    interactive: false,
  });
  m.addTo(baseLayers.aircraft);
  // Pure Follow centres on A/C; Follow plan uses applyFollowPlan instead
  if (state.sim.follow && !state.followPlan) {
    map.panTo([lat, lon], { animate: true, duration: 0.4 });
  }
  // Keep map rotated with live heading when compass is in heading-up mode
  if (state.mapHeadingUp) applyMapBearingFromAircraft();
}

/** Lazy-load leaflet-rotate only when heading-up is requested (keeps hub stable). */
function ensureLeafletRotateLoaded() {
  if (_leafletRotateLoaded && typeof L.Map.prototype.setBearing === "function") {
    return Promise.resolve(true);
  }
  if (_leafletRotateLoading) return _leafletRotateLoading;
  _leafletRotateLoading = new Promise(function (resolve) {
    try {
      if (typeof L.Map.prototype.setBearing === "function") {
        _leafletRotateLoaded = true;
        resolve(true);
        return;
      }
      const s = document.createElement("script");
      s.src = "/lib/leaflet-rotate/leaflet-rotate.js?v=1";
      s.async = true;
      s.onload = function () {
        _leafletRotateLoaded = typeof L.Map.prototype.setBearing === "function";
        resolve(_leafletRotateLoaded);
      };
      s.onerror = function () {
        resolve(false);
      };
      document.head.appendChild(s);
    } catch (_) {
      resolve(false);
    }
  });
  return _leafletRotateLoading;
}

/** Keep cyan/blue taxi + procedure paths above yellow taxiway centerlines. */
function bringPathLayersToFront() {
  if (!map || map._navapronStub || !baseLayers) return;
  const keys = [
    "route",
    "taxiIn",
    "departure",
    "arrival",
    "flightPlan",
    "activeLeg",
    "aircraft",
    "markers",
  ];
  for (const key of keys) {
    try {
      const layer = baseLayers[key];
      if (layer && map.hasLayer(layer) && typeof layer.bringToFront === "function") {
        layer.bringToFront();
      }
    } catch (_) {}
  }
}

/** Recreate the Leaflet map with rotation support, restoring drawn paths. */
function recreateMapWithRotation() {
  if (!map || map._navapronStub) return false;
  let center = null;
  let zoom = 13;
  try {
    center = map.getCenter();
    zoom = map.getZoom();
  } catch (_) {}
  try {
    if (typeof map.remove === "function") map.remove();
  } catch (_) {}
  map = null;
  _mapReady = false;
  _mapCreating = false;
  if (!ensureMapReady()) return false;
  try {
    if (center) map.setView(center, zoom, { animate: false });
  } catch (_) {}
  // Surfaces first, then cyan taxi paths — otherwise yellow centerlines looked
  // like the route after heading-up recreate (paths restored under/before paint).
  try {
    if (state.layout || state.depChart || state.destChart) {
      redrawSurfaces({ fit: false });
    }
  } catch (_) {}
  try {
    restoreAllPathLayers();
  } catch (err) {
    console.warn("restoreAllPathLayers after rotate enable", err);
  }
  try {
    highlightClearanceTaxiways();
  } catch (_) {}
  try {
    bringPathLayersToFront();
  } catch (_) {}
  try {
    if (state.sim.lat != null) {
      updateAircraftMarker(state.sim.lat, state.sim.lon, state.sim.heading, {
        gsKt: state.sim.gsKt,
        altFt: state.sim.altitudeFt,
      });
    }
  } catch (_) {}
  // Weather tile layer was destroyed with the old map — reload if still enabled
  try {
    if (state.layerVisibility.weather) {
      ensureWeatherOverlay({ quiet: true, force: true }).catch(function () {});
    }
  } catch (_) {}
  return !!(map && !map._navapronStub && map._rotate);
}

/** Current map bearing degrees (0 = north-up), if rotate plugin is available. */
function getMapBearing() {
  try {
    if (map && map._rotate && typeof map.getBearing === "function") {
      return ((Number(map.getBearing()) % 360) + 360) % 360;
    }
  } catch (_) {}
  return 0;
}

function updateCompassUi() {
  const btn = $("#btn-map-compass");
  if (!btn) return;
  btn.classList.toggle("active", !!state.mapHeadingUp);
  btn.setAttribute("aria-pressed", state.mapHeadingUp ? "true" : "false");
  btn.title = state.mapHeadingUp
    ? "Heading-up — click for north-up"
    : "North-up — click to orient map to aircraft heading";
  const label = $("#map-toolbar-compass-label");
  if (label) {
    label.textContent = state.mapHeadingUp ? "Heading up" : "North up";
  }
  const rose = btn.querySelector(".map-compass-rose");
  if (rose) {
    // getBearing() is the CSS map rotation. Rotate the rose by the same
    // amount so N stays aligned with true north on screen.
    const b = getMapBearing();
    rose.style.transform = "rotate(" + b + "deg)";
  }
}

/**
 * Heading-up: leaflet-rotate uses bearing = -heading so aircraft track is
 * screen-up (same convention as map.setHeading in newer leaflet-rotate forks).
 */
function headingToMapBearing(hdg) {
  const h = ((Number(hdg) % 360) + 360) % 360;
  return ((-h % 360) + 360) % 360;
}

/**
 * Apply map rotation: heading-up uses live MSFS HDG; north-up resets to 0.
 */
function applyMapBearingFromAircraft() {
  if (!map || !map._rotate || typeof map.setBearing !== "function") {
    updateCompassUi();
    return;
  }
  try {
    if (state.mapHeadingUp) {
      const hdg = Number(state.sim.heading);
      if (Number.isFinite(hdg)) {
        map.setBearing(headingToMapBearing(hdg));
      }
    } else {
      map.setBearing(0);
    }
  } catch (err) {
    console.warn("setBearing", err);
  }
  updateCompassUi();
}

/** Redraw aircraft chevron after north-up ↔ heading-up (arrow is screen-relative). */
function refreshAircraftMarkerIcon() {
  try {
    if (state.sim.lat == null || state.sim.lon == null) return;
    if (!baseLayers || !baseLayers.aircraft) return;
    // Rebuild icon only — skip applyMapBearingFromAircraft re-entry
    baseLayers.aircraft.clearLayers();
    L.marker([state.sim.lat, state.sim.lon], {
      icon: aircraftIcon(state.sim.heading, {
        gsKt: state.sim.gsKt,
        altFt: state.sim.altitudeFt,
      }),
      zIndexOffset: 1000,
      interactive: false,
    }).addTo(baseLayers.aircraft);
  } catch (_) {}
}

function setMapHeadingUp(on, { quiet = false } = {}) {
  const want = !!on;
  if (want) {
    const hdg = Number(state.sim.heading);
    if (!Number.isFinite(hdg)) {
      if (!quiet) {
        setStatus("Connect MSFS for heading-up map orientation", "err");
      }
      return false;
    }
  }
  if (!want) {
    state.mapHeadingUp = false;
    applyMapBearingFromAircraft();
    refreshAircraftMarkerIcon();
    if (!quiet) setStatus("Map orientation: north-up", "ok");
    return true;
  }

  // Enable rotation plugin on demand (not at hub boot — that froze WebView2)
  if (!quiet) setStatus("Enabling heading-up…", "busy");
  ensureLeafletRotateLoaded().then(function (ok) {
    if (!ok) {
      state.mapHeadingUp = false;
      updateCompassUi();
      if (!quiet) setStatus("Map rotate plugin failed to load", "err");
      return;
    }
    if (!map || map._navapronStub) {
      if (!quiet) setStatus("Open a map mode first, then use the compass", "err");
      return;
    }
    if (!map._rotate) {
      if (!recreateMapWithRotation()) {
        state.mapHeadingUp = false;
        updateCompassUi();
        if (!quiet) setStatus("Could not enable map rotation", "err");
        return;
      }
    }
    state.mapHeadingUp = true;
    applyMapBearingFromAircraft();
    refreshAircraftMarkerIcon();
    if (!quiet) setStatus("Map orientation: aircraft heading-up", "ok");
  });
  return true;
}

function toggleMapCompass() {
  if (state.mapHeadingUp) {
    setMapHeadingUp(false);
  } else {
    setMapHeadingUp(true);
  }
}

async function pollSim() {
  try {
    const res = await fetch("/api/sim/position");
    const st = await res.json();
    state.sim.connected = !!st.connected;
    state.sim.enabled = !!st.enabled;
    setSimPill(st);
    if (st.ok && st.lat != null) {
      state.sim.lat = st.lat;
      state.sim.lon = st.lon;
      state.sim.heading = st.heading_deg;
      state.sim.onGround = st.on_ground;
      state.sim.altitudeFt =
        st.altitude_ft != null ? st.altitude_ft : null;
      state.sim.gsKt = st.gs_kt != null ? st.gs_kt : null;
      updateAircraftMarker(st.lat, st.lon, st.heading_deg, {
        gsKt: state.sim.gsKt,
        altFt: state.sim.altitudeFt,
      });
      updateActiveLeg(st.lat, st.lon);
      // Lined up on departure runway → flight plan journey step
      maybeAutoFlightPlanOnDepRunway(st.lat, st.lon, st);
      // After landing at destination: auto gate + taxi-in (user can override)
      maybeAutoArriveTaxiIn(st.lat, st.lon, st).catch(function () {});
      // Recompute taxi-out / taxi-in if aircraft left the planned path
      maybeAutoRerouteTaxi(st.lat, st.lon).catch(function (err) {
        console.warn("maybeAutoRerouteTaxi", err);
      });
      // Keep OBS overlay HUD fresh while sim is live
      scheduleOverlayPublish();
    } else if (!st.connected) {
      baseLayers.aircraft.clearLayers();
      baseLayers.activeLeg?.clearLayers();
      state.activeLegInfo = null;
      updateActiveLegHud(null);
      state.sim.altitudeFt = null;
      state.sim.gsKt = null;
      try {
        _trailOwn.length = 0;
      } catch (_) {}
    }
  } catch {
    setSimPill({ available: true, enabled: state.sim.enabled, connected: false });
  }
}

function startSimPoll() {
  stopSimPoll();
  pollSim();
  state.sim.pollTimer = setInterval(pollSim, 750);
}

function stopSimPoll() {
  if (state.sim.pollTimer) {
    clearInterval(state.sim.pollTimer);
    state.sim.pollTimer = null;
  }
}

async function toggleSimConnect() {
  try {
    if (state.sim.enabled || state.sim.connected) {
      await fetch("/api/sim/disconnect", { method: "POST" });
      state.sim.enabled = false;
      state.sim.connected = false;
      stopSimPoll();
      baseLayers.aircraft.clearLayers();
      baseLayers.activeLeg?.clearLayers();
      state.activeLegInfo = null;
      updateActiveLegHud(null);
      _simStatusPhase = "off";
      setSimPill({ available: true, enabled: false, connected: false });
      setStatus("Disconnected from MSFS", "ok");
      return;
    }
    setStatus("Connecting to MSFS…", "busy");
    const res = await fetch("/api/sim/connect", { method: "POST" });
    const st = await res.json();
    state.sim.enabled = !!st.enabled;
    _simStatusPhase = ""; // allow setSimPill to announce next phase
    setSimPill(st);
    if (st.error && !st.available) {
      setStatus(st.error, "err");
      return;
    }
    startSimPoll();
    _simStatusPhase = ""; // force setSimPill to announce searching/live
    setStatus("Looking for MSFS (start a flight if needed)…", "busy");
  } catch (err) {
    setStatus("SimConnect error: " + err.message, "err");
  }
}

/**
 * Snap lat/lon to nearest stand/gate within maxM (default 100 m).
 * Returns { lat, lon, label, parking } or null.
 */
function findNearestParking(lat, lon, maxM = 100, parkingList) {
  const parking = parkingList || state.layout?.parking || [];
  if (!parking.length) return null;
  let best = null;
  let bestD = maxM;
  for (const p of parking) {
    if (p.lat == null || p.lon == null) continue;
    // Skip raw OSM numeric IDs — not useful as assigned gates
    const rawName = String(p.name || p.ref || "");
    if (/^\d{6,}$/.test(rawName)) continue;
    const d = haversineApproxM(lat, lon, Number(p.lat), Number(p.lon));
    if (d < bestD) {
      bestD = d;
      best = p;
    }
  }
  if (!best) return null;
  const name = best.name || best.ref || best.id || "Stand";
  const kind = best.type === "gate" ? "Gate" : "Stand";
  return {
    lat: Number(best.lat),
    lon: Number(best.lon),
    label: `${kind} ${name}`,
    parking: best,
    distM: bestD,
  };
}

/** Normalize gate/stand refs for matching (A12, GATE A12, Stand 12 → comparable). */
function normalizeGateRef(s) {
  return String(s || "")
    .toUpperCase()
    .replace(/^(GATE|STAND|PARKING|RAMP)\s*/i, "")
    .replace(/[\s\-_./]/g, "")
    .trim();
}

/**
 * Find parking by planned gate name in a layout (SimBrief / OFP).
 * Prefers exact ref match, then contains.
 */
function findParkingByGateName(gateName, parkingList) {
  const want = normalizeGateRef(gateName);
  if (!want) return null;
  const parking = parkingList || state.layout?.parking || [];
  let loose = null;
  for (const p of parking) {
    if (p.lat == null || p.lon == null) continue;
    const nm = normalizeGateRef(p.name || p.ref || "");
    if (!nm) continue;
    if (nm === want) {
      const kind = p.type === "gate" ? "Gate" : "Stand";
      return {
        lat: Number(p.lat),
        lon: Number(p.lon),
        label: `${kind} ${p.name || p.ref}`,
        parking: p,
        match: "exact",
      };
    }
    if (!loose && (nm.includes(want) || want.includes(nm))) {
      const kind = p.type === "gate" ? "Gate" : "Stand";
      loose = {
        lat: Number(p.lat),
        lon: Number(p.lon),
        label: `${kind} ${p.name || p.ref}`,
        parking: p,
        match: "loose",
      };
    }
  }
  return loose;
}

/** Sync #arr-stand-select to a stand {lat,lon,label}. */
function selectArrStandDropdown(stand) {
  const arrStand = $("#arr-stand-select");
  if (!arrStand || !stand) return;
  const wantLat = Number(stand.lat);
  const wantLon = Number(stand.lon);
  for (const opt of arrStand.options || []) {
    if (!opt.value) continue;
    try {
      const v = JSON.parse(opt.value);
      if (
        Math.abs(Number(v.lat) - wantLat) < 1e-5 &&
        Math.abs(Number(v.lon) - wantLon) < 1e-5
      ) {
        arrStand.value = opt.value;
        return;
      }
    } catch (_) {
      /* ignore */
    }
  }
  // Inject option so the UI shows the auto pick
  const opt = document.createElement("option");
  opt.value = JSON.stringify({
    lat: stand.lat,
    lon: stand.lon,
    label: stand.label,
  });
  opt.textContent = stand.label || "Stand";
  arrStand.appendChild(opt);
  arrStand.value = opt.value;
}

/** Valid pre-selected arrival stand from state (manual or restored pick). */
function _arrivalStandIfSet() {
  const cands = [state.arrivalStand, state.arrPick && state.arrPick.stand];
  for (const s of cands) {
    if (
      s &&
      s.lat != null &&
      s.lon != null &&
      Number.isFinite(Number(s.lat)) &&
      Number.isFinite(Number(s.lon))
    ) {
      return {
        lat: Number(s.lat),
        lon: Number(s.lon),
        label: s.label || "Stand",
      };
    }
  }
  return null;
}

/**
 * Set arrival stand (auto or user). source: 'auto' | 'user'
 */
function setArrivalStandChoice(stand, { source = "user", reroute = false } = {}) {
  if (!stand || stand.lat == null || stand.lon == null) return;
  const next = {
    lat: Number(stand.lat),
    lon: Number(stand.lon),
    label: stand.label || "Stand",
  };
  state.arrivalStand = next;
  if (!state.arrPick) state.arrPick = { stand: null, runway: null };
  state.arrPick.stand = { ...next };
  state._arrStandSource = source;
  placeArrStandMarker(next);
  selectArrStandDropdown(next);
  updateArrTaxiButtons();
  scheduleSessionPush();
  if (reroute && state.sim.connected && state.sim.onGround !== false) {
    computeTaxiIn(false, {
      quiet: false,
      fromAircraft: true,
      skipFit: true,
    }).catch(function () {});
  }
}

function arrivalAirportContext() {
  const chart = state.destChart;
  if (chart?.airport) {
    return {
      airport: chart.airport,
      layout: chart.layout,
      runwayEnds: chart.runwayEnds || [],
      parking: (chart.layout && chart.layout.parking) || [],
    };
  }
  if (state.airport && state.layout) {
    return {
      airport: state.airport,
      layout: state.layout,
      runwayEnds: state.runwayEnds || [],
      parking: state.layout.parking || [],
    };
  }
  return null;
}

function distToArrivalAirportM(lat, lon) {
  // Prefer planned destination (FP / dest chart). Never treat the departure
  // airport as "arrival" when dest charts are still loading (career soft-land bug).
  try {
    const dest = resolveDestinationPoint();
    if (dest && dest.lat != null && dest.lon != null) {
      return haversineApproxM(lat, lon, Number(dest.lat), Number(dest.lon));
    }
  } catch (_) {
    /* ignore */
  }
  const chart = state.destChart;
  if (chart?.airport?.lat != null && chart.airport.lon != null) {
    return haversineApproxM(
      lat,
      lon,
      Number(chart.airport.lat),
      Number(chart.airport.lon)
    );
  }
  // Last resort: state.airport only if it matches planned dest ICAO
  try {
    const fpDest = String(
      state.flightPlan?.dest?.icao || $("#fp-dest")?.value || ""
    )
      .trim()
      .toUpperCase();
    const fpDep = String(
      state.flightPlan?.dep?.icao || $("#fp-dep")?.value || ""
    )
      .trim()
      .toUpperCase();
    const ap = state.airport;
    if (ap && ap.lat != null && ap.lon != null) {
      const apIcao = String(ap.icao || "")
        .trim()
        .toUpperCase();
      if (fpDep && apIcao === fpDep && (!fpDest || fpDest !== fpDep)) {
        return Infinity;
      }
      if (!fpDest || apIcao === fpDest) {
        return haversineApproxM(lat, lon, Number(ap.lat), Number(ap.lon));
      }
    }
  } catch (_) {
    /* ignore */
  }
  return Infinity;
}

function distToDepartureAirportM(lat, lon) {
  try {
    const dep = resolveDeparturePoint();
    if (dep && dep.lat != null && dep.lon != null) {
      return haversineApproxM(lat, lon, Number(dep.lat), Number(dep.lon));
    }
  } catch (_) {
    /* ignore */
  }
  if (state.depChart?.airport?.lat != null) {
    const a = state.depChart.airport;
    return haversineApproxM(lat, lon, Number(a.lat), Number(a.lon));
  }
  return Infinity;
}

/** True when aircraft is on/near the planned arrival field (~8 NM). */
function isNearArrivalField(lat, lon) {
  const d = distToArrivalAirportM(lat, lon);
  return Number.isFinite(d) && d <= 15000;
}

/** True when still on/near the planned departure field (~8 NM). */
function isNearDepartureField(lat, lon) {
  const d = distToDepartureAirportM(lat, lon);
  return Number.isFinite(d) && d <= 15000;
}

/**
 * Still on the origin side of the trip (closer to dep than dest).
 * Blocks false "landed at arrival" while parked at departure with a plan loaded.
 */
function isCloserToDepartureThanArrival(lat, lon) {
  const dDep = distToDepartureAirportM(lat, lon);
  const dDest = distToArrivalAirportM(lat, lon);
  if (!Number.isFinite(dDep) || !Number.isFinite(dDest)) return false;
  if (dDest >= 1e12) return false;
  return dDep + 2500 < dDest;
}

/** Apply landing runway on dest chart (SimBrief arr_rwy or nearest end). */
function ensureLandingRunwayForAutoArrive(lat, lon, ctx) {
  if (ensureArrRunwayActive()) return true;
  const want = normalizeRwyName(
    state.simbriefMeta?.arr_rwy || state.flightPlan?.arr_rwy || ""
  );
  const ends = ctx.runwayEnds || [];
  if (want) {
    for (const e of ends) {
      if (normalizeRwyName(e.name) === want) {
        applyRunwaySelection(
          {
            name: e.name,
            lat: e.lat,
            lon: e.lon,
            approach_hdg: e.approach_hdg,
            runway: e.runway,
            label: e.name ? `RWY ${e.name}` : "Runway",
          },
          { forArrival: true, syncFrom: "arr-runway-select" }
        );
        return ensureArrRunwayActive();
      }
    }
  }
  // Nearest runway threshold to the aircraft (after landing / rollout)
  let best = null;
  let bestD = 3500;
  for (const e of ends) {
    if (e.lat == null || e.lon == null) continue;
    const d = haversineApproxM(lat, lon, Number(e.lat), Number(e.lon));
    if (d < bestD) {
      bestD = d;
      best = e;
    }
  }
  if (!best) return false;
  applyRunwaySelection(
    {
      name: best.name,
      lat: best.lat,
      lon: best.lon,
      approach_hdg: best.approach_hdg,
      runway: best.runway,
      label: best.name ? `RWY ${best.name}` : "Runway",
    },
    { forArrival: true, syncFrom: "arr-runway-select" }
  );
  return ensureArrRunwayActive();
}

/**
 * When lined up / holding on the selected departure runway (still on ground),
 * advance journey step to Flight plan (once per taxi-out).
 */
function maybeAutoFlightPlanOnDepRunway(lat, lon, st) {
  try {
    if (state._depRunwayFpDone) return;
    if (!state.sim.connected) return;
    if (lat == null || lon == null) return;
    if (state.mode !== "journey" && state.mode !== "taxi" && state.mode !== "departure") {
      return;
    }
    // Already on flight-plan step
    if (state.mode === "journey" && state.journeyStep === "flightplan") {
      state._depRunwayFpDone = true;
      return;
    }
    // Only from taxi-out / taxi / departure — not after landing
    if (state.mode === "journey" && state.journeyStep === "taxi-in") return;
    if (state.mode === "arrival") return;

    const onGround =
      st && st.on_ground != null ? !!st.on_ground : state.sim.onGround;
    if (onGround === false) return;

    // Need a selected departure runway
    const depName =
      state.depPick?.runway?.name ||
      (state.journeyStep !== "taxi-in" ? state.runwayEndMeta?.name : null);
    if (!depName) return;

    // Ensure runwayEndMeta is the dep runway for centreline check
    if (
      state.runwayEndMeta &&
      String(state.runwayEndMeta.name || "").toUpperCase() !==
        String(depName).toUpperCase() &&
      state.depPick?.runway
    ) {
      /* centreline helper prefers depPick when forArrival=false */
    }

    const d = minDistToRunwayCentrelineM(lat, lon, false);
    if (!Number.isFinite(d) || d > 45) return;

    // Ignore if still near gate (false positive on parallel taxiways rare but
    // gate spawn on runway heading at some airports) — require being away from start
    if (state.start && state.start.lat != null) {
      const fromGate = haversineApproxM(
        lat,
        lon,
        Number(state.start.lat),
        Number(state.start.lon)
      );
      if (fromGate < 120) return;
    }

    state._depRunwayFpDone = true;
    if (state.mode === "journey") {
      setJourneyStep("flightplan", { skipFit: true });
      setStatus("On departure runway — switched to Flight plan", "ok");
    } else if (typeof enterMode === "function" && state.depChart && state.destChart) {
      enterMode("journey");
      setTimeout(function () {
        try {
          setJourneyStep("flightplan", { skipFit: true });
        } catch (_) {}
      }, 40);
      setStatus("On departure runway — switched to Flight plan", "ok");
    } else if (typeof switchTab === "function") {
      switchTab("flightplan");
      setStatus("On departure runway — switched to Flight plan", "ok");
    }
  } catch (err) {
    console.warn("maybeAutoFlightPlanOnDepRunway", err);
  }
}

/**
 * Distance (m) from aircraft to the selected runway centreline (threshold↔far end),
 * or Infinity if we can't resolve geometry.
 */
function minDistToRunwayCentrelineM(lat, lon, forArrival) {
  try {
    const ends = forArrival
      ? state.destChart?.runwayEnds || state.runwayEnds || []
      : state.depChart?.runwayEnds || state.runwayEnds || [];
    const meta = state.runwayEndMeta;
    const want = String(
      (forArrival ? state.arrPick?.runway?.name : state.depPick?.runway?.name) ||
        meta?.name ||
        ""
    )
      .toUpperCase()
      .replace(/^RWY\s*/, "")
      .trim();
    if (!want || !ends.length) return Infinity;

    // Pair this end with the opposite threshold on the same strip
    let a = null;
    let b = null;
    for (const e of ends) {
      const n = String(e.name || "")
        .toUpperCase()
        .replace(/^RWY\s*/, "")
        .trim();
      if (!n) continue;
      if (n === want) a = e;
    }
    if (!a || a.lat == null) return Infinity;
    // Opposite: same runway strip, different end name
    const strip = a.runway || null;
    for (const e of ends) {
      if (e === a) continue;
      const n = String(e.name || "")
        .toUpperCase()
        .replace(/^RWY\s*/, "")
        .trim();
      if (strip && e.runway && e.runway === strip) {
        b = e;
        break;
      }
      // Heuristic: reciprocal heading ends often share digits (18L↔36R)
    }
    if (!b) {
      // Fall back: nearest other end within 5 km
      let bestD = 5000;
      for (const e of ends) {
        if (e === a || e.lat == null) continue;
        const d = haversineApproxM(a.lat, a.lon, e.lat, e.lon);
        if (d > 800 && d < bestD) {
          bestD = d;
          b = e;
        }
      }
    }
    if (!b || b.lat == null) {
      return haversineApproxM(lat, lon, a.lat, a.lon);
    }
    const { dist } = distPointToSegmentM(
      lat,
      lon,
      Number(a.lat),
      Number(a.lon),
      Number(b.lat),
      Number(b.lon)
    );
    return dist;
  } catch (_) {
    return Infinity;
  }
}

/**
 * Distance along the landing runway from the selected threshold toward the
 * far end (metres). Used to detect “rolled past planned exit” (E8 → E9).
 */
function alongLandingRunwayM(lat, lon) {
  try {
    const ends =
      state.destChart?.runwayEnds || state.runwayEnds || [];
    const want = String(
      state.arrPick?.runway?.name || state.runwayEndMeta?.name || ""
    )
      .toUpperCase()
      .replace(/^RWY\s*/, "")
      .trim();
    if (!want || !ends.length) return NaN;
    let a = null;
    let b = null;
    for (const e of ends) {
      const n = String(e.name || "")
        .toUpperCase()
        .replace(/^RWY\s*/, "")
        .trim();
      if (n === want) a = e;
    }
    if (!a || a.lat == null) return NaN;
    const strip = a.runway || null;
    for (const e of ends) {
      if (e === a) continue;
      if (strip && e.runway && e.runway === strip) {
        b = e;
        break;
      }
    }
    if (!b) {
      let bestD = 5000;
      for (const e of ends) {
        if (e === a || e.lat == null) continue;
        const d = haversineApproxM(a.lat, a.lon, e.lat, e.lon);
        if (d > 800 && d < bestD) {
          bestD = d;
          b = e;
        }
      }
    }
    if (!b || b.lat == null) return NaN;
    // Project onto land→far using the same local-frame idea as distPointToSegmentM
    const alat = Number(a.lat);
    const alon = Number(a.lon);
    const blat = Number(b.lat);
    const blon = Number(b.lon);
    const { dist, t } = distPointToSegmentM(lat, lon, alat, alon, blat, blon);
    if (!Number.isFinite(t)) return NaN;
    const total = haversineApproxM(alat, alon, blat, blon);
    // t is 0..1 along segment in distPointToSegmentM — confirm API
    if (typeof t === "number") return Math.max(0, t) * total;
    // Fallback: along ≈ distance from threshold when near centreline
    if (Number.isFinite(dist) && dist < 120) {
      return haversineApproxM(alat, alon, lat, lon);
    }
    return NaN;
  } catch (_) {
    return NaN;
  }
}

/**
 * Live tracking: after landing at the arrival airport, auto-assign a gate
 * (SimBrief/OFP if known, else nearest once off the runway) and build taxi-in.
 */
async function maybeAutoArriveTaxiIn(lat, lon, st) {
  if (!state.autoArriveTaxiIn) return;
  if (state._autoArriveBusy) return;
  if (!state.sim.connected) return;
  if (lat == null || lon == null) return;

  const onGround = st && st.on_ground != null ? !!st.on_ground : state.sim.onGround;
  const alt =
    st && st.altitude_ft != null
      ? Number(st.altitude_ft)
      : state.sim.altitudeFt != null
        ? Number(state.sim.altitudeFt)
        : null;
  const gs =
    st && st.gs_kt != null
      ? Number(st.gs_kt)
      : state.sim.gsKt != null
        ? Number(state.sim.gsKt)
        : null;

  // Track airborne so we only fire after a real landing, not gate spawn
  const airborne =
    onGround === false ||
    (alt != null && alt > 1200 && (gs == null || gs > 60));
  if (airborne) {
    state._simWasAirborne = true;
    state._autoArriveDoneKey = null;
    // Next landing may auto-switch again
    state._journeyStepUserLock = false;
    // Leaving the field again (go-around / next sector)
    return;
  }
  if (onGround === false) return;

  const nearDest = isNearArrivalField(lat, lon);
  if (!nearDest) return;

  // Still at departure (career accept + Connect with plan loaded) — never
  // treat that as an arrival landing when dep and dest are different fields.
  try {
    const dep = resolveDeparturePoint();
    const dest = resolveDestinationPoint();
    const depIcao = String(dep?.icao || "")
      .trim()
      .toUpperCase();
    const destIcao = String(dest?.icao || "")
      .trim()
      .toUpperCase();
    if (
      depIcao &&
      destIcao &&
      depIcao !== destIcao &&
      (isNearDepartureField(lat, lon) || isCloserToDepartureThanArrival(lat, lon))
    ) {
      return;
    }
  } catch (_) {
    /* ignore */
  }

  // Soft land: SimConnect reconnect / missed airborne flag while already on
  // the *destination* field. Do NOT treat "flight plan loaded at the gate" as
  // having been airborne — that yanked career missions to Taxi-in forever.
  if (!state._simWasAirborne) {
    const softOk =
      state.mode === "arrival" ||
      state.journeyStep === "taxi-in" ||
      !!(state.pathTracks?.arrival?.coords?.length) ||
      // Reconnect mid-rollout at dest while still on flight-plan step
      (state.journeyStep === "flightplan" &&
        nearDest &&
        !isNearDepartureField(lat, lon));
    if (!softOk) return;
    state._simWasAirborne = true;
  }

  // Flip UI to Taxi-in as soon as wheels are down at destination (even during
  // rollout). Path / stand assignment waits for taxi speed below.
  try {
    switchToTaxiInModeAfterLanding();
  } catch (_) {
    /* ignore */
  }

  // Still rolling out fast — mode already flipped; wait to build taxi-in path
  if (gs != null && gs > 55) return;

  const ctx = arrivalAirportContext();
  if (!ctx?.airport || !ctx.parking?.length) {
    setStatus(
      "Landed — switched to Taxi-in. Load destination chart / pick a stand if needed.",
      "busy"
    );
    return;
  }

  const destIcao = String(ctx.airport.icao || "").toUpperCase();
  const fpDest = String(
    state.flightPlan?.dest?.icao ||
      state.flightPlan?._raw?.dest?.icao ||
      state.destChart?.airport?.icao ||
      ""
  ).toUpperCase();
  // Prefer matching flight-plan destination when we have one
  if (fpDest && destIcao && fpDest !== destIcao) {
    if (!state.destChart?.airport?.icao) return;
  }

  const doneKey = destIcao || "arr";
  const hasTaxiIn = !!(state.pathTracks?.taxiIn?.coords?.length);
  // Allow retry while no path yet (failed first attempt / missing stand)
  if (state._autoArriveDoneKey === doneKey && hasTaxiIn) return;

  // Pre-selected gate/stand (manual list, map click, sync, journey pick) —
  // never replace with OFP/nearest. Only auto-pick when nothing is set yet.
  const preselected = _arrivalStandIfSet();
  if (preselected) {
    if (!state.arrivalStand) {
      state.arrivalStand = { ...preselected };
    }
    if (!state.arrPick) state.arrPick = { stand: null, runway: null };
    if (!state.arrPick.stand) state.arrPick.stand = { ...preselected };
    // Remember it as intentional so later chart reloads don't look "empty"
    if (!state._arrStandSource) state._arrStandSource = "user";
    if (!hasTaxiIn) {
      state._autoArriveBusy = true;
      try {
        ensureTaxiInContext();
        const data = await computeTaxiIn(false, {
          quiet: false,
          fromAircraft: true,
          skipFit: true,
        });
        if (data) {
          state._autoArriveDoneKey = doneKey;
          setStatus(
            "Taxi-in → " +
              (preselected.label || "your stand") +
              " (kept your pre-selected gate)",
            "ok"
          );
        }
      } finally {
        state._autoArriveBusy = false;
      }
    } else {
      state._autoArriveDoneKey = doneKey;
    }
    return;
  }

  state._autoArriveBusy = true;
  try {
    if (state.destChart?.airport) {
      ensureAirportForTaxiFocus("taxiIn");
    }

    const liveCtx = arrivalAirportContext() || ctx;
    if (!ensureLandingRunwayForAutoArrive(lat, lon, liveCtx)) {
      setStatus(
        "Landed — pick landing runway, then Best taxi-in (or choose a stand)",
        "busy"
      );
      return;
    }

    // No stand yet → Prefer SimBrief / OFP gate, else nearest once off runway
    // (mid-rollout nearest often picks a stand beside the strip).
    const planned =
      state.plannedArrGate ||
      state.simbriefMeta?.arr_gate ||
      null;
    let stand = planned
      ? findParkingByGateName(planned, liveCtx.parking)
      : null;
    let how = stand ? "OFP gate " + (planned || "") : null;
    if (!stand) {
      const onRwy = minDistToRunwayCentrelineM(lat, lon, true);
      if (Number.isFinite(onRwy) && onRwy < 55) {
        setStatus(
          "Landed — waiting until clear of runway to auto-pick a stand (or choose one)",
          "busy"
        );
        return;
      }
      stand = findNearestParking(lat, lon, 8000, liveCtx.parking);
      how = stand
        ? "nearest stand (" + Math.round(stand.distM) + " m)"
        : null;
    }
    if (!stand) {
      setStatus(
        "Landed at " +
          (liveCtx.airport.icao || "arrival") +
          " — no gates on chart; pick a stand for taxi-in",
        "busy"
      );
      return;
    }

    setArrivalStandChoice(stand, { source: "auto", reroute: false });
    const data = await computeTaxiIn(false, {
      quiet: false,
      fromAircraft: true,
      skipFit: true,
    });
    if (data) {
      state._autoArriveDoneKey = doneKey;
      setStatus(
        "Auto taxi-in → " +
          stand.label +
          " (" +
          how +
          "). Change gate/stand to override.",
        "ok"
      );
    } else {
      // Leave doneKey unset so we retry next poll
      setStatus(
        "Assigned " +
          stand.label +
          " — taxi-in needs a retry (Best taxi-in). You can pick another stand.",
        "busy"
      );
    }
  } catch (err) {
    console.warn("auto-arrive taxi-in", err);
  } finally {
    state._autoArriveBusy = false;
  }
}

/** Select matching option in #start-select if present. */
function selectStartDropdownForParking(parking) {
  const startSel = $("#start-select");
  if (!startSel || !parking) return;
  const wantLat = Number(parking.lat);
  const wantLon = Number(parking.lon);
  for (const opt of startSel.options || []) {
    if (!opt.value) continue;
    try {
      const v = JSON.parse(opt.value);
      if (
        Math.abs(Number(v.lat) - wantLat) < 1e-5 &&
        Math.abs(Number(v.lon) - wantLon) < 1e-5
      ) {
        startSel.value = opt.value;
        return;
      }
    } catch (_) {
      /* ignore */
    }
  }
  // Fallback: match by name in option text
  const nm = String(parking.name || parking.ref || "").toUpperCase();
  if (!nm) return;
  for (const opt of startSel.options || []) {
    if (String(opt.textContent || "").toUpperCase().includes(nm)) {
      startSel.value = opt.value;
      return;
    }
  }
}

function useAircraftAsStart() {
  if (state.sim.lat == null || state.sim.lon == null) {
    setStatus("No live aircraft position yet", "err");
    return;
  }
  const lat = state.sim.lat;
  const lon = state.sim.lon;
  const near = findNearestParking(lat, lon, 120);
  if (near) {
    setStart(near.lat, near.lon, near.label);
    selectStartDropdownForParking(near.parking);
    // Arrival taxi-in stand if that mode is active
    if (
      (typeof isArrivalPhase === "function" && isArrivalPhase()) ||
      state.mode === "arrival" ||
      state.journeyStep === "taxi-in"
    ) {
      const stand = {
        lat: near.lat,
        lon: near.lon,
        label: near.label,
      };
      state.arrivalStand = stand;
      if (!state.arrPick) state.arrPick = { stand: null, runway: null };
      state.arrPick.stand = stand;
      placeArrStandMarker(stand);
      const arrStand = $("#arr-stand-select");
      if (arrStand) {
        for (const opt of arrStand.options || []) {
          if (!opt.value) continue;
          try {
            const v = JSON.parse(opt.value);
            if (
              Math.abs(Number(v.lat) - near.lat) < 1e-5 &&
              Math.abs(Number(v.lon) - near.lon) < 1e-5
            ) {
              arrStand.value = opt.value;
              break;
            }
          } catch (_) {
            /* ignore */
          }
        }
      }
    }
    setStatus(
      `Start set to nearest gate/stand (${near.label}, ${Math.round(near.distM)} m)`,
      "ok"
    );
  } else {
    setStart(lat, lon, "Aircraft (live)");
    setStatus(
      "Taxi start set to aircraft (no gate within 120 m — pick stand from list if needed)",
      "ok"
    );
  }
}

$("#btn-sim-connect")?.addEventListener("click", () => toggleSimConnect());
$("#btn-aircraft-bubble")?.addEventListener("click", () => {
  setAircraftDataBubble(!state.sim.showDataBubble);
});
loadAircraftBubblePref();
loadAirportClutterPref();
loadMapLegendPref();
loadLiveTracePref();
loadMapStylePref();
syncMapStyleChips();

document.querySelectorAll(".map-style-chip").forEach(function (btn) {
  btn.addEventListener("click", function () {
    const id = btn.getAttribute("data-map-style");
    if (id) setMapStyle(id);
  });
});

$("#btn-map-clutter")?.addEventListener("click", () => {
  setShowAirportClutter(!state.showAirportClutter);
});
$("#btn-map-legend")?.addEventListener("click", () => {
  setShowMapLegend(!state.showMapLegend);
});
$("#btn-live-trace")?.addEventListener("click", () => {
  setShowLiveTrace(!state.showLiveTrace);
});
$("#btn-map-legend-hide")?.addEventListener("click", () => {
  setShowMapLegend(false);
});
$("#btn-map-legend-show")?.addEventListener("click", () => {
  setShowMapLegend(true);
});

$("#btn-sim-follow")?.addEventListener("click", () => {
  state.sim.follow = !state.sim.follow;
  $("#btn-sim-follow")?.classList.toggle("active", state.sim.follow);
  if (state.sim.follow) {
    // Mutual exclusion with Follow plan
    if (state.followPlan) setFollowPlan(false);
    if (state.sim.lat != null) map.panTo([state.sim.lat, state.sim.lon]);
  }
});
$("#btn-map-compass")?.addEventListener("click", () => toggleMapCompass());

function setMapToolbarMenuOpen(open) {
  const menu = $("#map-toolbar-menu");
  const btn = $("#btn-map-more");
  const wrap = $("#map-toolbar-more");
  if (!menu || !btn) return;
  const on = !!open;
  if (on) menu.removeAttribute("hidden");
  else menu.setAttribute("hidden", "");
  btn.setAttribute("aria-expanded", on ? "true" : "false");
  if (wrap) wrap.classList.toggle("is-open", on);
}

function toggleMapToolbarMenu() {
  const btn = $("#btn-map-more");
  const open = btn && btn.getAttribute("aria-expanded") === "true";
  setMapToolbarMenuOpen(!open);
}

$("#btn-map-more")?.addEventListener("click", function (ev) {
  ev.preventDefault();
  ev.stopPropagation();
  toggleMapToolbarMenu();
});

document.addEventListener("click", function (ev) {
  const wrap = $("#map-toolbar-more");
  if (!wrap || wrap.hasAttribute("hidden")) return;
  const btn = $("#btn-map-more");
  if (!btn || btn.getAttribute("aria-expanded") !== "true") return;
  if (wrap.contains(ev.target)) return;
  setMapToolbarMenuOpen(false);
});

document.addEventListener("keydown", function (ev) {
  if (ev.key !== "Escape") return;
  setMapToolbarMenuOpen(false);
});

// Initial compass face (north-up)
try {
  updateCompassUi();
} catch (_) {}
$("#btn-follow-plan")?.addEventListener("click", () => {
  setFollowPlan(!state.followPlan);
});
$("#btn-use-aircraft")?.addEventListener("click", () => useAircraftAsStart());
$("#btn-use-aircraft-start")?.addEventListener("click", () => useAircraftAsStart());

// Probe sim availability after first paint (avoid competing with hub/WebView start)
setTimeout(function () {
  fetch("/api/sim/status")
    .then((r) => r.json())
    .then((st) => setSimPill(st))
    .catch(() =>
      setSimPill({ available: false, enabled: false, connected: false })
    );
}, 1200);

// ── Map tools ────────────────────────────────────────────────────
function _setMapToolCursor(cursor) {
  try {
    if (map && map.getContainer) map.getContainer().style.cursor = cursor || "";
  } catch (_) {}
}

function _disableClickStartMode() {
  state.clickStartMode = false;
  $("#btn-click-start")?.classList.remove("active");
}

function _disableDrawTaxiMode({ clearStroke } = {}) {
  state.drawTaxiMode = false;
  $("#btn-draw-taxi")?.classList.remove("active");
  if (clearStroke !== false) _cancelPenStroke();
  try {
    if (map && map.dragging && typeof map.dragging.enable === "function") {
      map.dragging.enable();
    }
  } catch (_) {}
}

function setClickStartMode(on) {
  const enable = !!on;
  if (enable) _disableDrawTaxiMode({ clearStroke: true });
  state.clickStartMode = enable;
  $("#btn-click-start")?.classList.toggle("active", enable);
  setHint(
    enable
      ? "Click the map to set your <strong>aircraft / start</strong> position"
      : "",
    enable
  );
  _setMapToolCursor(enable ? "crosshair" : state.drawTaxiMode ? "crosshair" : "");
}

function setDrawTaxiMode(on) {
  const enable = !!on;
  if (enable) _disableClickStartMode();
  state.drawTaxiMode = enable;
  $("#btn-draw-taxi")?.classList.toggle("active", enable);
  setHint(
    enable
      ? "Trace the <strong>yellow taxi lines</strong> — release to snap onto them"
      : "",
    enable
  );
  _setMapToolCursor(enable ? "crosshair" : state.clickStartMode ? "crosshair" : "");
  if (!enable) _cancelPenStroke();
}

$("#btn-click-start")?.addEventListener("click", () => {
  setClickStartMode(!state.clickStartMode);
});

$("#btn-draw-taxi")?.addEventListener("click", () => {
  setDrawTaxiMode(!state.drawTaxiMode);
});

const _PEN_MIN_SAMPLE_M = 10;

function _haversineMClient(a, b) {
  const R = 6371000;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(b[0] - a[0]);
  const dLon = toRad(b[1] - a[1]);
  const lat1 = toRad(a[0]);
  const lat2 = toRad(b[0]);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
}

function _clearPenPreview() {
  try {
    if (baseLayers.penPreview && baseLayers.penPreview.clearLayers) {
      baseLayers.penPreview.clearLayers();
    }
  } catch (_) {}
  _penPolyline = null;
}

function _cancelPenStroke() {
  _penDrawing = false;
  _penStroke = null;
  _clearPenPreview();
  try {
    if (map && map.dragging && typeof map.dragging.enable === "function") {
      map.dragging.enable();
    }
  } catch (_) {}
}

function _updatePenPreview() {
  if (!_penStroke || _penStroke.length < 2) return;
  try {
    if (!_penPolyline) {
      _penPolyline = L.polyline(_penStroke, {
        color: "#f59e0b",
        weight: 4,
        opacity: 0.9,
        lineCap: "round",
        lineJoin: "round",
        dashArray: "6 6",
        interactive: false,
        smoothFactor: 0,
      }).addTo(baseLayers.penPreview);
    } else {
      _penPolyline.setLatLngs(_penStroke);
    }
  } catch (_) {}
}

function _penPhaseIsTaxiIn() {
  return isArrivalTaxiMode();
}

function _downsampleStroke(points, minM = 12, maxPts = 80) {
  const src = Array.isArray(points) ? points : [];
  if (src.length <= 2) return src.slice();
  const out = [src[0]];
  for (let i = 1; i < src.length; i++) {
    const prev = out[out.length - 1];
    const cur = src[i];
    if (!prev || !cur) continue;
    if (_haversineMClient(prev, cur) >= minM) out.push(cur);
    if (out.length >= maxPts - 1) break;
  }
  const last = src[src.length - 1];
  if (
    last &&
    out.length &&
    (out[out.length - 1][0] !== last[0] || out[out.length - 1][1] !== last[1])
  ) {
    out.push(last);
  }
  return out;
}

async function snapTraceAndApply(points) {
  const pts = _downsampleStroke(points, 12, 80);
  if (pts.length < 2) {
    setStatus("Draw a longer stroke along the taxiways", "err");
    return null;
  }
  const taxiIn = _penPhaseIsTaxiIn();
  try {
    ensureAirportForTaxiFocus(taxiIn ? "taxiIn" : "route");
  } catch (_) {}
  const icao = state.airport && state.airport.icao;
  if (!icao) {
    setStatus("Load an airport first, then draw a taxi path", "err");
    return null;
  }
  setLoading(true, "Snapping drawing to taxiways…");
  setStatus("Snapping hand-drawn path…", "busy");
  const ac = typeof AbortController !== "undefined" ? new AbortController() : null;
  const timeoutId = setTimeout(() => {
    try {
      if (ac) ac.abort();
    } catch (_) {}
  }, 12000);
  try {
    const res = await fetch("/api/route/snap-trace", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        icao,
        points: pts,
        phase: taxiIn ? "taxi-in" : "taxi-out",
        prefer_taxiway: true,
      }),
      signal: ac ? ac.signal : undefined,
    });
    let data = null;
    try {
      data = await res.json();
    } catch (_) {
      data = null;
    }
    if (!res.ok || !data || data.ok === false) {
      throw new Error(
        (data && data.error) ||
          "Could not snap drawing (HTTP " + res.status + ")"
      );
    }
    if (!state.manualTaxiPath) {
      state.manualTaxiPath = { route: false, taxiIn: false };
    }
    if (taxiIn) {
      drawTaxiIn(
        data,
        {
          startLat: data.coords[0][0],
          startLon: data.coords[0][1],
          startNote: "Hand-drawn start",
        },
        { skipFit: false }
      );
      showArrTaxiSummary(data, "Hand-drawn");
      state.manualTaxiPath.taxiIn = true;
    } else {
      drawRoute(data, { skipFit: false });
      showRouteSummary(data);
      state.manualTaxiPath.route = true;
    }
    setStatus(
      (data.message || "Hand-drawn taxi path ready") +
        " — draw again to replace",
      "ok"
    );
    return data;
  } catch (err) {
    console.error("snapTraceAndApply", err);
    const aborted =
      (err && err.name === "AbortError") ||
      (err && String(err.message || "").toLowerCase().includes("abort"));
    setStatus(
      aborted
        ? "Snapping timed out — try a shorter stroke along one taxiway"
        : err && err.message
          ? err.message
          : String(err),
      "err"
    );
    return null;
  } finally {
    try {
      clearTimeout(timeoutId);
    } catch (_) {}
    setLoading(false);
    _clearPenPreview();
  }
}

function _eventToLatLng(ev) {
  try {
    if (!map || typeof map.mouseEventToLatLng !== "function") return null;
    // Touch: use first changed/touch point
    let src = ev;
    if (ev && ev.touches && ev.touches[0]) src = ev.touches[0];
    else if (ev && ev.changedTouches && ev.changedTouches[0]) {
      src = ev.changedTouches[0];
    }
    const ll = map.mouseEventToLatLng(src);
    if (!ll || ll.lat == null) return null;
    return [ll.lat, ll.lng];
  } catch (_) {
    return null;
  }
}

function _bindMapInteractionTools() {
  if (_penMapBound) return;
  if (!map || map._navapronStub || typeof map.on !== "function") return;
  const container = map.getContainer && map.getContainer();
  if (!container) return;
  _penMapBound = true;

  map.on("click", (e) => {
    if (!state.clickStartMode) return;
    setStart(e.latlng.lat, e.latlng.lng, "Map position");
    setClickStartMode(false);
    setHint("Start position set", true);
    setTimeout(() => setHint("", false), 2000);
    const startSel = $("#start-select");
    if (startSel) startSel.value = "";
  });

  // Container-level capture so strokes that start on taxiway polylines still work
  // (Leaflet interactive paths swallow map mousedown otherwise).
  const onPenDown = (ev) => {
    if (!state.drawTaxiMode) return;
    try {
      if (ev && ev.button != null && ev.button !== 0) return;
      if (ev && typeof ev.preventDefault === "function") ev.preventDefault();
      if (ev && typeof ev.stopPropagation === "function") ev.stopPropagation();
    } catch (_) {}
    const pt = _eventToLatLng(ev);
    if (!pt) return;
    _penDrawing = true;
    _penStroke = [pt];
    _clearPenPreview();
    try {
      if (map.dragging && typeof map.dragging.disable === "function") {
        map.dragging.disable();
      }
    } catch (_) {}
  };

  const onPenMove = (ev) => {
    if (!_penDrawing || !state.drawTaxiMode || !_penStroke) return;
    try {
      if (ev && typeof ev.preventDefault === "function") ev.preventDefault();
    } catch (_) {}
    const pt = _eventToLatLng(ev);
    if (!pt) return;
    const last = _penStroke[_penStroke.length - 1];
    if (last && _haversineMClient(last, pt) < _PEN_MIN_SAMPLE_M) return;
    _penStroke.push(pt);
    if (_penStroke.length > 600) _penStroke.shift();
    _updatePenPreview();
  };

  const onPenUp = async (ev) => {
    if (!_penDrawing) return;
    _penDrawing = false;
    try {
      if (map.dragging && typeof map.dragging.enable === "function") {
        map.dragging.enable();
      }
    } catch (_) {}
    const pt = ev ? _eventToLatLng(ev) : null;
    if (pt && _penStroke && _penStroke.length) {
      const last = _penStroke[_penStroke.length - 1];
      if (!last || _haversineMClient(last, pt) >= 2) _penStroke.push(pt);
    }
    const pts = _penStroke ? _penStroke.slice() : [];
    _penStroke = null;
    if (pts.length < 2) {
      _clearPenPreview();
      setStatus("Draw a longer stroke along the taxiways", "err");
      return;
    }
    await snapTraceAndApply(pts);
  };

  container.addEventListener("mousedown", onPenDown, true);
  container.addEventListener("mousemove", onPenMove, true);
  container.addEventListener("mouseup", onPenUp, true);
  container.addEventListener("mouseleave", () => {
    if (_penDrawing) onPenUp(null);
  });
  container.addEventListener("touchstart", onPenDown, { capture: true, passive: false });
  container.addEventListener("touchmove", onPenMove, { capture: true, passive: false });
  container.addEventListener("touchend", onPenUp, { capture: true, passive: false });

  document.addEventListener("keydown", (ev) => {
    if (!ev || ev.key !== "Escape") return;
    if (_penDrawing) {
      _cancelPenStroke();
      setStatus("Drawing cancelled", "ok");
      return;
    }
    if (state.drawTaxiMode) {
      setDrawTaxiMode(false);
      setHint("", false);
    } else if (state.clickStartMode) {
      setClickStartMode(false);
      setHint("", false);
    }
  });
}

$("#btn-fit")?.addEventListener("click", () => {
  if (!state.layout) return;
  drawLayout(state.layout);
  if (state.start) setStart(state.start.lat, state.start.lon, state.start.label);
  if (state.end) setEnd(state.end.lat, state.end.lon, state.end.label);
});

$("#btn-refresh")?.addEventListener("click", () => {
  if (!state.airport) return;
  const asDest = state.mode === "journey" && state.journeyStep === "taxi-in";
  loadAirport(state.airport.icao, {
    refresh: true,
    role: asDest ? "dest" : "dep",
    keepPaths: true,
  });
});

// ── Flight plan ──────────────────────────────────────────────────
function clearFlightPlanLayer() {
  baseLayers.flightPlan.clearLayers();
  clearPathTrack("flightPlan");
  state.flightPlan = null;
  const sum = $("#fp-summary");
  if (sum) sum.classList.remove("visible");
  const w = $("#fp-warnings");
  if (w) w.textContent = "";
}

function _fpNear(a, b, maxM = 2500) {
  if (!a || !b || a.lat == null || b.lat == null) return false;
  return haversineM(Number(a.lat), Number(a.lon), Number(b.lat), Number(b.lon)) <= maxM;
}

/** Airport ref for procedure sanity checks (must match dep/dest, not the other end). */
function _fpAirportRef(which, data) {
  if (which === "dep") {
    return (
      data?.dep ||
      state.depChart?.airport ||
      state.flightPlan?._raw?.dep ||
      state.flightPlan?.dep ||
      null
    );
  }
  // Destination: prefer plan dest, then dest chart, then ICAO field + chart guess
  const fromPlan = data?.dest || state.flightPlan?._raw?.dest || state.flightPlan?.dest;
  if (fromPlan?.lat != null) return fromPlan;
  if (state.destChart?.airport?.lat != null) return state.destChart.airport;
  if (fromPlan?.icao && state.destChart?.airport?.icao === fromPlan.icao) {
    return state.destChart.airport;
  }
  return fromPlan || state.destChart?.airport || null;
}

function _ptFromPair(lat, lon, ident) {
  if (lat == null || lon == null || !Number.isFinite(Number(lat)) || !Number.isFinite(Number(lon))) {
    return null;
  }
  return { lat: Number(lat), lon: Number(lon), ident: ident || "WP" };
}

/**
 * SID exit = last non-runway fix in procedure order (true SID termination).
 * Do NOT pick "farthest from airport" — turning SIDs (LEMD etc.) have doglegs
 * farther out than the real exit; joining there made the pink line double back
 * along the cyan SID ("connecting twice").
 */
function getSidExitPoint(planData) {
  if (!state.activeDeparture && !(state.pathTracks?.departure?.coords?.length)) {
    return null;
  }
  const depAp = _fpAirportRef("dep", planData);
  const destAp = _fpAirportRef("dest", planData);
  const pts = state.activeDeparture?.points;
  let pt = null;

  if (pts && pts.length) {
    const candidates = pts.filter(
      (p) => p && p.lat != null && p.lon != null && p.kind !== "runway"
    );
    const list = candidates.length ? candidates : pts.filter((p) => p?.lat != null);
    if (list.length) {
      // Default: last fix in catalog order
      let best = list[list.length - 1];
      if (depAp?.lat != null && list.length > 1) {
        const dLast = haversineM(
          Number(best.lat),
          Number(best.lon),
          Number(depAp.lat),
          Number(depAp.lon)
        );
        // Odd catalogs: last point still on the field — use farthest instead
        if (dLast < 3 * 1852) {
          let far = best;
          let farD = dLast;
          for (const p of list) {
            const d = haversineM(
              Number(p.lat),
              Number(p.lon),
              Number(depAp.lat),
              Number(depAp.lon)
            );
            if (d > farD) {
              farD = d;
              far = p;
            }
          }
          best = far;
        }
      }
      pt = _ptFromPair(
        best.lat,
        best.lon,
        best.ident || state.activeDeparture?.sid_name || "SID exit"
      );
    }
  }

  if (!pt) {
    // Track fallback: last vertex of the drawn SID path
    const track = state.pathTracks?.departure?.coords;
    if (track && track.length) {
      const last = track[track.length - 1];
      pt = _ptFromPair(
        last[0],
        last[1],
        (state.pathTracks.departure.labels &&
          state.pathTracks.departure.labels[track.length - 1]) ||
          state.activeDeparture?.sid_name ||
          "SID exit"
      );
    }
  }

  if (!pt) return null;
  // Near departure (200 NM) — SIDs can extend well out
  if (depAp?.lat != null && !_fpNear(pt, depAp, 200 * 1852)) {
    console.warn("SID exit ignored — not near departure airport", pt, depAp);
    return null;
  }
  // Prefer not to use a point that is clearly at destination
  if (destAp?.lat != null && depAp?.lat != null) {
    const dDep = haversineM(pt.lat, pt.lon, Number(depAp.lat), Number(depAp.lon));
    const dDest = haversineM(pt.lat, pt.lon, Number(destAp.lat), Number(destAp.lon));
    if (dDest < dDep && dDest < 30 * 1852) {
      console.warn("SID exit ignored — closer to destination than departure");
      return null;
    }
  }
  // Never treat the airport / threshold itself as the join point
  if (depAp?.lat != null && _fpNear(pt, depAp, 1.2 * 1852)) {
    console.warn("SID exit ignored — too close to departure airport", pt);
    return null;
  }
  return pt;
}

/**
 * STAR entry = first feeder in procedure order (IAF / STAR start).
 * Do NOT pick "farthest from airport" — STARs with doglegs (EDDB etc.) have
 * mid-procedure fixes farther out than the real entry; joining there made the
 * pink line meet the wrong STAR fix instead of the start.
 *
 * Procedure point order is feeder → final → threshold.
 */
function getStarEntryPoint(planData) {
  if (!state.activeArrival && !(state.pathTracks?.arrival?.coords?.length)) {
    return null;
  }
  const destAp = _fpAirportRef("dest", planData);
  const depAp = _fpAirportRef("dep", planData);
  const pts = state.activeArrival?.points;
  let pt = null;

  function _fartherFromDest(a, b) {
    if (!destAp?.lat) return a;
    const da = haversineM(Number(a.lat), Number(a.lon), Number(destAp.lat), Number(destAp.lon));
    const db = haversineM(Number(b.lat), Number(b.lon), Number(destAp.lat), Number(destAp.lon));
    return db > da ? b : a;
  }

  if (pts && pts.length) {
    // Feeder / STAR fixes only — never kind "final" or "runway"
    const feeders = pts.filter(
      (p) =>
        p &&
        p.lat != null &&
        p.lon != null &&
        p.kind !== "runway" &&
        p.kind !== "final"
    );
    if (feeders.length) {
      // Default: first feeder in catalog order = STAR start / IAF
      let best = feeders[0];
      if (destAp?.lat != null && feeders.length > 1) {
        const dFirst = haversineM(
          Number(best.lat),
          Number(best.lon),
          Number(destAp.lat),
          Number(destAp.lon)
        );
        // Odd catalogs only: first point still on the field — use farthest
        // feeder (true outer entry). Do NOT use the old 20 NM threshold; that
        // jumped to mid-STAR doglegs on LEMD→EDDB.
        if (dFirst < 3 * 1852) {
          let far = best;
          let farD = dFirst;
          for (const p of feeders) {
            const d = haversineM(
              Number(p.lat),
              Number(p.lon),
              Number(destAp.lat),
              Number(destAp.lon)
            );
            if (d > farD) {
              farD = d;
              far = p;
            }
          }
          best = far;
        }
      }
      pt = _ptFromPair(
        best.lat,
        best.lon,
        best.ident || state.activeArrival?.star_name || "STAR entry"
      );
    } else {
      // Approach-only (all "final"): use the first final fix (start of approach),
      // not the farthest (which can be a dogleg / base turn).
      const finals = pts.filter(
        (p) => p && p.lat != null && p.lon != null && p.kind === "final"
      );
      if (finals.length) {
        let best = finals[0];
        if (destAp?.lat != null) {
          const d0 = haversineM(
            Number(best.lat),
            Number(best.lon),
            Number(destAp.lat),
            Number(destAp.lon)
          );
          if (d0 < 3 * 1852) {
            for (const p of finals) best = _fartherFromDest(best, p);
          }
        }
        pt = _ptFromPair(
          best.lat,
          best.lon,
          best.ident || state.activeArrival?.star_name || "Approach entry"
        );
      }
    }
  }

  if (!pt) {
    // Track fallback: first vertex of the drawn STAR path (start), not the
    // farthest point in the entry half (that recreated the dogleg bug).
    const track = state.pathTracks?.arrival?.coords;
    const labels = state.pathTracks?.arrival?.labels;
    if (track && track.length) {
      let idx = 0;
      if (destAp?.lat != null) {
        const d0 = haversineM(
          track[0][0],
          track[0][1],
          Number(destAp.lat),
          Number(destAp.lon)
        );
        // First vertex on the field — walk forward to first point ≥ 3 NM out
        if (d0 < 3 * 1852) {
          for (let i = 1; i < track.length; i++) {
            const d = haversineM(
              track[i][0],
              track[i][1],
              Number(destAp.lat),
              Number(destAp.lon)
            );
            if (d >= 3 * 1852) {
              idx = i;
              break;
            }
            idx = i;
          }
        }
      }
      const p = track[idx];
      pt = _ptFromPair(
        p[0],
        p[1],
        (labels && labels[idx]) ||
          state.activeArrival?.star_name ||
          "STAR entry"
      );
    }
  }

  if (!pt) return null;

  // Near destination (250 NM — long STAR transitions)
  if (destAp?.lat != null && !_fpNear(pt, destAp, 250 * 1852)) {
    console.warn("STAR entry ignored — not near destination airport", pt, destAp);
    return null;
  }
  // Reject if closer to dep than dest (wrong airport procedure)
  if (depAp?.lat != null && destAp?.lat != null) {
    const dDep = haversineM(pt.lat, pt.lon, Number(depAp.lat), Number(depAp.lon));
    const dDest = haversineM(pt.lat, pt.lon, Number(destAp.lat), Number(destAp.lon));
    if (dDep < dDest && dDep < 40 * 1852) {
      console.warn("STAR entry ignored — closer to departure than destination");
      return null;
    }
  }
  // Never treat the airport / threshold itself as the join point
  if (destAp?.lat != null && _fpNear(pt, destAp, 1.2 * 1852)) {
    console.warn("STAR entry ignored — too close to destination airport", pt);
    return null;
  }
  return pt;
}

/** Kinds that are procedure geometry or airport endpoints — not enroute DCT fixes. */
const _FP_STRIP_KINDS = new Set([
  "airport",
  "runway",
  "sid",
  "star",
  "climb",
  "final",
  "sid_join",
  "star_join",
  "vector",
  // Keep TOC/TOD on the enroute track so next-WP distance is meaningful
  // (do not strip toc/tod)
]);

/**
 * Keep enroute fixes for the pink line (SID exit → … → STAR entry).
 * Strips airport/runway and true procedure points. Only rescues mid-route
 * points mis-tagged as sid/star when they sit on the *opposite* side of the
 * flight (e.g. climb fix labelled star). Never keep arrival-half `star` or
 * departure-half `sid` — those belong on the green/cyan procedure layers
 * (GCTS / Berlin: pink was weaving through multiple STAR feeders).
 */
function extractEnrouteLegs(data) {
  let legs = (data.legs || [])
    .filter((l) => l && l.lat != null && l.lon != null)
    .map((l) => ({ ...l }));

  if (!legs.length && data.coords && data.coords.length) {
    legs = data.coords.map((c, i) => ({
      ident: i === 0 ? "START" : i === data.coords.length - 1 ? "END" : "WP",
      lat: Number(c[0]),
      lon: Number(c[1]),
      kind: "fix",
    }));
  }

  const dep = data.dep;
  const dest = data.dest;
  const nearFieldNm = 25;

  function _dists(l) {
    if (!dep?.lat || !dest?.lat || l.lat == null) return null;
    return {
      dDep: haversineM(
        Number(l.lat),
        Number(l.lon),
        Number(dep.lat),
        Number(dep.lon)
      ),
      dDest: haversineM(
        Number(l.lat),
        Number(l.lon),
        Number(dest.lat),
        Number(dest.lon)
      ),
    };
  }

  function _shouldRescueSidStar(l, k) {
    const d = _dists(l);
    if (!d) return false;
    if (d.dDep <= nearFieldNm * 1852 || d.dDest <= nearFieldNm * 1852) {
      return false;
    }
    // Arrival-half stars / finals stay on the STAR layer (often 30–150 NM out)
    if (k === "star" && d.dDest <= d.dDep) return false;
    // Departure-half sids stay on the SID layer
    if (k === "sid" && d.dDep <= d.dDest) return false;
    return true;
  }

  const fixes = legs.filter((l) => {
    const k = String(l.kind || "").toLowerCase();
    if (!_FP_STRIP_KINDS.has(k)) return true; // fix / toc / tod / …
    if ((k === "sid" || k === "star") && _shouldRescueSidStar(l, k)) return true;
    return false;
  });
  if (fixes.length >= 1) return fixes;

  // DCT airport→airport: no enroute fixes — return empty so we only join SID→STAR
  const onlyAirports = legs.every(
    (l) => l.kind === "airport" || l.kind === "runway" || !l.kind
  );
  if (onlyAirports) return [];

  // Fallback: drop first/last airport/runway only
  legs = legs.slice();
  while (legs.length && (legs[0].kind === "airport" || legs[0].kind === "runway")) {
    legs.shift();
  }
  while (
    legs.length &&
    (legs[legs.length - 1].kind === "airport" || legs[legs.length - 1].kind === "runway")
  ) {
    legs.pop();
  }
  return legs.filter((l) => {
    const k = String(l.kind || "").toLowerCase();
    if (!_FP_STRIP_KINDS.has(k) || k === "fix") return true;
    return (k === "sid" || k === "star") && _shouldRescueSidStar(l, k);
  });
}

/** True if lat/lon sits on the drawn STAR / approach (procedure layer owns it). */
function _fpOnActiveStar(l, maxM = 1852) {
  if (!l || l.lat == null) return false;
  const pts = state.activeArrival?.points;
  if (pts && pts.length) {
    for (const p of pts) {
      if (p?.lat == null) continue;
      if (_fpNear(l, p, maxM)) return true;
    }
  }
  const track = state.pathTracks?.arrival?.coords;
  if (track && track.length) {
    for (const c of track) {
      if (!c || c[0] == null) continue;
      if (
        haversineM(Number(l.lat), Number(l.lon), Number(c[0]), Number(c[1])) <=
        maxM
      ) {
        return true;
      }
    }
  }
  return false;
}

/** True if lat/lon sits on the drawn SID. */
function _fpOnActiveSid(l, maxM = 1852) {
  if (!l || l.lat == null) return false;
  const pts = state.activeDeparture?.points;
  if (pts && pts.length) {
    for (const p of pts) {
      if (p?.lat == null || p.kind === "runway") continue;
      if (_fpNear(l, p, maxM)) return true;
    }
  }
  const track = state.pathTracks?.departure?.coords;
  if (track && track.length) {
    for (const c of track) {
      if (!c || c[0] == null) continue;
      if (
        haversineM(Number(l.lat), Number(l.lon), Number(c[0]), Number(c[1])) <=
        maxM
      ) {
        return true;
      }
    }
  }
  return false;
}

/**
 * Stitch enroute plan so it joins the SID exit and STAR entry.
 * Pink = SID exit → enroute mid-fixes → STAR entry (procedures stay on own layers).
 */
function stitchFlightPlanToProcedures(data) {
  if (!data) return data;
  const sidExit = getSidExitPoint(data);
  const starEntry = getStarEntryPoint(data);

  if (!sidExit && !starEntry) {
    return { ...data, linked: { sid: false, star: false } };
  }

  let legs = extractEnrouteLegs(data);

  // No fixes: still allow SID exit → STAR entry (or dest) connector
  if (!legs.length) {
    legs = [];
    if (sidExit) {
      legs.push({
        ident: sidExit.ident || "SID",
        lat: sidExit.lat,
        lon: sidExit.lon,
        kind: "sid_join",
        note: "Join from SID",
      });
    } else if (data.dep?.lat != null) {
      legs.push({
        ident: data.dep.icao || "DEP",
        lat: Number(data.dep.lat),
        lon: Number(data.dep.lon),
        kind: "airport",
      });
    }
    if (starEntry) {
      legs.push({
        ident: starEntry.ident || "STAR",
        lat: starEntry.lat,
        lon: starEntry.lon,
        kind: "star_join",
        note: "Join to STAR",
      });
    } else if (data.dest?.lat != null) {
      legs.push({
        ident: data.dest.icao || "DEST",
        lat: Number(data.dest.lat),
        lon: Number(data.dest.lon),
        kind: "airport",
      });
    }
  } else {
    // Drop procedure/airport endpoints at the start — keep real enroute fixes.
    // Pink must meet the SID at the exit once; never keep OFP SID clones that
    // make the line double back along the cyan procedure (LEMD → LEPA / LEAS).
    if (sidExit) {
      const exitDistDep =
        data.dep?.lat != null
          ? haversineM(
              sidExit.lat,
              sidExit.lon,
              Number(data.dep.lat),
              Number(data.dep.lon)
            )
          : null;
      while (legs.length > 0) {
        const head = legs[0];
        const k0 = String(head.kind || "").toLowerCase();
        if (
          k0 === "airport" ||
          k0 === "runway" ||
          k0 === "sid" ||
          k0 === "sid_join" ||
          k0 === "climb"
        ) {
          legs.shift();
          continue;
        }
        if (data.dep?.lat != null && _fpNear(head, data.dep, 1.5 * 1852)) {
          legs.shift();
          continue;
        }
        if (_fpNear(head, sidExit, 1.5 * 1852)) {
          legs.shift();
          continue;
        }
        // OFP duplicates of SID geometry — cyan layer owns these
        if (_fpOnActiveSid(head, 1.5 * 1852)) {
          legs.shift();
          continue;
        }
        // Still inside the SID bubble toward the field (closer to dep than exit)
        if (
          exitDistDep != null &&
          data.dep?.lat != null &&
          head.lat != null
        ) {
          const dHead = haversineM(
            Number(head.lat),
            Number(head.lon),
            Number(data.dep.lat),
            Number(data.dep.lon)
          );
          if (dHead + 2 * 1852 < exitDistDep) {
            legs.shift();
            continue;
          }
        }
        break;
      }
      legs.unshift({
        ident: sidExit.ident || "SID",
        lat: sidExit.lat,
        lon: sidExit.lon,
        kind: "sid_join",
        note: "Join from SID",
      });
    } else if (data.dep?.lat != null) {
      if (!legs.length || !_fpNear(legs[0], data.dep, 5000)) {
        legs.unshift({
          ident: data.dep.icao || "DEP",
          lat: Number(data.dep.lat),
          lon: Number(data.dep.lon),
          kind: "airport",
        });
      }
    }

    // Re-anchor the END on STAR / approach *entry* only — never keep a chain of
    // STAR feeders on the pink line (GCTS / Berlin).
    if (starEntry) {
      const entryDistDest =
        data.dest?.lat != null
          ? haversineM(
              starEntry.lat,
              starEntry.lon,
              Number(data.dest.lat),
              Number(data.dest.lon)
            )
          : null;
      while (legs.length > 0) {
        const last = legs[legs.length - 1];
        const kind = String(last.kind || "").toLowerCase();
        if (
          kind === "airport" ||
          kind === "runway" ||
          kind === "star" ||
          kind === "star_join" ||
          kind === "final" ||
          kind === "climb"
        ) {
          legs.pop();
          continue;
        }
        if (_fpNear(last, starEntry, 1.5 * 1852)) {
          legs.pop();
          continue;
        }
        // Any OFP fix that sits on the drawn STAR/approach → green layer owns it
        if (_fpOnActiveStar(last, 1.5 * 1852)) {
          legs.pop();
          continue;
        }
        // Past the join toward the field (closer to dest than the entry is)
        if (
          entryDistDest != null &&
          data.dest?.lat != null &&
          last.lat != null
        ) {
          const dLast = haversineM(
            Number(last.lat),
            Number(last.lon),
            Number(data.dest.lat),
            Number(data.dest.lon)
          );
          if (dLast + 2 * 1852 < entryDistDest) {
            legs.pop();
            continue;
          }
        }
        break;
      }
      legs.push({
        ident: starEntry.ident || "STAR",
        lat: starEntry.lat,
        lon: starEntry.lon,
        kind: "star_join",
        note: "Join to STAR",
      });
    } else if (data.dest?.lat != null) {
      const last = legs[legs.length - 1];
      if (!last || !_fpNear(last, data.dest, 5000)) {
        legs.push({
          ident: data.dest.icao || "DEST",
          lat: Number(data.dest.lat),
          lon: Number(data.dest.lon),
          kind: "airport",
        });
      }
    }
  }

  // Final sweep: drop any remaining non-join points that duplicate SID/STAR
  // geometry (OFP often lists procedure fixes as kind=fix). Joins are the
  // only pink contact with the cyan/green layers — never keep a near-exit twin.
  legs = legs.filter((l) => {
    const k = String(l.kind || "").toLowerCase();
    if (k === "sid_join" || k === "star_join") return true;
    if (starEntry && _fpOnActiveStar(l, 1.5 * 1852)) return false;
    if (sidExit && _fpOnActiveSid(l, 1.5 * 1852)) return false;
    return true;
  });

  // Dedupe consecutive points
  const clean = [];
  for (const leg of legs) {
    if (
      clean.length &&
      Math.abs(clean[clean.length - 1].lat - leg.lat) < 1e-5 &&
      Math.abs(clean[clean.length - 1].lon - leg.lon) < 1e-5
    ) {
      continue;
    }
    clean.push(leg);
  }

  // Guard: if everything collapsed near dep, abort stitch and return original
  if (clean.length >= 2 && data.dep?.lat != null && data.dest?.lat != null) {
    const span = haversineM(
      clean[0].lat,
      clean[0].lon,
      clean[clean.length - 1].lat,
      clean[clean.length - 1].lon
    );
    const od = haversineM(
      Number(data.dep.lat),
      Number(data.dep.lon),
      Number(data.dest.lat),
      Number(data.dest.lon)
    );
    // Stitched path much shorter than dep–dest → likely wrong join
    if (od > 30000 && span < od * 0.15) {
      console.warn("Flight plan stitch rejected — path collapsed near one airport");
      return { ...data, linked: { sid: false, star: false }, stitchRejected: true };
    }
  }

  const coords = clean.map((l) => [l.lat, l.lon]);
  let distM = 0;
  for (let i = 0; i < coords.length - 1; i++) {
    distM += haversineM(coords[i][0], coords[i][1], coords[i + 1][0], coords[i + 1][1]);
  }

  const linkBits = [];
  if (sidExit) linkBits.push("SID");
  if (starEntry) linkBits.push("STAR");
  const baseMsg = (data.message || "").replace(/\s*·\s*linked to.*$/i, "");
  const linkNote =
    linkBits.length > 0 ? ` · linked to ${linkBits.join(" + ")}` : "";

  return {
    ...data,
    legs: clean,
    coords,
    distance_m: Math.round(distM),
    distance_nm: Math.round((distM / 1852) * 10) / 10,
    message: baseMsg + linkNote,
    linked: { sid: !!sidExit, star: !!starEntry },
  };
}

function _clonePlanRaw(src) {
  if (!src) return null;
  return {
    coords: Array.isArray(src.coords)
      ? src.coords.map((c) => (Array.isArray(c) ? [c[0], c[1]] : c))
      : src.coords,
    legs: Array.isArray(src.legs) ? src.legs.map((l) => ({ ...l })) : src.legs,
    message: src.message,
    distance_nm: src.distance_nm,
    distance_m: src.distance_m,
    icao_route: src.icao_route,
    dep: src.dep ? { ...src.dep } : src.dep,
    dest: src.dest ? { ...src.dest } : src.dest,
    warnings: src.warnings ? [...src.warnings] : src.warnings,
    route_text: src.route_text,
    source: src.source,
  };
}

function relinkFlightPlanToProcedures() {
  if (!state.flightPlan) return;
  const fp = state.flightPlan;
  // Always restitch from the original unlinked plan (never from prior join geometry)
  const base = _clonePlanRaw(fp._raw) || _clonePlanRaw(fp);
  if (!base) return;
  if (!base.dest && fp.dest) base.dest = { ...fp.dest };
  if (!base.dep && fp.dep) base.dep = { ...fp.dep };
  if (!base.source && fp.source) base.source = fp.source;

  const linked = stitchFlightPlanToProcedures(base);
  linked._raw = fp._raw ? _clonePlanRaw(fp._raw) : _clonePlanRaw(base);
  // Preserve SimBrief/OFP source across SID/STAR re-link
  if (!linked.source) {
    linked.source = fp.source || fp._raw?.source || base.source || null;
  }
  if (linked._raw && !linked._raw.source && linked.source) {
    linked._raw.source = linked.source;
  }
  state.flightPlan = linked;
  drawFlightPlan(linked, { fit: false, skipStitch: true });

  if ($("#fp-summary")?.classList.contains("visible")) {
    if ($("#fp-dist") && linked.distance_nm != null) {
      $("#fp-dist").textContent =
        `${linked.distance_nm} NM` +
        (linked.distance_m != null ? ` (${linked.distance_m} m)` : "");
    }
    if ($("#fp-msg") && linked.message) $("#fp-msg").textContent = linked.message;
  }

  const bits = [];
  if (linked.linked?.sid) bits.push("SID");
  if (linked.linked?.star) bits.push("STAR");
  if (bits.length) {
    setStatus("Flight plan re-linked to " + bits.join(" + "), "ok");
  }
}

/** True when flightTrace is the live tracking path (not a logbook review). */
let _flightTraceIsLive = false;
/** Who owns the live pink path: "airline" | "career" | "live" | null */
let _flightTraceOwner = null;
/** Dedicated SVG renderer so live updates don't blank the map canvas pane. */
let _flightTraceRenderer = null;
/** In-place live polyline/markers — avoid clear+redraw flash every poll. */
let _liveTracePolyline = null;
let _liveTraceStartMarker = null;
let _liveTraceEndMarker = null;

function _getFlightTraceRenderer() {
  if (_flightTraceRenderer) return _flightTraceRenderer;
  try {
    if (map && !map._navapronStub && L && typeof L.svg === "function") {
      _flightTraceRenderer = L.svg({ padding: 0.5 });
      return _flightTraceRenderer;
    }
  } catch (_) {}
  return null;
}

/** Clear the flown-path overlay (live or logbook review). */
function clearFlownTrace() {
  try {
    if (baseLayers && baseLayers.flightTrace && baseLayers.flightTrace.clearLayers) {
      baseLayers.flightTrace.clearLayers();
    }
  } catch (_) {}
  _flightTraceIsLive = false;
  _flightTraceOwner = null;
  _liveTracePolyline = null;
  _liveTraceStartMarker = null;
  _liveTraceEndMarker = null;
}

/**
 * Clear only the live tracking trail — leaves a logbook “Show on map” path.
 * Pass owner ("airline"|"career") so Airline polls don't wipe a Career trace
 * (and the reverse).
 */
function clearLiveTrackingTrace(owner) {
  if (!_flightTraceIsLive) return;
  if (owner && _flightTraceOwner && owner !== _flightTraceOwner) return;
  clearFlownTrace();
}

function _traceToLatLngs(trace) {
  const latlngs = [];
  if (!Array.isArray(trace)) return latlngs;
  for (let i = 0; i < trace.length; i++) {
    const p = trace[i];
    let la = null;
    let lo = null;
    if (Array.isArray(p) && p.length >= 2) {
      la = Number(p[0]);
      lo = Number(p[1]);
    } else if (p && typeof p === "object") {
      la = Number(p.lat);
      lo = Number(p.lon != null ? p.lon : p.lng);
    }
    if (!Number.isFinite(la) || !Number.isFinite(lo)) continue;
    latlngs.push([la, lo]);
  }
  return latlngs;
}

/**
 * Draw a flown trace (live tracking or saved logbook path).
 * @param {Array} trace — [{lat,lon}|[lat,lon], ...]
 * @param {{ fit?: boolean, label?: string, quiet?: boolean, live?: boolean }} [opts]
 */
function showFlownTrace(trace, opts) {
  opts = opts || {};
  const live = !!opts.live;
  const fit = opts.fit !== false && !live;
  const label = opts.label || (live ? "Tracking path" : "Flown path");
  const owner = opts.owner || (live ? "live" : "logbook");
  clearFlownTrace();
  const latlngs = _traceToLatLngs(trace);
  if (latlngs.length < 2) {
    if (!opts.quiet && !live) {
      setStatus("No flown path recorded for this flight", "err");
    }
    return false;
  }
  if (!live) {
    try {
      if (typeof enterMode === "function" && state.mode === "hub") {
        enterMode("journey");
      }
    } catch (_) {}
  }
  try {
    ensureMapReady();
  } catch (_) {}
  if (!map || map._navapronStub || !baseLayers || !baseLayers.flightTrace) {
    if (!opts.quiet && !live) {
      setStatus("Map not ready — open Journey and try again", "err");
    }
    return false;
  }
  let unwrapped = latlngs;
  try {
    if (typeof unwrapLatLngs === "function") unwrapped = unwrapLatLngs(latlngs);
  } catch (_) {}
  try {
    _flightTraceIsLive = live;
    _flightTraceOwner = live ? owner : "logbook";
    _liveTracePolyline = null;
    _liveTraceStartMarker = null;
    _liveTraceEndMarker = null;
    const renderer = live ? _getFlightTraceRenderer() : null;
    const pathOpts = {
      color: "#f472b6",
      weight: live ? 3 : 3.5,
      opacity: live ? 0.9 : 0.88,
      // Solid for live precision; dashed when reviewing a finished log
      dashArray: live ? null : "10 8",
      lineCap: "round",
      lineJoin: "round",
      smoothFactor: live ? 0 : 1,
      className: "flight-trace-line" + (live ? " is-live" : ""),
    };
    if (renderer) pathOpts.renderer = renderer;
    const line = L.polyline(unwrapped, pathOpts)
      .bindPopup("<strong>" + _escapeHtml(label) + "</strong>")
      .addTo(baseLayers.flightTrace);
    const mkOpts = {
      radius: live ? 3.5 : 5,
      color: "#fb7185",
      fillColor: "#fda4af",
      fillOpacity: 0.95,
      weight: 2,
      interactive: false,
    };
    if (renderer) mkOpts.renderer = renderer;
    const startMk = L.circleMarker(unwrapped[0], mkOpts).addTo(baseLayers.flightTrace);
    const endOpts = {
      radius: live ? 4 : 5,
      color: "#db2777",
      fillColor: "#f472b6",
      fillOpacity: 0.95,
      weight: 2,
      interactive: false,
    };
    if (renderer) endOpts.renderer = renderer;
    const endMk = L.circleMarker(unwrapped[unwrapped.length - 1], endOpts).addTo(
      baseLayers.flightTrace
    );
    if (live) {
      _liveTracePolyline = line;
      _liveTraceStartMarker = startMk;
      _liveTraceEndMarker = endMk;
    }
    if (!map.hasLayer(baseLayers.flightTrace)) {
      baseLayers.flightTrace.addTo(map);
    }
    if (fit) {
      try {
        map.fitBounds(L.latLngBounds(unwrapped).pad(0.18));
      } catch (_) {}
    }
    if (!opts.quiet && !live) {
      setStatus(label + " — " + latlngs.length + " points", "ok");
    }
    return true;
  } catch (err) {
    console.warn("showFlownTrace", err);
    if (!opts.quiet && !live) {
      setStatus(
        "Could not draw flown path: " +
          (err && err.message ? err.message : String(err)),
        "err"
      );
    }
    return false;
  }
}

/**
 * Update the live tracking path from airline/career active.trace_live.
 * @param {object|null} active
 * @param {{ label?: string }} [opts]
 */
function updateLiveTrackingTrace(active, opts) {
  opts = opts || {};
  const owner = opts.owner || "live";
  if (!active || !(active.tracking || active.has_trace_live)) {
    clearLiveTrackingTrace(owner);
    return false;
  }
  // Toolbar “Hide trace” — tracking continues; only the map path is suppressed
  if (state.showLiveTrace === false) {
    clearLiveTrackingTrace(owner);
    return false;
  }
  const trace = active.trace_live || active.trace;
  if (!Array.isArray(trace) || trace.length < 2) return false;
  const label =
    opts.label ||
    active.flight_number ||
    active.title ||
    (active.dep_icao || active.dep || "?") +
      " → " +
      (active.dest_icao || active.dest || "?");

  // In-place update — never clear+redraw while the same owner is live
  if (
    _flightTraceIsLive &&
    _liveTracePolyline &&
    typeof _liveTracePolyline.setLatLngs === "function" &&
    (!_flightTraceOwner || _flightTraceOwner === owner)
  ) {
    try {
      let latlngs = _traceToLatLngs(trace);
      if (latlngs.length < 2) return false;
      try {
        if (typeof unwrapLatLngs === "function") latlngs = unwrapLatLngs(latlngs);
      } catch (_) {}
      _flightTraceOwner = owner;
      _liveTracePolyline.setLatLngs(latlngs);
      if (_liveTraceStartMarker && typeof _liveTraceStartMarker.setLatLng === "function") {
        _liveTraceStartMarker.setLatLng(latlngs[0]);
      }
      if (_liveTraceEndMarker && typeof _liveTraceEndMarker.setLatLng === "function") {
        _liveTraceEndMarker.setLatLng(latlngs[latlngs.length - 1]);
      }
      return true;
    } catch (err) {
      console.warn("updateLiveTrackingTrace in-place", err);
      // Fall through to full redraw
    }
  }

  return showFlownTrace(trace, {
    live: true,
    fit: false,
    quiet: true,
    label: String(label),
    owner: owner,
  });
}

function drawFlightPlan(data, { fit = true, skipStitch = false } = {}) {
  baseLayers.flightPlan.clearLayers();
  if (!data) {
    clearPathTrack("flightPlan");
    return;
  }
  // Preserve original for re-link; stitch SID exit / STAR entry
  if (!data._raw && !skipStitch) {
    data = {
      ...data,
      _raw: {
        coords: data.coords,
        legs: data.legs,
        message: data.message,
        distance_nm: data.distance_nm,
        distance_m: data.distance_m,
        icao_route: data.icao_route,
        dep: data.dep,
        dest: data.dest,
        warnings: data.warnings,
        route_text: data.route_text,
        source: data.source,
      },
    };
  }
  const plan = skipStitch ? data : stitchFlightPlanToProcedures(data._raw || data);
  if (!skipStitch) {
    plan._raw = data._raw || data;
    // Keep OFP source on the live plan so auto-rebuild never replaces it
    if (!plan.source && (data.source || data._raw?.source)) {
      plan.source = data.source || data._raw.source;
    }
    state.flightPlan = plan;
  } else if (data && !state.flightPlan) {
    state.flightPlan = data;
  }

  if (!plan?.coords || plan.coords.length < 2) {
    clearPathTrack("flightPlan");
    return;
  }
  const latlngs = unwrapLatLngs(plan.coords.map((c) => [c[0], c[1]]));
  if (latlngs.length < 2) {
    clearPathTrack("flightPlan");
    return;
  }

  const linked = plan.linked || {};
  L.polyline(latlngs, {
    color: "#a855f7",
    weight: 10,
    opacity: 0.28,
    lineCap: "round",
    lineJoin: "round",
  }).addTo(baseLayers.flightPlan);
  L.polyline(latlngs, {
    color: linked.sid || linked.star ? "#e9d5ff" : "#c084fc",
    weight: 4,
    opacity: 0.95,
    lineCap: "round",
    lineJoin: "round",
    dashArray: linked.sid || linked.star ? "2 0" : null,
  }).addTo(baseLayers.flightPlan);

  (plan.legs || []).forEach((leg, i) => {
    if (leg.lat == null || leg.lon == null) return;
    const isJoin = leg.kind === "sid_join" || leg.kind === "star_join";
    const isEnd = i === 0 || i === plan.legs.length - 1;
    L.circleMarker([leg.lat, leg.lon], {
      radius: isJoin ? 8 : isEnd ? 7 : 5,
      color: isJoin ? "#fde68a" : "#f3e8ff",
      weight: 2,
      fillColor: isJoin
        ? leg.kind === "sid_join"
          ? "#c084fc"
          : "#4ade80"
        : isEnd
          ? "#a855f7"
          : "#7c3aed",
      fillOpacity: 0.95,
    })
      .bindTooltip(
        (leg.ident || "WP") + (isJoin ? " (join)" : ""),
        { permanent: false, direction: "top" }
      )
      .addTo(baseLayers.flightPlan);
  });
  if (state.layerVisibility.flightPlan && !map.hasLayer(baseLayers.flightPlan)) {
    baseLayers.flightPlan.addTo(map);
  }
  const trackCoords = unwrapLatLngs(
    (plan.legs || [])
      .filter((l) => l.lat != null && l.lon != null)
      .map((l) => [l.lat, l.lon])
  );
  const trackLabels = (plan.legs || [])
    .filter((l) => l.lat != null && l.lon != null)
    .map((l) => l.ident || "");
  setPathTrack("flightPlan", trackCoords.length >= 2 ? trackCoords : latlngs, {
    name: "Flight plan",
    labels: trackLabels.length ? trackLabels : null,
  });
  if (state.sim.lat != null) updateActiveLeg(state.sim.lat, state.sim.lon);
  if (fit) {
    try {
      map.fitBounds(L.latLngBounds(latlngs).pad(0.15));
    } catch (_) {}
  }
}

function showFpSummary(data) {
  state.flightPlan = data;
  const sum = $("#fp-summary");
  if (sum) {
    sum.classList.add("visible");
    $("#fp-dist").textContent =
      data.distance_nm != null
        ? `${data.distance_nm} NM` +
          (data.distance_m != null ? ` (${data.distance_m} m)` : "")
        : "—";
    $("#fp-msg").textContent = data.message || "";
    $("#fp-via").textContent = data.icao_route || "";
  }
  const w = $("#fp-warnings");
  if (w) {
    const bits = [];
    if (data.source === "simbrief") bits.push("Source: SimBrief OFP");
    if (data.aircraft) bits.push("A/C " + data.aircraft);
    if (data.airac) bits.push("AIRAC " + data.airac);
    if ((data.warnings || []).length) bits.push(data.warnings.join(" · "));
    w.textContent = bits.join(" · ");
  }
  if (data.dep?.icao && $("#fp-dep")) $("#fp-dep").value = data.dep.icao;
  if (data.dest?.icao && $("#fp-dest")) $("#fp-dest").value = data.dest.icao;
  if (data.route_text != null && $("#fp-route")) $("#fp-route").value = data.route_text;
}

function _arrRunwayMeta() {
  const sel = $("#arr-runway-select");
  if (!sel?.value) return null;
  try {
    return JSON.parse(sel.value);
  } catch {
    return null;
  }
}

let _fpAutoBuildTimer = null;
let _fpAutoBuildBusy = false;
/** Last auto-built pair `DEP|DEST` — skip duplicate rebuilds */
let _fpAutoBuildKey = "";

function _fpIcaoPair() {
  const dep = ($("#fp-dep")?.value || "").trim().toUpperCase();
  const dest = ($("#fp-dest")?.value || "").trim().toUpperCase();
  if (!dep || !dest || dep === dest) return null;
  if (dep.length < 4 || dest.length < 4) return null;
  return { dep: dep, dest: dest, key: dep + "|" + dest };
}

/**
 * True when the pink line came from a SimBrief/OFP navlog (full lat/lon fixes),
 * not from the local navaids route builder (which drops RNAV waypoints).
 */
function _isImportedOfpPlan(fp) {
  if (!fp) return false;
  const src = String(fp.source || fp._raw?.source || "").toLowerCase();
  return src === "simbrief" || src === "ofp" || src === "imported";
}

/**
 * Draw enroute path automatically once Dep + Dest are known (DCT if Route empty).
 * Never replaces an imported SimBrief/OFP track — the navaids rebuild only knows
 * VORs/NDBs, so RNAV midpoints (KONAN, REMBA, SUTAL, …) would vanish.
 * @param {{ force?: boolean, quiet?: boolean }} [opts]
 */
async function autoShowFlightPlanIfReady(opts) {
  opts = opts || {};
  const pair = _fpIcaoPair();
  if (!pair) return false;
  if (!opts.force && pair.key === _fpAutoBuildKey && state.flightPlan) {
    return false;
  }
  // Protect full OFP geometry from chart-load / Dep+Dest auto-rebuild
  if (state.flightPlan && _isImportedOfpPlan(state.flightPlan)) {
    const existingDep = String(
      state.flightPlan.dep?.icao || state.flightPlan._raw?.dep?.icao || ""
    )
      .trim()
      .toUpperCase();
    const existingDest = String(
      state.flightPlan.dest?.icao || state.flightPlan._raw?.dest?.icao || ""
    )
      .trim()
      .toUpperCase();
    if (existingDep === pair.dep && existingDest === pair.dest) {
      _fpAutoBuildKey = pair.key;
      return false;
    }
  }
  if (_fpAutoBuildBusy) return false;
  _fpAutoBuildBusy = true;
  try {
    const routeEl = $("#fp-route");
    if (routeEl && !(routeEl.value || "").trim()) {
      routeEl.value = "DCT";
    }
    await buildFlightPlan({ quiet: !!opts.quiet, fromAuto: true });
    _fpAutoBuildKey = pair.key;
    return true;
  } finally {
    _fpAutoBuildBusy = false;
  }
}

function scheduleAutoShowFlightPlan(delayMs) {
  if (_fpAutoBuildTimer) {
    clearTimeout(_fpAutoBuildTimer);
    _fpAutoBuildTimer = null;
  }
  // If a SimBrief/OFP plan is already on the map for this pair, do not schedule
  // a navaids rebuild (loadAirport used to fire this ~250ms into chart load and
  // wipe RNAV midpoints a few seconds after import).
  const pair = _fpIcaoPair();
  if (
    pair &&
    state.flightPlan &&
    _isImportedOfpPlan(state.flightPlan)
  ) {
    const existingDep = String(
      state.flightPlan.dep?.icao || state.flightPlan._raw?.dep?.icao || ""
    )
      .trim()
      .toUpperCase();
    const existingDest = String(
      state.flightPlan.dest?.icao || state.flightPlan._raw?.dest?.icao || ""
    )
      .trim()
      .toUpperCase();
    if (existingDep === pair.dep && existingDest === pair.dest) {
      _fpAutoBuildKey = pair.key;
      return;
    }
  }
  _fpAutoBuildTimer = setTimeout(function () {
    _fpAutoBuildTimer = null;
    autoShowFlightPlanIfReady({ quiet: true }).catch(function () {});
  }, delayMs == null ? 450 : delayMs);
}

/**
 * @param {{ quiet?: boolean, fromAuto?: boolean }} [opts]
 */
async function buildFlightPlan(opts) {
  opts = opts || {};
  const dep = ($("#fp-dep")?.value || "").trim().toUpperCase();
  const dest = ($("#fp-dest")?.value || "").trim().toUpperCase();
  let route = ($("#fp-route")?.value || "").trim();
  if (!dep || !dest) {
    if (!opts.fromAuto) setStatus("Enter departure and destination ICAO", "err");
    return;
  }
  if (!route) {
    route = "DCT";
    if ($("#fp-route")) $("#fp-route").value = "DCT";
  }
  const ownLoading = !opts.quiet;
  if (ownLoading) setLoading(true, "Building flight plan…");
  setStatus("Building enroute plan…", "busy");
  try {
    const arrMeta = _arrRunwayMeta();
    // Prefer journey dep runway (taxi/SID) over arrival runway if active chart is dest
    const depRwy =
      state.end?.label?.replace(/^RWY\s*/i, "") ||
      (state.depChart && state.runwayEndMeta && !isArrivalTaxiMode()
        ? state.runwayEndMeta.name
        : null) ||
      $("#runway-select")?.selectedOptions?.[0]?.textContent?.replace(/^Runway\s*/i, "") ||
      null;

    // Do NOT pass sid_id/star_id into the builder — that embeds full SID/STAR
    // geometry into the plan, and stitching then loops back to the departure.
    // Map join uses the drawn SID exit / STAR entry only.
    const body = {
      dep_icao: dep,
      dest_icao: dest,
      route_text: route,
      dep_rwy: depRwy || state.end?.label?.replace(/^RWY\s*/i, "") || null,
      arr_rwy: arrMeta?.name || null,
      sid_id: null,
      star_id: null,
      dep_lat: state.end?.lat ?? state.depChart?.airport?.lat ?? null,
      dep_lon: state.end?.lon ?? state.depChart?.airport?.lon ?? null,
      arr_lat: arrMeta?.lat ?? null,
      arr_lon: arrMeta?.lon ?? null,
    };
    const res = await fetch("/api/flightplan/build", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.ok === false) {
      const detail = data.detail;
      const msg =
        typeof detail === "string"
          ? detail
          : Array.isArray(detail)
            ? detail.map((d) => d.msg || d).join("; ")
            : data.error || "Build failed";
      throw new Error(msg);
    }
    // Stitch to drawn SID exit / STAR entry so the purple plan joins procedures
    const linked = stitchFlightPlanToProcedures(data);
    linked._raw = {
      coords: data.coords,
      legs: data.legs,
      message: data.message,
      distance_nm: data.distance_nm,
      distance_m: data.distance_m,
      icao_route: data.icao_route,
      dep: data.dep,
      dest: data.dest,
      warnings: data.warnings,
      route_text: data.route_text,
    };
    showFpSummary(linked);
    drawFlightPlan(linked, { skipStitch: true });
    _fpAutoBuildKey = dep + "|" + dest;
    const joinBits = [];
    if (linked.linked?.sid) joinBits.push("SID");
    if (linked.linked?.star) joinBits.push("STAR");
    setStatus(
      (linked.message || "Flight plan ready") +
        (joinBits.length ? ` (joined to ${joinBits.join(" + ")})` : ""),
      "ok"
    );
  } catch (err) {
    setStatus(err.message || "Flight plan failed", "err");
  } finally {
    if (ownLoading) setLoading(false);
  }
}

/**
 * Career sightseeing hop: paint a DCT plan like SimBrief import.
 * Draws the purple enroute line immediately from airport lat/lon.
 */
async function applyCareerDirectPlan(depIcao, destIcao) {
  const dep = String(depIcao || "")
    .trim()
    .toUpperCase();
  const dest = String(destIcao || "")
    .trim()
    .toUpperCase();
  if (!dep || !dest) {
    throw new Error("Career mission missing departure or destination");
  }

  try {
    await ensureLeafletLoaded();
  } catch (err) {
    console.error(err);
    throw new Error("Map library not loaded yet — wait a second and try again");
  }
  try {
    ensureMapReady();
  } catch (err) {
    console.warn("ensureMapReady before career plan", err);
  }
  if (!map || map._navapronStub) {
    throw new Error("Map is not ready yet");
  }

  try {
    clearSessionPlanning({ quiet: true });
  } catch (err) {
    console.warn("clearSessionPlanning before career plan", err);
  }
  if (_fpAutoBuildTimer) {
    clearTimeout(_fpAutoBuildTimer);
    _fpAutoBuildTimer = null;
  }

  if ($("#fp-dep")) $("#fp-dep").value = dep;
  if ($("#fp-dest")) $("#fp-dest").value = dest;
  if ($("#fp-route")) $("#fp-route").value = "DCT";
  if ($("#fp-ac") && !($("#fp-ac").value || "").trim()) {
    $("#fp-ac").value = "C172";
  }

  setLoading(true, `Loading career hop ${dep} → ${dest}…`);
  try {
    const [depRes, destRes] = await Promise.all([
      fetch("/api/airports/" + encodeURIComponent(dep), { cache: "no-store" }),
      fetch("/api/airports/" + encodeURIComponent(dest), { cache: "no-store" }),
    ]);
    const depAp = await depRes.json().catch(() => null);
    const destAp = await destRes.json().catch(() => null);
    if (!depRes.ok || !depAp || depAp.lat == null || depAp.lon == null) {
      throw new Error("Unknown departure airport: " + dep);
    }
    if (!destRes.ok || !destAp || destAp.lat == null || destAp.lon == null) {
      throw new Error("Unknown destination airport: " + dest);
    }

    const toRad = (d) => (d * Math.PI) / 180;
    const Rnm = 3440.065;
    const dLat = toRad(destAp.lat - depAp.lat);
    const dLon = toRad(destAp.lon - depAp.lon);
    const aa =
      Math.sin(dLat / 2) ** 2 +
      Math.cos(toRad(depAp.lat)) *
        Math.cos(toRad(destAp.lat)) *
        Math.sin(dLon / 2) ** 2;
    const nm = 2 * Rnm * Math.asin(Math.min(1, Math.sqrt(aa)));

    // Prefer API builder, always fall back to straight DCT
    let data = null;
    try {
      const res = await fetch("/api/flightplan/build", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dep_icao: dep,
          dest_icao: dest,
          route_text: "DCT",
          dep_lat: depAp.lat,
          dep_lon: depAp.lon,
          arr_lat: destAp.lat,
          arr_lon: destAp.lon,
        }),
      });
      const built = await res.json().catch(() => ({}));
      if (res.ok && built && built.ok !== false && (built.coords || []).length >= 2) {
        data = built;
      }
    } catch (_) {}

    if (!data) {
      data = {
        ok: true,
        coords: [
          [Number(depAp.lat), Number(depAp.lon)],
          [Number(destAp.lat), Number(destAp.lon)],
        ],
        legs: [
          {
            ident: dep,
            lat: Number(depAp.lat),
            lon: Number(depAp.lon),
            kind: "airport",
          },
          {
            ident: dest,
            lat: Number(destAp.lat),
            lon: Number(destAp.lon),
            kind: "airport",
          },
        ],
        dep: {
          icao: dep,
          name: depAp.name,
          lat: Number(depAp.lat),
          lon: Number(depAp.lon),
        },
        dest: {
          icao: dest,
          name: destAp.name,
          lat: Number(destAp.lat),
          lon: Number(destAp.lon),
        },
        distance_nm: Math.round(nm * 10) / 10,
        distance_m: Math.round(nm * 1852),
        icao_route: dep + " DCT " + dest,
        message: dep + " → " + dest + " (direct)",
        route_text: "DCT",
        warnings: [],
      };
    }

    data.source = "career";
    data.route_text = "DCT";
    data.ok = true;

    // Make sure Enroute layer is on
    try {
      state.layerVisibility.flightPlan = true;
      document
        .querySelectorAll('.layer-chip[data-layer="flightPlan"]')
        .forEach(function (chip) {
          chip.classList.add("active");
        });
    } catch (_) {}

    showFpSummary(data);
    // Draw via normal path
    drawFlightPlan(data, { fit: false, skipStitch: true });
    state.flightPlan = data;
    _fpAutoBuildKey = dep + "|" + dest;

    // Hard guarantee: if layer group is empty/missing, paint raw Leaflet line
    try {
      if (baseLayers.flightPlan && map) {
        if (!map.hasLayer(baseLayers.flightPlan)) {
          baseLayers.flightPlan.addTo(map);
        }
        const n =
          typeof baseLayers.flightPlan.getLayers === "function"
            ? baseLayers.flightPlan.getLayers().length
            : 0;
        if (n < 1) {
          const ll = data.coords.map(function (c) {
            return [c[0], c[1]];
          });
          L.polyline(ll, {
            color: "#c084fc",
            weight: 5,
            opacity: 0.95,
          }).addTo(baseLayers.flightPlan);
          L.circleMarker(ll[0], {
            radius: 7,
            color: "#f3e8ff",
            fillColor: "#a855f7",
            fillOpacity: 0.95,
          })
            .bindTooltip(dep)
            .addTo(baseLayers.flightPlan);
          L.circleMarker(ll[ll.length - 1], {
            radius: 7,
            color: "#f3e8ff",
            fillColor: "#a855f7",
            fillOpacity: 0.95,
          })
            .bindTooltip(dest)
            .addTo(baseLayers.flightPlan);
        }
      }
    } catch (paintErr) {
      console.error("career force paint", paintErr);
    }

    try {
      state.journeyStep = "flightplan";
      setJourneyStep("flightplan", { skipFit: true });
    } catch (_) {}

    try {
      const ll = data.coords.map(function (c) {
        return [c[0], c[1]];
      });
      map.fitBounds(L.latLngBounds(ll).pad(0.25));
      map.invalidateSize(true);
    } catch (_) {}

    // Charts in background for taxi later
    setTimeout(function () {
      loadBothAirports({
        dep,
        dest,
        quietLoading: true,
        skipSessionPush: true,
      }).catch(function (err) {
        console.warn("career chart load", err);
      });
    }, 400);

    setStatus(
      `Career plan ready: ${dep} → ${dest}` +
        (data.distance_nm != null ? ` (${data.distance_nm} NM)` : ""),
      "ok"
    );
    return data;
  } finally {
    setLoading(false);
  }
}

/**
 * Load departure + destination surface charts without wiping paths.
 * @param {{ dep?: string, dest?: string, quietLoading?: boolean }} [opts]
 *   Pass ICAOs explicitly (SimBrief OFP) so we don't depend only on form fields.
 */
async function loadBothAirports(opts = {}) {
  const dep = (
    opts.dep ||
    $("#fp-dep")?.value ||
    state.flightPlan?.dep?.icao ||
    state.flightPlan?._raw?.dep?.icao ||
    state.depChart?.airport?.icao ||
    ""
  )
    .toString()
    .trim()
    .toUpperCase();
  const dest = (
    opts.dest ||
    $("#fp-dest")?.value ||
    state.flightPlan?.dest?.icao ||
    state.flightPlan?._raw?.dest?.icao ||
    state.destChart?.airport?.icao ||
    ""
  )
    .toString()
    .trim()
    .toUpperCase();
  if (!dep || !dest) {
    setStatus("Set both departure and destination ICAOs first", "err");
    return { dep: null, dest: null };
  }
  // Keep form fields in sync
  if ($("#fp-dep")) $("#fp-dep").value = dep;
  if ($("#fp-dest")) $("#fp-dest").value = dest;

  const ownLoading = !opts.quietLoading;
  // Keep overlay up for the whole dual load (child loadAirport uses quietLoading)
  let bothGen = null;
  if (ownLoading) {
    bothGen = setLoading(true, `Loading ${dep} + ${dest} charts…`);
  }
  setStatus(`Loading ${dep} + ${dest} for gate-to-gate…`, "busy");
  _setSbStatus(`Loading charts ${dep} → ${dest}…`);

  let depChart = null;
  let destChart = null;
  try {
    depChart = await loadAirport(dep, {
      role: "dep",
      keepPaths: true,
      fit: false,
      quietLoading: true,
      skipSessionPush: !!opts.skipSessionPush,
    });
    if (ownLoading) bothGen = setLoading(true, `Loading ${dest} chart…`);
    destChart = await loadAirport(dest, {
      role: "dest",
      keepPaths: true,
      fit: false,
      quietLoading: true,
      skipSessionPush: !!opts.skipSessionPush,
    });

    redrawSurfaces({ fit: false });
    if (state.flightPlan) drawFlightPlan(state.flightPlan, { fit: false });
    // Active chart follows journey step / flight-plan overview
    if (state.journeyStep === "taxi-in" && state.destChart) {
      applyChartAsActive(state.destChart, { fit: false, redrawAll: true });
    } else if (state.journeyStep === "flightplan") {
      // Show both surfaces under the enroute plan
      redrawSurfaces({ fit: false });
      if (state.depChart) {
        state.airport = state.depChart.airport;
        state.layout = state.depChart.layout;
        state.runwayEnds = state.depChart.runwayEnds || [];
        renderAirportCard({
          airport: state.depChart.airport,
          layout: state.depChart.layout,
        });
        populateSelects({
          airport: state.depChart.airport,
          layout: state.depChart.layout,
          runway_ends: state.depChart.runwayEnds,
        });
      }
    } else if (state.depChart) {
      applyChartAsActive(state.depChart, { fit: false, redrawAll: true });
    }
    try {
      fitAllRoutes();
    } catch (_) {}

    const _chartOk = function (ch) {
      if (!ch || !ch.layout) return false;
      const st = ch.layout.stats || {};
      if (st.minimal) return false;
      return (st.taxiway_segments || 0) > 0 || (st.named_taxiways || 0) > 0;
    };
    // Prefer the just-fetched chart; ignore leftover stub charts in state
    if (depChart) state.depChart = depChart;
    if (destChart) state.destChart = destChart;
    if (state.depChart && !_chartOk(state.depChart)) state.depChart = depChart || null;
    if (state.destChart && !_chartOk(state.destChart)) state.destChart = destChart || null;
    const okDep = _chartOk(depChart) || _chartOk(state.depChart);
    const okDest = _chartOk(destChart) || _chartOk(state.destChart);
    if (okDep && okDest) {
      setStatus(`Gate-to-gate: ${dep} → ${dest} charts loaded`, "ok");
      setHint(
        `Both airports loaded — <strong>${escapeHtml(dep)}</strong> (taxi out) · <strong>${escapeHtml(dest)}</strong> (taxi in)`,
        true
      );
      setTimeout(() => setHint("", false), 7000);
      // Auto-draw enroute path once both airports are known — skip if a matching
      // plan is already on the map (e.g. SimBrief OFP just applied).
      try {
        if (_fpAutoBuildTimer) {
          clearTimeout(_fpAutoBuildTimer);
          _fpAutoBuildTimer = null;
        }
        const existingDep = String(
          state.flightPlan?.dep?.icao ||
            state.flightPlan?._raw?.dep?.icao ||
            ""
        )
          .trim()
          .toUpperCase();
        const existingDest = String(
          state.flightPlan?.dest?.icao ||
            state.flightPlan?._raw?.dest?.icao ||
            ""
        )
          .trim()
          .toUpperCase();
        const alreadyHavePlan =
          !!state.flightPlan &&
          existingDep === dep &&
          existingDest === dest;
        if (!alreadyHavePlan) {
          if (ownLoading) bothGen = setLoading(true, "Drawing flight plan…");
          await autoShowFlightPlanIfReady({ force: true, quiet: true });
        } else {
          try {
            drawFlightPlan(state.flightPlan, { fit: false });
          } catch (_) {}
        }
        try {
          fitAllRoutes();
        } catch (_) {}
      } catch (err) {
        console.warn("autoShowFlightPlanIfReady after loadBoth", err);
      }
    } else {
      const missing = [!okDep && dep, !okDest && dest].filter(Boolean).join(", ");
      setStatus(`Charts incomplete — failed: ${missing || "unknown"}`, "err");
    }
    return { dep: depChart, dest: destChart };
  } finally {
    if (ownLoading) clearLoadingIf(bothGen);
  }
}

let _sbWaitAbort = false;
let _sbGenerateInFlight = false;
let _sbImportInFlight = false;

function _sbUserBody(raw) {
  return /^\d+$/.test(raw) ? { userid: raw } : { username: raw };
}

function _setSbStatus(text) {
  const el = $("#fp-sb-status");
  if (el) el.textContent = text || "";
}

function _setSbWaitingUi(on) {
  $("#btn-sb-cancel-wait")?.classList.toggle("hidden", !on);
  const gen = $("#btn-sb-generate");
  if (gen) gen.disabled = !!on;
  const setupGo = $("#btn-sb-setup-go");
  if (setupGo) setupGo.disabled = !!on;
  const setupImp = $("#btn-sb-setup-import");
  if (setupImp) setupImp.disabled = !!on;
}

async function openSimBriefDispatch(extra = {}) {
  const dep = ($("#fp-dep")?.value || "").trim().toUpperCase();
  const dest = ($("#fp-dest")?.value || "").trim().toUpperCase();
  const typecode =
    ($("#fp-ac")?.value || getRememberedAircraftType() || "B738")
      .trim()
      .toUpperCase() || "B738";
  if ($("#fp-ac")) $("#fp-ac").value = typecode;
  if ($("#sb-ac")) $("#sb-ac").value = typecode;
  persistAircraftType(typecode);
  const route = ($("#fp-route")?.value || "").trim();
  try {
    const res = await fetch("/api/simbrief/dispatch-url", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        orig: dep || null,
        dest: dest || null,
        typecode,
        route: route || null,
        static_id: extra.static_id || null,
      }),
    });
    const data = await res.json();
    if (!data.url) throw new Error("No SimBrief URL");
    window.open(data.url, "_blank", "noopener,noreferrer");
    if (!extra.quiet) {
      setStatus(
        "SimBrief opened — generate the OFP, then use Generate & import or Import latest",
        "ok"
      );
    }
    return data.url;
  } catch (err) {
    const q = new URLSearchParams();
    if (dep) q.set("orig", dep);
    if (dest) q.set("dest", dest);
    q.set("type", typecode);
    if (route) q.set("route", route);
    if (extra.static_id) q.set("static_id", extra.static_id);
    const url =
      "https://dispatch.simbrief.com/options/custom?" + q.toString();
    window.open(url, "_blank", "noopener,noreferrer");
    return url;
  }
}

function setSbOfpBubbleVisible(show) {
  const bubble = $("#sb-ofp-bubble");
  const tab = $("#btn-sb-ofp-show");
  if (!bubble) return;
  if (show) {
    bubble.classList.remove("hidden");
    bubble.removeAttribute("hidden");
    if (tab) {
      tab.classList.add("hidden");
      tab.setAttribute("hidden", "");
    }
  } else {
    bubble.classList.add("hidden");
    bubble.setAttribute("hidden", "");
    // Only show restore tab if we have OFP data loaded
    if (tab && state.simbriefOfpSummary) {
      tab.classList.remove("hidden");
      tab.removeAttribute("hidden");
    }
  }
}

function hideSbOfpBubble() {
  setSbOfpBubbleVisible(false);
}

function showSbOfpBubble() {
  if (!state.simbriefOfpSummary) return;
  setSbOfpBubbleVisible(true);
}

function clearSbOfpBubble() {
  state.simbriefOfpSummary = null;
  const bubble = $("#sb-ofp-bubble");
  const tab = $("#btn-sb-ofp-show");
  if (bubble) {
    bubble.classList.add("hidden");
    bubble.setAttribute("hidden", "");
  }
  if (tab) {
    tab.classList.add("hidden");
    tab.setAttribute("hidden", "");
  }
}

/** Fill and show the bottom-centre SimBrief summary bubble. */
function showSbOfpSummary(data) {
  const s = data?.ofp_summary;
  if (!s || !s.has_data) {
    // Still try with partial top-level fields if present
    if (!s) {
      clearSbOfpBubble();
      return;
    }
  }
  state.simbriefOfpSummary = s;

  const set = (id, val) => {
    const el = $(id);
    if (el) el.textContent = val || "—";
  };
  set("#sb-ofp-cruise", s.cruise_alt);
  set("#sb-ofp-time", s.flight_time);
  set("#sb-ofp-payload", s.payload);
  set("#sb-ofp-zfw", s.zfw);
  set("#sb-ofp-fuel", s.fuel);
  set("#sb-ofp-tow", s.tow);

  const title = $("#sb-ofp-bubble-title");
  if (title) {
    const route =
      (data.dep?.icao || "?") + " → " + (data.dest?.icao || "?");
    const ac = data.aircraft ? " · " + data.aircraft : "";
    title.textContent = "SimBrief · " + route + ac;
  }

  setSbOfpBubbleVisible(true);
}

async function applySimBriefPlan(data) {
  if (data && !data.source) data.source = "simbrief";
  // Map drawing needs Leaflet — wait if panel/boot deferred it
  try {
    await ensureLeafletLoaded();
  } catch (err) {
    console.error(err);
    throw new Error(
      "Map library not loaded yet — wait a second and try Import again"
    );
  }
  try {
    ensureMapReady();
  } catch (err) {
    console.warn("ensureMapReady before SimBrief paint", err);
  }
  // Same wipe as hub “Clear session” so a previous flight’s taxi paths, SID/STAR,
  // stands, and charts don’t leak into the new OFP (same-session re-import).
  try {
    clearSessionPlanning({ quiet: true });
  } catch (err) {
    console.warn("clearSessionPlanning before SimBrief import", err);
  }
  // Cancel any pending Dep/Dest auto-rebuild BEFORE painting — chart loads used
  // to schedule a navaids rebuild ~250ms later that dropped RNAV midpoints
  // (KONAN, REMBA, SUTAL, …) while keeping VORs (BIG, KOK, GTQ).
  if (_fpAutoBuildTimer) {
    clearTimeout(_fpAutoBuildTimer);
    _fpAutoBuildTimer = null;
  }
  showFpSummary(data);
  // First paint may have no SID/STAR drawn yet (full track). After charts load,
  // applySimBriefSidStarToMap → relink stitches SID exit → mid-fixes → STAR entry.
  drawFlightPlan(data);
  reportCommunityFlightPlan(data, "simbrief");
  showSbOfpSummary(data);
  const depIcao = (data.dep?.icao || "").toString().trim().toUpperCase();
  const destIcao = (data.dest?.icao || "").toString().trim().toUpperCase();
  if (depIcao && destIcao) {
    _fpAutoBuildKey = depIcao + "|" + destIcao;
  }
  if (depIcao && $("#fp-dep")) $("#fp-dep").value = depIcao;
  if (destIcao && $("#fp-dest")) $("#fp-dest").value = destIcao;
  if (data.route_text != null && $("#fp-route")) {
    $("#fp-route").value = data.route_text;
  }
  // Always apply OFP aircraft type and remember for next plan
  if (data.aircraft) {
    applyAircraftTypeToFields(data.aircraft);
    persistAircraftType(data.aircraft);
  }
  // Remember SimBrief SID/STAR (injected into server catalog on import)
  state.simbriefProcedures = data.procedures || null;
  state.simbriefMeta = {
    sid_ident: data.sid_ident || null,
    star_ident: data.star_ident || null,
    dep_rwy: data.dep_rwy || null,
    arr_rwy: data.arr_rwy || null,
    dep_gate: data.dep_gate || null,
    arr_gate: data.arr_gate || null,
  };
  state.plannedArrGate = data.arr_gate || null;

  // Always load both surface charts from the OFP (gate-to-gate ready)
  try {
    if (depIcao && destIcao) {
      setStatus(`OFP imported — loading ${depIcao} + ${destIcao} charts…`, "busy");
      _setSbStatus(`Loading charts ${depIcao} → ${destIcao}…`);
      // Use owned loading overlay so BOTH dep+dest charts always finish visibly
      // and the spinner is cleared (quietLoading alone left dest unloaded / stuck).
      await loadBothAirports({
        dep: depIcao,
        dest: destIcao,
        quietLoading: false,
        skipSessionPush: true,
      });
    } else if (depIcao) {
      await loadAirport(depIcao, {
        role: "dep",
        keepPaths: true,
        fit: false,
        quietLoading: false,
        skipSessionPush: true,
      });
    } else if (destIcao) {
      await loadAirport(destIcao, {
        role: "dest",
        keepPaths: true,
        fit: false,
        quietLoading: false,
        skipSessionPush: true,
      });
    }
  } finally {
    try {
      setLoading(false);
    } catch (_) {}
  }

  // Runways + SID/STAR: select and draw on the map automatically
  try {
    await applySimBriefSidStarToMap(data);
  } catch (err) {
    console.warn("applySimBriefSidStarToMap", err);
  }

  const extra = [];
  if (data.sid_ident || data.procedures?.sid?.id) {
    extra.push("SID " + (data.sid_ident || data.procedures.sid.id));
  }
  if (data.star_ident || data.procedures?.star?.id) {
    extra.push("STAR " + (data.star_ident || data.procedures.star.id));
  }
  const msg =
    (data.message || "SimBrief plan imported") +
    (extra.length ? " — applied " + extra.join(" + ") : "");
  const bothOk =
    !!(state.depChart && state.destChart) || !(depIcao && destIcao);
  setStatus(
    bothOk
      ? msg
      : `OFP imported but charts incomplete (${depIcao || "?"} / ${destIcao || "?"})`,
    bothOk ? "ok" : "err"
  );
  _setSbStatus(data.message || "Imported");
  if (data.warnings && data.warnings.length) {
    console.warn("SimBrief warnings:", data.warnings);
  }
  try {
    if (window.NavApronPlates && typeof window.NavApronPlates.onSimBriefImported === "function") {
      window.NavApronPlates.onSimBriefImported(data);
    }
  } catch (err) {
    console.warn("plates.onSimBriefImported", err);
  }
}

/** Compact procedure id for matching (HELDO 2A / HELDO2A → HELDO2A). */
function _procIdKey(s) {
  return String(s || "")
    .toUpperCase()
    .replace(/\s+/g, "");
}

/** Select a runway end on the given chart into dep or arr picks. */
function _selectOfpRunway(chart, rwyName, { forArrival }) {
  if (!chart || !rwyName) return false;
  const want = normalizeRwyName(rwyName);
  const ends = chart.runwayEnds || [];
  let hit = ends.find((e) => normalizeRwyName(e.name) === want);
  if (!hit) {
    // Bare number match (07 vs 07L)
    const bare = want.replace(/[LCR]$/, "");
    hit = ends.find(
      (e) => normalizeRwyName(e.name).replace(/[LCR]$/, "") === bare
    );
  }
  if (!hit) return false;
  applyRunwaySelection(
    {
      name: hit.name,
      lat: hit.lat,
      lon: hit.lon,
      approach_hdg: hit.approach_hdg,
      runway: hit.runway,
      label: hit.name ? `RWY ${hit.name}` : "Runway",
    },
    {
      forArrival: !!forArrival,
      syncFrom: forArrival ? "arr-runway-select" : "dep-runway-select",
    }
  );
  return true;
}

/** Put procedure into select; inject option if missing. Also fill ATC field. */
function _selectProcInDropdown(selId, atcId, procId, prettyName) {
  const id = _procIdKey(procId);
  if (!id) return false;
  const atc = $(atcId);
  if (atc) atc.value = prettyName || procId;
  const sel = $(selId);
  if (!sel) return !!atc;
  let matched = null;
  for (const opt of sel.options || []) {
    if (!opt.value) continue;
    const v = _procIdKey(opt.value);
    const t = _procIdKey(opt.textContent);
    if (v === id || t.includes(id) || id.includes(v)) {
      matched = opt.value;
      break;
    }
  }
  if (!matched) {
    const opt = document.createElement("option");
    opt.value = procId;
    opt.textContent = `[SimBrief] ${prettyName || procId}`;
    sel.appendChild(opt);
    matched = procId;
    // Keep suggestions list in sync for Show SID meta lookup
    if (selId === "#dep-select") {
      state.depSuggestions = (state.depSuggestions || []).concat([
        {
          id: procId,
          name: prettyName || procId,
          kind: "sid",
          source: "simbrief",
        },
      ]);
    }
    if (selId === "#arr-select") {
      state.arrSuggestions = (state.arrSuggestions || []).concat([
        {
          id: procId,
          name: prettyName || procId,
          kind: "star",
          source: "simbrief",
        },
      ]);
    }
  }
  sel.value = matched;
  sel.disabled = false;
  return true;
}

/**
 * After SimBrief OFP import: set dep/arr runways, select SID/STAR, draw both on map.
 */
async function applySimBriefSidStarToMap(data) {
  if (!data) return;
  const sidId =
    data.sid_ident ||
    data.procedures?.sid?.id ||
    null;
  const starId =
    data.star_ident ||
    data.procedures?.star?.id ||
    null;
  const sidName =
    data.procedures?.sid?.name || data.sid_ident || sidId;
  const starName =
    data.procedures?.star?.name || data.star_ident || starId;

  const drawn = [];

  // ── SID on departure airport ───────────────────────────────────
  if (sidId && state.depChart?.airport) {
    try {
      applyChartAsActive(state.depChart, { fit: false, redrawAll: true });
      if (data.dep_rwy) {
        _selectOfpRunway(state.depChart, data.dep_rwy, { forArrival: false });
      } else {
        ensureDepRunwayActive();
      }
      await onRunwayChangedForDeparture();
      _selectProcInDropdown("#dep-select", "#dep-atc", sidId, sidName);
      // Draw via dropdown (catalog/SimBrief runtime). Clear ATC temporarily so
      // showDeparture doesn't take the generic ATC/custom path.
      const atc = $("#dep-atc");
      const atcSaved = atc ? atc.value : "";
      if (atc) atc.value = "";
      const sel = $("#dep-select");
      if (sel && !sel.value) sel.value = sidId;
      await showDeparture();
      if (atc) atc.value = atcSaved || sidName || sidId;
      drawn.push("SID " + (sidName || sidId));
    } catch (err) {
      console.warn("auto SID draw failed", err);
      // Fallback: ATC field only
      try {
        const atc = $("#dep-atc");
        if (atc) atc.value = sidName || sidId;
        await showDeparture();
        drawn.push("SID " + (sidName || sidId));
      } catch (err2) {
        console.warn("auto SID ATC fallback failed", err2);
      }
    }
  } else if (data.dep_rwy && state.depChart) {
    try {
      applyChartAsActive(state.depChart, { fit: false, redrawAll: true });
      _selectOfpRunway(state.depChart, data.dep_rwy, { forArrival: false });
    } catch (_) {
      /* ignore */
    }
  }

  // ── STAR on destination airport ────────────────────────────────
  if (starId && state.destChart?.airport) {
    try {
      applyChartAsActive(state.destChart, { fit: false, redrawAll: true });
      if (data.arr_rwy) {
        _selectOfpRunway(state.destChart, data.arr_rwy, { forArrival: true });
      } else {
        ensureArrRunwayActive();
      }
      await onRunwayChangedForArrival();
      _selectProcInDropdown("#arr-select", "#arr-atc", starId, starName);
      const atc = $("#arr-atc");
      const atcSaved = atc ? atc.value : "";
      if (atc) atc.value = "";
      const sel = $("#arr-select");
      if (sel && !sel.value) sel.value = starId;
      await showArrival();
      if (atc) atc.value = atcSaved || starName || starId;
      drawn.push("STAR " + (starName || starId));
    } catch (err) {
      console.warn("auto STAR draw failed", err);
      try {
        const atc = $("#arr-atc");
        if (atc) atc.value = starName || starId;
        await showArrival();
        drawn.push("STAR " + (starName || starId));
      } catch (err2) {
        console.warn("auto STAR ATC fallback failed", err2);
      }
    }
  } else if (data.arr_rwy && state.destChart) {
    try {
      applyChartAsActive(state.destChart, { fit: false, redrawAll: true });
      _selectOfpRunway(state.destChart, data.arr_rwy, { forArrival: true });
    } catch (_) {
      /* ignore */
    }
  }

  // Show both airports + procedures together.
  // skipStitch: true — SID/STAR draw already called relinkFlightPlanToProcedures;
  // stitching again here used to collapse SimBrief waypoints a few seconds after import.
  try {
    if (state.depChart && state.destChart) {
      redrawSurfaces({ fit: false });
      restoreAllPathLayers();
      if (state.flightPlan) {
        drawFlightPlan(state.flightPlan, { fit: false, skipStitch: true });
      }
      fitJourneyOverview({ quiet: true });
    }
  } catch (_) {
    /* ignore */
  }

  if (drawn.length) {
    setStatus("SimBrief procedures applied: " + drawn.join(" · "), "ok");
  }
}

/**
 * Import the latest OFP from the user's SimBrief account.
 * @param {{ fromSetup?: boolean }} opts fromSetup: use setup form user field + open Full journey
 */
async function importSimBriefOfp(opts = {}) {
  if (_sbImportInFlight) return;
  const fromSetup = !!opts.fromSetup;
  const raw = fromSetup
    ? ($("#sb-user")?.value || "").trim()
    : ($("#fp-sb-user")?.value || "").trim();
  if (!raw) {
    const msg = "Enter your SimBrief username or pilot ID";
    setStatus(msg, "err");
    if (fromSetup) _setSbSetupStatus(msg);
    else _setSbStatus(msg);
    return;
  }
  persistSimBriefUser(raw);
  // Keep main plan fields in sync when importing from setup
  if (fromSetup && $("#fp-sb-user")) $("#fp-sb-user").value = raw;

  _sbImportInFlight = true;
  setLoading(true, "Importing SimBrief OFP…");
  setStatus("Fetching latest SimBrief flight plan…", "busy");
  _setSbStatus("Fetching latest OFP…");
  if (fromSetup) _setSbSetupStatus("Fetching your last SimBrief OFP…");
  try {
    const res = await fetch("/api/simbrief/import", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(_sbUserBody(raw)),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.ok === false) {
      const detail = data.detail;
      throw new Error(
        typeof detail === "string"
          ? detail
          : data.error || "SimBrief import failed"
      );
    }
    if (fromSetup) {
      hideSimBriefSetup();
      enterMode("journey");
      // Wait for Leaflet + map shell before painting OFP (avoids "L is not defined")
      try {
        await ensureLeafletLoaded();
      } catch (_) {}
      for (let i = 0; i < 40; i++) {
        try {
          if (ensureMapReady()) break;
        } catch (_) {}
        await new Promise(function (r) {
          setTimeout(r, 100);
        });
      }
      try {
        setJourneyStep("flightplan");
      } catch (_) {}
      await applySimBriefPlan(data);
      const dI = data.dep?.icao || "?";
      const aI = data.dest?.icao || "?";
      setStatus(
        `Last SimBrief OFP imported — ${dI} + ${aI} charts loaded`,
        "ok"
      );
      _setSbSetupStatus("");
    } else {
      await applySimBriefPlan(data);
    }
  } catch (err) {
    setStatus(err.message || "SimBrief import failed", "err");
    _setSbStatus(err.message || "Import failed");
    if (fromSetup) {
      _setSbSetupStatus(err.message || "Import failed");
      // Don't leave the user trapped off-hub after a failed setup import
      try {
        if (!$("#hub") || $("#hub").hidden) {
          if ($("#sb-setup") && !$("#sb-setup").hidden) {
            /* still on setup — Back works */
          } else {
            showSimBriefSetup();
          }
        }
      } catch (_) {}
    }
  } finally {
    _sbImportInFlight = false;
    setLoading(false);
  }
}

/**
 * Open SimBrief Dispatch prefilled, wait until a *new* OFP appears for this
 * user (matching dep/dest when possible), then import automatically.
 *
 * @param {{ fromSetup?: boolean }} opts fromSetup: after import open Full journey map
 */
async function generateAndImportSimBrief(opts = {}) {
  if (_sbGenerateInFlight) return;
  const fromSetup = !!opts.fromSetup;
  const raw = fromSetup
    ? ($("#sb-user")?.value || "").trim()
    : ($("#fp-sb-user")?.value || "").trim();
  if (!raw) {
    const msg = "Enter your SimBrief username or pilot ID first";
    setStatus(msg, "err");
    if (fromSetup) _setSbSetupStatus(msg);
    else _setSbStatus(msg);
    return;
  }
  const dep = fromSetup
    ? (_sbPicks.dep?.icao || $("#sb-dep-search")?.value || "").trim().toUpperCase()
    : ($("#fp-dep")?.value || "").trim().toUpperCase();
  const dest = fromSetup
    ? (_sbPicks.dest?.icao || $("#sb-dest-search")?.value || "").trim().toUpperCase()
    : ($("#fp-dest")?.value || "").trim().toUpperCase();
  if (!dep || !dest) {
    const msg = "Select departure and arrival airports first";
    setStatus(msg, "err");
    if (fromSetup) _setSbSetupStatus(msg);
    else _setSbStatus(msg);
    return;
  }
  // Ensure pick objects exist if user typed ICAO only
  if (fromSetup) {
    if (!_sbPicks.dep) setSbAirportPick("dep", { icao: dep });
    if (!_sbPicks.dest) setSbAirportPick("dest", { icao: dest });
  }
  const typecode = fromSetup
    ? ($("#sb-ac")?.value || getRememberedAircraftType() || "B738")
        .trim()
        .toUpperCase() || "B738"
    : ($("#fp-ac")?.value || getRememberedAircraftType() || "B738")
        .trim()
        .toUpperCase() || "B738";
  const route = fromSetup
    ? ($("#sb-route")?.value || "").trim()
    : ($("#fp-route")?.value || "").trim();

  // Sync into main plan fields so journey map has them
  if ($("#fp-dep")) $("#fp-dep").value = dep;
  if ($("#fp-dest")) $("#fp-dest").value = dest;
  if ($("#fp-ac")) $("#fp-ac").value = typecode;
  if ($("#sb-ac")) $("#sb-ac").value = typecode;
  if ($("#fp-route") && route) $("#fp-route").value = route;
  if ($("#fp-sb-user")) $("#fp-sb-user").value = raw;
  if ($("#sb-user")) $("#sb-user").value = raw;
  persistSimBriefUser(raw);
  persistAircraftType(typecode);

  _sbGenerateInFlight = true;
  _sbWaitAbort = false;
  _setSbWaitingUi(true);
  if (fromSetup) {
    $("#btn-sb-setup-cancel-wait")?.classList.remove("hidden");
    const go = $("#btn-sb-setup-go");
    if (go) go.disabled = true;
  }
  setLoading(true, "Preparing SimBrief…");
  setStatus("Opening SimBrief Dispatch…", "busy");
  _setSbStatus("Starting session…");
  if (fromSetup) _setSbSetupStatus("Opening SimBrief…");

  try {
    const body = {
      ..._sbUserBody(raw),
      orig: dep,
      dest: dest,
      typecode,
      route: route || null,
    };
    const res = await fetch("/api/simbrief/generate-session", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const session = await res.json().catch(() => ({}));
    if (!res.ok || session.ok === false) {
      throw new Error(
        typeof session.detail === "string"
          ? session.detail
          : session.error || "Could not start SimBrief session"
      );
    }

    window.open(session.url, "_blank", "noopener,noreferrer");
    const beforeFp = session.before_fingerprint || null;
    const wantDep = (session.want_dep || dep).toUpperCase();
    const wantDest = (session.want_dest || dest).toUpperCase();

    setStatus(
      "SimBrief opened — click Generate Flight Plan there. Waiting to import…",
      "busy"
    );
    _setSbStatus(
      "Waiting for you to click Generate on SimBrief… (auto-import when ready)"
    );
    if (fromSetup) {
      _setSbSetupStatus(
        "SimBrief opened — click Generate Flight Plan, then wait here…"
      );
    }
    setLoading(true, "Waiting for SimBrief OFP…");

    const maxPolls = 80; // ~4 minutes at 3s
    for (let i = 0; i < maxPolls; i++) {
      if (_sbWaitAbort) {
        setStatus("SimBrief wait cancelled", "ok");
        _setSbStatus("Cancelled — use Import latest when ready");
        if (fromSetup) _setSbSetupStatus("Cancelled");
        return;
      }
      await new Promise((r) => setTimeout(r, 3000));
      if (_sbWaitAbort) return;

      const sec = (i + 1) * 3;
      setStatus(`Waiting for SimBrief OFP… ${sec}s`, "busy");
      _setSbStatus(
        `Waiting for new OFP (${sec}s) — generate on the SimBrief page…`
      );
      if (fromSetup) {
        _setSbSetupStatus(`Waiting for SimBrief OFP… ${sec}s`);
      }
      setLoading(true, `Waiting for SimBrief… ${sec}s`);

      try {
        const imp = await fetch("/api/simbrief/import", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(_sbUserBody(raw)),
        });
        const data = await imp.json().catch(() => ({}));
        if (!imp.ok || data.ok === false) continue;

        const fp = data.fingerprint || "";
        const isNew = !beforeFp || fp !== beforeFp;
        const matchDep =
          !wantDep ||
          String(data.dep?.icao || "").toUpperCase() === wantDep;
        const matchDest =
          !wantDest ||
          String(data.dest?.icao || "").toUpperCase() === wantDest;

        if (isNew && matchDep && matchDest) {
          if (fromSetup) {
            // Open Full journey map first, then draw plan + both airport charts
            hideSimBriefSetup();
            enterMode("journey");
            try {
              await ensureLeafletLoaded();
            } catch (_) {}
            for (let w = 0; w < 40; w++) {
              try {
                if (ensureMapReady()) break;
              } catch (_) {}
              await new Promise(function (r) {
                setTimeout(r, 100);
              });
            }
            try {
              setJourneyStep("flightplan");
            } catch (_) {}
            await applySimBriefPlan(data);
            setStatus(
              `SimBrief OFP ready — ${(data.dep?.icao || "?") + " + " + (data.dest?.icao || "?")} charts loaded`,
              "ok"
            );
            _setSbSetupStatus("");
          } else {
            await applySimBriefPlan(data);
            _setSbStatus(
              `New OFP imported — ${(data.dep?.icao || "?") + " → " + (data.dest?.icao || "?")} charts loaded`
            );
          }
          return;
        }
        if (isNew && (!matchDep || !matchDest)) {
          const note = `Saw OFP ${data.dep?.icao || "?"}→${data.dest?.icao || "?"} — waiting for ${wantDep}→${wantDest}…`;
          _setSbStatus(note);
          if (fromSetup) _setSbSetupStatus(note);
        }
      } catch (_) {
        /* keep waiting */
      }
    }

    setStatus(
      "Timed out waiting for SimBrief. Generate the OFP, then click Import latest only.",
      "err"
    );
    _setSbStatus("Timed out — click Import latest only after generating");
    if (fromSetup) {
      _setSbSetupStatus(
        "Timed out — generate on SimBrief, then try again or use Full journey → Import"
      );
    }
  } catch (err) {
    setStatus(err.message || "SimBrief generate failed", "err");
    _setSbStatus(err.message || "Failed");
    if (fromSetup) _setSbSetupStatus(err.message || "Failed");
  } finally {
    _sbGenerateInFlight = false;
    _setSbWaitingUi(false);
    if (fromSetup) {
      $("#btn-sb-setup-cancel-wait")?.classList.add("hidden");
      const go = $("#btn-sb-setup-go");
      if (go) go.disabled = false;
    }
    setLoading(false);
  }
}

function cancelSimBriefWait() {
  _sbWaitAbort = true;
  _sbGenerateInFlight = false;
  _setSbWaitingUi(false);
  $("#btn-sb-setup-cancel-wait")?.classList.add("hidden");
  const go = $("#btn-sb-setup-go");
  if (go) go.disabled = false;
  setLoading(false);
  setStatus("Cancelled SimBrief wait", "ok");
  _setSbStatus("Cancelled");
  _setSbSetupStatus("Cancelled");
}

async function saveFlightPlan() {
  if (!state.flightPlan) {
    setStatus("Build a plan first", "err");
    return;
  }
  const name =
    ($("#fp-name")?.value || "").trim() ||
    `${state.flightPlan.dep?.icao || "DEP"}-${state.flightPlan.dest?.icao || "DEST"}`;
  try {
    const res = await fetch("/api/flightplan/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, plan: state.flightPlan }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Save failed");
    setStatus(`Saved plan: ${data.name || name}`, "ok");
    refreshSavedPlansList();
  } catch (err) {
    setStatus(err.message || "Save failed", "err");
  }
}

async function refreshSavedPlansList() {
  const sel = $("#fp-saved");
  if (!sel) return;
  try {
    const res = await fetch("/api/flightplan/list");
    const data = await res.json();
    const cur = sel.value;
    sel.innerHTML = `<option value="">— Load a saved plan —</option>`;
    for (const p of data.plans || []) {
      const opt = document.createElement("option");
      opt.value = p.id;
      opt.textContent = `${p.name || p.id} (${p.dep || "?"}→${p.dest || "?"}${
        p.distance_nm != null ? ", " + p.distance_nm + " NM" : ""
      })`;
      sel.appendChild(opt);
    }
    if (cur) sel.value = cur;
  } catch (_) {}
}

/** Opt-in community counter for saved / SimBrief plans (builds report server-side). */
function reportCommunityFlightPlan(data, source) {
  try {
    const dep = (
      (data && data.dep && data.dep.icao) ||
      $("#fp-dep")?.value ||
      ""
    )
      .toString()
      .trim()
      .toUpperCase();
    const dest = (
      (data && data.dest && data.dest.icao) ||
      $("#fp-dest")?.value ||
      ""
    )
      .toString()
      .trim()
      .toUpperCase();
    if (!dep || !dest || dep === dest) return;
    const body = {
      dep_icao: dep,
      dest_icao: dest,
      source: source || "build",
    };
    if (data && data.distance_nm != null) body.distance_nm = Number(data.distance_nm);
    fetch("/api/community/flightplan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }).catch(function () {});
  } catch (_) {}
}

async function loadSavedPlan(id) {
  if (!id) return;
  try {
    const res = await fetch(`/api/flightplan/${encodeURIComponent(id)}`);
    if (!res.ok) throw new Error("Plan not found");
    const data = await res.json();
    showFpSummary(data);
    if ($("#fp-name")) $("#fp-name").value = data.name || "";
    drawFlightPlan(data);
    reportCommunityFlightPlan(data, "saved");
    setStatus("Loaded saved plan", "ok");
  } catch (err) {
    setStatus(err.message || "Load failed", "err");
  }
}

$("#btn-fp-build")?.addEventListener("click", () => buildFlightPlan());
$("#btn-fp-both")?.addEventListener("click", () => loadBothAirports());
$("#btn-fp-save")?.addEventListener("click", () => saveFlightPlan());
$("#btn-fp-clear")?.addEventListener("click", () => {
  clearFlightPlanLayer();
  _fpAutoBuildKey = "";
  setStatus("Flight plan cleared from map", "ok");
});
// Typing Dep/Dest → auto Show plan (DCT) once both ICAOs look complete
["#fp-dep", "#fp-dest"].forEach(function (sel) {
  const el = $(sel);
  if (!el) return;
  el.addEventListener("change", function () {
    scheduleAutoShowFlightPlan(200);
  });
  el.addEventListener("blur", function () {
    scheduleAutoShowFlightPlan(100);
  });
  el.addEventListener("input", function () {
    scheduleAutoShowFlightPlan(500);
  });
});
$("#btn-sb-open")?.addEventListener("click", () => openSimBriefDispatch());
$("#btn-sb-import")?.addEventListener("click", () => importSimBriefOfp());
$("#btn-sb-generate")?.addEventListener("click", () => generateAndImportSimBrief());
$("#btn-sb-cancel-wait")?.addEventListener("click", () => cancelSimBriefWait());
$("#btn-sb-ofp-hide")?.addEventListener("click", () => hideSbOfpBubble());
$("#btn-sb-ofp-show")?.addEventListener("click", () => showSbOfpBubble());
$("#fp-saved")?.addEventListener("change", (e) => {
  loadSavedPlan(e.target.value);
});
// ── SimBrief pilot ID + aircraft type (remembered across restarts) ──
const SB_USER_LS_KEY = "navapron_simbrief_user";
const AIRCRAFT_TYPE_LS_KEY = "navapron_aircraft_type";
let _sbUserSaveTimer = null;
let _aircraftTypeSaveTimer = null;

function getSimBriefUserFields() {
  return [$("#sb-user"), $("#fp-sb-user")].filter(Boolean);
}

function getAircraftTypeFields() {
  return [$("#fp-ac"), $("#sb-ac")].filter(Boolean);
}

function applySimBriefUserToFields(raw, opts) {
  opts = opts || {};
  // Keep raw text while syncing live keystrokes — trim only on blur/persist.
  const v = String(raw == null ? "" : raw);
  const skipEl = opts.except || null;
  // allowEmpty: syncing from the field being edited (user cleared it)
  if (!v && !opts.allowEmpty && !skipEl) return;
  getSimBriefUserFields().forEach(function (el) {
    if (!el || el === skipEl) return;
    // Don't fight the caret while the user is typing (same fix as aircraft type)
    if (document.activeElement === el) return;
    el.value = v;
  });
}

function applyAircraftTypeToFields(raw, opts) {
  opts = opts || {};
  const v = String(raw || "")
    .trim()
    .toUpperCase();
  if (!v) return;
  const skipEl = opts.except || null;
  getAircraftTypeFields().forEach(function (el) {
    if (!el || el === skipEl) return;
    // Don't fight the user while they are typing into this field
    if (document.activeElement === el) return;
    el.value = v;
  });
}

/** Prefer the field the user is editing; otherwise either filled value. */
function readSimBriefUserFromFields(preferEl) {
  if (preferEl && preferEl.value != null) {
    return String(preferEl.value || "");
  }
  const active = document.activeElement;
  if (active && (active.id === "sb-user" || active.id === "fp-sb-user")) {
    return String(active.value || "");
  }
  const fromSetup = ($("#sb-user")?.value || "").trim();
  if (fromSetup) return fromSetup;
  return ($("#fp-sb-user")?.value || "").trim();
}

/** Prefer the field the user is editing; otherwise either filled value. */
function readAircraftTypeFromFields(preferEl) {
  if (preferEl && preferEl.value != null) {
    const t = String(preferEl.value || "")
      .trim()
      .toUpperCase();
    if (t) return t;
  }
  const active = document.activeElement;
  if (active && (active.id === "fp-ac" || active.id === "sb-ac")) {
    const t = String(active.value || "")
      .trim()
      .toUpperCase();
    if (t) return t;
  }
  const fromFp = ($("#fp-ac")?.value || "").trim().toUpperCase();
  if (fromFp) return fromFp;
  return ($("#sb-ac")?.value || "").trim().toUpperCase();
}

function getRememberedAircraftType() {
  try {
    const v = (localStorage.getItem(AIRCRAFT_TYPE_LS_KEY) || "").trim().toUpperCase();
    if (v) return v;
  } catch (_) {}
  return readAircraftTypeFromFields() || "";
}

function persistSimBriefUser(raw, opts) {
  opts = opts || {};
  const v = String(raw || "").trim();
  try {
    if (v) localStorage.setItem(SB_USER_LS_KEY, v);
    else localStorage.removeItem(SB_USER_LS_KEY);
  } catch (_) {}
  // Server-side file under data/ — survives WebView profile wipes and zip updates
  if (opts.skipServer) return;
  try {
    fetch("/api/user/prefs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ simbrief_user: v }),
      keepalive: true,
    }).catch(function () {});
  } catch (_) {}
}

function persistAircraftType(raw, opts) {
  opts = opts || {};
  const v = String(raw || "")
    .trim()
    .toUpperCase();
  try {
    if (v) localStorage.setItem(AIRCRAFT_TYPE_LS_KEY, v);
    else localStorage.removeItem(AIRCRAFT_TYPE_LS_KEY);
  } catch (_) {}
  if (opts.skipServer) return;
  try {
    fetch("/api/user/prefs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ aircraft_type: v }),
      keepalive: true,
    }).catch(function () {});
  } catch (_) {}
}

function schedulePersistSimBriefUser(fromEl) {
  // Read from the field being edited — never pull the sibling's old value back
  // in when this box is cleared (that blocked deleting the username).
  const src = fromEl || document.activeElement;
  const v = readSimBriefUserFromFields(src);
  applySimBriefUserToFields(v, { except: src, allowEmpty: true });
  if (_sbUserSaveTimer) clearTimeout(_sbUserSaveTimer);
  _sbUserSaveTimer = setTimeout(function () {
    persistSimBriefUser(v);
  }, 400);
}

function finalizeSimBriefUserField(el) {
  if (!el) return;
  const v = String(el.value || "").trim();
  el.value = v;
  applySimBriefUserToFields(v, { except: el, allowEmpty: true });
  if (_sbUserSaveTimer) clearTimeout(_sbUserSaveTimer);
  _sbUserSaveTimer = null;
  persistSimBriefUser(v);
}

function schedulePersistAircraftType(fromEl) {
  // Read from the field being edited — never clobber it with the other field's value
  const v = readAircraftTypeFromFields(fromEl || document.activeElement);
  if (!v) return;
  // Sync the other field only (not the one being typed)
  applyAircraftTypeToFields(v, { except: fromEl || null });
  if (_aircraftTypeSaveTimer) clearTimeout(_aircraftTypeSaveTimer);
  _aircraftTypeSaveTimer = setTimeout(function () {
    persistAircraftType(v);
  }, 450);
}

async function loadRememberedSimBriefUser() {
  let fromLs = "";
  let acFromLs = "";
  try {
    fromLs = localStorage.getItem(SB_USER_LS_KEY) || "";
    acFromLs = localStorage.getItem(AIRCRAFT_TYPE_LS_KEY) || "";
  } catch (_) {}
  if (fromLs) applySimBriefUserToFields(fromLs);
  if (acFromLs) applyAircraftTypeToFields(acFromLs);
  try {
    const res = await fetch("/api/user/prefs", { cache: "no-store" });
    if (!res.ok) return;
    const data = await res.json();
    const server = (data && data.simbrief_user) || "";
    if (server) {
      applySimBriefUserToFields(server);
      try {
        localStorage.setItem(SB_USER_LS_KEY, server);
      } catch (_) {}
    } else if (fromLs) {
      // Migrate browser-only value into durable prefs
      persistSimBriefUser(fromLs);
    }
    const acServer = (data && data.aircraft_type) || "";
    if (acServer) {
      applyAircraftTypeToFields(acServer);
      try {
        localStorage.setItem(AIRCRAFT_TYPE_LS_KEY, acServer);
      } catch (_) {}
    } else if (acFromLs) {
      persistAircraftType(acFromLs);
    }
  } catch (_) {
    /* offline / not ready */
  }
}

getSimBriefUserFields().forEach(function (el) {
  el.addEventListener("input", function () {
    schedulePersistSimBriefUser(el);
  });
  el.addEventListener("change", function () {
    finalizeSimBriefUserField(el);
  });
  el.addEventListener("blur", function () {
    finalizeSimBriefUserField(el);
  });
});
getAircraftTypeFields().forEach(function (el) {
  el.addEventListener("input", function () {
    schedulePersistAircraftType(el);
  });
  el.addEventListener("change", function () {
    const v = readAircraftTypeFromFields(el);
    if (!v) return;
    // On commit, uppercase and sync both fields
    el.value = v;
    applyAircraftTypeToFields(v);
    persistAircraftType(v);
  });
  el.addEventListener("blur", function () {
    const v = readAircraftTypeFromFields(el);
    if (!v) return;
    el.value = v;
    applyAircraftTypeToFields(v);
    persistAircraftType(v);
  });
});
loadRememberedSimBriefUser();

// SimBrief setup screen (Home → SimBrief → Full journey)
wireSbAirportSearch("dep");
wireSbAirportSearch("dest");
setSbAirportPick("dep", null);
setSbAirportPick("dest", null);
function navapronSbSetupBack() {
  try {
    cancelSimBriefWait();
  } catch (_) {}
  showHub();
  try {
    _setSbSetupStatus("");
    setStatus("Home", "ok");
  } catch (_) {}
}
function navapronSbSetupGo() {
  try {
    _setSbSetupStatus("Starting SimBrief…");
  } catch (_) {}
  return generateAndImportSimBrief({ fromSetup: true });
}
function navapronSbSetupImport() {
  try {
    _setSbSetupStatus("Importing last OFP…");
    setStatus("Importing last SimBrief OFP…", "busy");
  } catch (_) {}
  return importSimBriefOfp({ fromSetup: true });
}
window.navapronSbSetupBack = navapronSbSetupBack;
window.navapronSbSetupGo = navapronSbSetupGo;
window.navapronSbSetupImport = navapronSbSetupImport;
window.showHub = showHub;
window.showLauncher = showLauncher;
window.hideLauncherOverlay = hideLauncherOverlay;
window.hideHubOverlay = hideHubOverlay;
window.hideSimBriefSetup = hideSimBriefSetup;
window.loadBothAirports = loadBothAirports;
window.loadAirport = loadAirport;
window.enterMode = enterMode;
window.clearSessionPlanning = clearSessionPlanning;
window.buildFlightPlan = buildFlightPlan;
window.autoShowFlightPlanIfReady = autoShowFlightPlanIfReady;
window.applyCareerDirectPlan = applyCareerDirectPlan;
window.getActiveProcedure = getActiveProcedure;
window.fitActiveProcedure = fitActiveProcedure;
window.focusProcedureFix = focusProcedureFix;
window.drawFlightPlan = drawFlightPlan;
window.showFlownTrace = showFlownTrace;
window.clearFlownTrace = clearFlownTrace;
window.clearLiveTrackingTrace = clearLiveTrackingTrace;
window.updateLiveTrackingTrace = updateLiveTrackingTrace;
window.setJourneyStep = setJourneyStep;
window.fitAllRoutes = fitAllRoutes;
window.getNavapronMap = function () {
  return map;
};

$("#btn-sb-setup-back")?.addEventListener("click", function (ev) {
  try {
    if (ev && ev.preventDefault) ev.preventDefault();
  } catch (_) {}
  navapronSbSetupBack();
});
$("#btn-sb-setup-go")?.addEventListener("click", function (ev) {
  try {
    if (ev && ev.preventDefault) ev.preventDefault();
  } catch (_) {}
  navapronSbSetupGo();
});
$("#btn-sb-setup-import")?.addEventListener("click", function (ev) {
  try {
    if (ev && ev.preventDefault) ev.preventDefault();
  } catch (_) {}
  navapronSbSetupImport();
});
$("#btn-sb-setup-cancel-wait")?.addEventListener("click", () => cancelSimBriefWait());
// Extra Home affordance: logo on SimBrief setup
document.querySelector("#sb-setup .hub-logo")?.addEventListener("click", function () {
  navapronSbSetupBack();
});

// ── Sidebar collapse (more map while flying) ─────────────────────
function isSidebarCollapsed() {
  return !!$("#app")?.classList.contains("sidebar-collapsed");
}

function setSidebarCollapsed(collapsed, { persist = true, quiet = false } = {}) {
  const app = $("#app");
  if (!app) return;
  const on = !!collapsed;
  app.classList.toggle("sidebar-collapsed", on);
  document.body.classList.toggle("sidebar-collapsed", on);

  const hideBtn = $("#btn-sidebar-collapse");
  const openBtn = $("#btn-sidebar-open");
  if (hideBtn) {
    hideBtn.setAttribute("aria-expanded", on ? "false" : "true");
    hideBtn.title = on
      ? "Sidebar hidden — use the Menu tab on the map to show it"
      : "Hide sidebar — more map (click the Menu tab to show again)";
  }
  if (openBtn) {
    openBtn.setAttribute("aria-expanded", on ? "false" : "true");
    openBtn.setAttribute("aria-hidden", on ? "false" : "true");
  }

  if (persist) {
    try {
      localStorage.setItem("navapron_sidebar_collapsed", on ? "1" : "0");
    } catch (_) {}
  }

  // Leaflet must remeasure after grid column animates
  const fixMap = () => {
    try {
      map.invalidateSize(true);
    } catch (_) {}
  };
  fixMap();
  setTimeout(fixMap, 80);
  setTimeout(fixMap, 260);

  if (!quiet) {
    setStatus(on ? "Sidebar hidden — click Menu on the map edge to show" : "Sidebar shown", "ok");
  }
}

function toggleSidebar() {
  setSidebarCollapsed(!isSidebarCollapsed());
}

$("#btn-sidebar-collapse")?.addEventListener("click", () => setSidebarCollapsed(true));
$("#btn-sidebar-open")?.addEventListener("click", () => setSidebarCollapsed(false));

// ── Right dock resize (Logbook / Charts / Career share one width) ─
const RIGHT_DOCK_W_KEY = "navapron_right_dock_w";
const RIGHT_DOCK_MIN = 280;
const RIGHT_DOCK_MAX_DEFAULT = 720;

function _rightDockMaxPx() {
  try {
    const app = $("#app");
    const w = (app && app.clientWidth) || window.innerWidth || 1200;
    return Math.max(RIGHT_DOCK_MIN + 40, Math.min(RIGHT_DOCK_MAX_DEFAULT, Math.floor(w * 0.62)));
  } catch (_) {
    return RIGHT_DOCK_MAX_DEFAULT;
  }
}

function _readRightDockWidthPx() {
  const app = $("#app");
  const root = document.documentElement;
  const raw =
    (app && app.style.getPropertyValue("--right-dock-w")) ||
    root.style.getPropertyValue("--right-dock-w") ||
    (app && getComputedStyle(app).getPropertyValue("--right-dock-w")) ||
    "";
  const n = parseInt(String(raw).trim(), 10);
  return Number.isFinite(n) ? n : 360;
}

function applyRightDockWidth(px, { persist = true, quietMap = false } = {}) {
  const app = $("#app");
  const root = document.documentElement;
  if (!app) return;
  const max = _rightDockMaxPx();
  const w = Math.max(RIGHT_DOCK_MIN, Math.min(max, Math.round(Number(px) || 360)));
  const val = w + "px";
  // Set on :root + #app. CSS maps --right-w → --right-dock-w when a panel is open.
  root.style.setProperty("--right-dock-w", val);
  app.style.setProperty("--right-dock-w", val);
  app.style.setProperty("--airline-w", val);
  app.style.setProperty("--career-w", val);
  app.style.setProperty("--plates-panel-w", val);
  // Clear any stale inline --right-w so collapse (0) still works via CSS classes
  app.style.removeProperty("--right-w");
  const handle = $("#right-dock-resizer");
  if (handle) {
    handle.setAttribute("aria-valuenow", String(w));
    handle.setAttribute("aria-valuemin", String(RIGHT_DOCK_MIN));
    handle.setAttribute("aria-valuemax", String(max));
  }
  if (persist) {
    try {
      localStorage.setItem(RIGHT_DOCK_W_KEY, String(w));
    } catch (_) {}
  }
  if (!quietMap) {
    try {
      if (typeof window.fixMapSize === "function") window.fixMapSize();
      else if (window.map && typeof window.map.invalidateSize === "function") {
        window.map.invalidateSize(true);
      }
    } catch (_) {}
  }
  return w;
}

function loadRightDockWidth() {
  let raw = null;
  try {
    raw = localStorage.getItem(RIGHT_DOCK_W_KEY);
  } catch (_) {}
  if (raw != null && raw !== "") {
    const n = parseInt(raw, 10);
    if (Number.isFinite(n)) applyRightDockWidth(n, { persist: false });
  }
}

function initRightDockResizer() {
  const handle = $("#right-dock-resizer");
  const app = $("#app");
  if (!handle || !app) return;
  loadRightDockWidth();

  let dragging = false;
  let startX = 0;
  let startW = 0;
  let lastW = startW;

  const onMove = (ev) => {
    if (!dragging) return;
    const clientX =
      ev.clientX != null
        ? ev.clientX
        : ev.touches && ev.touches[0]
          ? ev.touches[0].clientX
          : null;
    if (clientX == null) return;
    const dx = startX - clientX; // drag left → wider dock
    lastW = applyRightDockWidth(startW + dx, { persist: false, quietMap: true });
    ev.preventDefault();
  };
  const onUp = (ev) => {
    if (!dragging) return;
    dragging = false;
    document.body.classList.remove("right-dock-resizing");
    document.removeEventListener("pointermove", onMove, true);
    document.removeEventListener("pointerup", onUp, true);
    document.removeEventListener("pointercancel", onUp, true);
    document.removeEventListener("mousemove", onMove, true);
    document.removeEventListener("mouseup", onUp, true);
    try {
      if (ev && ev.pointerId != null) handle.releasePointerCapture(ev.pointerId);
    } catch (_) {}
    applyRightDockWidth(lastW || _readRightDockWidthPx(), { persist: true });
    setTimeout(() => {
      try {
        if (window.map && window.map.invalidateSize) window.map.invalidateSize(true);
      } catch (_) {}
    }, 80);
  };

  const beginDrag = (clientX, pointerId) => {
    if (window.matchMedia && window.matchMedia("(max-width: 900px)").matches) return false;
    dragging = true;
    startX = clientX;
    startW = _readRightDockWidthPx();
    lastW = startW;
    document.body.classList.add("right-dock-resizing");
    document.addEventListener("pointermove", onMove, true);
    document.addEventListener("pointerup", onUp, true);
    document.addEventListener("pointercancel", onUp, true);
    document.addEventListener("mousemove", onMove, true);
    document.addEventListener("mouseup", onUp, true);
    if (pointerId != null) {
      try {
        handle.setPointerCapture(pointerId);
      } catch (_) {}
    }
    return true;
  };

  handle.addEventListener("pointerdown", (ev) => {
    if (ev.button != null && ev.button !== 0) return;
    if (!beginDrag(ev.clientX, ev.pointerId)) return;
    ev.preventDefault();
    ev.stopPropagation();
  });

  handle.addEventListener("keydown", (ev) => {
    const cur = _readRightDockWidthPx();
    if (ev.key === "ArrowLeft") {
      applyRightDockWidth(cur + 24);
      ev.preventDefault();
    } else if (ev.key === "ArrowRight") {
      applyRightDockWidth(cur - 24);
      ev.preventDefault();
    } else if (ev.key === "Home") {
      applyRightDockWidth(RIGHT_DOCK_MIN);
      ev.preventDefault();
    } else if (ev.key === "End") {
      applyRightDockWidth(_rightDockMaxPx());
      ev.preventDefault();
    }
  });

  window.addEventListener("resize", () => {
    applyRightDockWidth(_readRightDockWidthPx(), { persist: false });
  });
}

try {
  initRightDockResizer();
} catch (err) {
  console.warn("right-dock resize init", err);
}
window.applyRightDockWidth = applyRightDockWidth;

// Keyboard: [ hides, ] shows (when not typing in a field)
document.addEventListener("keydown", (e) => {
  if (e.ctrlKey || e.metaKey || e.altKey) return;
  const t = e.target;
  const tag = (t && t.tagName) || "";
  if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || t?.isContentEditable) {
    return;
  }
  if (e.key === "[") {
    e.preventDefault();
    setSidebarCollapsed(true);
  } else if (e.key === "]") {
    e.preventDefault();
    setSidebarCollapsed(false);
  }
});

// Desktop: menu open. Phone: keep map full-screen until user taps Menu.
try {
  const mobile =
    typeof window !== "undefined" &&
    window.matchMedia &&
    window.matchMedia("(max-width: 900px)").matches;
  setSidebarCollapsed(mobile, { persist: false, quiet: true });
  if (mobile) {
    $("#app")?.classList.add("airline-collapsed");
  }
} catch (_) {}

// Phone rotate / browser chrome show-hide — keep Leaflet sized correctly
try {
  window.addEventListener("resize", function () {
    try {
      if (map && map.invalidateSize) map.invalidateSize(true);
    } catch (_) {}
  });
  window.addEventListener("orientationchange", function () {
    setTimeout(function () {
      try {
        if (map && map.invalidateSize) map.invalidateSize(true);
      } catch (_) {}
    }, 200);
  });
} catch (_) {}

// ── Always on top (desktop window) ───────────────────────────────
// Works only when NavApron.exe / run.bat hosts the window (WebView2 or Edge app).
// A plain browser tab cannot pin itself — button still saves the pref for next desktop launch.
let windowPrefsDesktopHost = false;

async function loadWindowPrefs() {
  try {
    const res = await fetch("/api/window/prefs");
    if (!res.ok) return;
    const prefs = await res.json();
    windowPrefsDesktopHost = !!prefs.desktop_host;
    const on = !!prefs.always_on_top;
    const btn = $("#btn-always-on-top");
    btn?.classList.toggle("active", on);
    if (btn) {
      btn.title = windowPrefsDesktopHost
        ? "Keep NavApron above other windows (WebView or Edge/Chrome app mode). Use borderless/windowed MSFS — exclusive fullscreen can cover everything."
        : "Keep on top only works in the NavApron desktop window (NavApron.exe / run.bat), not a normal browser tab.";
    }
  } catch {
    /* ignore */
  }
}

async function toggleAlwaysOnTop() {
  const btn = $("#btn-always-on-top");
  const next = !btn?.classList.contains("active");
  try {
    const res = await fetch("/api/window/prefs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ always_on_top: next }),
    });
    const prefs = await res.json();
    windowPrefsDesktopHost = !!prefs.desktop_host;
    const on = !!prefs.always_on_top;
    btn?.classList.toggle("active", on);
    if (on && !windowPrefsDesktopHost) {
      setStatus(
        "Keep on top is saved, but only applies in NavApron.exe (WebView or Edge/Chrome app) — not a normal browser tab",
        "err"
      );
    } else if (on) {
      setStatus(
        "Keep on top on (works in WebView and Edge/Chrome app mode) — use windowed/borderless MSFS if it still goes under",
        "ok"
      );
    } else {
      setStatus("Window is no longer always on top", "ok");
    }
  } catch (err) {
    setStatus("Could not change always-on-top: " + err.message, "err");
  }
}

$("#btn-always-on-top")?.addEventListener("click", () => toggleAlwaysOnTop());
setTimeout(function () {
  try {
    loadWindowPrefs();
  } catch (_) {}
}, 600);

// ── PC ↔ iPad session sync ───────────────────────────────────────
function scheduleSessionPush() {
  try {
    if (
      window.NavApronSessionSync &&
      typeof NavApronSessionSync.schedulePush === "function" &&
      !NavApronSessionSync.isApplying()
    ) {
      NavApronSessionSync.schedulePush();
    }
  } catch (_) {}
  // Always refresh OBS HUD snapshot (even if iPad sync is off)
  try {
    scheduleOverlayPublish();
  } catch (_) {}
}

let _overlayPublishTimer = null;
function scheduleOverlayPublish() {
  if (_overlayPublishTimer) clearTimeout(_overlayPublishTimer);
  _overlayPublishTimer = setTimeout(function () {
    _overlayPublishTimer = null;
    publishOverlaySnapshot();
  }, 400);
}

function publishOverlaySnapshot() {
  try {
    const payload = buildSessionPayload();
    fetch("/api/overlay/publish", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ payload: payload }),
      keepalive: true,
    }).catch(function () {});
  } catch (_) {}
}

function _cloneSyncPoint(p) {
  if (!p || p.lat == null || p.lon == null) return null;
  return {
    lat: Number(p.lat),
    lon: Number(p.lon),
    label: p.label || p.name || null,
    name: p.name || null,
    approach_hdg: p.approach_hdg != null ? p.approach_hdg : null,
    runway: p.runway || null,
  };
}

function buildSessionPayload() {
  // Hub-only: still publish so the other device can leave hub when we open a mode
  const depIcao =
    (state.depChart && state.depChart.airport && state.depChart.airport.icao) ||
    ($("#fp-dep") && $("#fp-dep").value) ||
    null;
  const destIcao =
    (state.destChart && state.destChart.airport && state.destChart.airport.icao) ||
    ($("#fp-dest") && $("#fp-dest").value) ||
    null;
  const activeIcao =
    (state.airport && state.airport.icao) || depIcao || destIcao || null;
  return {
    mode: state.mode || "hub",
    journeyStep: state.journeyStep || "taxi-out",
    depIcao: depIcao ? String(depIcao).toUpperCase() : null,
    destIcao: destIcao ? String(destIcao).toUpperCase() : null,
    activeIcao: activeIcao ? String(activeIcao).toUpperCase() : null,
    clearance: Array.isArray(state.clearance) ? state.clearance.slice() : [],
    arrClearance: Array.isArray(state.arrClearance)
      ? state.arrClearance.slice()
      : [],
    followPlan: !!state.followPlan,
    simFollow: !!(state.sim && state.sim.follow),
    controls: {
      followPlan: !!state.followPlan,
      simFollow: !!(state.sim && state.sim.follow),
    },
    start: _cloneSyncPoint(state.start),
    end: _cloneSyncPoint(state.end),
    runway: _cloneSyncPoint(state.runwayEndMeta || state.depPick?.runway),
    arrivalStand: _cloneSyncPoint(state.arrivalStand || state.arrPick?.stand),
    arrRunway: _cloneSyncPoint(state.arrPick?.runway),
    pathSnapshots: state.pathSnapshots
      ? JSON.parse(JSON.stringify(state.pathSnapshots))
      : null,
    flightPlan: state.flightPlan
      ? {
          coords: state.flightPlan.coords,
          legs: state.flightPlan.legs,
          message: state.flightPlan.message,
          distance_nm: state.flightPlan.distance_nm,
          distance_m: state.flightPlan.distance_m,
          icao_route: state.flightPlan.icao_route,
          dep: state.flightPlan.dep,
          dest: state.flightPlan.dest,
          linked: state.flightPlan.linked,
          _raw: state.flightPlan._raw || null,
        }
      : null,
    fpFields: {
      dep: ($("#fp-dep") && $("#fp-dep").value) || "",
      dest: ($("#fp-dest") && $("#fp-dest").value) || "",
      route: ($("#fp-route") && $("#fp-route").value) || "",
    },
    // OBS overlay / multi-device HUD
    ofpSummary: state.simbriefOfpSummary || null,
    aircraft:
      state.flightPlan?.aircraft ||
      ($("#fp-ac") && $("#fp-ac").value) ||
      ($("#sb-ac") && $("#sb-ac").value) ||
      null,
  };
}

async function applySessionPayload(payload) {
  if (!payload || typeof payload !== "object") return;

  // Enter / switch planning mode if remote left hub (or left a single-purpose
  // mode for Full journey — needed for taxi-out → taxi-in across airports).
  const remoteMode = payload.mode || "hub";
  const remoteWantStep = payload.journeyStep
    ? String(payload.journeyStep)
    : null;
  const wantJourney =
    remoteMode === "journey" ||
    remoteMode === "simbrief" ||
    !!remoteWantStep;
  // Capture generation BEFORE any awaits — if the user taps Taxi-in / Flight plan
  // while we load charts, do not yank them back to the remote step afterward.
  const journeyGenAtStart = state._journeyStepGen || 0;

  // EFB SimBrief OFP → use the same dual-airport import path as PC "Import".
  // The generic depIcao/destIcao branch often left destChart unloaded when the
  // map was still booting or when only a partial payload was applied.
  const efbOfpRaw =
    payload.flightPlan &&
    (payload.source === "navapron-efb" ||
      payload.source === "simbrief" ||
      payload.flightPlan.source === "simbrief" ||
      payload.flightPlan._raw)
      ? payload.flightPlan._raw || payload.flightPlan
      : null;
  const efbOfp =
    efbOfpRaw &&
    efbOfpRaw.dep &&
    efbOfpRaw.dest &&
    (efbOfpRaw.dep.icao || efbOfpRaw.dest.icao);
  if (efbOfp && typeof applySimBriefPlan === "function") {
    try {
      if (state.mode === "hub" || (wantJourney && state.mode !== "journey" && state.mode !== "simbrief")) {
        if (remoteWantStep) state.journeyStep = remoteWantStep;
        enterMode("journey");
        await new Promise(function (r) {
          setTimeout(r, 700);
        });
      }
      const depI = String((efbOfpRaw.dep && efbOfpRaw.dep.icao) || "").toUpperCase();
      const arrI = String((efbOfpRaw.dest && efbOfpRaw.dest.icao) || "").toUpperCase();
      try {
        setLoading(
          true,
          depI && arrI
            ? "Loading " + depI + " + " + arrI + " charts…"
            : "Loading OFP charts…"
        );
      } catch (_) {}
      await applySimBriefPlan(efbOfpRaw);
      try {
        setLoading(false);
      } catch (_) {}

      // Apply follow / sim controls from the same payload without redoing airports
      if (payload.followPlan != null) {
        try {
          setFollowPlan(!!payload.followPlan);
        } catch (_) {
          state.followPlan = !!payload.followPlan;
        }
      }
      if (payload.simFollow != null || (payload.controls && payload.controls.simFollow != null)) {
        const on = !!(
          payload.simFollow != null ? payload.simFollow : payload.controls.simFollow
        );
        state.sim.follow = on;
        try {
          $("#btn-sim-follow")?.classList.toggle("active", on);
        } catch (_) {}
      }

      // Respect Taxi-in / Taxi-out if the user changed step during chart load
      if (
        (state._journeyStepGen || 0) !== journeyGenAtStart &&
        state.journeyStep === "taxi-in" &&
        state.destChart
      ) {
        try {
          applyChartAsActive(state.destChart, { fit: false, redrawAll: true });
        } catch (_) {}
      }

      try {
        setStatus(
          "OFP from EFB — " +
            (depI || "?") +
            " + " +
            (arrI || "?") +
            " charts loaded",
          "ok"
        );
      } catch (_) {}
      return;
    } catch (err) {
      console.warn("session EFB SimBrief apply failed, falling back", err);
      try {
        setLoading(false);
      } catch (_) {}
      // fall through to generic airport apply
    }
  }

  try {
    if (wantJourney && state.mode !== "journey" && state.mode !== "simbrief") {
      // Prefill only when leaving hub so enterMode finishUi opens the right step
      if (remoteWantStep) state.journeyStep = remoteWantStep;
      enterMode("journey");
      await new Promise(function (r) {
        setTimeout(r, 700);
      });
    } else if (remoteMode && remoteMode !== "hub" && state.mode === "hub") {
      if (remoteWantStep) state.journeyStep = remoteWantStep;
      enterMode(remoteMode === "simbrief" ? "journey" : remoteMode);
      await new Promise(function (r) {
        setTimeout(r, 700);
      });
    }
  } catch (_) {}

  // Airports (skipSessionPush: do not echo while applying)
  const wantDep = payload.depIcao
    ? String(payload.depIcao).toUpperCase()
    : payload.flightPlan && payload.flightPlan.dep && payload.flightPlan.dep.icao
      ? String(payload.flightPlan.dep.icao).toUpperCase()
      : null;
  const wantDest = payload.destIcao
    ? String(payload.destIcao).toUpperCase()
    : payload.flightPlan && payload.flightPlan.dest && payload.flightPlan.dest.icao
      ? String(payload.flightPlan.dest.icao).toUpperCase()
      : null;
  const haveDep = state.depChart?.airport?.icao
    ? String(state.depChart.airport.icao).toUpperCase()
    : null;
  const haveDest = state.destChart?.airport?.icao
    ? String(state.destChart.airport.icao).toUpperCase()
    : null;

  try {
    if (wantDep && wantDest && wantDep !== wantDest) {
      if (haveDep !== wantDep || haveDest !== wantDest) {
        if ($("#fp-dep")) $("#fp-dep").value = wantDep;
        if ($("#fp-dest")) $("#fp-dest").value = wantDest;
        await loadBothAirports({
          dep: wantDep,
          dest: wantDest,
          quietLoading: true,
          skipSessionPush: true,
        });
      }
    } else if (wantDep && haveDep !== wantDep) {
      await loadAirport(wantDep, {
        role: "dep",
        keepPaths: true,
        fit: false,
        quietLoading: true,
        skipSessionPush: true,
      });
    } else if (wantDest && haveDest !== wantDest) {
      await loadAirport(wantDest, {
        role: "dest",
        keepPaths: true,
        fit: false,
        quietLoading: true,
        skipSessionPush: true,
      });
    }
  } catch (err) {
    console.warn("session airport apply", err);
  } finally {
    // Session sync always uses quietLoading — guarantee the overlay is cleared
    // even if a progress timer left it on.
    try {
      setLoading(false);
    } catch (_) {}
  }

  if (payload.fpFields) {
    if ($("#fp-dep") && payload.fpFields.dep != null)
      $("#fp-dep").value = payload.fpFields.dep;
    if ($("#fp-dest") && payload.fpFields.dest != null)
      $("#fp-dest").value = payload.fpFields.dest;
    if ($("#fp-route") && payload.fpFields.route != null)
      $("#fp-route").value = payload.fpFields.route;
  }

  // Paths + plan BEFORE journey step so restoreAllPathLayers sees remote data
  if (payload.pathSnapshots) {
    try {
      state.pathSnapshots = payload.pathSnapshots;
    } catch (_) {}
  }
  if (payload.flightPlan && payload.flightPlan.coords) {
    try {
      state.flightPlan = payload.flightPlan;
      if (!state.flightPlan.source && payload.flightPlan._raw?.source) {
        state.flightPlan.source = payload.flightPlan._raw.source;
      }
    } catch (_) {}
  }

  // Clearance
  if (Array.isArray(payload.clearance)) {
    state.clearance = payload.clearance.slice();
  }
  if (Array.isArray(payload.arrClearance)) {
    state.arrClearance = payload.arrClearance.slice();
  }
  if (payload.followPlan != null) {
    try {
      setFollowPlan(!!payload.followPlan);
    } catch (_) {
      state.followPlan = !!payload.followPlan;
    }
  }
  // Aircraft follow (map centres on A/C) — from EFB / panel remotes
  if (payload.simFollow != null || (payload.controls && payload.controls.simFollow != null)) {
    const on = !!(
      payload.simFollow != null ? payload.simFollow : payload.controls.simFollow
    );
    state.sim.follow = on;
    try {
      $("#btn-sim-follow")?.classList.toggle("active", on);
    } catch (_) {}
    if (on && state.followPlan) {
      try {
        setFollowPlan(false);
      } catch (_) {
        state.followPlan = false;
      }
    }
  }
  if (payload.controls && payload.controls.followPlan != null && payload.followPlan == null) {
    try {
      setFollowPlan(!!payload.controls.followPlan);
    } catch (_) {
      state.followPlan = !!payload.controls.followPlan;
    }
  }
  if (payload.ofpSummary) {
    try {
      state.simbriefOfpSummary = payload.ofpSummary;
    } catch (_) {}
  }

  // Stash picks on depPick / arrPick first (don't clobber active runway yet)
  if (!state.depPick) state.depPick = { start: null, runway: null };
  if (!state.arrPick) state.arrPick = { stand: null, runway: null };
  if (payload.start && payload.start.lat != null) {
    state.depPick.start = {
      lat: payload.start.lat,
      lon: payload.start.lon,
      label: payload.start.label || "Start",
    };
  }
  if (payload.runway && payload.runway.lat != null) {
    state.depPick.runway = { ...payload.runway };
  }
  if (payload.arrRunway && payload.arrRunway.lat != null) {
    state.arrPick.runway = { ...payload.arrRunway };
  }
  if (payload.arrivalStand && payload.arrivalStand.lat != null) {
    state.arrPick.stand = {
      lat: payload.arrivalStand.lat,
      lon: payload.arrivalStand.lon,
      label: payload.arrivalStand.label || "Stand",
    };
    state.arrivalStand = { ...state.arrPick.stand };
    if (!state._arrStandSource) state._arrStandSource = "user";
  }

  // Journey step — AFTER airports + snapshots, so taxi-in activates dest chart.
  // Never override if the user changed step while charts were loading (common
  // when EFB SimBrief import still carries journeyStep=flightplan).
  const userMovedDuringApply =
    (state._journeyStepGen || 0) !== journeyGenAtStart;
  const wantStep = remoteWantStep;
  if (wantStep && state.mode === "journey" && !userMovedDuringApply) {
    try {
      if (wantStep !== state.journeyStep) {
        setJourneyStep(wantStep, { skipFit: true, skipSync: true });
      } else if (wantStep === "taxi-in" && state.destChart) {
        // Same step but ensure dest surface is active (dual-airport)
        applyChartAsActive(state.destChart, { fit: false, redrawAll: true });
      } else if (wantStep === "taxi-out" && state.depChart) {
        applyChartAsActive(state.depChart, { fit: false, redrawAll: true });
      }
    } catch (err) {
      console.warn("session journeyStep", err);
    }
  } else if (userMovedDuringApply && state.journeyStep === "taxi-in" && state.destChart) {
    try {
      applyChartAsActive(state.destChart, { fit: false, redrawAll: true });
    } catch (_) {}
  }

  // Active runway/stand for the step the user is actually on now
  const step = userMovedDuringApply
    ? state.journeyStep || "taxi-out"
    : wantStep || state.journeyStep || "taxi-out";
  try {
    if (step === "taxi-in") {
      if (state.arrPick?.runway?.lat != null) {
        state.runwayEndMeta = { ...state.arrPick.runway };
      }
      if (state.arrPick?.stand) {
        state.arrivalStand = { ...state.arrPick.stand };
        placeArrStandMarker(state.arrivalStand);
        try {
          selectArrStandDropdown(state.arrivalStand);
        } catch (_) {}
      }
      try {
        restoreSurfacePicks("arr");
      } catch (_) {}
      try {
        renderArrClearance();
        highlightArrClearanceTaxiways();
      } catch (_) {}
    } else {
      if (state.depPick?.runway?.lat != null) {
        state.runwayEndMeta = { ...state.depPick.runway };
        state.end = {
          lat: state.depPick.runway.lat,
          lon: state.depPick.runway.lon,
          label: state.depPick.runway.name
            ? "RWY " + state.depPick.runway.name
            : state.depPick.runway.label || "Runway",
        };
      } else if (payload.end && payload.end.lat != null) {
        state.end = {
          lat: payload.end.lat,
          lon: payload.end.lon,
          label: payload.end.label || "End",
        };
      }
      if (state.depPick?.start?.lat != null) {
        setStart(
          state.depPick.start.lat,
          state.depPick.start.lon,
          state.depPick.start.label,
          { remember: false }
        );
      }
      try {
        restoreSurfacePicks("dep");
      } catch (_) {}
      try {
        renderClearance();
        highlightClearanceTaxiways();
      } catch (_) {}
    }
    updateRouteButton();
    updateArrTaxiButtons();
  } catch (err) {
    console.warn("session picks apply", err);
  }

  // Draw paths last (journey step already restored once; do again with picks)
  try {
    restoreAllPathLayers();
  } catch (err) {
    console.warn("session restore paths", err);
  }
  if (state.flightPlan && state.flightPlan.coords) {
    try {
      drawFlightPlan(state.flightPlan, { fit: false, skipStitch: true });
      showFpSummary(state.flightPlan);
    } catch (err) {
      console.warn("session flightPlan", err);
    }
  }

  // In-sim panel / EFB can ask the PC to recompute when it only sent picks/clearance
  const cmd = payload.panelCommand || payload.command || null;
  try {
    if (cmd === "computeRoute" || cmd === "showPath") {
      const stepNow = wantStep || state.journeyStep || "taxi-out";
      if (stepNow === "taxi-in" && typeof computeTaxiIn === "function") {
        await computeTaxiIn(true, { quiet: true, skipFit: false });
      } else if (typeof computeRoute === "function") {
        await computeRoute(true, {
          fromAircraft: !!payload.fromAircraft,
          quiet: false,
          skipFit: false,
        });
      }
    } else if (cmd === "computeTaxiIn" && typeof computeTaxiIn === "function") {
      await computeTaxiIn(!!(payload.useClearance !== false), {
        quiet: false,
        skipFit: false,
      });
    } else if (cmd === "connectSim") {
      // EFB already POSTed /api/sim/connect — sync PC pill + start aircraft poll
      try {
        state.sim.enabled = true;
        const res = await fetch("/api/sim/status");
        const st = await res.json().catch(() => ({}));
        state.sim.enabled = !!(st.enabled ?? true);
        state.sim.connected = !!st.connected;
        _simStatusPhase = "";
        setSimPill(st);
        startSimPoll();
        setStatus(
          st.connected ? "MSFS connected (from EFB)" : "Looking for MSFS (from EFB)…",
          st.connected ? "ok" : "busy"
        );
      } catch (e) {
        console.warn("session connectSim", e);
      }
    } else if (cmd === "disconnectSim") {
      try {
        await fetch("/api/sim/disconnect", { method: "POST" });
        state.sim.enabled = false;
        state.sim.connected = false;
        stopSimPoll();
        try {
          baseLayers.aircraft.clearLayers();
          baseLayers.activeLeg?.clearLayers();
        } catch (_) {}
        state.activeLegInfo = null;
        updateActiveLegHud(null);
        _simStatusPhase = "off";
        setSimPill({ available: true, enabled: false, connected: false });
        setStatus("Disconnected from MSFS (from EFB)", "ok");
      } catch (e) {
        console.warn("session disconnectSim", e);
      }
    }
  } catch (err) {
    console.warn("session panelCommand", err);
  }

  try {
    setLoading(false);
  } catch (_) {}

  try {
    const fromEfb = payload.source === "navapron-efb";
    const fromPanel = payload.source === "navapron-panel";
    setStatus(
      fromEfb
        ? "Updated from NavApron EFB"
        : fromPanel
          ? "Updated from in-sim NavApron panel"
          : "Synced planning from another device",
      "ok"
    );
  } catch (_) {}
}

function initSessionSync() {
  if (!window.NavApronSessionSync) return;
  NavApronSessionSync.init({
    buildPayload: buildSessionPayload,
    applyPayload: applySessionPayload,
  });
}

// ── Boot ─────────────────────────────────────────────────────────
// Ensure logo stays on PNG; fall back to SVG only if PNG missing
(() => {
  const logo = document.getElementById("app-logo");
  if (!logo) return;
  logo.addEventListener("error", () => {
    if (logo.dataset.fallback) return;
    logo.dataset.fallback = "1";
    logo.src = "/img/logo.svg?v=5";
  });
})();

function _clearBootBanner() {
  try {
    document.documentElement.classList.remove("navapron-booting");
    const b = document.getElementById("hub-boot-banner");
    if (b) b.hidden = true;
  } catch (_) {}
}

function _showBootBanner(msg) {
  try {
    const b = document.getElementById("hub-boot-banner");
    if (!b) return;
    if (msg) b.textContent = String(msg);
    b.hidden = false;
  } catch (_) {}
}

document.title = "NavApron — " + appVersionLabel();
// Unified home hub on boot (no product chooser). Do NOT create Leaflet here.
try {
  showHub();
  _clearBootBanner();
  setStatus("Choose how to plan — or open Pilot Career below", "ok");
} catch (bootErr) {
  console.error("hub boot failed", bootErr);
  try {
    document.body.classList.add("hub-open");
    const hub = document.getElementById("hub");
    if (hub) {
      hub.hidden = false;
      hub.removeAttribute("aria-hidden");
    }
  } catch (_) {}
  _showBootBanner(
    "NavApron hit a startup glitch. Close and reopen — your logbook is safe."
  );
}
// Prefetch CARTO key ASAP so first Full-journey click does not race map paint
try {
  ensureCartoKeyLoaded();
} catch (_) {}
// Defer session sync — polling during first hub seconds fought WebView input
setTimeout(function () {
  try {
    initSessionSync();
  } catch (err) {
    console.warn("initSessionSync", err);
  }
}, 3500);
// Defer network prefs until after first paint (reduces first-launch WebView thrash)
setTimeout(function () {
  try {
    loadAirportClutterPref();
  } catch (_) {}
  hydrateRecentAirportsFromServer()
    .catch(function () {})
    .finally(function () {
      runSearch("").catch(function () {});
    });
}, 2500);
// Map is created only when leaving Home (enterMode → ensureMapReady). Do not
// warm-up while hub is open — that still crashes some WebView2 hosts.

// ── First-run tutorial hooks (frontend/js/tutorial.js) ───────────
function _tutorialWait(ms) {
  return new Promise(function (resolve) {
    setTimeout(resolve, ms);
  });
}

function _tutorialPickFirstSelect(sel) {
  if (!sel || !sel.options) return false;
  for (let i = 0; i < sel.options.length; i++) {
    if (sel.options[i].value) {
      sel.selectedIndex = i;
      sel.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    }
  }
  return false;
}

function _tutorialGetState() {
  const routeCoords =
    (state.pathTracks &&
      state.pathTracks.route &&
      state.pathTracks.route.coords) ||
    [];
  const fpCoords =
    (state.pathTracks &&
      state.pathTracks.flightPlan &&
      state.pathTracks.flightPlan.coords) ||
    (state.flightPlan && state.flightPlan.coords) ||
    [];
  const mapReady = !!(
    _mapReady &&
    map &&
    !map._navapronStub &&
    !_mapCreating &&
    !_enterModeBusy
  );
  return {
    mode: state.mode,
    journeyStep: state.journeyStep,
    mapReady: mapReady,
    mapCreating: !!(_mapCreating || _enterModeBusy),
    depIcao: state.depChart && state.depChart.airport
      ? state.depChart.airport.icao
      : state.airport && state.mode !== "hub"
        ? state.airport.icao
        : null,
    destIcao: state.destChart && state.destChart.airport
      ? state.destChart.airport.icao
      : null,
    hasTaxiOut: Array.isArray(routeCoords) && routeCoords.length >= 2,
    hasFlightPlan: Array.isArray(fpCoords) && fpCoords.length >= 2,
    hasStart: !!(state.start && state.start.lat != null),
    hasEnd: !!(
      (state.end && state.end.lat != null) ||
      (state.depPick && state.depPick.runway)
    ),
    hasArrRunway: !!(state.arrPick && state.arrPick.runway),
    hasArrStand: !!(
      state.arrivalStand ||
      (state.arrPick && state.arrPick.stand)
    ),
  };
}

async function _tutorialLoadDemoDep(icao) {
  icao = (icao || "EGNM").toUpperCase();
  if (typeof enterMode === "function" && state.mode === "hub") {
    enterMode("journey");
    await _tutorialWait(900);
  }
  await loadAirport(icao, { role: "dep", fit: true, keepPaths: true });
  if ($("#fp-dep")) $("#fp-dep").value = icao;
}

async function _tutorialLoadDemoAirports(dep, dest) {
  dep = (dep || "EGNM").toUpperCase();
  dest = (dest || "EGLL").toUpperCase();
  if (typeof enterMode === "function" && state.mode === "hub") {
    enterMode("journey");
    await _tutorialWait(900);
  }
  if ($("#fp-dep")) $("#fp-dep").value = dep;
  if ($("#fp-dest")) $("#fp-dest").value = dest;
  await loadBothAirports({ dep: dep, dest: dest });
  if (typeof setJourneyStep === "function") {
    setJourneyStep("taxi-out", { skipFit: true });
  }
  await _tutorialWait(200);
  try {
    if (map && !map._navapronStub && state.depChart) {
      fitChartBounds(state.depChart, { maxZoom: 15 });
    }
  } catch (_) {}
}

async function _tutorialDemoTaxiOut() {
  if (typeof setJourneyStep === "function") {
    setJourneyStep("taxi-out", { skipFit: false });
  }
  await _tutorialWait(350);
  _tutorialPickFirstSelect($("#start-select"));
  await _tutorialWait(150);
  _tutorialPickFirstSelect($("#runway-select"));
  await _tutorialWait(200);
  try {
    await computeRoute(false, { quiet: false, skipFit: false });
  } catch (err) {
    console.warn("tutorial taxi-out", err);
  }
}

async function _tutorialDemoFlightPlan() {
  if (typeof setJourneyStep === "function") {
    setJourneyStep("flightplan", { skipFit: false });
  }
  await _tutorialWait(400);
  const dep =
    ($("#fp-dep") && $("#fp-dep").value) ||
    state.depChart?.airport?.icao ||
    "EGNM";
  const dest =
    ($("#fp-dest") && $("#fp-dest").value) ||
    state.destChart?.airport?.icao ||
    "EGLL";
  if ($("#fp-dep")) $("#fp-dep").value = String(dep).toUpperCase();
  if ($("#fp-dest")) $("#fp-dest").value = String(dest).toUpperCase();
  if ($("#fp-route") && !$("#fp-route").value.trim()) {
    $("#fp-route").value = "DCT";
  }
  try {
    await buildFlightPlan();
  } catch (err) {
    console.warn("tutorial flight plan", err);
  }
}

async function _tutorialDemoTaxiIn() {
  if (typeof setJourneyStep === "function") {
    setJourneyStep("taxi-in", { skipFit: false });
  }
  await _tutorialWait(350);
  // Prefer destination chart for arrival
  try {
    if (state.destChart) {
      applyChartAsActive(state.destChart, { fit: true, redrawAll: true });
    }
  } catch (_) {}
  await _tutorialWait(200);
  _tutorialPickFirstSelect($("#arr-runway-select"));
  await _tutorialWait(150);
  _tutorialPickFirstSelect($("#arr-stand-select"));
}

try {
  window.navapronTutorialApi = {
    enterMode: enterMode,
    showHub: showHub,
    showLauncher: showLauncher,
    setJourneyStep: setJourneyStep,
    loadAirport: loadAirport,
    loadBothAirports: loadBothAirports,
    getState: _tutorialGetState,
    loadDemoDep: _tutorialLoadDemoDep,
    loadDemoAirports: _tutorialLoadDemoAirports,
    demoTaxiOut: _tutorialDemoTaxiOut,
    demoFlightPlan: _tutorialDemoFlightPlan,
    demoTaxiIn: _tutorialDemoTaxiIn,
  };
} catch (_) {}
