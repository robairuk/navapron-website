/**
 * NavApron — zip auto-update UI (feed = version.json on your website)
 */
(function () {
  const $ = (sel) => document.querySelector(sel);

  let lastCheck = null;
  let pollTimer = null;
  let busy = false;

  function setStatus(text, mode) {
    if (typeof window.setStatus === "function") {
      window.setStatus(text, mode);
      return;
    }
    const el = $("#status-text");
    const dot = $("#status-dot");
    if (el) el.textContent = text;
    if (dot) {
      dot.classList.remove("busy", "err");
      if (mode === "busy") dot.classList.add("busy");
      if (mode === "err") dot.classList.add("err");
    }
  }

  function openModal() {
    try {
      const modal = $("#update-modal");
      if (!modal) return;
      // Never call focus() here — crashes some Edge WebView hosts.
      // Backdrop must not use CSS backdrop-filter (GPU crash).
      modal.classList.add("is-open");
      modal.setAttribute("aria-hidden", "false");
      modal.removeAttribute("hidden");
    } catch (err) {
      console.error("openModal", err);
    }
  }

  function closeModal() {
    try {
      const modal = $("#update-modal");
      if (!modal) return;
      modal.classList.remove("is-open");
      modal.setAttribute("aria-hidden", "true");
      modal.setAttribute("hidden", "");
      stopProgressPoll();
    } catch (err) {
      console.error("closeModal", err);
    }
  }

  function setBadge(show) {
    const badge = $("#hub-update-badge");
    if (badge) badge.classList.toggle("hidden", !show);
  }

  function fillUi(data, opts) {
    try {
      const quiet = !!(opts && opts.quiet);
      const line = $("#update-status-line");
      const localEl = $("#update-local-ver");
      const remoteEl = $("#update-remote-ver");
      const notes = $("#update-notes");
      const installBtn = $("#btn-update-install");
      const sub = $("#update-sub");

      const local =
        (data && data.local_version) ||
        (typeof window.NAVAPRON_VERSION === "string" ? window.NAVAPRON_VERSION : "—");
      if (localEl) localEl.textContent = local || "—";

      if (!data) {
        if (line) line.textContent = "Not checked yet.";
        if (remoteEl) remoteEl.textContent = "—";
        if (installBtn) installBtn.classList.add("hidden");
        return;
      }

      if (data.feed_url === null || data.feed_configured === false) {
        if (line)
          line.textContent =
            "Update feed is not set. Rebuild NavApron or check https://navapron.com/version.json";
        if (remoteEl) remoteEl.textContent = "—";
        if (notes)
          notes.textContent =
            "The app expects version.json on navapron.com (see UPDATE-HOSTING.md).";
        if (installBtn) installBtn.classList.add("hidden");
        setBadge(false);
        if (!quiet) setStatus("Update feed not configured", "err");
        return;
      }

      if (data.ok === false && data.error) {
        if (line) line.textContent = "Could not check: " + String(data.error);
        if (remoteEl) remoteEl.textContent = data.remote_version || "—";
        if (notes) notes.textContent = "";
        if (installBtn) installBtn.classList.add("hidden");
        if (!quiet) setStatus("Update check failed", "err");
        return;
      }

      if (remoteEl) remoteEl.textContent = data.remote_version || "—";
      if (sub && data.feed_url) {
        sub.textContent = "Feed: " + String(data.feed_url);
      }

      if (data.update_available) {
        if (line)
          line.textContent =
            "A newer build is available (" +
            (data.remote_version || "?") +
            "). Your airline logbook and layouts are kept.";
        if (notes) notes.textContent = data.notes ? String(data.notes) : "";
        if (installBtn) {
          installBtn.classList.remove("hidden");
          installBtn.disabled = false;
          installBtn.textContent = "Download & install";
        }
        setBadge(true);
        if (!quiet) setStatus("Update available: " + (data.remote_version || ""), "ok");
      } else {
        if (line) line.textContent = "You are on the latest version.";
        if (notes) notes.textContent = data.notes ? String(data.notes) : "";
        if (installBtn) installBtn.classList.add("hidden");
        setBadge(false);
        if (!quiet) setStatus("NavApron is up to date", "ok");
      }
    } catch (err) {
      console.error("fillUi", err);
    }
  }

  function stopProgressPoll() {
    if (pollTimer) {
      clearInterval(pollTimer);
      pollTimer = null;
    }
    const wrap = $("#update-progress-wrap");
    if (wrap) wrap.classList.add("hidden");
  }

  function startProgressPoll() {
    stopProgressPoll();
    const wrap = $("#update-progress-wrap");
    const bar = $("#update-progress-bar");
    if (wrap) wrap.classList.remove("hidden");
    pollTimer = setInterval(async function () {
      try {
        const res = await fetch("/api/update/status");
        const st = await res.json();
        if (bar && st.progress != null) {
          bar.style.width = Math.round((st.progress || 0) * 100) + "%";
        }
        if (!st.downloading && pollTimer) {
          /* keep bar until install finishes */
        }
      } catch (_) {
        /* ignore */
      }
    }, 400);
  }

  async function checkUpdates(opts) {
    opts = opts || {};
    const quiet = !!opts.quiet;
    const open = !!opts.open;
    /** Auto-open dialog when a newer version is found (launch check). */
    const openIfAvailable = !!opts.openIfAvailable;
    // If a check is already running (e.g. launch auto-check), wait briefly
    // instead of returning stale/empty UI — hub clicks must always resolve.
    if (busy) {
      var waited = 0;
      while (busy && waited < 25000) {
        await new Promise(function (r) {
          setTimeout(r, 200);
        });
        waited += 200;
      }
      if (busy) {
        if (open) openModal();
        if (lastCheck) fillUi(lastCheck, { quiet: quiet });
        return lastCheck;
      }
    }
    busy = true;
    try {
      if (open) openModal();
      const line = $("#update-status-line");
      if (line && !quiet) line.textContent = "Checking…";
      if (!quiet) setStatus("Checking for updates…", "busy");
      // Manual timeout fallback for hosts without AbortSignal.timeout
      var controller =
        typeof AbortController !== "undefined" ? new AbortController() : null;
      var timeoutId = null;
      if (controller) {
        timeoutId = setTimeout(function () {
          try {
            controller.abort();
          } catch (_) {}
        }, 20000);
      }
      var res;
      try {
        res = await fetch("/api/update/check", {
          method: "POST",
          signal: controller ? controller.signal : undefined,
        });
      } finally {
        if (timeoutId) clearTimeout(timeoutId);
      }
      let data = {};
      try {
        data = await res.json();
      } catch (_) {
        data = { ok: false, error: "Invalid response from update check" };
      }
      lastCheck = data;
      if (applyStoreChannelUi(data)) return data;
      fillUi(data, { quiet: quiet && !data.update_available });
      if (data.update_available) {
        setBadge(true);
        if (!quiet) setStatus("Update available: " + (data.remote_version || ""), "ok");
        if (openIfAvailable && !open) {
          openModal();
          fillUi(data, { quiet: false });
        }
      } else if (quiet && data.ok !== false) {
        setBadge(false);
      }
      return data;
    } catch (err) {
      const fail = {
        ok: false,
        error: (err && err.message) || "Network error",
        local_version:
          typeof window.NAVAPRON_VERSION === "string" ? window.NAVAPRON_VERSION : "—",
      };
      lastCheck = fail;
      if (!quiet) fillUi(fail, { quiet: false });
      return fail;
    } finally {
      busy = false;
    }
  }

  /**
   * On every launch: check navapron.com for a newer zip.
   * Opens the update dialog only when an update is available.
   * Delayed so it never blocks hub clicks / What's New at startup.
   */
  function applyStoreChannelUi(data) {
    if (!(data && (data.store_build || data.updates_managed_by_store))) return false;
    try {
      const panel = $("#hub-updates-panel");
      if (panel) panel.hidden = true;
      setBadge(false);
      const line = $("#update-status-line");
      if (line)
        line.textContent =
          "Microsoft Store install — updates come from the Store, not the website zip.";
      const installBtn = $("#btn-update-install");
      if (installBtn) installBtn.classList.add("hidden");
    } catch (_) {}
    return true;
  }

  async function autoCheckOnLaunch() {
    const maxAttempts = 3;
    for (let i = 0; i < maxAttempts; i++) {
      try {
        const health = await fetch("/api/health");
        if (!health.ok) throw new Error("not ready");
        // Detect Store/MSIX channel first — skip zip updater entirely
        try {
          const stRes = await fetch("/api/update/status");
          const st = await stRes.json();
          if (applyStoreChannelUi(st)) return;
        } catch (_) {}
        // Badge only — do NOT auto-open the updates modal on launch.
        // Opening overlays during first paint has crashed some WebView2 hosts.
        await checkUpdates({ quiet: true, open: false, openIfAvailable: false });
        return;
      } catch (_) {
        await new Promise(function (r) {
          setTimeout(r, 2000);
        });
      }
    }
  }

  async function postJson(url) {
    const res = await fetch(url, { method: "POST" });
    let data = {};
    try {
      data = await res.json();
    } catch (_) {
      data = {};
    }
    return { res: res, data: data };
  }

  /** Apply a staged package; retry a few times if the first attempt fails. */
  async function applyStagedWithRetry(line, installBtn) {
    var lastErr = "Install/restart failed";
    for (var attempt = 1; attempt <= 3; attempt++) {
      if (line)
        line.textContent =
          attempt === 1
            ? "Download complete. Installing and restarting NavApron…"
            : "Retrying install (" + attempt + "/3)…";
      if (installBtn) installBtn.textContent = "Installing…";
      setStatus("Installing update — restarting…", "busy");
      try {
        var out = await postJson("/api/update/apply");
        var ap = out.data;
        if (out.res.ok && ap.ok !== false && ap.applying) {
          return ap;
        }
        lastErr =
          typeof ap.detail === "string"
            ? ap.detail
            : ap.error || lastErr;
        // Staged on disk but spawn failed — wait briefly and retry
        if (ap.staged || /staged|installer|apply/i.test(String(lastErr))) {
          await new Promise(function (r) {
            setTimeout(r, 800 * attempt);
          });
          continue;
        }
        throw new Error(lastErr);
      } catch (err) {
        lastErr = (err && err.message) || lastErr;
        await new Promise(function (r) {
          setTimeout(r, 800 * attempt);
        });
      }
    }
    throw new Error(lastErr);
  }

  async function installUpdate() {
    if (busy) return;
    busy = true;
    const installBtn = $("#btn-update-install");
    const line = $("#update-status-line");
    if (installBtn) {
      installBtn.disabled = true;
      installBtn.textContent = "Downloading…";
    }
    if (line)
      line.textContent =
        "Downloading zip… then NavApron will install and restart. Leave this window open.";
    setStatus("Downloading update…", "busy");
    startProgressPoll();
    try {
      // Phase 1 — download & stage (can take a while on large zips)
      const dlOut = await postJson("/api/update/download");
      const dl = dlOut.data;
      if (!dlOut.res.ok || dl.ok === false) {
        throw new Error(
          typeof dl.detail === "string"
            ? dl.detail
            : dl.error || "Download failed"
        );
      }
      if (!dl.staged) {
        stopProgressPoll();
        if (line)
          line.textContent = dl.message || "Nothing to install (already up to date).";
        if (installBtn) {
          installBtn.disabled = false;
          installBtn.textContent = "Download & install";
        }
        setStatus(dl.message || "Already up to date", "ok");
        busy = false;
        return;
      }

      // Phase 2 — always apply after a successful stage (with retries)
      if (installBtn) installBtn.textContent = "Installing…";
      var ap;
      try {
        ap = await applyStagedWithRetry(line, installBtn);
      } catch (applyErr) {
        // Fallback: one-shot install endpoint (download already staged → apply only)
        if (line) line.textContent = "Trying alternate install path…";
        var instOut = await postJson("/api/update/install");
        var inst = instOut.data;
        if (!instOut.res.ok || inst.ok === false || !inst.applying) {
          throw new Error(
            typeof inst.detail === "string"
              ? inst.detail
              : inst.error ||
                (applyErr && applyErr.message) ||
                "Install/restart failed"
          );
        }
        ap = inst;
      }

      if (line)
        line.textContent =
          ap.message ||
          "Installing… this window will close; a single new NavApron will open.";
      if (installBtn) installBtn.textContent = "Restarting…";

      // Soft-close the UI if the host allows it (Edge app mode / some WebViews)
      try {
        setTimeout(function () {
          try {
            window.close();
          } catch (_) {}
        }, 1500);
      } catch (_) {}

      // If still open after ~15s, apply script may have failed — point at log / bat
      setTimeout(function () {
        if (line)
          line.textContent =
            "Still open? Quit every NavApron window, then double-click " +
            "_apply_update.bat next to NavApron.exe (or check _update_log.txt).";
        if (installBtn) {
          installBtn.disabled = false;
          installBtn.textContent = "Retry install";
        }
        busy = false;
        stopProgressPoll();
      }, 15000);
    } catch (err) {
      stopProgressPoll();
      if (line) line.textContent = err.message || "Update failed";
      if (installBtn) {
        installBtn.disabled = false;
        installBtn.textContent = "Download & install";
      }
      setStatus(err.message || "Update failed", "err");
      busy = false;
    }
  }

  function safeCheck(opts) {
    // Return from the click handler immediately; open UI on next tick.
    try {
      var o = opts || {};
      if (o.open) {
        try {
          openModal();
          var line = $("#update-status-line");
          if (line && !o.quiet) line.textContent = "Checking…";
        } catch (_) {}
      }
      setTimeout(function () {
        try {
          checkUpdates(Object.assign({}, o, { open: false }))
            .then(function (data) {
              // Ensure panel is visible after check when user asked for it
              if (o.open) openModal();
              return data;
            })
            .catch(function (err) {
              console.error("checkUpdates", err);
              if (o.open) {
                openModal();
                fillUi(
                  {
                    ok: false,
                    error: (err && err.message) || "Update check failed",
                    local_version:
                      typeof window.NAVAPRON_VERSION === "string"
                        ? window.NAVAPRON_VERSION
                        : "—",
                  },
                  { quiet: false }
                );
              }
            });
        } catch (err) {
          console.error("checkUpdates sync", err);
        }
      }, 0);
    } catch (err) {
      console.error("safeCheck", err);
    }
  }

  function bind() {
    function onCheckClick(e) {
      try {
        if (e && e.preventDefault) e.preventDefault();
        if (e && e.stopPropagation) e.stopPropagation();
        safeCheck({ open: true, quiet: false });
      } catch (err) {
        console.error("check-updates click", err);
      }
    }
    $("#btn-check-updates-hub")?.addEventListener("click", onCheckClick);
    $("#btn-check-updates")?.addEventListener("click", onCheckClick);
    $("#btn-update-recheck")?.addEventListener("click", onCheckClick);
    $("#btn-update-install")?.addEventListener("click", function (e) {
      if (e && e.preventDefault) e.preventDefault();
      try {
        installUpdate();
      } catch (err) {
        console.error(err);
      }
    });
    document.querySelectorAll("[data-update-close]").forEach(function (el) {
      el.addEventListener("click", function (e) {
        try {
          if (e && e.preventDefault) e.preventDefault();
          closeModal();
        } catch (err) {
          console.error(err);
        }
      });
    });
    document.addEventListener("keydown", function (e) {
      try {
        if (e.key !== "Escape") return;
        const modal = $("#update-modal");
        if (modal && modal.classList.contains("is-open")) closeModal();
      } catch (_) {}
    });
    $("#hub-update-badge")?.addEventListener("click", onCheckClick);
  }

  bind();
  // Delay auto-check well after first paint so WebView2 can settle (hub UI first)
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () {
      setTimeout(autoCheckOnLaunch, 12000);
    });
  } else {
    setTimeout(autoCheckOnLaunch, 12000);
  }
})();
