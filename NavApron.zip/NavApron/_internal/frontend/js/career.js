/**
 * Pilot Career — hub overlay + map mission panel.
 * Does not replace NavApron planning or the Airline roleplay panel.
 */
(function () {
  "use strict";

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  let overview = null;
  let hubPick = null;
  let pollTimer = null;
  let suggestTimer = null;
  let currency = {
    code: "USD",
    symbol: "$",
    rate: 1,
  };

  function setStatus(msg, kind) {
    try {
      if (typeof window.setStatus === "function") window.setStatus(msg, kind || "ok");
    } catch (_) {}
  }

  function money(n) {
    const x = Number(n);
    if (!Number.isFinite(x)) return (currency.symbol || "$") + "—";
    const converted = x * (Number(currency.rate) || 1);
    const sign = converted < 0 ? "-" : "";
    return (
      sign +
      (currency.symbol || "$") +
      Math.abs(converted).toLocaleString(undefined, { maximumFractionDigits: 0 })
    );
  }

  async function loadCurrencyPrefs() {
    try {
      const prefs = await api("/api/user/prefs");
      currency = {
        code: prefs.career_currency || "USD",
        symbol: prefs.career_currency_symbol || "$",
        rate: Number(prefs.career_currency_rate) || 1,
      };
      window.__navapronCareerCurrency = currency;
    } catch (_) {}
  }

  function showView(name) {
    const views = ["setup", "home", "jobs", "hangar", "airlines"];
    views.forEach(function (v) {
      const el = $("#career-view-" + v);
      if (el) el.hidden = v !== name;
    });
  }

  function showCareerHub() {
    try {
      if (typeof window.hideLauncherOverlay === "function") window.hideLauncherOverlay();
      else {
        const L = $("#launcher");
        if (L) {
          L.hidden = true;
          L.setAttribute("aria-hidden", "true");
          L.style.setProperty("display", "none", "important");
        }
      }
      if (typeof window.hideHubOverlay === "function") window.hideHubOverlay();
      if (typeof window.hideSimBriefSetup === "function") window.hideSimBriefSetup();
    } catch (_) {}
    const el = $("#career-hub");
    if (el) {
      el.hidden = false;
      el.removeAttribute("aria-hidden");
      el.style.setProperty("display", "block", "important");
      el.style.zIndex = "5100";
    }
    document.body.classList.add("hub-open");
    try {
      if (window.state) window.state.mode = "career";
      localStorage.setItem("navapron_mode", "career");
    } catch (_) {}
    refreshOverview();
  }

  function hideCareerHub() {
    const el = $("#career-hub");
    if (el) {
      el.hidden = true;
      el.setAttribute("aria-hidden", "true");
      el.style.setProperty("display", "none", "important");
    }
    // Career hub used hub-open; clear it so the map receives clicks
    try {
      document.body.classList.remove("hub-open");
    } catch (_) {}
  }

  window.showCareerHub = showCareerHub;
  window.hideCareerHub = hideCareerHub;
  window.paintHubCareerStrip = function () {
    // Fetch if we have never loaded; otherwise paint cached overview
    if (!overview) {
      refreshOverview().catch(function () {});
      return;
    }
    paintHubCareerStrip();
  };

  function setCareerPanelOpen(open, opts) {
    const quiet = !!(opts && opts.quiet);
    const panel = $("#career-panel");
    const app = $("#app");
    const wrap = document.querySelector(".map-wrap");
    const openBtn = $("#btn-career-open");
    if (!panel) return;
    if (open) {
      panel.hidden = false;
      panel.removeAttribute("hidden");
      panel.style.removeProperty("display");
      document.body.classList.add("career-panel-open");
      if (app) app.classList.add("career-panel-open");
      if (wrap) wrap.classList.add("career-drawer-open");
      if (openBtn) openBtn.setAttribute("aria-expanded", "true");
      // Career takes the single right-dock slot (pushes map like Airline)
      try {
        if (typeof window.setAirlineCollapsed === "function") {
          window.setAirlineCollapsed(true, { persist: true, quiet: true });
        } else if (app) {
          app.classList.add("airline-collapsed");
        }
      } catch (_) {}
      try {
        if (window.NavApronPlates && typeof window.NavApronPlates.close === "function") {
          window.NavApronPlates.close({ quiet: true });
        }
      } catch (_) {}
    } else {
      panel.hidden = true;
      panel.setAttribute("hidden", "");
      panel.style.removeProperty("display");
      document.body.classList.remove("career-panel-open");
      if (app) app.classList.remove("career-panel-open");
      if (wrap) wrap.classList.remove("career-drawer-open");
      if (openBtn) openBtn.setAttribute("aria-expanded", "false");
    }
    function fixMap() {
      try {
        if (typeof window.fixMapSize === "function") window.fixMapSize();
        else if (window.map && typeof window.map.invalidateSize === "function") {
          window.map.invalidateSize(true);
        }
      } catch (_) {}
    }
    fixMap();
    setTimeout(fixMap, 80);
    setTimeout(fixMap, 260);
    if (!quiet) {
      /* callers set status when useful */
    }
  }

  window.setCareerPanelOpen = setCareerPanelOpen;

  async function api(path, opts) {
    const res = await fetch(path, {
      cache: "no-store",
      headers: { "Content-Type": "application/json", ...(opts && opts.headers) },
      ...opts,
    });
    let data = null;
    try {
      data = await res.json();
    } catch (_) {
      data = null;
    }
    if (!res.ok) {
      const err =
        (data && (data.detail || data.error)) ||
        "Request failed (" + res.status + ")";
      throw new Error(typeof err === "string" ? err : JSON.stringify(err));
    }
    return data;
  }

  function setHubCareerStatus(msg, isErr) {
    const el = $("#hub-career-status");
    if (!el) return;
    el.textContent = msg || "";
    el.classList.toggle("err", !!isErr);
  }

  /** Paint the Pilot Career strip on the unified NavApron home hub. */
  function paintHubCareerStrip() {
    const setup = $("#hub-career-setup");
    const ready = $("#hub-career-ready");
    const actions = $("#hub-career-actions-ready");
    const sub = $("#hub-career-sub");
    if (!setup || !ready) return;

    if (!overview) {
      setup.hidden = false;
      ready.hidden = true;
      if (actions) actions.hidden = true;
      if (sub) {
        sub.textContent =
          "Optional economy mode — hire a Cessna, fly jobs, earn cash";
      }
      return;
    }

    if (overview.setup_required) {
      setup.hidden = false;
      ready.hidden = true;
      if (actions) actions.hidden = true;
      if (sub) {
        sub.textContent = "Create a pilot when you want — planning above stays free";
      }
      setHubCareerStatus("");
      return;
    }

    setup.hidden = true;
    ready.hidden = false;
    if (actions) actions.hidden = false;

    const p = overview.profile || {};
    const cash = money(p.cash);
    if ($("#hub-career-cash")) $("#hub-career-cash").textContent = cash;
    if ($("#hub-career-hours"))
      $("#hub-career-hours").textContent =
        Number(p.airborne_hours || 0).toFixed(1) + "h";
    if ($("#hub-career-flights"))
      $("#hub-career-flights").textContent = String(p.flights || 0);
    if ($("#hub-career-station"))
      $("#hub-career-station").textContent = p.station_icao || "—";

    const airline = (overview.airlines || []).find(function (a) {
      return a.id === p.airline_id;
    });
    if ($("#hub-career-pilot")) {
      $("#hub-career-pilot").textContent =
        (p.name || "Pilot") +
        " · Hub " +
        (p.hub_icao || "—") +
        (airline ? " · " + airline.name : " · Freelance");
    }
    if (sub) {
      sub.textContent = airline
        ? airline.name + " · station " + (p.station_icao || "—")
        : "Freelance · station " + (p.station_icao || "—");
    }

    const active = overview.active;
    const ban = $("#hub-career-active");
    if (ban) {
      if (active) {
        ban.hidden = false;
        if ($("#hub-career-active-title"))
          $("#hub-career-active-title").textContent = active.title || "Mission";
        if ($("#hub-career-active-route"))
          $("#hub-career-active-route").textContent =
            (active.dep || "?") + " → " + (active.dest || "?");
      } else {
        ban.hidden = true;
      }
    }
    setHubCareerStatus("");
  }

  function paintHome() {
    paintHubCareerStrip();
    if (!overview || overview.setup_required) {
      showView("setup");
      $("#career-cash-pill") && ($("#career-cash-pill").textContent = "$5,000 start");
      return;
    }
    showView("home");
    const p = overview.profile || {};
    const cash = money(p.cash);
    if ($("#career-cash-pill")) $("#career-cash-pill").textContent = cash;
    if ($("#career-stat-cash")) $("#career-stat-cash").textContent = cash;
    if ($("#career-stat-hours"))
      $("#career-stat-hours").textContent =
        Number(p.airborne_hours || 0).toFixed(1) + "h";
    if ($("#career-stat-flights"))
      $("#career-stat-flights").textContent = String(p.flights || 0);
    if ($("#career-stat-station"))
      $("#career-stat-station").textContent = p.station_icao || "—";
    const airline = (overview.airlines || []).find(function (a) {
      return a.id === p.airline_id;
    });
    if ($("#career-pilot-line")) {
      $("#career-pilot-line").textContent =
        (p.name || "Pilot") +
        " · Hub " +
        (p.hub_icao || "—") +
        (airline ? " · " + airline.name : " · Freelance");
    }
    if ($("#career-hub-sub")) {
      $("#career-hub-sub").textContent = airline
        ? airline.name + " · " + (p.station_icao || "")
        : "Freelance · station " + (p.station_icao || "");
    }

    const active = overview.active;
    const ban = $("#career-active-banner");
    if (ban) {
      if (active) {
        ban.hidden = false;
        if ($("#career-active-title"))
          $("#career-active-title").textContent = active.title || "Mission";
        if ($("#career-active-route"))
          $("#career-active-route").textContent =
            (active.dep || "?") + " → " + (active.dest || "?");
      } else {
        ban.hidden = true;
      }
    }
    paintPanel();
  }

  function paintHangar() {
    const body = $("#career-hangar-body");
    if (!body || !overview) return;
    const ac = overview.aircraft || {};
    const hired = ac.hired;
    const owned = (ac.owned || [])[0];
    let html = "";
    if (hired) {
      html +=
        '<div class="career-hangar-card"><h3>Hired</h3><p>' +
        (hired.label || hired.type) +
        " · " +
        (hired.reg || "") +
        "</p><p class=\"muted\">$" +
        (hired.hire_fee || 150) +
        " deducted each flight until you buy your own.</p></div>";
    }
    if (owned) {
      html +=
        '<div class="career-hangar-card"><h3>Owned — ' +
        (owned.label || owned.type) +
        "</h3><p>Reg " +
        (owned.reg || "—") +
        " · Hull <strong>" +
        Number(owned.hull_pct || 0).toFixed(0) +
        "%</strong> · " +
        Number(owned.total_nm || 0).toFixed(0) +
        " NM</p>";
      if (Number(owned.hull_pct || 100) < 99.5) {
        html +=
          '<button type="button" class="btn btn-secondary" id="btn-career-repair">Repair hull</button>';
      }
      html += "</div>";
    } else {
      const price = (overview.economy && overview.economy.buy_c172) || 45000;
      html +=
        '<div class="career-hangar-card"><h3>Buy a Cessna 172</h3><p>Own your aircraft — pay maintenance and landing wear instead of hire fees.</p>' +
        '<button type="button" class="btn btn-primary" id="btn-career-buy"' +
        (ac.can_buy_c172 ? "" : " disabled") +
        ">Buy for " +
        money(price) +
        "</button></div>";
    }
    body.innerHTML = html;
    $("#btn-career-buy")?.addEventListener("click", async function () {
      try {
        overview = await api("/api/career/aircraft/buy", { method: "POST", body: "{}" });
        setStatus("Cessna 172 purchased", "ok");
        paintHangar();
        paintHome();
      } catch (err) {
        setMsg("career-hangar-status", err.message, true);
      }
    });
    $("#btn-career-repair")?.addEventListener("click", async function () {
      try {
        overview = await api("/api/career/aircraft/repair", {
          method: "POST",
          body: "{}",
        });
        setStatus("Aircraft repaired", "ok");
        paintHangar();
        paintHome();
      } catch (err) {
        setMsg("career-hangar-status", err.message, true);
      }
    });
  }

  function paintAirlines() {
    const list = $("#career-airline-list");
    const lead = $("#career-airlines-lead");
    if (!list || !overview) return;
    const hours = Number((overview.profile && overview.profile.airborne_hours) || 0);
    const unlock = Number(overview.unlock_hours || 10);
    const joined = overview.profile && overview.profile.airline_id;
    if (lead) {
      lead.textContent = joined
        ? "You fly for this carrier. Resign to return to freelance sightseeing."
        : hours >= unlock
          ? "Choose an airline — job board switches to paid sectors."
          : "Need " +
            unlock.toFixed(0) +
            "h airborne (you have " +
            hours.toFixed(1) +
            "h).";
    }
    list.innerHTML = "";
    (overview.airlines || []).forEach(function (a) {
      const card = document.createElement("div");
      card.className = "career-airline-card";
      if (joined === a.id) card.classList.add("joined");
      card.innerHTML =
        "<header><strong>" +
        (j.title || "Job") +
        "</strong><span>" +
        (j.kind === "airline"
          ? (j.airline || "") + " " + (j.fltnum || "")
          : "Sightseeing (NavApron)") +
        "</span></header>" +
        '<p class="route">' +
        (j.dep || "?") +
        "  ->  " +
        (j.dest || "?") +
        "  |  " +
        j.distance_nm +
        " NM  |  " +
        (j.aircraft || "") +
        "</p>" +
        '<p class="pay">Payout ' +
        money(j.payout) +
        "  |  Est. net " +
        money(
          overview && overview.aircraft && overview.aircraft.owns_c172
            ? Number(j.payout || 0) -
                Number(j.fuel_est_usd || 0) -
                Number(j.fees_est || 0)
            : j.net_est
        ) +
        (j.hire_fee &&
        !(overview && overview.aircraft && overview.aircraft.owns_c172)
          ? "  |  Hire " + money(j.hire_fee)
          : "") +
        (j.kind !== "airline" ? "  |  No SimBrief" : "") +
        "</p>";
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "btn btn-secondary";
      if (joined === a.id) {
        btn.textContent = "Resign";
        btn.addEventListener("click", async function () {
          try {
            overview = await api("/api/career/airlines/resign", {
              method: "POST",
              body: "{}",
            });
            paintAirlines();
            paintHome();
          } catch (err) {
            setMsg("career-airlines-status", err.message, true);
          }
        });
      } else {
        btn.textContent = "Join";
        btn.disabled = !!joined || hours < unlock;
        btn.addEventListener("click", async function () {
          try {
            overview = await api("/api/career/airlines/join", {
              method: "POST",
              body: JSON.stringify({ airline_id: a.id }),
            });
            setStatus("Welcome to " + a.name, "ok");
            paintAirlines();
            paintHome();
          } catch (err) {
            setMsg("career-airlines-status", err.message, true);
          }
        });
      }
      card.appendChild(btn);
      list.appendChild(card);
    });
  }

  function setMsg(id, text, isErr) {
    const el = $("#" + id);
    if (!el) return;
    el.textContent = text || "";
    el.classList.toggle("err", !!isErr);
  }

  function paintJobs(jobs) {
    const list = $("#career-job-list");
    if (!list) return;
    list.innerHTML = "";
    if (!jobs || !jobs.length) {
      list.innerHTML = '<p class="career-lead">No jobs — tap Refresh.</p>';
      return;
    }
    jobs.forEach(function (j) {
      const card = document.createElement("article");
      card.className = "career-job-card";
      card.innerHTML =
        "<header><strong>" +
        (j.title || "Job") +
        "</strong><span>" +
        (j.kind === "airline"
          ? j.airline + " " + (j.fltnum || "")
          : "Sightseeing · NavApron only") +
        "</span></header>" +
        '<p class="route">' +
        j.dep +
        " → " +
        j.dest +
        " · " +
        j.distance_nm +
        " NM · " +
        (j.aircraft || "") +
        "</p>" +
        '<p class="pay">Payout ' +
        money(j.payout) +
        " | Est. net " +
        money(
          overview && overview.aircraft && overview.aircraft.owns_c172
            ? Number(j.payout || 0) -
                Number(j.fuel_est_usd || 0) -
                Number(j.fees_est || 0)
            : j.net_est
        ) +
        (j.hire_fee &&
        !(overview && overview.aircraft && overview.aircraft.owns_c172)
          ? " | Hire " + money(j.hire_fee)
          : "") +
        (j.kind !== "airline" ? " | No SimBrief" : "") +
        "</p>";
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "btn btn-primary";
      btn.textContent = "Accept job";
      btn.addEventListener("click", function () {
        acceptJob(j.id);
      });
      card.appendChild(btn);
      list.appendChild(card);
    });

    const p = overview && overview.profile;
    const ferry = $("#career-ferry-wrap");
    if (ferry && p) {
      const away = p.station_icao && p.hub_icao && p.station_icao !== p.hub_icao;
      ferry.hidden = !away || !!p.airline_id === false && false;
      ferry.hidden = !away;
    }
  }

  async function refreshJobsBoard() {
    setMsg("career-jobs-status", "Loading jobs…");
    try {
      const data = await api("/api/career/jobs/refresh", {
        method: "POST",
        body: "{}",
      });
      paintJobs(data.jobs || []);
      setMsg("career-jobs-status", (data.jobs || []).length + " jobs available");
    } catch (err) {
      setMsg("career-jobs-status", err.message, true);
    }
  }

  async function acceptJob(jobId) {
    setMsg("career-jobs-status", "Accepting…");
    $$("#career-job-list .btn").forEach(function (b) {
      b.disabled = true;
    });
    try {
      const data = await api("/api/career/jobs/accept", {
        method: "POST",
        body: JSON.stringify({ job_id: jobId }),
      });
      overview = data.overview || (await api("/api/career"));
      const active = data.active;
      if (!active) {
        throw new Error("Mission was not created — try Refresh and Accept again.");
      }
      const direct = !!data.navapron_direct || active.kind !== "airline";
      setMsg(
        "career-jobs-status",
        direct
          ? "Mission accepted — loading " +
              (active.dep || "?") +
              " to " +
              (active.dest || "?") +
              "…"
          : "Mission accepted — opening SimBrief…"
      );
      setStatus(
        "Accepted " + (active.dep || "") + " -> " + (active.dest || ""),
        "ok"
      );
      await handoffToMap(active, data.dispatch_url, direct);
    } catch (err) {
      const msg = err && err.message ? err.message : String(err);
      setMsg("career-jobs-status", msg, true);
      setStatus(msg, "err");
      $$("#career-job-list .btn").forEach(function (b) {
        b.disabled = false;
      });
    }
  }

  function getMap() {
    try {
      if (window.map && !window.map._navapronStub) return window.map;
    } catch (_) {}
    try {
      if (typeof window.getNavapronMap === "function") {
        const m = window.getNavapronMap();
        if (m && !m._navapronStub) return m;
      }
    } catch (_) {}
    return null;
  }

  function waitForMapReady(timeoutMs) {
    const limit = timeoutMs || 8000;
    const t0 = Date.now();
    return new Promise(function (resolve) {
      function tick() {
        try {
          if (window._navapronMapReady && getMap()) {
            resolve(true);
            return;
          }
          const m = getMap();
          if (m && typeof m.getContainer === "function") {
            resolve(true);
            return;
          }
        } catch (_) {}
        if (Date.now() - t0 > limit) {
          resolve(false);
          return;
        }
        setTimeout(tick, 120);
      }
      tick();
    });
  }

  /** Last-resort: draw DCT on the live Leaflet map without app helpers. */
  async function paintCareerPlanFallback(depIcao, destIcao) {
    const m = getMap();
    if (!m || typeof L === "undefined") {
      throw new Error("Map not available for fallback paint");
    }
    const [depRes, destRes] = await Promise.all([
      fetch("/api/airports/" + encodeURIComponent(depIcao), { cache: "no-store" }),
      fetch("/api/airports/" + encodeURIComponent(destIcao), { cache: "no-store" }),
    ]);
    const depAp = await depRes.json();
    const destAp = await destRes.json();
    if (!depRes.ok || depAp.lat == null) throw new Error("Bad departure " + depIcao);
    if (!destRes.ok || destAp.lat == null) throw new Error("Bad destination " + destIcao);

    const ll = [
      [Number(depAp.lat), Number(depAp.lon)],
      [Number(destAp.lat), Number(destAp.lon)],
    ];

    // Prefer app flightPlan layer
    let layer = window.baseLayers && window.baseLayers.flightPlan;
    if (!layer) {
      layer = L.layerGroup().addTo(m);
      if (!window.baseLayers) window.baseLayers = {};
      window.baseLayers.flightPlan = layer;
    }
    try {
      layer.clearLayers();
    } catch (_) {}
    if (m.hasLayer && !m.hasLayer(layer)) {
      layer.addTo(m);
    }
    L.polyline(ll, { color: "#c084fc", weight: 5, opacity: 0.95 }).addTo(layer);
    L.circleMarker(ll[0], {
      radius: 7,
      color: "#f3e8ff",
      fillColor: "#a855f7",
      fillOpacity: 0.95,
    })
      .bindTooltip(depIcao)
      .addTo(layer);
    L.circleMarker(ll[1], {
      radius: 7,
      color: "#f3e8ff",
      fillColor: "#a855f7",
      fillOpacity: 0.95,
    })
      .bindTooltip(destIcao)
      .addTo(layer);
    try {
      m.fitBounds(L.latLngBounds(ll).pad(0.25));
    } catch (_) {}
    return { coords: ll, dep: depIcao, dest: destIcao };
  }

  async function handoffToMap(active, dispatchUrl, navapronDirect) {
    if (!active) return;
    const depIcao = (active.dep || "").toString().trim().toUpperCase();
    const destIcao = (active.dest || "").toString().trim().toUpperCase();

    hideCareerHub();
    try {
      document.body.classList.remove("hub-open");
    } catch (_) {}

    // Open journey map first (Leaflet boots async)
    try {
      if (typeof window.enterMode === "function") {
        window.enterMode("journey");
      } else {
        throw new Error("Map launcher missing — restart NavApron");
      }
    } catch (err) {
      setStatus(err.message || String(err), "err");
      setMsg("career-jobs-status", err.message || String(err), true);
      showCareerHub();
      showView("jobs");
      return;
    }

    const mapOk = await waitForMapReady(15000);
    if (!mapOk) {
      setStatus("Map did not start — open Journey from NavApron hub, then retry", "err");
      showCareerHub();
      showView("jobs");
      return;
    }

    // Let enterMode finishUi (journey tabs / taxi-out step) settle before we paint
    await new Promise(function (r) {
      setTimeout(r, 700);
    });

    try {
      const dep = $("#fp-dep");
      const dest = $("#fp-dest");
      const ac = $("#fp-ac");
      const route = $("#fp-route");
      const fn = $("#al-fn");
      if (dep) dep.value = depIcao;
      if (dest) dest.value = destIcao;
      if (ac) ac.value = active.aircraft || "C172";
      if (route) route.value = navapronDirect ? "DCT" : "";
      if (fn) fn.value = active.fltnum || "";
    } catch (_) {}

    setCareerPanelOpen(true);
    paintPanel();

    // Cessna / sightseeing: load like a SimBrief OFP (clear + DCT plan + flight-plan step)
    if (navapronDirect) {
      try {
        setStatus("Building career plan " + depIcao + " -> " + destIcao + "…", "busy");
        let plan = null;
        if (typeof window.applyCareerDirectPlan === "function") {
          try {
            plan = await window.applyCareerDirectPlan(depIcao, destIcao);
          } catch (err1) {
            console.warn("applyCareerDirectPlan failed, using fallback", err1);
          }
        }
        if (!plan) {
          plan = await paintCareerPlanFallback(depIcao, destIcao);
        }
        try {
          if (typeof window.setJourneyStep === "function") {
            window.setJourneyStep("flightplan", { skipFit: true });
          }
        } catch (_) {}
        const nm =
          plan && plan.distance_nm != null ? " (" + plan.distance_nm + " NM)" : "";
        setStatus(
          "Career plan " + depIcao + " -> " + destIcao + nm + " — Start tracking when ready",
          "ok"
        );
        setMsg(
          "cpanel-msg",
          "Plan on map: " + depIcao + " -> " + destIcao + nm
        );
      } catch (err) {
        console.error("career handoff", err);
        setStatus(
          "Mission accepted but plan failed: " + (err.message || err),
          "err"
        );
        setMsg("cpanel-msg", err.message || String(err), true);
      }
      startPanelPoll();
      return;
    }

    // Airline jobs: SimBrief Dispatch with flight number
    if (dispatchUrl) {
      try {
        window.open(dispatchUrl, "_blank", "noopener");
      } catch (_) {}
      setStatus(
        "Generate the OFP in SimBrief, then Import last OFP — career mission is ready",
        "ok"
      );
    }
    startPanelPoll();
  }

  function paintPanel() {
    const active = overview && overview.active;
    const empty = $("#career-panel-empty");
    const mission = $("#career-panel-mission");
    if (!active) {
      if (empty) empty.hidden = false;
      if (mission) mission.hidden = true;
      // Only clear Career's own live path — Airline poll must not fight this layer
      try {
        if (typeof window.clearLiveTrackingTrace === "function") {
          window.clearLiveTrackingTrace("career");
        }
      } catch (_) {}
      return;
    }
    if (empty) empty.hidden = true;
    if (mission) mission.hidden = false;
    const dispatchBtn = $("#btn-cpanel-dispatch");
    if (dispatchBtn) {
      const airlineJob = active.kind === "airline";
      dispatchBtn.hidden = !airlineJob;
      dispatchBtn.style.display = airlineJob ? "" : "none";
    }
    if ($("#cpanel-title")) $("#cpanel-title").textContent = active.title || "Mission";
    if ($("#cpanel-route")) {
      let routeTxt = (active.dep || "?") + "  ->  " + (active.dest || "?");
      if (active.fltnum) {
        routeTxt += "   |   " + (active.airline || "") + " " + active.fltnum;
      }
      $("#cpanel-route").textContent = routeTxt;
    }
    if ($("#cpanel-payout")) $("#cpanel-payout").textContent = money(active.payout);
    if ($("#cpanel-net")) $("#cpanel-net").textContent = money(active.net_est);
    if ($("#cpanel-ac")) {
      $("#cpanel-ac").textContent = [active.aircraft, active.reg]
        .filter(Boolean)
        .join("  ");
    }
    if ($("#cpanel-status")) $("#cpanel-status").textContent = active.status || "—";
    const airS = Number(active.airborne_accum_s || 0);
    if ($("#cpanel-air"))
      $("#cpanel-air").textContent = (airS / 3600).toFixed(2) + " h";
    if ($("#cpanel-nm"))
      $("#cpanel-nm").textContent =
        Number(active.nm_flown || active.distance_nm || 0).toFixed(1) + " NM";
    if ($("#cpanel-ldg")) {
      const fpm = active.landing_fpm;
      $("#cpanel-ldg").textContent =
        fpm == null ? "—" : String(fpm) + " fpm";
    }
    if ($("#cpanel-sim"))
      $("#cpanel-sim").textContent = active.sim_connected ? "Live" : "—";
    const trackBtn = $("#btn-cpanel-track");
    if (trackBtn) {
      trackBtn.textContent = active.tracking ? "Tracking…" : "Start tracking";
      trackBtn.disabled = !!active.tracking;
    }
    const showPlanBtn = $("#btn-cpanel-show-plan");
    if (showPlanBtn) {
      const hasRoute = !!(active.dep && active.dest);
      showPlanBtn.hidden = !hasRoute;
      showPlanBtn.disabled = !hasRoute;
    }
    // Live flown path while career mission is tracking
    try {
      if (
        active.tracking &&
        typeof window.updateLiveTrackingTrace === "function"
      ) {
        window.updateLiveTrackingTrace(active, {
          owner: "career",
          label:
            (active.title || "Mission") +
            " · " +
            (active.dep || "?") +
            " → " +
            (active.dest || "?"),
        });
      }
    } catch (_) {}
  }

  /**
   * Redraw the active mission dep→dest plan on the map (e.g. after relaunch).
   * Uses the same DCT path as Accept for sightseeing; airline missions get a
   * DCT preview so the route is visible without re-importing SimBrief.
   */
  async function showActiveMissionPlan() {
    let active = overview && overview.active;
    if (!active) {
      try {
        overview = await api("/api/career");
        active = overview && overview.active;
        paintPanel();
      } catch (_) {}
    }
    if (!active) {
      setMsg("cpanel-msg", "No active career mission", true);
      setStatus("No active career mission", "err");
      return;
    }
    const depIcao = (active.dep || "").toString().trim().toUpperCase();
    const destIcao = (active.dest || "").toString().trim().toUpperCase();
    if (!depIcao || !destIcao) {
      setMsg("cpanel-msg", "Mission is missing dep/dest", true);
      setStatus("Mission is missing dep/dest", "err");
      return;
    }

    const btn = $("#btn-cpanel-show-plan");
    if (btn) btn.disabled = true;
    setMsg("cpanel-msg", "Drawing plan " + depIcao + " → " + destIcao + "…");
    setStatus("Drawing career plan " + depIcao + " → " + destIcao + "…", "busy");

    try {
      hideCareerHub();
      try {
        document.body.classList.remove("hub-open");
      } catch (_) {}

      try {
        if (typeof window.enterMode === "function") {
          window.enterMode("journey");
        }
      } catch (err) {
        throw new Error(err.message || "Could not open map");
      }

      const mapOk = await waitForMapReady(15000);
      if (!mapOk) {
        throw new Error("Map did not start — open Journey, then try Show plan again");
      }
      await new Promise(function (r) {
        setTimeout(r, 500);
      });

      try {
        const dep = $("#fp-dep");
        const dest = $("#fp-dest");
        const ac = $("#fp-ac");
        const route = $("#fp-route");
        if (dep) dep.value = depIcao;
        if (dest) dest.value = destIcao;
        if (ac) ac.value = active.aircraft || "C172";
        if (route) route.value = "DCT";
      } catch (_) {}

      setCareerPanelOpen(true);

      let plan = null;
      if (typeof window.applyCareerDirectPlan === "function") {
        try {
          plan = await window.applyCareerDirectPlan(depIcao, destIcao);
        } catch (err1) {
          console.warn("show plan applyCareerDirectPlan", err1);
        }
      }
      if (!plan) {
        plan = await paintCareerPlanFallback(depIcao, destIcao);
      }
      try {
        if (typeof window.setJourneyStep === "function") {
          window.setJourneyStep("flightplan", { skipFit: true });
        }
      } catch (_) {}

      const nm =
        plan && plan.distance_nm != null ? " (" + plan.distance_nm + " NM)" : "";
      const note =
        "Plan on map: " +
        depIcao +
        " → " +
        destIcao +
        nm +
        (active.kind === "airline"
          ? " — use SimBrief Dispatch for a full OFP"
          : "");
      setMsg("cpanel-msg", note);
      setStatus(
        "Career plan " + depIcao + " → " + destIcao + nm,
        "ok"
      );
      startPanelPoll();
    } catch (err) {
      console.error("showActiveMissionPlan", err);
      setMsg("cpanel-msg", err.message || String(err), true);
      setStatus(err.message || String(err), "err");
    } finally {
      if (btn) {
        const activeNow = overview && overview.active;
        btn.disabled = !(activeNow && activeNow.dep && activeNow.dest);
      }
    }
  }

  let lastReceipt = null;

  function showReceipt(receipt) {
    const modal = $("#career-receipt-modal");
    const body = $("#career-receipt-body");
    if (!modal || !body || !receipt) return;
    lastReceipt = receipt;
    body.innerHTML =
      '<div class="al-end-stats">' +
      '<div class="al-end-stat"><span class="al-end-stat-n">' +
      money(receipt.payout) +
      '</span><span class="al-end-stat-l">Payout</span></div>' +
      '<div class="al-end-stat"><span class="al-end-stat-n">' +
      money(receipt.net) +
      '</span><span class="al-end-stat-l">Net</span></div>' +
      '<div class="al-end-stat"><span class="al-end-stat-n">' +
      Number(receipt.hours || 0).toFixed(2) +
      "h</span><span class=\"al-end-stat-l\">Hours</span></div>" +
      '<div class="al-end-stat"><span class="al-end-stat-n">' +
      (receipt.station_icao || "—") +
      '</span><span class="al-end-stat-l">Station</span></div></div>' +
      "<p class=\"al-end-hint\">Fuel " +
      money(receipt.fuel_usd) +
      " · Fees " +
      money(receipt.fees) +
      (receipt.hire_fee ? " · Hire " + money(receipt.hire_fee) : "") +
      (receipt.maintenance ? " · Maint " + money(receipt.maintenance) : "") +
      (receipt.damage_pct
        ? " · Hull −" + Number(receipt.damage_pct).toFixed(1) + "%"
        : "") +
      (receipt.landing_fpm != null ? " · Landing " + receipt.landing_fpm + " fpm" : "") +
      "</p>";
    const traceBtn = $("#btn-career-receipt-trace");
    if (traceBtn) {
      const has =
        !!receipt.has_trace ||
        (Array.isArray(receipt.trace) && receipt.trace.length >= 2) ||
        Number(receipt.trace_points || 0) >= 2;
      traceBtn.hidden = !has;
      traceBtn.disabled = !has;
    }
    modal.classList.add("is-open");
    modal.hidden = false;
    modal.removeAttribute("hidden");
    modal.setAttribute("aria-hidden", "false");
  }

  function hideReceipt() {
    const modal = $("#career-receipt-modal");
    if (modal) {
      modal.classList.remove("is-open");
      modal.hidden = true;
      modal.setAttribute("hidden", "");
      modal.setAttribute("aria-hidden", "true");
    }
  }

  async function showReceiptFlownTrace() {
    const receipt = lastReceipt;
    if (!receipt) return;
    const btn = $("#btn-career-receipt-trace");
    if (btn) btn.disabled = true;
    try {
      let trace =
        Array.isArray(receipt.trace) && receipt.trace.length >= 2
          ? receipt.trace
          : null;
      if (!trace && receipt.id) {
        const data = await api(
          "/api/career/logbook/" + encodeURIComponent(receipt.id)
        );
        const entry = data && data.entry;
        if (entry && Array.isArray(entry.trace)) trace = entry.trace;
      }
      if (!Array.isArray(trace) || trace.length < 2) {
        throw new Error("No flown path recorded for this mission");
      }
      const label =
        (receipt.title || "Mission") +
        " · " +
        (receipt.dep || "?") +
        " → " +
        (receipt.dest || "?");
      hideReceipt();
      setCareerPanelOpen(false);
      if (typeof window.showFlownTrace === "function") {
        window.showFlownTrace(trace, { fit: true, label: label });
      } else {
        throw new Error("Map helper missing — restart NavApron");
      }
    } catch (err) {
      setStatus(err.message || String(err), "err");
      setMsg("cpanel-msg", err.message || String(err), true);
    } finally {
      if (btn && lastReceipt) {
        const has =
          !!lastReceipt.has_trace ||
          (Array.isArray(lastReceipt.trace) && lastReceipt.trace.length >= 2) ||
          Number(lastReceipt.trace_points || 0) >= 2;
        btn.disabled = !has;
      }
    }
  }

  async function refreshOverview() {
    try {
      await loadCurrencyPrefs();
      overview = await api("/api/career");
      paintHome();
      paintPanel();
      paintHubCareerStrip();
      if (overview && overview.save_dir && $("#career-home-status")) {
        const el = $("#career-home-status");
        if (el && !el.classList.contains("err") && !(overview.active)) {
          el.textContent = "Saved on this PC";
        }
      }
    } catch (err) {
      setMsg("career-setup-status", err.message, true);
      setMsg("career-home-status", err.message, true);
      setHubCareerStatus(err.message || String(err), true);
      paintHubCareerStrip();
    }
  }

  function startPanelPoll() {
    stopPanelPoll();
    pollTimer = setInterval(async function () {
      try {
        overview = await api("/api/career");
        paintPanel();
        if (overview && overview.profile) {
          if ($("#career-cash-pill"))
            $("#career-cash-pill").textContent = money(overview.profile.cash);
        }
      } catch (_) {}
    }, 1000);
  }

  function stopPanelPoll() {
    if (pollTimer) {
      clearInterval(pollTimer);
      pollTimer = null;
    }
  }

  async function searchHub(q) {
    const box = $("#career-hub-suggest");
    if (!box) return;
    if (!q || q.length < 1) {
      box.hidden = true;
      box.innerHTML = "";
      return;
    }
    try {
      const res = await fetch(
        "/api/airports/search?q=" + encodeURIComponent(q) + "&limit=8",
        { cache: "no-store" }
      );
      const data = await res.json();
      const list = Array.isArray(data) ? data : data.airports || data.results || [];
      box.innerHTML = "";
      list.forEach(function (ap) {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "career-suggest-item";
        btn.textContent =
          (ap.icao || "") +
          " — " +
          (ap.name || "") +
          (ap.city ? " (" + ap.city + ")" : "");
        btn.addEventListener("click", function () {
          hubPick = ap;
          const input = $("#career-hub-icao");
          if (input) input.value = ap.icao || "";
          box.hidden = true;
          if ($("#career-hub-picked"))
            $("#career-hub-picked").textContent =
              "Hub: " + (ap.icao || "") + " · " + (ap.name || "");
        });
        box.appendChild(btn);
      });
      box.hidden = list.length === 0;
    } catch (_) {
      box.hidden = true;
    }
  }

  function openCareerFromHome(viewName) {
    showCareerHub();
    if (viewName === "jobs") {
      showView("jobs");
      refreshJobsBoard();
    } else if (viewName === "hangar") {
      showView("hangar");
      paintHangar();
    } else if (viewName === "setup") {
      showView("setup");
    } else {
      paintHome();
    }
  }

  function wire() {
    $("#btn-launch-career")?.addEventListener("click", function (e) {
      try {
        if (e && e.preventDefault) e.preventDefault();
        showCareerHub();
      } catch (err) {
        console.error("launch-career", err);
      }
    });
    $("#btn-home-career-start")?.addEventListener("click", function () {
      openCareerFromHome("setup");
    });
    $("#btn-home-career-open")?.addEventListener("click", function () {
      openCareerFromHome("home");
    });
    $("#btn-home-career-jobs")?.addEventListener("click", function () {
      openCareerFromHome("jobs");
    });
    $("#btn-home-career-hangar")?.addEventListener("click", function () {
      openCareerFromHome("hangar");
    });
    $("#btn-home-career-resume")?.addEventListener("click", function () {
      hideCareerHub();
      setCareerPanelOpen(true);
      paintPanel();
      startPanelPoll();
      try {
        if (typeof window.enterMode === "function") window.enterMode("journey");
      } catch (_) {}
    });
    $("#btn-career-back-launcher")?.addEventListener("click", function () {
      hideCareerHub();
      if (typeof window.showHub === "function") window.showHub();
      else if (typeof window.showLauncher === "function") window.showLauncher();
      paintHubCareerStrip();
    });
    $("#btn-career-setup")?.addEventListener("click", async function () {
      const name = ($("#career-pilot-name") && $("#career-pilot-name").value) || "";
      const icao =
        (hubPick && hubPick.icao) ||
        (($("#career-hub-icao") && $("#career-hub-icao").value) || "").trim();
      setMsg("career-setup-status", "Creating career…");
      try {
        overview = await api("/api/career/setup", {
          method: "POST",
          body: JSON.stringify({ name: name, hub_icao: icao }),
        });
        setStatus("Career started — C172 hired", "ok");
        paintHome();
      } catch (err) {
        setMsg("career-setup-status", err.message, true);
      }
    });
    $("#career-hub-icao")?.addEventListener("input", function (e) {
      const q = e.target.value || "";
      clearTimeout(suggestTimer);
      suggestTimer = setTimeout(function () {
        searchHub(q);
      }, 200);
    });

    $("#btn-career-jobs")?.addEventListener("click", function () {
      showView("jobs");
      refreshJobsBoard();
    });
    $("#btn-career-jobs-back")?.addEventListener("click", function () {
      showView("home");
      paintHome();
    });
    $("#btn-career-jobs-refresh")?.addEventListener("click", refreshJobsBoard);
    $("#btn-career-hangar")?.addEventListener("click", function () {
      showView("hangar");
      paintHangar();
    });
    $("#btn-career-hangar-back")?.addEventListener("click", function () {
      showView("home");
      paintHome();
    });
    // Airlines WIP — card is disabled / Coming soon
    $("#btn-career-airlines")?.addEventListener("click", function (e) {
      try {
        if (e && e.preventDefault) e.preventDefault();
      } catch (_) {}
      setStatus("Airlines are coming soon", "ok");
    });
    $("#btn-career-airlines-back")?.addEventListener("click", function () {
      showView("home");
      paintHome();
    });
    $("#btn-career-open-map")?.addEventListener("click", function () {
      hideCareerHub();
      if (overview && overview.active) {
        setCareerPanelOpen(true);
        startPanelPoll();
      }
      try {
        if (typeof window.enterMode === "function") window.enterMode("journey");
        else if (typeof window.showHub === "function") window.showHub();
      } catch (_) {}
    });
    $("#btn-career-resume-mission")?.addEventListener("click", function () {
      hideCareerHub();
      setCareerPanelOpen(true);
      paintPanel();
      startPanelPoll();
      try {
        if (typeof window.enterMode === "function") window.enterMode("journey");
      } catch (_) {}
    });
    $("#btn-career-ferry-home")?.addEventListener("click", async function () {
      try {
        overview = await api("/api/career/travel-home", {
          method: "POST",
          body: "{}",
        });
        setStatus(
          "Back at hub" +
            (overview.ferry_fee != null ? " (−" + money(overview.ferry_fee) + ")" : ""),
          "ok"
        );
        paintHome();
        showView("jobs");
        refreshJobsBoard();
      } catch (err) {
        setMsg("career-jobs-status", err.message, true);
      }
    });

    $("#btn-career-open")?.addEventListener("click", function (e) {
      try {
        if (e && e.preventDefault) e.preventDefault();
        if (e && e.stopPropagation) e.stopPropagation();
      } catch (_) {}
      setCareerPanelOpen(true);
      refreshOverview()
        .then(function () {
          startPanelPoll();
        })
        .catch(function () {
          startPanelPoll();
        });
    });
    $("#btn-career-collapse")?.addEventListener("click", function (e) {
      try {
        if (e && e.preventDefault) e.preventDefault();
      } catch (_) {}
      setCareerPanelOpen(false);
      stopPanelPoll();
    });
    $("#btn-cpanel-hub")?.addEventListener("click", function (e) {
      try {
        if (e && e.preventDefault) e.preventDefault();
      } catch (_) {}
      setCareerPanelOpen(false);
      stopPanelPoll();
      showCareerHub();
      showView("home");
      paintHome();
    });
    $("#btn-cpanel-show-plan")?.addEventListener("click", function () {
      showActiveMissionPlan().catch(function (err) {
        console.error("btn-cpanel-show-plan", err);
      });
    });
    $("#btn-cpanel-track")?.addEventListener("click", async function () {
      try {
        // Require a live MSFS / SimConnect link before tracking
        let connected = !!(window.state && window.state.sim && window.state.sim.connected);
        if (!connected) {
          try {
            const st = await fetch("/api/sim/status", { cache: "no-store" }).then(
              function (r) {
                return r.json();
              }
            );
            connected = !!(st && st.connected);
            if (window.state && window.state.sim) {
              window.state.sim.connected = connected;
              window.state.sim.enabled = !!(st && st.enabled);
            }
          } catch (_) {}
        }
        if (!connected) {
          const msg =
            "Not connected to MSFS — click Connect on the map toolbar (aircraft pill), start a flight in the sim, then try Start tracking again.";
          setMsg("cpanel-msg", msg, true);
          setStatus(msg, "err");
          return;
        }
        await api("/api/career/mission/start-track", { method: "POST", body: "{}" });
        overview = await api("/api/career");
        paintPanel();
        setMsg("cpanel-msg", "Tracking started — fly the mission.");
        setStatus("Career mission tracking started", "ok");
      } catch (err) {
        setMsg("cpanel-msg", err.message, true);
        setStatus(err.message || String(err), "err");
      }
    });
    $("#btn-cpanel-dispatch")?.addEventListener("click", async function () {
      const active = overview && overview.active;
      if (!active) return;
      try {
        const res = await api("/api/simbrief/dispatch-url", {
          method: "POST",
          body: JSON.stringify({
            orig: active.dep,
            dest: active.dest,
            typecode: active.aircraft || "C172",
            airline: active.airline || undefined,
            fltnum: active.fltnum || undefined,
          }),
        });
        if (res && res.url) window.open(res.url, "_blank", "noopener");
      } catch (err) {
        setMsg("cpanel-msg", err.message, true);
      }
    });
    $("#btn-cpanel-settle")?.addEventListener("click", async function () {
      const btn = $("#btn-cpanel-settle");
      if (btn) btn.disabled = true;
      setMsg("cpanel-msg", "Settling mission…");
      try {
        const data = await api("/api/career/mission/settle", {
          method: "POST",
          body: "{}",
        });
        overview = data;
        stopPanelPoll();
        try {
          if (typeof window.clearLiveTrackingTrace === "function") {
            window.clearLiveTrackingTrace("career");
          }
        } catch (_) {}
        paintPanel();
        if (data && data.receipt) {
          showReceipt(data.receipt);
        } else {
          setStatus("Mission settled", "ok");
        }
        setMsg("cpanel-msg", "Mission settled — " + money((data.receipt || {}).net));
      } catch (err) {
        setMsg("cpanel-msg", err.message || String(err), true);
        setStatus(err.message || String(err), "err");
      } finally {
        if (btn) btn.disabled = false;
      }
    });
    // No window.confirm — blocked / broken in Edge WebView2
    let _cancelArmed = false;
    let _cancelArmTimer = null;
    $("#btn-cpanel-cancel")?.addEventListener("click", async function () {
      const btn = $("#btn-cpanel-cancel");
      if (!_cancelArmed) {
        _cancelArmed = true;
        if (btn) btn.textContent = "Click again to confirm";
        setMsg("cpanel-msg", "Click Cancel again to discard this mission (no pay).");
        clearTimeout(_cancelArmTimer);
        _cancelArmTimer = setTimeout(function () {
          _cancelArmed = false;
          if (btn) btn.textContent = "Cancel";
        }, 4000);
        return;
      }
      _cancelArmed = false;
      clearTimeout(_cancelArmTimer);
      if (btn) {
        btn.textContent = "Cancel";
        btn.disabled = true;
      }
      setMsg("cpanel-msg", "Cancelling…");
      try {
        overview = await api("/api/career/mission/cancel", {
          method: "POST",
          body: "{}",
        });
        stopPanelPoll();
        try {
          if (typeof window.clearLiveTrackingTrace === "function") {
            window.clearLiveTrackingTrace("career");
          }
        } catch (_) {}
        paintPanel();
        setMsg("cpanel-msg", "Mission cancelled.");
        setStatus("Career mission cancelled", "ok");
      } catch (err) {
        setMsg("cpanel-msg", err.message || String(err), true);
        setStatus(err.message || String(err), "err");
      } finally {
        if (btn) btn.disabled = false;
      }
    });
    function onReceiptClose() {
      hideReceipt();
      showCareerHub();
      showView("home");
      paintHome();
    }
    $("#btn-career-receipt-close")?.addEventListener("click", onReceiptClose);
    $("#btn-career-receipt-done")?.addEventListener("click", onReceiptClose);
    $("#career-receipt-backdrop")?.addEventListener("click", onReceiptClose);
    $("#btn-career-receipt-trace")?.addEventListener("click", function () {
      showReceiptFlownTrace().catch(function (err) {
        console.error("showReceiptFlownTrace", err);
      });
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () {
      wire();
      refreshOverview().catch(function () {});
    });
  } else {
    wire();
    refreshOverview().catch(function () {});
  }
})();
