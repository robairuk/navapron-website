/**
 * NavApron procedure charts panel —
 * own interactive SID/STAR strip (map + fixes) + FAA d-TPP (US) + AIP / ChartFox.
 */
(function () {
  "use strict";

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  const state = {
    open: false,
    icao: null,
    type: "DP",
    plates: [],
    active: null,
    coverage: null,
    external: null,
    status: null,
    loading: false,
    navapron: null,
    chartfox: null,
    drawMode: false,
  };

  let _drawCtx = null;
  let _drawStroke = false;
  let _drawResizeObs = null;
  let _drawBound = false;

  function _drawCanvas() {
    return $("#plate-draw-canvas");
  }

  function _drawStage() {
    return $("#plate-viewer-stage");
  }

  function resizePlateDrawCanvas() {
    const canvas = _drawCanvas();
    const stage = _drawStage();
    if (!canvas || !stage) return;
    const rect = stage.getBoundingClientRect();
    const w = Math.max(1, Math.round(rect.width));
    const h = Math.max(1, Math.round(rect.height));
    if (canvas.width === w && canvas.height === h && _drawCtx) return;
    // Preserve existing ink when the dock is resized
    let snapshot = null;
    if (_drawCtx && canvas.width > 0 && canvas.height > 0) {
      try {
        snapshot = canvas.toDataURL();
      } catch (_) {}
    }
    canvas.width = w;
    canvas.height = h;
    _drawCtx = canvas.getContext("2d");
    if (_drawCtx) {
      _drawCtx.lineCap = "round";
      _drawCtx.lineJoin = "round";
      _drawCtx.strokeStyle = "rgba(250, 204, 21, 0.95)";
      _drawCtx.lineWidth = 3;
    }
    if (snapshot && _drawCtx) {
      const img = new Image();
      img.onload = () => {
        try {
          _drawCtx.drawImage(img, 0, 0, w, h);
        } catch (_) {}
      };
      img.src = snapshot;
    }
  }

  function clearPlateDrawing() {
    const canvas = _drawCanvas();
    if (!canvas) return;
    if (!_drawCtx) resizePlateDrawCanvas();
    if (_drawCtx) _drawCtx.clearRect(0, 0, canvas.width, canvas.height);
  }

  function setPlateDrawMode(on) {
    state.drawMode = !!on;
    const stage = _drawStage();
    const btn = $("#btn-plate-draw");
    if (stage) stage.classList.toggle("is-drawing", state.drawMode);
    if (btn) {
      btn.classList.toggle("active", state.drawMode);
      btn.setAttribute("aria-pressed", state.drawMode ? "true" : "false");
      btn.textContent = state.drawMode ? "Drawing…" : "Draw";
    }
    if (state.drawMode) {
      resizePlateDrawCanvas();
      if (typeof window.setStatus === "function") {
        window.setStatus("Draw on the chart — click Draw again when done", "busy");
      }
    } else if (typeof window.setStatus === "function") {
      window.setStatus("Chart drawing off — PDF scroll/zoom available", "ok");
    }
  }

  function _drawPos(ev, canvas) {
    const rect = canvas.getBoundingClientRect();
    const src = ev.touches && ev.touches[0] ? ev.touches[0] : ev;
    return {
      x: ((src.clientX - rect.left) / Math.max(1, rect.width)) * canvas.width,
      y: ((src.clientY - rect.top) / Math.max(1, rect.height)) * canvas.height,
    };
  }

  function bindPlateDrawing() {
    if (_drawBound) return;
    const canvas = _drawCanvas();
    if (!canvas) return;
    _drawBound = true;
    resizePlateDrawCanvas();

    const start = (ev) => {
      if (!state.drawMode) return;
      resizePlateDrawCanvas();
      if (!_drawCtx) return;
      _drawStroke = true;
      const p = _drawPos(ev, canvas);
      _drawCtx.beginPath();
      _drawCtx.moveTo(p.x, p.y);
      try {
        canvas.setPointerCapture(ev.pointerId);
      } catch (_) {}
      ev.preventDefault();
    };
    const move = (ev) => {
      if (!_drawStroke || !state.drawMode || !_drawCtx) return;
      const p = _drawPos(ev, canvas);
      _drawCtx.lineTo(p.x, p.y);
      _drawCtx.stroke();
      _drawCtx.beginPath();
      _drawCtx.moveTo(p.x, p.y);
      ev.preventDefault();
    };
    const end = (ev) => {
      if (!_drawStroke) return;
      _drawStroke = false;
      try {
        if (ev && ev.pointerId != null) canvas.releasePointerCapture(ev.pointerId);
      } catch (_) {}
    };

    canvas.addEventListener("pointerdown", start);
    canvas.addEventListener("pointermove", move);
    canvas.addEventListener("pointerup", end);
    canvas.addEventListener("pointercancel", end);
    canvas.addEventListener("pointerleave", end);

    $("#btn-plate-draw")?.addEventListener("click", () => {
      setPlateDrawMode(!state.drawMode);
    });
    $("#btn-plate-draw-clear")?.addEventListener("click", () => {
      clearPlateDrawing();
      if (typeof window.setStatus === "function") {
        window.setStatus("Chart notes cleared", "ok");
      }
    });

    const stage = _drawStage();
    if (stage && typeof ResizeObserver !== "undefined") {
      _drawResizeObs = new ResizeObserver(() => resizePlateDrawCanvas());
      _drawResizeObs.observe(stage);
    } else {
      window.addEventListener("resize", resizePlateDrawCanvas);
    }
  }

  async function apiPost(path, body) {
    const url =
      typeof window.apiUrl === "function" ? window.apiUrl(path) : path;
    const res = await fetch(url, {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {}),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(text || res.statusText || "Request failed");
    }
    return res.json();
  }

  async function refreshChartfoxStatus() {
    try {
      state.chartfox = await apiGet("/api/plates/chartfox/status");
    } catch (_) {
      state.chartfox = { ok: false, configured: false, linked: false };
    }
    return state.chartfox;
  }

  async function loadChartfoxCharts(icaoU) {
    try {
      const typeQ = state.type ? `?type=${encodeURIComponent(state.type)}` : "";
      const data = await apiGet(
        `/api/plates/${encodeURIComponent(icaoU)}/chartfox${typeQ}`
      );
      if (data && data.ok && (data.charts || []).length) {
        // Merge ChartFox charts into the plate list (Europe primary source)
        const mapped = (data.charts || []).map((c) => ({
          name: c.name,
          type: c.type || "OTHER",
          pdf_name: c.id,
          pdf_url: c.pdf_url,
          source_url: data.airport_page || `https://chartfox.org/${icaoU}`,
          source: "ChartFox",
          id: c.id,
        }));
        state.plates = mapped;
        state.coverage = state.coverage === "faa" ? "faa" : "chartfox";
        return mapped;
      }
      if (data && data.status) state.chartfox = data.status;
      return [];
    } catch (err) {
      console.warn("plates.chartfox", err);
      return [];
    }
  }

  let _cfLinkPollTimer = null;
  let _cfLinkFocusHandler = null;

  function _clearChartfoxLinkWait() {
    if (_cfLinkPollTimer) {
      clearInterval(_cfLinkPollTimer);
      _cfLinkPollTimer = null;
    }
    if (_cfLinkFocusHandler) {
      window.removeEventListener("focus", _cfLinkFocusHandler);
      document.removeEventListener("visibilitychange", _cfLinkFocusHandler);
      _cfLinkFocusHandler = null;
    }
  }

  async function _onChartfoxLinked() {
    _clearChartfoxLinkWait();
    await refreshChartfoxStatus();
    if (typeof window.setStatus === "function") {
      window.setStatus("ChartFox account linked", "ok");
    }
    const statusEl = $("#plate-status-msg");
    if (statusEl) {
      statusEl.textContent = "ChartFox account linked — Europe charts ready";
    }
    if (state.icao) {
      try {
        await loadAirport(state.icao, { type: state.type, keepActive: true });
      } catch (_) {
        paint();
      }
    } else {
      paint();
    }
  }

  function _waitForChartfoxLink({ timeoutMs = 180000 } = {}) {
    _clearChartfoxLinkWait();
    const started = Date.now();
    const tick = async () => {
      try {
        const st = await refreshChartfoxStatus();
        if (st && st.linked) {
          await _onChartfoxLinked();
          return true;
        }
      } catch (_) {}
      if (Date.now() - started >= timeoutMs) {
        _clearChartfoxLinkWait();
        if (typeof window.setStatus === "function") {
          window.setStatus(
            "Still waiting for ChartFox — finish login in the browser, then open Charts again",
            "busy"
          );
        }
        paint();
        return false;
      }
      return false;
    };
    _cfLinkFocusHandler = () => {
      tick();
    };
    window.addEventListener("focus", _cfLinkFocusHandler);
    document.addEventListener("visibilitychange", _cfLinkFocusHandler);
    _cfLinkPollTimer = setInterval(tick, 2000);
    tick();
  }

  async function linkChartfox() {
    try {
      const start = await apiGet("/api/plates/chartfox/auth/start");
      if (!start.ok || !start.authorize_url) {
        throw new Error(start.error || "Could not start ChartFox login");
      }
      window.open(start.authorize_url, "_blank", "noopener");
      if (typeof window.setStatus === "function") {
        window.setStatus(
          "Sign in to ChartFox in the browser — NavApron will confirm when linked",
          "busy"
        );
      }
      const statusEl = $("#plate-status-msg");
      if (statusEl) {
        statusEl.textContent = "Waiting for ChartFox login…";
      }
      _waitForChartfoxLink();
    } catch (err) {
      console.warn("chartfox link", err);
      _clearChartfoxLinkWait();
      if (typeof window.setStatus === "function") {
        window.setStatus(
          err && err.message ? err.message : "ChartFox link failed",
          "err"
        );
      }
    }
  }

  function constraintChips(p) {
    const out = { alt: null, speed: null };
    if (!p) return out;
    const minA = p.alt_min_ft != null ? Number(p.alt_min_ft) : null;
    const maxA = p.alt_max_ft != null ? Number(p.alt_max_ft) : null;
    const atA = p.alt_ft != null ? Number(p.alt_ft) : null;
    const fmtAlt = (ft) => {
      if (!Number.isFinite(ft)) return "";
      if (ft >= 1000 && ft % 100 === 0) {
        return "FL" + String(Math.round(ft / 100)).padStart(2, "0");
      }
      return Math.round(ft) + " ft";
    };
    if (
      minA != null &&
      maxA != null &&
      Number.isFinite(minA) &&
      Number.isFinite(maxA)
    ) {
      out.alt = minA === maxA ? fmtAlt(minA) : fmtAlt(minA) + " – " + fmtAlt(maxA);
    } else if (minA != null && Number.isFinite(minA)) {
      out.alt = "↑ " + fmtAlt(minA);
    } else if (maxA != null && Number.isFinite(maxA)) {
      out.alt = "↓ " + fmtAlt(maxA);
    } else if (atA != null && Number.isFinite(atA)) {
      out.alt = "A " + fmtAlt(atA);
    }
    const minS = p.speed_min_kt != null ? Number(p.speed_min_kt) : null;
    const maxS = p.speed_max_kt != null ? Number(p.speed_max_kt) : null;
    const atS = p.speed_kt != null ? Number(p.speed_kt) : null;
    if (
      minS != null &&
      maxS != null &&
      Number.isFinite(minS) &&
      Number.isFinite(maxS)
    ) {
      out.speed = Math.round(minS) + "–" + Math.round(maxS) + " kt";
    } else if (maxS != null && Number.isFinite(maxS)) {
      out.speed = "max " + Math.round(maxS) + " kt";
    } else if (minS != null && Number.isFinite(minS)) {
      out.speed = "min " + Math.round(minS) + " kt";
    } else if (atS != null && Number.isFinite(atS)) {
      out.speed = Math.round(atS) + " kt";
    }
    return out;
  }

  function procedureKindForType(type) {
    const t = String(type || "").toUpperCase();
    if (t === "STAR" || t === "IAP") return "star";
    return "sid";
  }

  function resolveNavapronProcedure() {
    const kind = procedureKindForType(state.type);
    let data = null;
    if (typeof window.getActiveProcedure === "function") {
      data = window.getActiveProcedure(state.icao, kind);
    } else {
      const st = window.state || {};
      data = kind === "star" ? st.activeArrival : st.activeDeparture;
      if (data && state.icao && data.airport_icao) {
        if (String(data.airport_icao).toUpperCase() !== String(state.icao).toUpperCase()) {
          data = null;
        }
      }
    }
    if (!data || !(data.points || []).length) {
      state.navapron = null;
      return null;
    }
    state.navapron = data;
    return data;
  }

  function paintNavapron() {
    const box = $("#plate-navapron");
    if (!box) return;
    const data = resolveNavapronProcedure();
    if (!data) {
      box.classList.add("hidden");
      box.innerHTML = "";
      return;
    }
    const kind = procedureKindForType(state.type);
    const isStar = kind === "star";
    const name =
      (isStar ? data.star_name || data.star_id : data.sid_name || data.sid_id) ||
      "Procedure";
    const rwy = data.runway ? "RWY " + data.runway : "";
    const typ = data.type || (isStar ? "STAR" : "SID");
    const srcRaw = String(data.source || data.description || "").toLowerCase();
    let sourceLabel = "Catalog";
    if (srcRaw.indexOf("simbrief") >= 0) sourceLabel = "SimBrief";
    else if (data.description && /simbrief/i.test(data.description)) sourceLabel = "SimBrief";
    const nm =
      data.distance_nm != null ? data.distance_nm + " NM" : "";
    const missing = data.missing_fixes || [];
    const points = data.points || [];

    const rows = points
      .map((p, idx) => {
        const chips = constraintChips(p);
        const chipHtml = [];
        if (chips.alt) {
          chipHtml.push(
            `<span class="proc-chip proc-chip-alt">${escapeHtml(chips.alt)}</span>`
          );
        }
        if (chips.speed) {
          chipHtml.push(
            `<span class="proc-chip proc-chip-spd">${escapeHtml(chips.speed)}</span>`
          );
        }
        if (p.note) {
          chipHtml.push(
            `<span class="plate-nav-note">${escapeHtml(p.note)}</span>`
          );
        }
        const muted =
          p.kind === "climb" || p.kind === "runway" || p.kind === "final"
            ? " plate-nav-fix-muted"
            : "";
        const lat = p.lat != null ? Number(p.lat) : null;
        const lon = p.lon != null ? Number(p.lon) : null;
        const canFocus = Number.isFinite(lat) && Number.isFinite(lon);
        return (
          `<button type="button" class="plate-nav-fix${muted}" data-idx="${idx}"` +
          (canFocus
            ? ` data-lat="${lat}" data-lon="${lon}"`
            : ` disabled title="No coordinates"`) +
          `>` +
          `<span class="plate-nav-idx">${idx + 1}</span>` +
          `<span class="plate-nav-ident">${escapeHtml(p.ident || "—")}</span>` +
          `<span class="plate-nav-chips">${chipHtml.join("")}</span>` +
          `</button>`
        );
      })
      .join("");

    const missingHtml = missing.length
      ? `<p class="plate-nav-missing">Unresolved: ${escapeHtml(missing.join(", "))}</p>`
      : "";

    box.classList.remove("hidden");
    box.innerHTML =
      `<div class="plate-nav-head">` +
      `<div class="plate-nav-title-row">` +
      `<strong class="plate-nav-title">${escapeHtml(name)}</strong>` +
      `<span class="plate-nav-badge">${escapeHtml(sourceLabel)}</span>` +
      `</div>` +
      `<p class="plate-nav-meta">${escapeHtml(
        [state.icao || "", typ, rwy, nm].filter(Boolean).join(" · ")
      )}</p>` +
      (data.description
        ? `<p class="plate-nav-desc">${escapeHtml(data.description)}</p>`
        : "") +
      `<div class="plate-nav-actions">` +
      `<button type="button" class="btn btn-primary btn-tiny" id="btn-plate-fit-proc">Fit procedure</button>` +
      `</div>` +
      `</div>` +
      `<div class="plate-nav-list" role="list">${rows}</div>` +
      missingHtml;

    $("#btn-plate-fit-proc")?.addEventListener("click", () => {
      if (typeof window.fitActiveProcedure === "function") {
        window.fitActiveProcedure(kind);
      }
    });
    box.querySelectorAll(".plate-nav-fix[data-lat]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const lat = Number(btn.getAttribute("data-lat"));
        const lon = Number(btn.getAttribute("data-lon"));
        if (typeof window.focusProcedureFix === "function") {
          window.focusProcedureFix(lat, lon, { zoom: 12 });
        }
        box.querySelectorAll(".plate-nav-fix.active").forEach((el) => {
          el.classList.remove("active");
        });
        btn.classList.add("active");
      });
    });
  }

  function refreshNavapron() {
    if (!state.open) return;
    paintNavapron();
    // Keep empty / viewer messaging in sync when procedure appears
    const empty = $("#plate-empty");
    const data = state.navapron;
    if (data && empty && !state.active) {
      empty.classList.remove("hidden");
      empty.textContent =
        "NavApron chart is on the map. Use the fix list above, or Fit procedure.";
    }
  }

  function _currentMapIcao(preferredRole) {
    const role = String(preferredRole || "").toLowerCase();
    const dep =
      ($("#fp-dep") && $("#fp-dep").value) ||
      (window.state && window.state.airport && window.state.airport.icao) ||
      (window.state &&
        window.state.depChart &&
        window.state.depChart.airport &&
        window.state.depChart.airport.icao) ||
      "";
    const dest =
      ($("#fp-dest") && $("#fp-dest").value) ||
      (window.state && window.state.destAirport && window.state.destAirport.icao) ||
      (window.state &&
        window.state.destChart &&
        window.state.destChart.airport &&
        window.state.destChart.airport.icao) ||
      "";
    if (role === "dest") return String(dest || dep || "").trim().toUpperCase();
    if (role === "dep") return String(dep || "").trim().toUpperCase();
    return String(dep || dest || "").trim().toUpperCase();
  }

  /**
   * Map/taxi airport finished loading — if Charts is open, reload that ICAO
   * so the panel stays in sync with the map.
   */
  let _airportSyncTimer = null;
  function onAirportLoaded(icao, opts) {
    if (!state.open) return;
    const icaoU = String(icao || "").trim().toUpperCase();
    if (!icaoU) return;
    const role = (opts && opts.role) || "";
    let type = state.type || "DP";
    if (role === "dest" && (type === "DP" || type === "ODP")) type = "STAR";
    else if (role === "dep" && type === "STAR") type = "DP";
    if (_airportSyncTimer) clearTimeout(_airportSyncTimer);
    _airportSyncTimer = setTimeout(() => {
      _airportSyncTimer = null;
      if (!state.open) return;
      const same = state.icao === icaoU;
      loadAirport(icaoU, {
        type,
        keepActive: same,
        preferName: opts && opts.preferName,
        autoSelect: !(opts && opts.autoSelect === false) && !same,
      });
    }, 120);
  }

  function apiBase() {
    try {
      if (typeof window.apiUrl === "function") return "";
    } catch (_) {}
    return "";
  }

  async function apiGet(path) {
    const url =
      typeof window.apiUrl === "function" ? window.apiUrl(path) : path;
    const res = await fetch(url, { credentials: "same-origin" });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(text || res.statusText || "Request failed");
    }
    return res.json();
  }

  function invalidateMap() {
    try {
      const fix = () => {
        if (typeof window.fixMapSize === "function") window.fixMapSize();
        else if (window.map && typeof window.map.invalidateSize === "function") {
          window.map.invalidateSize(true);
        }
      };
      fix();
      setTimeout(fix, 80);
      setTimeout(fix, 260);
    } catch (_) {}
  }

  function setOpen(open, opts) {
    const quiet = !!(opts && opts.quiet);
    state.open = !!open;
    const panel = $("#plate-panel");
    const app = $("#app");
    if (panel) panel.classList.toggle("hidden", !state.open);
    if (app) app.classList.toggle("plates-open", state.open);
    const tab = $("#btn-plates-open-tab");
    if (tab) {
      tab.classList.toggle("hidden", state.open);
      tab.setAttribute("aria-expanded", state.open ? "true" : "false");
    }
    if (state.open) {
      // Charts takes the single right-dock slot (pushes map like Airline)
      try {
        if (typeof window.setAirlineCollapsed === "function") {
          window.setAirlineCollapsed(true, { persist: true, quiet: true });
        } else if (app) {
          app.classList.add("airline-collapsed");
        }
      } catch (_) {}
      try {
        if (typeof window.setCareerPanelOpen === "function") {
          window.setCareerPanelOpen(false, { quiet: true });
        }
      } catch (_) {}
    }
    invalidateMap();
    if (!quiet && state.open) {
      /* status set by callers when useful */
    }
  }

  function openPanel(opts) {
    opts = opts || {};
    setOpen(true);
    loadPlateCatalogHeight();
    const icao =
      (opts.icao && String(opts.icao).trim().toUpperCase()) ||
      _currentMapIcao(opts.role) ||
      state.icao ||
      "";
    if (icao) {
      loadAirport(icao, {
        type: opts.type || state.type,
        preferName: opts.preferName,
        autoSelect: opts.autoSelect !== false,
      });
    } else {
      paint();
    }
  }

  function closePanel(opts) {
    setOpen(false, opts);
  }

  function setType(type) {
    state.type = type || "DP";
    $$(".plate-type-btn").forEach((btn) => {
      btn.classList.toggle("active", btn.getAttribute("data-plate-type") === state.type);
    });
    if (state.icao) loadAirport(state.icao, { type: state.type, keepActive: true });
  }

  function cycleBadge(st) {
    if (!st || !st.cycle) return "FAA index…";
    const from = st.from_edate ? String(st.from_edate).replace(/^0901Z\s*/, "") : "";
    const to = st.to_edate ? String(st.to_edate).replace(/^0901Z\s*/, "") : "";
    return from && to ? `FAA ${st.cycle} · ${from}–${to}` : `FAA cycle ${st.cycle}`;
  }

  function paint() {
    const icaoEl = $("#plate-icao");
    const cycleEl = $("#plate-cycle");
    const listEl = $("#plate-list");
    const titleEl = $("#plate-active-title");
    const frame = $("#plate-frame");
    const empty = $("#plate-empty");
    const extBox = $("#plate-external");
    const statusEl = $("#plate-status-msg");

    if (icaoEl) icaoEl.textContent = state.icao || "—";
    if (cycleEl) cycleEl.textContent = cycleBadge(state.status);

    // Resolve active SID/STAR before status / AIP copy depends on it
    paintNavapron();

    if (statusEl) {
      if (state.loading) statusEl.textContent = "Loading charts…";
      else if (state.status && state.status.error && !(state.plates || []).length && state.coverage === "faa")
        statusEl.textContent = "Index error: " + state.status.error;
      else if (state.coverage === "chartfox") {
        statusEl.textContent = `${(state.plates || []).length} ChartFox chart(s)`;
      } else if (state.coverage === "europe") {
        const country = (state.external && state.external.country) || "Europe";
        const looking = ((state.external && state.external.looking_for) || []).join(" · ");
        const hasNav = !!(state.navapron && (state.navapron.points || []).length);
        const cf = state.chartfox;
        if ((state.plates || []).length) {
          statusEl.textContent = `${state.plates.length} ChartFox chart(s) · ${country}`;
        } else if (hasNav) {
          statusEl.textContent = looking
            ? `NavApron ${country} procedure · plan: ${looking}`
            : `NavApron ${country} procedure on the map`;
        } else if (cf && cf.configured && !cf.linked) {
          statusEl.textContent = `${country} — link ChartFox to load SID/STAR PDFs in-panel`;
        } else if (cf && cf.linked) {
          statusEl.textContent = looking
            ? `ChartFox linked · ${country} — loading charts for ${looking}`
            : `ChartFox account linked · ${country}`;
        } else {
          statusEl.textContent = looking
            ? `${country} — Show SID/STAR or SimBrief for ${looking}`
            : `${country} — Show SID/STAR, SimBrief, or link ChartFox for PDFs`;
        }
      } else if (state.coverage === "external")
        statusEl.textContent = state.navapron
          ? "NavApron procedure on the map · official AIP below"
          : "Show SID/STAR / SimBrief / ChartFox for charts · AIP links below";
      else if (state.coverage === "none")
        statusEl.textContent = "No FAA charts for this airport.";
      else if ((state.plates || []).length)
        statusEl.textContent = `${state.plates.length} chart(s)`;
      else statusEl.textContent = state.icao ? "Pick a type or airport." : "Select an airport.";
    }

    if (listEl) {
      listEl.innerHTML = "";
      (state.plates || []).forEach((p) => {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className =
          "plate-list-item" +
          (state.active && state.active.pdf_name === p.pdf_name ? " active" : "");
        const score =
          p.score != null && p.score >= 0.4
            ? `<span class="plate-score">${Math.round(p.score * 100)}%</span>`
            : "";
        btn.innerHTML = `<span class="plate-list-type">${escapeHtml(
          p.type || ""
        )}</span><span class="plate-list-name">${escapeHtml(
          p.name || ""
        )}</span>${score}`;
        btn.title = p.name || "";
        btn.addEventListener("click", () => showPlate(p));
        listEl.appendChild(btn);
      });
    }

    if (extBox) {
      const ext = state.external;
      if (
        (state.coverage === "external" ||
          state.coverage === "europe" ||
          state.coverage === "chartfox") &&
        (ext || state.chartfox)
      ) {
        extBox.classList.remove("hidden");
        const hasNav = !!(state.navapron && (state.navapron.points || []).length);
        const hasCfPlates = state.coverage === "chartfox" && (state.plates || []).length;
        const cf = state.chartfox || {};
        const cfUrl =
          (ext && ext.chartfox_url) ||
          (state.icao ? `https://chartfox.org/${state.icao}` : "https://chartfox.org/");
        let cfActions = "";
        if (cf.linked) {
          cfActions =
            `<div class="plate-cf-linked" role="status" aria-live="polite">` +
            `<div class="plate-ext-row">` +
            `<span class="plate-nav-badge plate-nav-badge-ok">ChartFox linked</span>` +
            `<button type="button" class="btn btn-ghost btn-tiny" id="btn-plate-cf-logout">Unlink</button>` +
            `<a class="btn btn-secondary btn-tiny" href="${escapeAttr(
              cfUrl
            )}" target="_blank" rel="noopener">Open ChartFox site</a>` +
            `</div>` +
            `<p class="hint-text plate-cf-linked-msg">Your ChartFox account is linked. Europe SID/STAR charts can load in this panel.</p>` +
            `</div>`;
        } else if (cf.configured) {
          cfActions =
            `<div class="plate-ext-row">` +
            `<button type="button" class="btn btn-primary btn-tiny" id="btn-plate-cf-link">Link ChartFox account</button>` +
            `<a class="btn btn-secondary btn-tiny" href="${escapeAttr(
              cfUrl
            )}" target="_blank" rel="noopener">Open ChartFox</a>` +
            `</div>` +
            `<p class="hint-text">Link once with your ChartFox login. NavApron will confirm here when it succeeds.</p>`;
        } else {
          cfActions =
            `<div class="plate-ext-row">` +
            `<a class="btn btn-primary btn-tiny" href="${escapeAttr(
              cfUrl
            )}" target="_blank" rel="noopener">Open ChartFox charts</a>` +
            `</div>` +
            `<p class="hint-text">When your ChartFox API client id arrives, save it as ` +
            `<code>data/chartfox_client_id.txt</code> then Link account for in-panel charts.</p>`;
        }
        const linkRows = ((ext && ext.links) || [])
          .filter((lnk) => lnk.id !== "chartfox")
          .map((lnk) => {
            const cls =
              lnk.primary && !hasNav && !hasCfPlates
                ? "btn btn-primary btn-tiny"
                : "btn btn-secondary btn-tiny";
            const note = lnk.note
              ? `<span class="plate-link-note">${escapeHtml(lnk.note)}</span>`
              : "";
            return `<div class="plate-ext-row"><a class="${cls}" href="${escapeAttr(
              lnk.url
            )}" target="_blank" rel="noopener">${escapeHtml(
              lnk.title || lnk.provider
            )}</a>${note}</div>`;
          });
        const looking = ((ext && ext.looking_for) || []).filter(Boolean);
        const lookingHtml = looking.length
          ? `<p class="plate-looking"><strong>From your plan:</strong> ${escapeHtml(
              looking.join(" · ")
            )}</p>`
          : "";
        const embedBtn =
          ext && ext.embed_url
            ? `<button type="button" class="btn btn-ghost btn-tiny" id="btn-plate-embed-aip">Show AIP in panel</button>`
            : "";
        const openDetails = !(hasNav || hasCfPlates);
        extBox.innerHTML =
          `<div class="plate-cf-box">${cfActions}</div>` +
          `<details class="plate-ext-details"${openDetails ? " open" : ""}>` +
          `<summary class="plate-ext-summary">Official AIP reference</summary>` +
          lookingHtml +
          `<p class="hint-text">${escapeHtml(
            hasCfPlates
              ? "ChartFox lists official national AIP charts. Pick one above to view in-panel."
              : hasNav
                ? "Authority documents stay on the national AIS. NavApron draws its own procedure chart from plan / catalog facts."
                : (ext && (ext.hint || ext.message)) || ""
          )}</p>` +
          `<div class="plate-ext-actions">${linkRows.join("")}${embedBtn}</div>` +
          `<p class="hint-text plate-ext-legal">${escapeHtml(
            (ext && ext.message) || ""
          )}</p>` +
          `</details>`;
        $("#btn-plate-embed-aip")?.addEventListener("click", () => {
          embedExternal(ext.embed_url, ext.country || ext.icao || "AIP charts");
        });
        $("#btn-plate-cf-link")?.addEventListener("click", () => {
          linkChartfox();
        });
        $("#btn-plate-cf-logout")?.addEventListener("click", async () => {
          try {
            _clearChartfoxLinkWait();
            await apiPost("/api/plates/chartfox/auth/logout", {});
            await refreshChartfoxStatus();
            if (typeof window.setStatus === "function") {
              window.setStatus("ChartFox account unlinked", "ok");
            }
            if (state.icao) loadAirport(state.icao, { type: state.type, keepActive: true });
            else paint();
          } catch (err) {
            console.warn("chartfox logout", err);
            if (typeof window.setStatus === "function") {
              window.setStatus(
                err && err.message ? err.message : "Could not unlink ChartFox",
                "err"
              );
            }
          }
        });
      } else {
        extBox.classList.add("hidden");
        extBox.innerHTML = "";
      }
    }

    if (state.active && (state.active.pdf_url || state.active.embed_url)) {
      const src = state.active.pdf_url || state.active.embed_url;
      if (titleEl) titleEl.textContent = state.active.name || "Chart";
      if (frame) {
        frame.classList.remove("hidden");
        if (frame.getAttribute("data-src") !== src) {
          frame.setAttribute("data-src", src);
          frame.src = src;
        }
      }
      if (empty) empty.classList.add("hidden");
      const openBtn = $("#btn-plate-open-browser");
      if (openBtn) {
        openBtn.href = state.active.source_url || state.active.embed_url || src;
        openBtn.classList.remove("hidden");
      }
    } else if (
      state.coverage === "europe" ||
      state.coverage === "external" ||
      state.coverage === "chartfox"
    ) {
      const hasNav = !!(state.navapron && (state.navapron.points || []).length);
      const hasCf = state.coverage === "chartfox" && (state.plates || []).length;
      if (titleEl) {
        titleEl.textContent = hasCf
          ? "Pick a ChartFox chart"
          : hasNav
            ? "NavApron procedure (map)"
            : "Europe charts";
      }
      if (frame) {
        frame.classList.add("hidden");
        frame.removeAttribute("data-src");
        frame.src = "about:blank";
      }
      if (empty) {
        empty.classList.remove("hidden");
        if (hasCf) {
          empty.textContent =
            "Select a SID, STAR, approach, or ground chart from the ChartFox list above.";
        } else if (hasNav) {
          empty.textContent =
            "Procedure track is on the map with altitude / speed chips. Use the fix list above or Fit procedure. Link ChartFox for official PDF charts.";
        } else {
          empty.textContent =
            "Link ChartFox for in-panel Europe SID/STAR charts, or Show SID / import SimBrief for a NavApron chart. Official AIP links stay below.";
        }
      }
      const openBtn = $("#btn-plate-open-browser");
      if (openBtn) {
        const ext = state.external;
        const cfUrl =
          (ext && ext.chartfox_url) ||
          (state.icao ? `https://chartfox.org/${state.icao}` : "");
        if (cfUrl) {
          openBtn.href = cfUrl;
          openBtn.textContent = "Open ChartFox";
          openBtn.classList.remove("hidden");
        } else if (ext && ext.embed_url) {
          openBtn.href = ext.embed_url;
          openBtn.textContent = "Open AIP";
          openBtn.classList.remove("hidden");
        } else {
          openBtn.classList.add("hidden");
        }
      }
    } else {
      if (titleEl) titleEl.textContent = "No chart selected";
      if (frame) {
        frame.classList.add("hidden");
        frame.removeAttribute("data-src");
        frame.src = "about:blank";
      }
      if (empty) {
        empty.classList.remove("hidden");
        empty.textContent =
          "Pick a SID, STAR, approach, or airport diagram. US airports use official FAA charts. " +
          "Europe opens the national AIP / AIP.aero chart set.";
      }
      const openBtn = $("#btn-plate-open-browser");
      if (openBtn) openBtn.classList.add("hidden");
    }
  }

  function embedExternal(url, title) {
    if (!url) return;
    state.active = {
      name: title || "AIP charts",
      embed_url: url,
      source_url: url,
      type: "AIP",
    };
    paint();
  }

  function escapeHtml(s) {
    return String(s || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function escapeAttr(s) {
    return escapeHtml(s).replace(/'/g, "&#39;");
  }

  async function loadAirport(icao, opts) {
    opts = opts || {};
    const icaoU = String(icao || "")
      .trim()
      .toUpperCase();
    if (!icaoU) return;
    state.icao = icaoU;
    if (opts.type) state.type = opts.type;
    state.loading = true;
    state.plates = [];
    state.external = null;
    state.coverage = null;
    if (!opts.keepActive) state.active = null;
    paint();

    try {
      const typeQ = state.type ? `&type=${encodeURIComponent(state.type)}` : "";
      const data = await apiGet(`/api/plates/${encodeURIComponent(icaoU)}?${typeQ}`);
      state.status = data.status || state.status;
      state.coverage = data.coverage || (data.plates && data.plates.length ? "faa" : "none");
      state.external = data.external || null;
      state.plates = data.plates || [];

      // Europe / non-FAA: pull ChartFox chart list when the account is linked
      if (state.coverage === "europe" || state.coverage === "external" || state.coverage === "none") {
        await refreshChartfoxStatus();
        if (state.chartfox && state.chartfox.linked) {
          await loadChartfoxCharts(icaoU);
        }
      }

      if (opts.preferName && state.plates.length) {
        const prefer = String(opts.preferName);
        let best = null;
        let bestScore = -1;
        state.plates.forEach((p) => {
          const sc =
            typeof p.score === "number"
              ? p.score
              : fuzzyScore(prefer, p.name || "", p.faanfd18 || "");
          if (sc > bestScore) {
            bestScore = sc;
            best = p;
          }
        });
        if (best && bestScore >= 0.4 && opts.autoSelect !== false) {
          showPlate(best);
          return;
        }
      } else if (
        opts.autoSelect !== false &&
        state.plates.length === 1 &&
        state.coverage === "faa"
      ) {
        showPlate(state.plates[0]);
        return;
      }
    } catch (err) {
      console.warn("plates.loadAirport", err);
      state.coverage = "none";
    } finally {
      state.loading = false;
      paint();
    }
  }

  function fuzzyScore(query, name, nfd) {
    const q = norm(query);
    const n = norm(name);
    const f = norm(nfd);
    if (!q) return 0;
    if (q === n || (f && q === f)) return 1;
    if (n.indexOf(q) >= 0 || q.indexOf(n) >= 0) return 0.9;
    return 0;
  }

  function norm(s) {
    return String(s || "")
      .toUpperCase()
      .replace(/\(.*?\)/g, " ")
      .replace(/[^A-Z0-9]+/g, "");
  }

  function showPlate(plate) {
    const prevId =
      state.active && (state.active.id || state.active.pdf_url || state.active.embed_url);
    const nextId = plate && (plate.id || plate.pdf_url || plate.embed_url);
    state.active = plate;
    // New chart → clear notes so ink doesn't sit on the wrong PDF
    if (prevId !== nextId) {
      clearPlateDrawing();
      if (state.drawMode) setPlateDrawMode(false);
    }
    paint();
    resizePlateDrawCanvas();
  }

  async function matchAndOpen(opts) {
    opts = opts || {};
    const dep = (opts.depIcao || "").toUpperCase();
    const dest = (opts.destIcao || "").toUpperCase();
    const sid = opts.sid || "";
    const star = opts.star || "";

    openPanel({});

    // Prefer departure SID first when present
    if (dep && sid) {
      try {
        const m = await apiGet(
          `/api/plates/${encodeURIComponent(dep)}/match?sid=${encodeURIComponent(sid)}`
        );
        state.status = m.status || state.status;
        if (m.coverage === "europe" || m.coverage === "external") {
          state.icao = dep;
          state.coverage = m.coverage;
          state.external = m.external;
          state.plates = [];
          state.active = null;
          paint();
          return m;
        }
        if (m.sid || (m.sid_candidates && m.sid_candidates.length)) {
          state.icao = dep;
          state.type = "DP";
          state.coverage = m.coverage || "faa";
          state.plates = m.sid_candidates || (m.sid ? [m.sid] : []);
          $$(".plate-type-btn").forEach((btn) => {
            btn.classList.toggle("active", btn.getAttribute("data-plate-type") === "DP");
          });
          if (m.sid) showPlate(m.sid);
          else paint();
          if (m.sid) return m;
        }
      } catch (err) {
        console.warn("plates.match sid", err);
      }
    }

    if (dest && star) {
      try {
        const m = await apiGet(
          `/api/plates/${encodeURIComponent(dest)}/match?star=${encodeURIComponent(star)}`
        );
        state.status = m.status || state.status;
        if (m.coverage === "europe" || m.coverage === "external") {
          state.icao = dest;
          state.coverage = m.coverage;
          state.external = m.external;
          state.plates = [];
          state.active = null;
          paint();
          return m;
        }
        if (m.star || (m.star_candidates && m.star_candidates.length)) {
          state.icao = dest;
          state.type = "STAR";
          state.coverage = m.coverage || "faa";
          state.plates = m.star_candidates || (m.star ? [m.star] : []);
          $$(".plate-type-btn").forEach((btn) => {
            btn.classList.toggle("active", btn.getAttribute("data-plate-type") === "STAR");
          });
          if (m.star) showPlate(m.star);
          else paint();
          return m;
        }
      } catch (err) {
        console.warn("plates.match star", err);
      }
    }

    // Fallback: browse dep airport
    if (dep) {
      await loadAirport(dep, { type: sid ? "DP" : "APD", preferName: sid });
    } else if (dest) {
      await loadAirport(dest, { type: star ? "STAR" : "APD", preferName: star });
    } else {
      paint();
    }
    return null;
  }

  function openForProcedure(kind, icao, name) {
    const type = kind === "star" || kind === "STAR" || kind === "arrival" ? "STAR" : "DP";
    openPanel({
      icao: icao,
      type: type,
      preferName: name,
      autoSelect: true,
    });
    $$(".plate-type-btn").forEach((btn) => {
      btn.classList.toggle("active", btn.getAttribute("data-plate-type") === type);
    });
  }

  const PLATE_CATALOG_H_KEY = "navapron_plate_catalog_h";
  const PLATE_CATALOG_MIN = 52;
  const PLATE_CATALOG_DEFAULT = 160;

  function applyPlateCatalogHeight(px, { persist = true } = {}) {
    const panel = $("#plate-panel");
    const catalog = $("#plate-catalog");
    if (!panel || !catalog) return;
    const panelH = panel.clientHeight || 600;
    const max = Math.max(PLATE_CATALOG_MIN + 40, Math.floor(panelH * 0.7));
    const h = Math.max(
      PLATE_CATALOG_MIN,
      Math.min(max, Math.round(Number(px) || PLATE_CATALOG_DEFAULT))
    );
    panel.style.setProperty("--plate-catalog-h", h + "px");
    const handle = $("#plate-v-resizer");
    if (handle) {
      handle.setAttribute("aria-valuenow", String(h));
      handle.setAttribute("aria-valuemin", String(PLATE_CATALOG_MIN));
      handle.setAttribute("aria-valuemax", String(max));
    }
    if (persist) {
      try {
        localStorage.setItem(PLATE_CATALOG_H_KEY, String(h));
      } catch (_) {}
    }
    try {
      resizePlateDrawCanvas();
    } catch (_) {}
    return h;
  }

  function loadPlateCatalogHeight() {
    let raw = null;
    try {
      raw = localStorage.getItem(PLATE_CATALOG_H_KEY);
    } catch (_) {}
    if (raw != null && raw !== "") {
      const n = parseInt(raw, 10);
      if (Number.isFinite(n)) applyPlateCatalogHeight(n, { persist: false });
    }
  }

  function bindPlateCatalogResizer() {
    const handle = $("#plate-v-resizer");
    const catalog = $("#plate-catalog");
    const panel = $("#plate-panel");
    if (!handle || !catalog || !panel) return;
    loadPlateCatalogHeight();

    let dragging = false;
    let startY = 0;
    let startH = 0;
    let lastH = 0;

    const onMove = (ev) => {
      if (!dragging) return;
      const clientY = ev.clientY != null ? ev.clientY : null;
      if (clientY == null) return;
      const dy = clientY - startY; // drag down → taller catalog
      lastH = applyPlateCatalogHeight(startH + dy, { persist: false });
      ev.preventDefault();
    };
    const onUp = (ev) => {
      if (!dragging) return;
      dragging = false;
      document.body.classList.remove("plate-v-resizing");
      document.removeEventListener("pointermove", onMove, true);
      document.removeEventListener("pointerup", onUp, true);
      document.removeEventListener("pointercancel", onUp, true);
      try {
        if (ev && ev.pointerId != null) handle.releasePointerCapture(ev.pointerId);
      } catch (_) {}
      applyPlateCatalogHeight(lastH || catalog.offsetHeight, { persist: true });
    };

    handle.addEventListener("pointerdown", (ev) => {
      if (ev.button != null && ev.button !== 0) return;
      dragging = true;
      startY = ev.clientY;
      startH = catalog.offsetHeight || PLATE_CATALOG_DEFAULT;
      lastH = startH;
      document.body.classList.add("plate-v-resizing");
      document.addEventListener("pointermove", onMove, true);
      document.addEventListener("pointerup", onUp, true);
      document.addEventListener("pointercancel", onUp, true);
      try {
        handle.setPointerCapture(ev.pointerId);
      } catch (_) {}
      ev.preventDefault();
      ev.stopPropagation();
    });

    handle.addEventListener("keydown", (ev) => {
      const cur = catalog.offsetHeight || PLATE_CATALOG_DEFAULT;
      if (ev.key === "ArrowUp") {
        // Up = more PDF = smaller catalog
        applyPlateCatalogHeight(cur - 24);
        ev.preventDefault();
      } else if (ev.key === "ArrowDown") {
        applyPlateCatalogHeight(cur + 24);
        ev.preventDefault();
      } else if (ev.key === "Home") {
        applyPlateCatalogHeight(PLATE_CATALOG_MIN);
        ev.preventDefault();
      }
    });

    $("#btn-plate-expand-pdf")?.addEventListener("click", () => {
      applyPlateCatalogHeight(PLATE_CATALOG_MIN);
      if (typeof window.setStatus === "function") {
        window.setStatus("PDF expanded — drag the bar above it to show more of the list", "ok");
      }
    });
  }

  function bindUi() {
    bindPlateDrawing();
    bindPlateCatalogResizer();
    $("#btn-plate-close")?.addEventListener("click", () => closePanel());
    $("#btn-plates-open-tab")?.addEventListener("click", () => {
      const dep =
        ($("#fp-dep") && $("#fp-dep").value) ||
        (window.state && window.state.airport && window.state.airport.icao) ||
        "";
      openPanel({ icao: String(dep).trim().toUpperCase() || null, type: state.type });
    });
    $$(".plate-type-btn").forEach((btn) => {
      btn.addEventListener("click", () => setType(btn.getAttribute("data-plate-type")));
    });
    $("#btn-plate-dep")?.addEventListener("click", () => {
      const icao =
        ($("#fp-dep") && $("#fp-dep").value) ||
        (window.state && window.state.airport && window.state.airport.icao) ||
        "";
      if (icao) loadAirport(String(icao).trim().toUpperCase(), { type: state.type });
    });
    $("#btn-plate-dest")?.addEventListener("click", () => {
      const icao =
        ($("#fp-dest") && $("#fp-dest").value) ||
        (window.state && window.state.destAirport && window.state.destAirport.icao) ||
        "";
      if (icao) loadAirport(String(icao).trim().toUpperCase(), { type: state.type });
    });
    $("#btn-fp-plates")?.addEventListener("click", () => {
      const dep = ($("#fp-dep") && $("#fp-dep").value) || "";
      const dest = ($("#fp-dest") && $("#fp-dest").value) || "";
      const meta = (window.state && window.state.simbriefMeta) || {};
      matchAndOpen({
        depIcao: dep,
        destIcao: dest,
        sid: meta.sid_ident || (window.state && window.state.activeDeparture && window.state.activeDeparture.sid_name) || "",
        star: meta.star_ident || (window.state && window.state.activeArrival && window.state.activeArrival.star_name) || "",
      });
    });
    $("#btn-dep-plate")?.addEventListener("click", () => {
      const icao =
        (window.state && window.state.airport && window.state.airport.icao) ||
        ($("#fp-dep") && $("#fp-dep").value) ||
        "";
      const name =
        (window.state && window.state.activeDeparture && window.state.activeDeparture.sid_name) ||
        ($("#dep-select") && $("#dep-select").value) ||
        ($("#dep-atc") && $("#dep-atc").value) ||
        "";
      openForProcedure("sid", icao, name);
    });
    $("#btn-arr-plate")?.addEventListener("click", () => {
      const icao =
        (window.state &&
          ((window.state.destAirport && window.state.destAirport.icao) ||
            (window.state.airport && window.state.airport.icao))) ||
        ($("#fp-dest") && $("#fp-dest").value) ||
        "";
      const name =
        (window.state && window.state.activeArrival && window.state.activeArrival.star_name) ||
        ($("#arr-select") && $("#arr-select").value) ||
        ($("#arr-atc") && $("#arr-atc").value) ||
        "";
      openForProcedure("star", icao, name);
    });
  }

  function onSimBriefImported(data) {
    if (!data) return;
    const dep = (data.dep && data.dep.icao) || data.dep_icao || "";
    const dest = (data.dest && data.dest.icao) || data.dest_icao || "";
    const sid = data.sid_ident || (data.procedures && data.procedures.sid && data.procedures.sid.id) || "";
    const star =
      data.star_ident || (data.procedures && data.procedures.star && data.procedures.star.id) || "";
    if (!sid && !star) return;
    // Soft prompt via status area — open panel with match
    try {
      if (typeof window.setStatus === "function") {
        window.setStatus(
          `Charts ready${sid ? " · SID " + sid : ""}${star ? " · STAR " + star : ""} — opening panel`,
          "ok"
        );
      }
    } catch (_) {}
    matchAndOpen({ depIcao: dep, destIcao: dest, sid: sid, star: star });
  }

  function init() {
    if (!$("#plate-panel")) return;
    bindUi();
    apiGet("/api/plates/status")
      .then((st) => {
        state.status = st;
        const cycleEl = $("#plate-cycle");
        if (cycleEl) cycleEl.textContent = cycleBadge(st);
      })
      .catch(() => {});
    refreshChartfoxStatus().catch(() => {});
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  window.NavApronPlates = {
    open: openPanel,
    close: closePanel,
    matchAndOpen: matchAndOpen,
    openForProcedure: openForProcedure,
    onSimBriefImported: onSimBriefImported,
    onAirportLoaded: onAirportLoaded,
    loadAirport: loadAirport,
    refreshNavapron: refreshNavapron,
    isOpen: () => state.open,
  };
})();
