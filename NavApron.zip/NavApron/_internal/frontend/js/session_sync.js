/**
 * PC ↔ iPad live planning sync via /api/session (same NavApron backend).
 * Last-write-wins with monotonic rev. Echoes from self are ignored.
 */
(function (global) {
  const POLL_MS = 1500;
  const PUSH_DEBOUNCE_MS = 400;
  const LS_ENABLED = "navapron_session_sync";
  const SS_CLIENT = "navapron_session_client_id";

  let api = null;
  let clientId = null;
  let appliedRev = 0;
  let lastPushRev = 0;
  let pushTimer = null;
  let pollTimer = null;
  let applying = false;
  let enabled = true;

  function _id() {
    if (clientId) return clientId;
    try {
      clientId = sessionStorage.getItem(SS_CLIENT);
    } catch (_) {}
    if (!clientId) {
      clientId =
        "c-" +
        Math.random().toString(36).slice(2, 10) +
        "-" +
        Date.now().toString(36);
      try {
        sessionStorage.setItem(SS_CLIENT, clientId);
      } catch (_) {}
    }
    return clientId;
  }

  function isEnabled() {
    try {
      const v = localStorage.getItem(LS_ENABLED);
      if (v === "0") return false;
      if (v === "1") return true;
    } catch (_) {}
    return enabled;
  }

  function setEnabled(on) {
    enabled = !!on;
    try {
      localStorage.setItem(LS_ENABLED, enabled ? "1" : "0");
    } catch (_) {}
    const cb = document.getElementById("hub-session-sync");
    if (cb) cb.checked = enabled;
    if (enabled) schedulePush(true);
  }

  function init(handlers) {
    api = handlers || {};
    _id();
    try {
      const v = localStorage.getItem(LS_ENABLED);
      enabled = v !== "0";
    } catch (_) {
      enabled = true;
    }
    const cb = document.getElementById("hub-session-sync");
    if (cb) {
      cb.checked = enabled;
      cb.addEventListener("change", function () {
        setEnabled(!!cb.checked);
      });
    }
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(pull, POLL_MS);
    setTimeout(pull, 800);
  }

  function schedulePush(force) {
    if (!isEnabled() || applying) return;
    if (pushTimer) clearTimeout(pushTimer);
    pushTimer = setTimeout(function () {
      pushTimer = null;
      push();
    }, force ? 50 : PUSH_DEBOUNCE_MS);
  }

  async function push() {
    if (!isEnabled() || applying || !api || typeof api.buildPayload !== "function") {
      return;
    }
    let payload;
    try {
      payload = api.buildPayload();
    } catch (err) {
      console.warn("session buildPayload", err);
      return;
    }
    if (!payload) return;
    try {
      const res = await fetch("/api/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          client_id: _id(),
          rev: appliedRev,
          payload: payload,
        }),
      });
      const data = await res.json().catch(function () {
        return null;
      });
      if (res.ok && data && data.rev != null) {
        lastPushRev = Number(data.rev) || lastPushRev;
        appliedRev = Math.max(appliedRev, lastPushRev);
      }
    } catch (err) {
      console.warn("session push", err);
    }
  }

  async function pull() {
    if (!isEnabled() || applying) return;
    try {
      const res = await fetch("/api/session", { cache: "no-store" });
      const data = await res.json().catch(function () {
        return null;
      });
      if (!data || !data.ok || data.payload == null) return;
      const rev = Number(data.rev) || 0;
      if (rev <= appliedRev) return;
      // Ignore our own publish
      if (data.client_id && data.client_id === _id() && rev <= lastPushRev + 0) {
        appliedRev = Math.max(appliedRev, rev);
        return;
      }
      if (data.client_id && data.client_id === _id()) {
        appliedRev = Math.max(appliedRev, rev);
        return;
      }
      applying = true;
      try {
        if (typeof api.applyPayload === "function") {
          await api.applyPayload(data.payload, {
            client_id: data.client_id,
            rev: rev,
          });
        }
        appliedRev = rev;
      } finally {
        applying = false;
      }
    } catch (err) {
      console.warn("session pull", err);
      applying = false;
    }
  }

  global.NavApronSessionSync = {
    init: init,
    schedulePush: schedulePush,
    setEnabled: setEnabled,
    isEnabled: isEnabled,
    isApplying: function () {
      return applying;
    },
  };
})(window);
