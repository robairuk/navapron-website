/**
 * NavApron OBS overlay — polls live sim + shared session for stream HUDs.
 * Keep this file free of Leaflet / main app deps (Browser Source friendly).
 */
(function () {
  "use strict";

  const params = new URLSearchParams(window.location.search || "");
  const layout = (params.get("layout") || "bar").toLowerCase() === "card" ? "card" : "bar";
  const scale = Math.max(0.75, Math.min(2, parseFloat(params.get("scale") || "1") || 1));

  const root = document.getElementById("obs-root");
  if (root) {
    root.classList.remove("layout-bar", "layout-card");
    root.classList.add(layout === "card" ? "layout-card" : "layout-bar");
    root.style.setProperty("--obs-scale", String(scale));
  }

  const $ = (id) => document.getElementById(id);

  function haversineM(lat1, lon1, lat2, lon2) {
    const R = 6371000;
    const toR = Math.PI / 180;
    const dLat = (lat2 - lat1) * toR;
    const dLon = (lon2 - lon1) * toR;
    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos(lat1 * toR) * Math.cos(lat2 * toR) * Math.sin(dLon / 2) ** 2;
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
  }

  function fmtNm(m) {
    const nm = Math.max(0, Number(m) || 0) / 1852;
    if (nm >= 100) return nm.toFixed(0) + " NM";
    if (nm >= 10) return nm.toFixed(1) + " NM";
    if (nm >= 1) return nm.toFixed(1) + " NM";
    return nm.toFixed(2) + " NM";
  }

  function fmtAlt(ft, onGround) {
    if (ft == null || !Number.isFinite(Number(ft))) return "—";
    const n = Math.round(Number(ft));
    if (onGround || n < 10000) return n.toLocaleString() + " ft";
    return "FL" + String(Math.round(n / 100)).padStart(3, "0");
  }

  function fmtGs(kt) {
    if (kt == null || !Number.isFinite(Number(kt))) return "—";
    return Math.round(Number(kt)) + " kt";
  }

  function fmtHdg(deg) {
    if (deg == null || !Number.isFinite(Number(deg))) return "—";
    let d = Math.round(Number(deg)) % 360;
    if (d < 0) d += 360;
    return String(d).padStart(3, "0") + "°";
  }

  function setText(id, text) {
    const el = $(id);
    if (el) el.textContent = text == null || text === "" ? "—" : String(text);
  }

  /** Along-track next fix + remaining to dest from OFP/plan legs. */
  function progressAlongLegs(legs, lat, lon) {
    if (!legs || legs.length < 2 || lat == null || lon == null) return null;
    const pts = legs.filter((l) => l && l.lat != null && l.lon != null);
    if (pts.length < 2) return null;

    let bestI = 0;
    let bestD = Infinity;
    for (let i = 0; i < pts.length - 1; i++) {
      const a = pts[i];
      const b = pts[i + 1];
      // Nearest segment by mid-point + endpoints (lightweight)
      const midLat = (Number(a.lat) + Number(b.lat)) / 2;
      const midLon = (Number(a.lon) + Number(b.lon)) / 2;
      const d = Math.min(
        haversineM(lat, lon, Number(a.lat), Number(a.lon)),
        haversineM(lat, lon, Number(b.lat), Number(b.lon)),
        haversineM(lat, lon, midLat, midLon)
      );
      if (d < bestD) {
        bestD = d;
        bestI = i;
      }
    }

    // Prefer the upcoming fix (segment end), skip if we're essentially on it
    let nextIdx = bestI + 1;
    while (nextIdx < pts.length - 1) {
      const n = pts[nextIdx];
      const dNext = haversineM(lat, lon, Number(n.lat), Number(n.lon));
      if (dNext > 900) break;
      nextIdx += 1;
    }
    const next = pts[Math.min(nextIdx, pts.length - 1)];
    let toNext = haversineM(lat, lon, Number(next.lat), Number(next.lon));
    let toDest = 0;
    // Remaining along polyline from nextIdx-ish
    let from = { lat, lon };
    for (let i = nextIdx; i < pts.length; i++) {
      toDest += haversineM(
        Number(from.lat),
        Number(from.lon),
        Number(pts[i].lat),
        Number(pts[i].lon)
      );
      from = pts[i];
    }
    // If best segment start is ahead of aircraft along route, include current→next
    if (nextIdx === bestI + 1) {
      toNext = haversineM(lat, lon, Number(next.lat), Number(next.lon));
    }

    return {
      nextLabel: next.ident || next.label || "WP",
      toNextM: toNext,
      toDestM: toDest,
      kind: String(next.kind || "").toLowerCase(),
    };
  }

  function phaseLabel(sim, session, prog) {
    const step = session && session.journeyStep;
    const onGround = sim && sim.on_ground === true;
    const alt = sim && sim.altitude_ft != null ? Number(sim.altitude_ft) : null;
    const gs = sim && sim.gs_kt != null ? Number(sim.gs_kt) : null;

    if (step === "taxi-out") return "Taxi out";
    if (step === "taxi-in") return "Taxi in";
    if (onGround) {
      if (gs != null && gs > 30) return "Rollout";
      return "Taxi";
    }
    if (prog && prog.toDestM != null && prog.toDestM < 40 * 1852) return "Arrival";
    if (alt != null && alt < 12000 && prog && prog.toDestM != null && prog.toDestM > 80 * 1852) {
      return "Departure";
    }
    if (alt != null && alt >= 18000) return "Cruise";
    if (alt != null && alt < 18000) return "Climb/desc";
    return "Airborne";
  }

  let _session = null;
  let _sessionAt = 0;

  async function fetchJson(url) {
    const res = await fetch(url, { cache: "no-store" });
    if (!res.ok) throw new Error("HTTP " + res.status);
    return res.json();
  }

  async function refreshSession(force) {
    const now = Date.now();
    if (!force && _session && now - _sessionAt < 2000) return _session;
    try {
      const data = await fetchJson("/api/overlay/state");
      _session = data || null;
      _sessionAt = now;
      return _session;
    } catch (_) {
      // Fallback: older builds without /api/overlay/state
      try {
        const [sim, sess] = await Promise.all([
          fetchJson("/api/sim/position").catch(() => null),
          fetchJson("/api/session").catch(() => null),
        ]);
        _session = {
          ok: true,
          sim: sim || {},
          payload: (sess && sess.payload) || null,
        };
        _sessionAt = now;
        return _session;
      } catch (err2) {
        return null;
      }
    }
  }

  function render(bundle) {
    const status = $("obs-status");
    if (!bundle) {
      if (root) {
        root.classList.add("is-offline");
        root.classList.remove("is-live");
      }
      if (status) status.textContent = "NavApron not reachable";
      return;
    }

    const sim = bundle.sim || {};
    const payload = bundle.payload || {};
    const fp = payload.flightPlan || null;
    const ofp = payload.ofpSummary || bundle.ofp || null;
    const connected = !!sim.connected && sim.lat != null;

    const dep =
      (fp && fp.dep && fp.dep.icao) ||
      payload.depIcao ||
      (payload.fpFields && payload.fpFields.dep) ||
      "";
    const dest =
      (fp && fp.dest && fp.dest.icao) ||
      payload.destIcao ||
      (payload.fpFields && payload.fpFields.dest) ||
      "";
    const ac = (payload.aircraft || ofp && ofp.aircraft || "").toString().trim();

    let route = "—— → ——";
    if (dep || dest) {
      route = (dep || "????") + " → " + (dest || "????");
      if (ac) route += " · " + ac;
    }
    setText("obs-route", route);

    const onGround = sim.on_ground === true;
    setText("obs-alt", connected ? fmtAlt(sim.altitude_ft, onGround) : "—");
    setText("obs-gs", connected ? fmtGs(sim.gs_kt) : "—");
    setText(
      "obs-hdg",
      connected ? fmtHdg(sim.heading_deg != null ? sim.heading_deg : sim.heading) : "—"
    );

    const legs = (fp && fp.legs) || null;
    const prog =
      connected && legs
        ? progressAlongLegs(legs, Number(sim.lat), Number(sim.lon))
        : null;

    setText("obs-phase", phaseLabel(sim, payload, prog));

    if (prog && prog.nextLabel) {
      setText(
        "obs-next",
        prog.nextLabel + (prog.toNextM != null ? " " + fmtNm(prog.toNextM) : "")
      );
    } else {
      setText("obs-next", connected ? "—" : "—");
    }

    if (prog && prog.toDestM != null && prog.toDestM > 500) {
      setText("obs-todest", fmtNm(prog.toDestM));
    } else if (fp && fp.distance_nm != null && !connected) {
      setText("obs-todest", Number(fp.distance_nm).toFixed(0) + " NM");
    } else {
      setText("obs-todest", "—");
    }

    setText("obs-cruise", (ofp && (ofp.cruise_alt || ofp.cruise)) || "—");
    setText("obs-fuel", (ofp && ofp.fuel) || "—");
    setText("obs-ete", (ofp && (ofp.flight_time || ofp.ete)) || "—");

    if (root) {
      root.classList.toggle("is-live", connected);
      root.classList.toggle("is-offline", !connected);
    }
    if (status) {
      if (!connected) {
        status.textContent = sim.connected
          ? "Sim connected — waiting for position"
          : "Connect MSFS in NavApron for live data";
      } else if (!dep && !dest) {
        status.textContent = "Live · load a flight plan for route / next WP";
      } else {
        status.textContent = "Live";
      }
    }
  }

  async function tick() {
    const bundle = await refreshSession(false);
    render(bundle);
  }

  tick();
  setInterval(tick, 500);
})();
